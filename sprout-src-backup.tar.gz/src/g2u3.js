/* ===================== GRADE 2 · UNIT 3 · OUR EARTH ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:2,id:"g2_earth",num:3,emoji:"🌍🏔️🌊",title:"Our Earth",short:"long i, plural nouns, land and water",badge:"🌍 Earth Explorer",
stories:[
/* 1 STORY: PROBLEM AND HAPPY ENDING */
{title:"The Kite on the Hill",e:"🪁",kind:"Story",pages:[
 {pic:"🪁⛰️",text:"Ravi and his grandpa walk up a big green hill. Ravi has a new red kite. The wind is strong today. Grandpa holds the kite up high. Ravi runs fast and lets out the string. The kite flies up into the blue sky. It goes higher and higher! Ravi smiles and holds the string tight.",
  qs:[f("What does Ravi have?","A red kite 🪁",["A blue bike 🚲","A big ball ⚽"],"Ravi has a new red kite."),
      f("Where do Ravi and Grandpa go?","Up a green hill ⛰️",["To the beach 🏖️","Into a cave 🦇"],"They walk up a big green hill.")]},
 {pic:"💨😟🌲",text:"Then a big gust of wind comes. Snap! The string breaks. The kite flies away over the hill. Ravi and Grandpa run after it. They see it fall down by the river. It is stuck high in a pine tree. Ravi is sad. \"My new kite!\" he cries. \"We cannot climb that tree,\" says Grandpa.",
  qs:[f("Where is the kite stuck?","In a pine tree 🌲",["In the river 🏞️","On a rock 🪨"],"It is stuck high in a pine tree."),
      p("What will Ravi and Grandpa do next?","Ask someone for help 🙋",["Climb the tall tree 🧗","Forget the kite 🏠"],"Grandpa says they cannot climb the tree, so they need help.")]},
 {pic:"👩🏽🌲",text:"A park ranger walks by the river. Her name is Ms. Diaz. \"Can you help us?\" asks Ravi. \"Our kite is stuck in that pine tree.\" Ms. Diaz looks up at the tree. \"I have a long pole in my truck,\" she says. She gets the pole. She lifts it up high. Gently, she pushes the kite off the branch.",
  qs:[f("Who helps Ravi?","Ms. Diaz, a park ranger",["A firefighter 🚒","A big bird 🐦"],"A park ranger walks by. Her name is Ms. Diaz."),
      f("What does Ms. Diaz use?","A long pole",["A ladder 🪜","A rope 🪢"],"\"I have a long pole in my truck.\"")]},
 {pic:"🪁😊🗑️",text:"The kite floats down. Ravi catches it! \"Thank you, Ms. Diaz!\" he says. Then Ravi sees some litter by the river. There is a can and a plastic bag. \"Litter can hurt fish and birds,\" says Ms. Diaz. Ravi and Grandpa pick it up. They put it in the bin. Now the river is clean, and Ravi is happy.",
  qs:[f("What does Ravi see by the river?","Some litter 🥫",["A big fish 🐟","His lost hat 🧢"],"Ravi sees some litter by the river."),
      t("Why do they pick up the litter?","It can hurt fish and birds",["They want to keep it","It is a toy"],"Ms. Diaz says litter can hurt fish and birds.")]}
],turn:{q:"Tell about a time you went to a hill, a park or a beach. Write one or two sentences.",model:"I went to the beach with my mom. We made a sandcastle by the water."}},
/* 2 NON-FICTION */
{title:"Land and Water on Earth",e:"🌍",kind:"Non-fiction",pages:[
 {pic:"🌍💧",text:"Earth is the planet we live on. From space, Earth looks blue and green. The blue parts are water. The green and brown parts are land. Most of Earth is covered by water. People, plants and animals need both land and water. A globe is a round model of Earth. You can spin it!",
  qs:[f("What are the blue parts on a globe?","Water 💧",["Land ⛰️","Snow ❄️"],"The blue parts are water."),
      f("Is most of Earth land or water?","Water 🌊",["Land ⛰️","Sand 🏜️"],"Most of Earth is covered by water.")]},
 {pic:"🌊🗺️",text:"The biggest areas of water are called oceans. There are five oceans on Earth. The Pacific Ocean is the biggest one. Ocean water is salty, so we cannot drink it. The biggest areas of land are called continents. There are seven continents. Asia is the biggest continent. Canada is on the continent of North America.",
  qs:[f("How many continents are there?","Seven 7️⃣",["Five 5️⃣","Ten 🔟"],"There are seven continents."),
      f("Why can't we drink ocean water?","It is salty 🧂",["It is too cold 🥶","It is green 🟢"],"Ocean water is salty, so we cannot drink it.")]},
 {pic:"🏔️🏜️",text:"Land has many shapes. A mountain is very high land. Mount Everest is the highest mountain on Earth. A hill is like a small mountain. A valley is low land between hills or mountains. A desert is dry land with very little rain. Some deserts are hot and sandy. Some deserts are cold and icy!",
  qs:[f("What is the highest mountain on Earth?","Mount Everest 🏔️",["A small hill ⛰️","The Sahara 🏜️"],"Mount Everest is the highest mountain on Earth."),
      p("The next page is about water. What will it tell about?","Rivers and lakes 🏞️",["Cars and trucks 🚗","Pizza and cake 🍕"],"Rivers and lakes are kinds of water.")]},
 {pic:"🏞️🏝️",text:"Water has many shapes too. A river is water that flows a long way. Most rivers flow into a lake or the sea. A stream is a small river. A lake is water with land all around it. An island is land with water all around it! Canada has more lakes than any other country.",
  qs:[f("What is a stream?","A small river 💧",["A big mountain 🏔️","A hot desert 🏜️"],"A stream is a small river."),
      t("How is a lake different from an island?","A lake is water. An island is land.",["They are the same","Both are deserts"],"A lake has land around it. An island has water around it.")]}
],turn:{q:"Name one kind of land or water. Write one or two sentences about it.",model:"A lake is water with land all around it. I like to swim in the lake."}},
/* 3 PATTERNED TEXT */
{title:"Can You See It Too?",e:"👀",kind:"Pattern book",pages:[
 {pic:"⛰️🪁",text:"Look up high! I see a hill. It is a big green hill. A white kite flies on the hill. The wind blows the kite. It flies so high in the sky. Look up high! Can you see it too? Yes, I can see the kite. It is up on the hill.",
  qs:[t("Which words come again and again?","Look up high!",["Good night!","Go to sleep!"],"Look up high! is said again. That is the pattern."),
      f("What flies on the hill?","A white kite 🪁",["A red bird 🐦","A bee 🐝"],"A white kite flies on the hill.")]},
 {pic:"🌋",text:"Look over there! I see a volcano. It is a tall mountain with a hole on top. Hot, melted rock comes out of the top. It is called lava. Look over there! Can you see it too? Yes, I see it. But I will not go near the lava! It is much too hot.",
  qs:[f("What comes out of the volcano?","Hot lava 🔥",["Cold snow ❄️","Fresh water 💧"],"Hot, melted rock comes out. It is called lava."),
      t("Why will the child not go near the lava?","It is much too hot",["It is bedtime","The volcano is tiny"],"The lava is much too hot.")]},
 {pic:"🏝️🌴🐦",text:"Look out at the sea! I see an island. It is a small island with a pine tree. No, wait! It is a palm tree. Water is all around the island. Five white birds fly by. Look out at the sea! Can you see it too? Yes, I see the island and the birds.",
  qs:[f("What kind of tree is on the island?","A palm tree 🌴",["A pine tree 🌲","An apple tree 🍎"],"No, wait! It is a palm tree."),
      p("The next page is at night. What might the child see?","Stars in the sky ✨",["The hot sun ☀️","A sandcastle 🏰"],"At night, we can see the moon and the stars.")]},
 {pic:"🌙✨",text:"Look up at night! I see the moon. It is big and bright. I see the stars. They shine with a white light. The sky is dark, and the night is quiet. Look up at night! Can you see them too? Yes! Good night, moon. Good night, stars. Good night, Earth!",
  qs:[f("What does the child see at night?","The moon and the stars 🌙",["The sun ☀️","A volcano 🌋"],"I see the moon. I see the stars."),
      t("Which word rhymes with night?","bright",["moon","dark"],"Night and bright both end in -ight.")]}
],turn:{q:"Write your own pattern sentence: Look up high! I see a ___.",model:"Look up high! I see a white bird in the sky."}},
/* 4 HOW-TO */
{title:"How to Make a Map of Your Room",e:"🗺️",kind:"How-to text",pages:[
 {pic:"🗺️✏️📏",text:"A map is a picture of a place from above. It shows where things are. You can make a map of your room! You need a big piece of paper. You need a pencil and some crayons. You also need a ruler for straight lines. Get them all first. Let us start!",
  qs:[f("What is a map?","A picture of a place from above",["A song about a place","A box of toys"],"A map is a picture of a place from above."),
      p("What do you think the first steps will be?","Look at the room and draw its shape",["Colour the whole map red","Go to bed"],"You must see the room before you can draw it.")]},
 {pic:"1️⃣2️⃣🚪",text:"First, stand at the door and look around. What is in your room? Next, draw the shape of your room on the paper. Use the ruler to make the walls. Then, draw the door. Draw a gap in one wall for it. Is there a window? Draw it on a wall too.",
  qs:[f("What do you do first?","Stand at the door and look",["Colour the bed","Draw a key"],"First, stand at the door and look around."),
      f("What do you use to make the walls?","A ruler 📏",["A crayon 🖍️","Your foot 🦶"],"Use the ruler to make the walls.")]},
 {pic:"🛏️🐦",text:"Now draw the things in your room. Look down at them, like a bird in the sky. From above, your bed looks like a rectangle. A round rug looks like a circle. Draw each thing in the right place. Is your desk by the window? Then draw it by the window too.",
  qs:[f("From above, what does a bed look like?","A rectangle ▭",["A circle ⚪","A star ⭐"],"From above, your bed looks like a rectangle."),
      t("Why do you look down like a bird?","A map shows things from above",["Birds like beds","It is fun to fly"],"A map is a picture from above.")]},
 {pic:"🔑🧭",text:"Last, make a map key. A key tells what the colours and shapes mean. Colour your bed blue. In the key, write: blue = bed. You can add a compass rose too. It shows north, south, east and west. Now your map is done! Can a friend use it to find your desk?",
  qs:[f("What does a map key tell?","What the colours and shapes mean",["What time it is","How to bake a cake"],"A key tells what the colours and shapes mean."),
      f("What does a compass rose show?","North, south, east and west 🧭",["Big and small","Hot and cold"],"It shows north, south, east and west.")]}
],turn:{q:"Write one step for making a map. Start with First, Next, Then or Last.",model:"First, I draw the walls of my room."}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Kids Around Our Earth",e:"🌏",kind:"Children around the world",pages:[
 {pic:"🇳🇵🏔️",text:"This is Tenzin. He lives in Nepal, in the high Himalaya mountains. The mountains are tall and white with snow. Tenzin's village is on a steep hill. He walks up and down paths every day. His family has yaks. Yaks are big, hairy animals. They can carry heavy things up the mountains.",
  qs:[f("Where does Tenzin live?","In the mountains of Nepal 🏔️",["On an island 🏝️","In a desert 🏜️"],"He lives in Nepal, in the high Himalaya mountains."),
      f("What can yaks do?","Carry heavy things",["Swim in the sea","Fly in the sky"],"They can carry heavy things up the mountains.")]},
 {pic:"🇲🇦🐪🏜️",text:"This is Amina. She lives in Morocco, near the Sahara Desert. The Sahara is the biggest hot desert on Earth. In the day, the sun is very hot. At night, the desert can get cold! Amina wears long, loose clothes. They keep the hot sun off her skin. Camels walk on the sand dunes.",
  qs:[f("What can the desert be like at night?","Cold 🥶",["Very hot 🔥","Rainy 🌧️"],"At night, the desert can get cold!"),
      t("Why does Amina wear long clothes?","To keep the sun off her skin",["To look like a camel","Because it rains"],"They keep the hot sun off her skin.")]},
 {pic:"🇧🇷🛶🐒",text:"This is Lucas. He lives in Brazil, by the Amazon River. The Amazon is a very big river. It flows through a huge rainforest. It rains a lot, so the trees are tall and green. Lucas goes to school in a small boat. He sees birds and monkeys in the trees. Some fish swim under the boat.",
  qs:[f("How does Lucas go to school?","In a small boat 🛶",["On a yak","On a camel 🐪"],"Lucas goes to school in a small boat."),
      p("The next child lives on an island. What will be all around her home?","Water 🌊",["Sand dunes 🏜️","Snowy mountains 🏔️"],"An island has water all around it.")]},
 {pic:"🇲🇻🏝️🐠",text:"This is Aisha. She lives in the Maldives. The Maldives is a country made of many small islands. Blue ocean water is all around them. Aisha can see the sea from her home. She swims and looks at fish and coral. Tenzin, Amina, Lucas and Aisha live in different places. They all live on our Earth!",
  qs:[f("What is the Maldives made of?","Many small islands 🏝️",["One big desert 🏜️","Tall mountains 🏔️"],"The Maldives is a country made of many small islands."),
      t("How are the four children the same?","They all live on Earth 🌍",["They all live in a desert","They all have yaks"],"They live in different places, but they all live on our Earth.")]}
],turn:{q:"Which child would you like to visit? Write one or two sentences.",model:"I would like to visit Lucas. I want to ride in his boat on the river."}},
/* 6 REAL-WORLD TEXT */
{title:"Real-world reading: Pine Lake Park",e:"🌲",kind:"Real-world text",pages:[
 {pic:"🪧🌲",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🌲 WELCOME TO PINE LAKE PARK 🌲</b><br><span style=\"font-size:22px;line-height:1.8\">🕗 Open 8 a.m. to 9 p.m.<br>🚶 Stay on the trail.<br>🚯 Take your litter home.<br>🔥 No fires.<br>🐕 Keep dogs on a leash.<br>🦆 Do not feed the ducks.</span></div>",
  qs:[f("When does the park close?","9 p.m. 🌙",["8 a.m. 🌅","Noon 🕛"],"🕗 Open 8 a.m. to 9 p.m."),
      f("What should you do with your litter?","Take it home 🎒",["Leave it on the trail","Give it to the ducks"],"🚯 Take your litter home.")]},
 {pic:"🗺️🔑",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🗺️ TRAIL MAP KEY</b><br><span style=\"font-size:22px;line-height:1.8\">🥾 Hiking trail<br>🏊 Swimming beach<br>🛶 Canoe dock<br>🌉 Bridge over the river<br>⛺ Campsite<br>🚻 Washrooms<br>🔭 Lookout on the hill</span></div>",
  qs:[f("What does ⛺ mean on the map?","Campsite",["Bridge","Washrooms"],"⛺ Campsite"),
      f("Which symbol shows the bridge?","🌉",["🛶","🔭"],"🌉 Bridge over the river")]},
 {pic:"♻️🗑️",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>♻️ WHICH BIN?</b><br><span style=\"font-size:22px;line-height:1.8\">🔵 BLUE BIN: cans 🥫, bottles 🧴, paper 📄<br>🟢 GREEN BIN: food scraps 🍌🍎<br>⚫ BLACK BIN: other garbage 🗑️</span></div>",
  qs:[f("Where does a banana peel go?","Green bin 🟢",["Blue bin 🔵","Black bin ⚫"],"🟢 GREEN BIN: food scraps"),
      p("Ravi has an empty can. Which bin will he use?","Blue bin 🔵",["Green bin 🟢","Black bin ⚫"],"🔵 BLUE BIN: cans, bottles, paper")]},
 {pic:"📅🌍",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🌍 EARTH DAY AT THE PARK · April 22</b><br><span style=\"font-size:22px;line-height:1.8\">🧤 9:00 Beach clean-up<br>🌱 10:30 Plant trees<br>🥪 12:00 Picnic lunch<br>🦋 1:30 Nature walk<br>🎨 3:00 Draw the lake</span></div>",
  qs:[f("What happens at 10:30?","Plant trees 🌱",["Picnic lunch 🥪","Nature walk 🦋"],"🌱 10:30 Plant trees"),
      f("What comes after the picnic lunch?","Nature walk 🦋",["Beach clean-up 🧤","Plant trees 🌱"],"🥪 12:00 Picnic lunch, then 🦋 1:30 Nature walk.")]}
],turn:{q:"Write one rule for a park.",model:"Please take your litter home."}}
],
poems:[
 {title:"Boats Sail on the Rivers (by Christina Rossetti, from Sing-Song, 1872)",
  lines:["Boats sail on the rivers,","And ships sail on the seas;","But clouds that sail across the sky","Are prettier far than these.","","There are bridges on the rivers,","As pretty as you please;","But the bow that bridges heaven,","And overtops the trees,","And builds a road from earth to sky,","Is prettier far than these."],
  qs:[f("What sails across the sky?","Clouds ☁️",["Boats ⛵","Ships 🚢"],"\"But clouds that sail across the sky.\""),
      t("What is \"the bow that bridges heaven\"?","A rainbow 🌈",["A boat ⛵","A tree 🌳"],"A rainbow is a coloured bow that goes across the sky like a bridge."),
      f("Which word rhymes with seas?","these",["sky","rivers"],"Seas and these end with the same sound.")]},
 {title:"My Big Round Earth",
  lines:["I climb the hill, I see the sky,","I watch the birds go flying by.","The river runs down to the sea,","The tall pine trees wave hi to me.","The night is dark, the stars are bright,","Our Earth is home, so treat it right!"],
  qs:[f("Where does the river run?","Down to the sea 🌊",["Up the hill ⛰️","Into the sky ☁️"],"\"The river runs down to the sea.\""),
      f("Which word rhymes with sky?","by",["sea","hill"],"Sky and by both end with the long i sound."),
      t("What does the poem ask us to do?","Take care of Earth 🌍",["Drop litter 🚯","Stay inside all day"],"\"Our Earth is home, so treat it right!\"")]}
],
words:[
 {w:"mountain",e:"🏔️",m:"very tall land that goes up high",ex:"The mountain has snow on top.",fill:"We climbed up the tall ___."},
 {w:"hill",e:"⛰️",m:"high land, smaller than a mountain",ex:"We ran down the grassy hill.",fill:"Ravi flew his kite on the ___."},
 {w:"valley",e:"🌄",m:"low land between hills or mountains",ex:"A river runs through the valley.",fill:"The farm is down in the ___ between two hills."},
 {w:"cliff",e:"🧗",m:"a high, steep wall of rock",ex:"Birds make nests on the cliff.",fill:"Do not stand near the edge of the ___."},
 {w:"cave",e:"🦇",m:"a big, dark hole in a hill or rock",ex:"Bats sleep in the dark cave.",fill:"We used a flashlight in the dark ___."},
 {w:"volcano",e:"🌋",m:"a mountain that can push out hot lava",ex:"Hot lava came out of the volcano.",fill:"Smoke rose from the top of the ___."},
 {w:"desert",e:"🏜️",m:"dry land that gets very little rain",ex:"Camels can walk far in the desert.",fill:"It hardly ever rains in the ___."},
 {w:"rock",e:"🪨",m:"a hard piece of stone",ex:"I sat on a big rock.",fill:"The lizard sat on a warm ___."},
 {w:"forest",e:"🌲",m:"a big place with lots of trees",ex:"Deer live in the forest.",fill:"We walked under the tall trees in the ___."},
 {w:"jungle",e:"🐒",m:"a hot, wet forest with many plants",ex:"Monkeys swing in the jungle.",fill:"Parrots and monkeys live in the ___."},
 {w:"river",e:"🏞️",m:"water that flows a long way across land",ex:"We saw fish in the river.",fill:"The boat floated down the ___."},
 {w:"lake",e:"🛶",m:"water with land all around it",ex:"We paddled a canoe on the lake.",fill:"We swim in the ___ in summer."},
 {w:"ocean",e:"🐋",m:"a huge area of salty water",ex:"Whales swim in the ocean.",fill:"The Pacific is the biggest ___."},
 {w:"wave",e:"🌊",m:"water that rises up and moves in the sea",ex:"A big wave splashed on the sand.",fill:"The surfer rode a big ___."},
 {w:"waterfall",e:"💦",m:"water that falls down over high rocks",ex:"The waterfall is loud and white.",fill:"Water drops down the ___ into the pool below."},
 {w:"stream",e:"💧",m:"a small, narrow river",ex:"We jumped over the little stream.",fill:"A small ___ runs past our camp."},
 {w:"island",e:"🏝️",m:"land with water all around it",ex:"We took a boat to the island.",fill:"Water is all around the ___."},
 {w:"beach",e:"🏖️",m:"sandy land next to the sea or a lake",ex:"We built a sandcastle on the beach.",fill:"We put on sun hats at the ___."},
 {w:"iceberg",e:"🧊",m:"a huge piece of ice floating in the sea",ex:"A white iceberg floats in the cold sea.",fill:"A big ___ floats in the Arctic Ocean."},
 {w:"swamp",e:"🐊",m:"wet, muddy land with lots of plants",ex:"Frogs croak in the swamp.",fill:"Alligators live in the muddy ___."},
 {w:"globe",e:"🌍",m:"a round model of Earth",ex:"I spin the globe and find Canada.",fill:"Spin the ___ and find the oceans."},
 {w:"map",e:"🗺️",m:"a picture that shows where places are",ex:"The map shows the way to the park.",fill:"Look at the ___ to find the lake."},
 {w:"compass",e:"🧭",m:"a tool that shows which way is north",ex:"The compass points north.",fill:"Use a ___ to find north."},
 {w:"continent",e:"🌎",m:"one of the seven biggest areas of land",ex:"Africa is a big continent.",fill:"Asia is the biggest ___."},
 {w:"country",e:"🇨🇦",m:"a land with its own name and flag",ex:"Canada is a big country.",fill:"Brazil is a ___ in South America."},
 {w:"north",e:"⬆️",m:"the way to the top of a map",ex:"Snowy places are far in the north.",fill:"On a map, ___ is at the top."},
 {w:"south",e:"⬇️",m:"the way to the bottom of a map",ex:"Some birds fly south in the fall.",fill:"On a map, ___ is at the bottom."},
 {w:"planet",e:"🪐",m:"a big, round world that goes around the sun",ex:"Earth is the planet we live on.",fill:"Mars is a red ___."},
 {w:"city",e:"🏙️",m:"a big town with many people and buildings",ex:"Toronto is a big city.",fill:"Tall buildings stand in the ___."},
 {w:"village",e:"🛖",m:"a small group of homes, away from a city",ex:"Tenzin lives in a mountain village.",fill:"Only a few families live in our small ___."},
 {w:"litter",e:"🚯",m:"trash left on the ground",ex:"We picked up litter at the park.",fill:"Do not drop ___ on the ground."},
 {w:"bin",e:"🗑️",m:"a box or can to put trash in",ex:"Put the paper in the blue bin.",fill:"Throw your trash in the ___."},
 {w:"recycle",e:"♻️",m:"to make old things into new things",ex:"We recycle cans and paper.",fill:"We ___ old bottles to make new ones."},
 {w:"reuse",e:"🔁",m:"to use something again",ex:"I reuse my lunch bag every day.",fill:"Do not throw the box away. You can ___ it!"},
 {w:"plant",e:"🌱",m:"to put a seed or a tree in the ground",ex:"We plant a tree on Earth Day.",fill:"Let us ___ seeds in the garden."},
 {w:"air",e:"🌬️",m:"what we breathe; it is all around us",ex:"Trees help keep the air clean.",fill:"We need clean ___ to breathe."},
 {w:"nature",e:"🍃",m:"plants, animals, land and water not made by people",ex:"We go for a walk in nature.",fill:"Trees, rivers and birds are part of ___."},
 {w:"protect",e:"🛡️",m:"to keep something safe from harm",ex:"We protect the ducks in the park.",fill:"A helmet will ___ your head."},
 {w:"Earth",e:"🌏",m:"the planet we all live on",ex:"Earth has land and water.",fill:"We live on the planet ___."},
 {w:"tap",e:"🚰",m:"where water comes out at a sink",ex:"Turn off the tap to save water.",fill:"Turn off the ___ when you brush your teeth."}
],
spelling:[],
facts:[
 {e:"🌊",c:"Most of Earth is covered by water.",t:true,x:"True! Oceans cover most of our planet."},
 {e:"🌍",c:"There are seven continents on Earth.",t:true,x:"True! Asia, Africa, North America, South America, Antarctica, Europe and Australia."},
 {e:"🐋",c:"The Atlantic is the biggest ocean.",t:false,x:"Not true! The Pacific Ocean is the biggest."},
 {e:"🧂",c:"Ocean water is salty.",t:true,x:"True! That is why we cannot drink it."},
 {e:"🏜️",c:"All deserts are hot.",t:false,x:"Not true! Antarctica is a cold desert. It gets very little rain or snow."},
 {e:"🏔️",c:"Mount Everest is the highest mountain on Earth.",t:true,x:"True! It is in Asia, between Nepal and China."},
 {e:"🏞️",c:"Rivers flow uphill.",t:false,x:"Not true! Water flows downhill, to lower land."},
 {e:"🏝️",c:"An island has water all around it.",t:true,x:"True! Some islands are tiny, and some are very big."},
 {e:"🇨🇦",c:"Canada has more lakes than any other country.",t:true,x:"True! Canada has a huge number of lakes."},
 {e:"🌋",c:"Volcanoes are only found in hot places.",t:false,x:"Not true! Iceland is a cold country, and it has many volcanoes."},
 {e:"♻️",c:"Old plastic bottles can be recycled to make new things.",t:true,x:"True! They can be made into new bottles, and even warm jackets."},
 {e:"🌐",c:"A globe is flat, like a piece of paper.",t:false,x:"Not true! A globe is round, just like Earth."}
],
writing:[
 {e:"⛰️",t:"Land and water I have seen",level:"Step 1 · 3 sentences",
  prompt:"Write 3 sentences about land or water you have seen, like a hill, a lake or a beach. What did you see there?",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Hh]ills?|[Mm]ountains?|[Ll]akes?|[Rr]ivers?|[Bb]each(es)?|[Oo]ceans?|[Ss]eas?|[Ff]orests?|[Ss]treams?|[Ii]slands?|[Vv]alleys?|[Dd]eserts?|[Cc]aves?|[Ww]aterfalls?|[Pp]onds?)\\b","I named land or water"]],
  starters:["I went to a ","I saw ","It was "],
  model:"I went to a big lake with my family. I saw ducks on the water. It was a sunny day."},
 {e:"♻️",t:"How I help the Earth",level:"Step 2 · 4 sentences",
  prompt:"Write 4 sentences about how you help the Earth. Do you recycle? Do you pick up litter or turn off the tap?",
  minS:4,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Rr]ecycl|[Ll]itter|[Bb]ins?\\b|[Pp]lant|[Tt]aps?\\b|[Rr]euse|[Cc]lean|[Tt]rash)","I told a way to help"]],
  starters:["I help the Earth ","I put ","I turn off ","My family and I "],
  model:"I help the Earth every day. I put cans and paper in the blue bin. I turn off the tap when I brush my teeth. My dad and I plant trees in the spring."},
 {e:"🏞️",t:"Describe a place",level:"Step 3 · 5 sentences with describing words",
  prompt:"Choose a place on Earth, like a beach, a forest or a mountain. Write 5 sentences about it. Use describing words, like tall, blue, cold or sandy. What can you see, hear and feel there?",
  minS:5,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Hh]ills?|[Mm]ountains?|[Ll]akes?|[Rr]ivers?|[Bb]each(es)?|[Oo]ceans?|[Ss]eas?|[Ff]orests?|[Ss]treams?|[Ii]slands?|[Vv]alleys?|[Dd]eserts?|[Cc]aves?|[Ww]aterfalls?|[Pp]onds?|[Jj]ungles?|[Pp]arks?|[Ss]wamps?)\\b","I named a place"],["(\\b(big|small|little|tall|high|low|long|wide|deep|blue|green|white|brown|red|yellow|golden|hot|cold|warm|cool|wet|dry|sandy|rocky|snowy|icy|sunny|quiet|loud|soft|hard|bright|dark|calm|huge|tiny|pretty|beautiful|clean|fresh|salty|shiny|grassy|muddy|windy|steep)\\b[\\s\\S]*){3}","I used 3 describing words"]],
  starters:["My place is ","The water is ","I can see ","I can hear ","I feel "],
  model:"My place is a sandy beach in Nova Scotia. The water is blue and cold. I can see tall rocks and white birds. I can hear big waves on the sand. I feel happy and calm at the beach."}
]};
UNITS.push(u);

/* ================= PHONICS: LONG I (i_e, igh, y) ================= */
const big=e=>`<span style="font-size:44px">${e}</span>`;
const IEW=["bike","kite","five","nine","pine","ice","mice","fire","hive","slide","dice","rice","dive","ride","hide","side","wide","time","tide","vine","wipe","ripe","white","shine","bite","drive","prize","hike","mile","lime"];
const IGHW=["night","light","high","bright","right","sight","might","tight","flight","fright","sigh","midnight","sunlight","flashlight","lightning","tonight","delight"];
const YW=["fly","sky","my","by","cry","dry","try","why","shy","spy","fry","sly","butterfly","reply","July"];
const PAT={"i_e":IEW,"igh":IGHW,"y":YW};
const PATWHY={"i_e":"the <b>i</b> and the quiet <b>e</b> at the end work together to say long i","igh":"the letters <b>igh</b> say long i, and the g and h are quiet","y":"the <b>y</b> at the end says long i"};
const patOf=w=>IEW.includes(w)?"i_e":IGHW.includes(w)?"igh":"y";
const iWhich=()=>{const r=Math.random(),ks=Object.keys(PAT);
  if(r<.5){const k=R(ks),w=R(PAT[k]);return mcQ(`Which spelling makes the <b>long i</b> sound in <b>${w}</b>?`,k,ks.filter(x=>x!==k),`In <b>${w}</b>, ${PATWHY[k]}.`,"Look at the letters after the first sound. Find i_e, igh or y.",{say:w})}
  const k=R(ks),w=R(PAT[k]),wr=ks.filter(x=>x!==k).map(x=>R(PAT[x]));
  return mcQ(`Which word has the long i spelled <b>${k}</b>?`,w,wr,`In <b>${w}</b>, ${PATWHY[k]}.`,k==="i_e"?"Find an i, one letter, then an e at the end.":k==="igh"?"Find the letters i-g-h together.":"Find a word that ends in y.")};
/* picture words: [word, picture, misspelling, misspelling] */
const LPIC=[["bike","🚲","byke","bik"],["kite","🪁","kyte","kight"],["five","5️⃣","fyve","fiv"],["nine","9️⃣","nyne","nighn"],["pine","🌲","pyne","pighn"],["ice","🧊","ise","yce"],["mice","🐭","mise","myce"],["fire","🔥","fyre","fier"],["hive","🐝","hyve","hiv"],["slide","🛝","slyde","slighd"],["dice","🎲","dise","dyce"],["rice","🍚","ryce","riec"],["dive","🤿","dyve","digh"],["ride","🏇","ryde","righd"],["night","🌙","nyte","nighte"],["light","💡","lyte","liet"],["flashlight","🔦","flashlyte","flashliet"],["lightning","⚡","lytning","litning"],["right","➡️","ryte","riet"],["sunlight","☀️","sunlyte","sunliet"],["midnight","🕛","midnyte","midnihgt"],["fly","🪰","fligh","fli"],["sky","🌤️","skigh","skie"],["cry","😢","crigh","crie"],["spy","🕵️","spigh","spie"],["fry","🍳","frigh","frie"],["butterfly","🦋","butterfli","butterfligh"],["shy","🙈","shigh","shie"]];
const SIPIC=[["pig","🐷"],["fish","🐟"],["six","6️⃣"],["pin","📌"],["lips","👄"],["milk","🥛"],["gift","🎁"],["ship","🚢"],["chick","🐥"],["swim","🏊"],["bricks","🧱"],["chips","🍟"],["ring","💍"],["mitten","🧤"]];
const iPic=()=>{const x=R(LPIC);
  if(Math.random()<.55)return mcQ(`What is this? ${big(x[1])}<br>Pick the right spelling.`,x[0],[x[2],x[3]],`${x[1]} is <b>${x[0]}</b>: ${PATWHY[patOf(x[0])]}.`,"Say the word. Which long i spelling looks right?");
  return mcQ(`Which picture shows <b>${x[0]}</b>?`,x[1],SAMPLE(LPIC.filter(y=>y!==x),2).map(y=>y[1]),`<b>${x[0]}</b> is ${x[1]}.`,"Read the word slowly, then find the picture.",{say:x[0]})};
const gapOf=w=>{const k=patOf(w);
  if(k==="igh"){const i=w.indexOf("igh");return w.slice(0,i).split("").concat(["_","_","_"],w.slice(i+3).split(""))}
  if(k==="y")return w.slice(0,-1).split("").concat(["_"]);
  const i=w.lastIndexOf("i");return w.split("").map((c,j)=>j===i||j===w.length-1?"_":c)};
const iMake=()=>{const x=R(LPIC),w=x[0],k=patOf(w),shown=gapOf(w).join(" ");
  if(Math.random()<.6)return {type:"type",q:`🧩 Complete the word. Fill the gaps and type the <b>whole word</b>.<br>${big(x[1])}<br><b style="font-size:28px;letter-spacing:6px">${shown}</b>`,a:[w],why:`${x[1]} <b>${w}</b>: ${PATWHY[k]}.`,hint:k==="igh"?"Three letters together say long i.":k==="y"?"One letter at the end says long i.":"An i in the middle and a quiet e at the end."};
  const opts={"i_e":"i … e","igh":"igh","y":"y"};
  return mcQ(`🧩 Which letters complete the word?<br>${big(x[1])}<br><b style="font-size:28px;letter-spacing:6px">${shown}</b>`,opts[k],Object.keys(opts).filter(z=>z!==k).map(z=>opts[z]),`${x[1]} <b>${w}</b>: ${PATWHY[k]}.`,"Say the word. Count the gaps.")};
const SIW=["fish","six","pin","milk","gift","hill","ship","chick","wig","sit","swim","dig","zip","bin","lid","fin","win","twin","spin","hid","slid","rip","dim","big","did","kick","crib","sink","lips","mitt"];
const MAGIC=[["kit","kite"],["pin","pine"],["bit","bite"],["rid","ride"],["hid","hide"],["dim","dime"],["rip","ripe"],["slid","slide"],["fin","fine"],["twin","twine"],["spin","spine"],["pip","pipe"],["sit","site"],["din","dine"],["shin","shine"],["strip","stripe"],["quit","quite"]];
const LONGL="Long i 🪁 (like kite)",SHORTL="Short i 🐷 (like pig)";
const iLong=()=>{const r=Math.random();
  if(r<.35){const lg=Math.random()<.5,w=lg?R(IEW.concat(IGHW,YW).filter(x=>x!=="kite")):R(SIW);
    return mcQ(`Does <b>${w}</b> have a <b>long i</b> or a <b>short i</b>?`,lg?LONGL:SHORTL,[lg?SHORTL:LONGL],lg?`<b>${w}</b> has long i: the i says its name.`:`<b>${w}</b> has short i: /i/, like in pig.`,"Long i says its name, like in kite. Short i says /i/, like in pig.",{say:w})}
  if(r<.6){const m=R(MAGIC);return {type:"type",q:`✨ Add a magic <b>e</b> to the end of <b>${m[0]}</b>. Type the new word.`,a:[m[1]],why:`<b>${m[0]}</b> + e = <b>${m[1]}</b>. The magic e makes the i say its name.`,hint:"Just add e at the end."}}
  if(r<.8){const m=R(MAGIC),o=R(SIW.filter(x=>x!==m[0]));return mcQ(`Which word has the <b>long i</b> sound?`,m[1],[m[0],o],`<b>${m[1]}</b> has long i. <b>${m[0]}</b> has short i.`,"Look for a quiet e at the end.")}
  const x=R(LPIC.filter(y=>!["ride","sky","right","sunlight","midnight","shy","spy","fry","lightning","flashlight"].includes(y[0])));return mcQ(`Which picture has the <b>long i</b> sound, like in 🪁 kite?`,x[1],SAMPLE(SIPIC,2).map(y=>y[1]),`${x[1]} is <b>${x[0]}</b>. It has long i.`,"Say the name of each picture. Does the i say its name?")};
const ILIST=G4.sp([["bike","I ride my bike to the park.","b-i-k-e: the e is quiet"],["kite","My kite is red and white.","k-i-t-e: the e makes the i say its name"],["five","I have five fingers on one hand.","f-i-v-e"],["nine","Nine is one more than eight.","n-i-n-e"],["pine","A pine tree is green all year.","p-i-n-e"],["slide","We go down the slide.","s-l-i-d-e"],["time","It is time for bed.","t-i-m-e"],["white","Snow is white.","wh-i-t-e"],["hike","We hike up the hill.","h-i-k-e"],["ride","I ride the bus.","r-i-d-e"],["wide","The river is wide.","w-i-d-e"],["night","The sky is dark at night.","n-igh-t: igh says long i"],["light","Please turn on the light.","l-igh-t"],["high","The bird is up so high.","h-igh: the g and h are quiet"],["bright","The sun is bright.","br-igh-t"],["right","Turn right at the lake.","r-igh-t"],["fly","Birds can fly.","f-l-y: y says long i at the end"],["sky","The sky is blue today.","s-k-y"],["my","This is my map.","m-y"],["cry","Babies cry when they are hungry.","c-r-y"],["dry","The desert is very dry.","d-r-y"],["try","I will try again.","t-r-y"],["why","Why is the sea salty?","wh-y"],["shy","The new girl is a bit shy.","sh-y"]]);

/* ================= GRAMMAR: PLURAL NOUNS ================= */
const ESN=[["box","📦"],["fox","🦊"],["bus","🚌"],["glass","🥛"],["dress","👗"],["dish","🍽️"],["brush","🖌️"],["bush","🌳"],["wish","🌠"],["beach","🏖️"],["bench","🪑"],["lunch","🍱"],["peach","🍑"],["watch","⌚"],["sandwich","🥪"],["branch","🌿"],["inch","📏"],["class","🏫"],["splash","💦"],["couch","🛋️"]];
const SN=[["hill","⛰️"],["river","🏞️"],["lake","🛶"],["rock","🪨"],["cave","🦇"],["map","🗺️"],["kite","🪁"],["bike","🚲"],["tree","🌳"],["cloud","☁️"],["star","⭐"],["shell","🐚"],["boat","⛵"],["bird","🐦"],["island","🏝️"],["wave","🌊"],["globe","🌍"],["mountain","🏔️"],["planet","🪐"],["ship","🚢"],["frog","🐸"],["duck","🦆"],["camel","🐪"],["forest","🌲"]];
const SPEC=[["child","children","🧒","childs","childes"],["foot","feet","🦶","foots","feets"],["mouse","mice","🐭","mouses","mices"],["man","men","👨","mans","mens"],["woman","women","👩","womans","womens"],["tooth","teeth","🦷","tooths","teeths"],["goose","geese","🐦","gooses","geeses"],["person","people","🧑","persones","peeple"],["sheep","sheep","🐑","sheeps","sheepes"],["deer","deer","🦌","deers","deeres"]];
const isES=w=>/(s|x|ch|sh)$/.test(w);
const plOf=w=>isES(w)?w+"es":w+"s";
const badOf=w=>isES(w)?w+"s":w+"es";
const ESWHY="Add <b>-es</b> when a word ends in <b>s, x, ch</b> or <b>sh</b>: box → boxes. Most other words just add <b>-s</b>: hill → hills.";
const NUMS=["two","three","four","five","six","many","lots of"];
const plSes=()=>{const x=R(Math.random()<.5?ESN:SN),w=x[0],r=Math.random();
  if(r<.4)return mcQ(`One ${x[1]} <b>${w}</b>. Add <b>-s</b> or <b>-es</b>?`,isES(w)?"-es":"-s",[isES(w)?"-s":"-es"],`<b>${w}</b> → <b>${plOf(w)}</b>. ${isES(w)?"It ends in "+w.match(/(s|x|ch|sh)$/)[0]+", so add -es.":"Just add -s."}`,"Look at the last letters. Do they make a hissing or shushing sound: s, x, ch, sh?");
  if(r<.7)return mcQ(`One <b>${w}</b> ${x[1]}, ${R(NUMS)} ___. Which is right?`,plOf(w),[badOf(w)],`<b>${plOf(w)}</b>. ${ESWHY}`,"Say both words aloud. Which one sounds right?");
  return {type:"type",q:`✍️ Write the plural (more than one).<br>one <b>${w}</b> ${x[1]} → two ___`,a:[plOf(w)],why:`<b>${plOf(w)}</b>. ${ESWHY}`,hint:isES(w)?"This word ends in s, x, ch or sh.":"This word just needs one letter."}};
const ALLN=ESN.map(x=>[x[0],plOf(x[0]),x[1],badOf(x[0])]).concat(SN.map(x=>[x[0],plOf(x[0]),x[1],badOf(x[0])]),SPEC.filter(x=>x[0]!==x[1]).map(x=>[x[0],x[1],x[2],x[3]]));
const FRAMES=[n=>`I can see ${n} ___.`,n=>`There are ${n} ___ here.`,n=>`We counted ${n} ___.`,n=>`Look at the ${n} ___!`];
const FINDPL=[["The foxes ran into the forest.","foxes",["forest","ran"]],["We saw two lakes from the hill.","lakes",["hill","saw"]],["The children swim in the river.","children",["river","swim"]],["My feet are wet from the stream.","feet",["stream","wet"]],["Three boats sail on the sea.","boats",["sea","sail"]],["The mice hide in the barn.","mice",["barn","hide"]],["Birds sing in the tall tree.","Birds",["tree","tall"]],["The beach has lots of shells.","shells",["beach","has"]],["Put the dishes in the sink.","dishes",["sink","Put"]],["A goose and two ducks swim.","ducks",["goose","swim"]],["The men climb the mountain.","men",["mountain","climb"]],["I have two wishes for the Earth.","wishes",["Earth","have"]],["The bus stops at the benches.","benches",["bus","stops"]],["Big waves hit the island.","waves",["island","hit"]],["Our teeth are white.","teeth",["white","Our"]],["The deer drink from the pond.","deer",["pond","drink"]],["We pack our lunches for the hike.","lunches",["hike","pack"]],["The sheep eat grass on the hill.","sheep",["hill","grass"]],["Camels walk across the desert.","Camels",["desert","walk"]],["The people plant a tree.","people",["tree","plant"]],["Stars shine in the night sky.","Stars",["sky","night"]],["Two women paddle a canoe.","women",["canoe","paddle"]]];
const plPick=()=>{const r=Math.random();
  if(r<.4){const x=R(ALLN),fr=R(FRAMES)(R(NUMS));return mcQ(`${x[2]} Choose the plural.<br><b>${fr}</b>`,x[1],[x[0],x[3]],`${fr.replace("___","<b>"+x[1]+"</b>")}`,"More than one needs the plural form.",{say:fr.replace("___","blank")})}
  if(r<.7){const x=R(ALLN),o=SAMPLE(ALLN.filter(y=>y!==x&&!/s$/.test(y[0])),2).map(y=>y[0]).filter(y=>y!==x[1]);return mcQ(`Which word means <b>more than one</b>?`,x[1],o,`<b>${x[1]}</b> means more than one ${x[0]}.`,"Look for an -s, an -es, or a special plural like feet.")}
  const x=R(FINDPL);return mcQ(`${G4.box("Sentence",x[0])}Which word is a <b>plural noun</b>? <span style="color:var(--muted);font-size:15px">(more than one)</span>`,x[1],x[2],`<b>${x[1]}</b> means more than one.`,"Find the naming word that means more than one.",{say:x[0]})};
const SPS=[["Two ___ play in the park.","child"],["My ___ are cold in the snow.","foot"],["Three ___ ran into the hole.","mouse"],["The ___ fish in the river.","man"],["Two ___ climb the hill.","woman"],["I brush my ___ every night.","tooth"],["The ___ fly south in the fall.","goose"],["Many ___ live in the city.","person"],["The ___ eat grass on the farm.","sheep"],["Four ___ walk in the forest.","deer"],["The ___ build a sandcastle.","child"],["Ducks have webbed ___.","foot"],["The cat ran after two ___.","mouse"],["Babies have small ___.","tooth"]];
const plSpecial=()=>{const r=Math.random();
  if(r<.3){const x=R(SPEC);return mcQ(`${x[2]} One <b>${x[0]}</b>, two ___.`,x[1],[x[3],x[4]],`one ${x[0]} → two <b>${x[1]}</b>. This word has a special plural.`,"This word does not just add -s. It changes, or stays the same.")}
  if(r<.55){const x=R(SPEC);return {type:"type",q:`✍️ Special plural! Type the word for more than one.<br>${x[2]} one <b>${x[0]}</b> → many ___`,a:[x[1]],why:`one ${x[0]} → many <b>${x[1]}</b>.`,hint:`It starts with "${x[1][0]}" and has ${x[1].length} letters.`}}
  if(r<.75){const x=R(SPEC.filter(y=>y[0]!==y[1])),o=R(SPEC.filter(y=>y!==x&&y[0]!==y[1]));return mcQ(`<b>${x[1]}</b> means more than one. What is just <b>ONE</b>?`,x[0],[x[3],o[0]],`one <b>${x[0]}</b> → many ${x[1]}.`,"Think: one ___, two "+x[1]+".")}
  const s=R(SPS),x=SPEC.find(y=>y[0]===s[1]);return mcQ(`${x[2]} Choose the right word.<br><b>${s[0]}</b>`,x[1],[x[3],x[0]],`${s[0].replace("___","<b>"+x[1]+"</b>")}`,"It means more than one, and it is a special plural.",{say:s[0].replace("___","blank")})};

/* ================= WORD SKILL: LAND AND WATER WORDS ================= */
const LW=[["hill","land","⛰️"],["mountain","land","🏔️"],["valley","land","🌄"],["cliff","land","🧗"],["cave","land","🦇"],["volcano","land","🌋"],["desert","land","🏜️"],["forest","land","🌲"],["jungle","land","🐒"],["island","land","🏝️"],["canyon","land","🪨"],["river","water","🏞️"],["lake","water","🛶"],["ocean","water","🐋"],["sea","water","🌊"],["stream","water","💧"],["pond","water","🦆"],["waterfall","water","💦"],["wave","water","🏄"]];
const LWDEF=[["land with water all around it","island"],["water with land all around it","lake"],["very high land","mountain"],["low land between hills","valley"],["dry land with very little rain","desert"],["a small river","stream"],["a huge area of salty water","ocean"],["water that falls over high rocks","waterfall"],["a mountain that can push out lava","volcano"],["a big, dark hole in a hill","cave"],["a high, steep wall of rock","cliff"],["a big place with lots of trees","forest"],["sandy land next to the water","beach"],["a little bit of still water, smaller than a lake","pond"],["water that flows a long way to the sea","river"],["a hot, wet forest full of plants","jungle"]];
const LWPIC=[["island","🏝️"],["volcano","🌋"],["desert","🏜️"],["beach","🏖️"],["forest","🌲"],["mountain","🏔️"],["wave","🌊"],["river","🏞️"]];
const LWBIG=[["ocean","lake"],["lake","pond"],["river","stream"],["mountain","hill"],["sea","pond"],["ocean","river"],["mountain","rock"],["forest","bush"]];
const an=w=>(/^[aeiou]/.test(w)?"an ":"a ")+w;
const lwQ=()=>{const r=Math.random();
  if(r<.3){const x=R(LW),L="Land ⛰️",W="Water 💧";return mcQ(`Is ${an(x[0]).replace(x[0],"<b>"+x[0]+"</b>")} land or water?`,x[1]==="land"?L:W,[x[1]==="land"?W:L],`${cap(an(x[0]))} is ${x[1]}.`,"Can you walk on it, or can you swim in it?")}
  if(r<.65){const x=R(LWDEF);return mcQ(`Which word means: <b>${x[0]}</b>?`,x[1],SAMPLE(LWDEF.filter(y=>y!==x),2).map(y=>y[1]),`${cap(an(x[1]))} is ${x[0]}.`,"Picture each place in your mind.")}
  if(r<.85){const x=R(LWPIC);return mcQ(`Which picture shows ${an(x[0]).replace(x[0],"<b>"+x[0]+"</b>")}?`,x[1],SAMPLE(LWPIC.filter(y=>y!==x),2).map(y=>y[1]),`${x[1]} is ${an(x[0])}.`,"Look at each picture carefully.")}
  const x=R(LWBIG),flip=Math.random()<.5;return mcQ(`Which is <b>${flip?"smaller":"bigger"}</b>?`,flip?x[1]:x[0],[flip?x[0]:x[1]],`${cap(an(x[0]))} is bigger than ${an(x[1])}.`,"Picture them side by side.")};

/* ================= READING: READ A MAP ================= */
const SYM=[["🏠","house"],["🌲","forest"],["🏔️","mountain"],["🌊","lake"],["🏫","school"],["⛺","tent"],["🌉","bridge"],["🏖️","beach"],["🌋","volcano"],["🏝️","island"],["🏪","shop"],["🛝","playground"]];
const DIRS=[["north","above",-1,0],["south","below",1,0],["east","to the right of",0,1],["west","to the left of",0,-1]];
const mapQ=()=>{const g=SAMPLE(SYM,9),at=(r,c)=>g[r*3+c],lbl=s=>s[0]+" "+s[1];
  const doc=`<div class="realdoc" style="text-align:center"><b>🗺️ Our map</b> <span style="font-size:15px">(⬆️ north is at the top)</span><div style="font-size:40px;line-height:1.3;margin:6px 0">${[0,1,2].map(r=>[0,1,2].map(c=>at(r,c)[0]).join(" ")).join("<br>")}</div><div style="font-size:16px">🔑 ${g.map(lbl).join(" · ")}</div></div>`;
  let r0,c0,d;do{r0=rint3();c0=rint3();d=R(DIRS)}while(r0+d[2]<0||r0+d[2]>2||c0+d[3]<0||c0+d[3]>2);
  const a=at(r0,c0),b=at(r0+d[2],c0+d[3]),q=Math.random();
  if(q<.5)return mcQ(`${doc}What is just <b>${d[0]}</b> of the ${lbl(a)}? <span style="color:var(--muted);font-size:15px">(${d[1]} it)</span>`,lbl(b),SAMPLE(g.filter(s=>s!==a&&s!==b),2).map(lbl),`The ${lbl(b)} is ${d[1]} the ${a[1]}, so it is <b>${d[0]}</b> of it.`,"North is up, south is down, east is right, west is left.");
  return mcQ(`${doc}Which way is the ${lbl(b)} from the ${lbl(a)}?`,d[0],DIRS.filter(x=>x!==d).map(x=>x[0]),`The ${b[1]} is ${d[1]} the ${a[1]}, so it is <b>${d[0]}</b>.`,"North is up, south is down, east is right, west is left.")};
const rint3=()=>Math.floor(Math.random()*3);

/* ================= THINKING: EARTH SMARTS ================= */
const ETH=[
 {q:"🚯 You see litter at the park. What can you do?",o:["Put it in a bin","Kick it away","Leave it there"],a:"Put it in a bin",why:"A clean park is safe for people and animals."},
 {q:"🚰 You are brushing your teeth. What saves water?",o:["Turn off the tap","Let the tap run","Fill the sink to the top"],a:"Turn off the tap",why:"Turning off the tap saves clean water."},
 {q:"🥫 You have an empty can. Where does it go?",o:["The recycling bin","The river","Under a bush"],a:"The recycling bin",why:"Cans can be recycled into new things."},
 {q:"🛍️ Your lunch bag is still good. What can you do?",o:["Reuse it tomorrow","Throw it in the lake","Burn it"],a:"Reuse it tomorrow",why:"Using things again makes less trash."},
 {q:"🌋 Where would you see lava?",o:["At a volcano","In a cold lake","In a forest stream"],a:"At a volcano",why:"Lava comes out of a volcano."},
 {q:"🏜️ You go to a desert. What should you bring?",o:["Lots of water","A snow shovel","A rain boat"],a:"Lots of water",why:"Deserts are dry, so you need water."},
 {q:"🏔️ You hike up a snowy mountain. What do you wear?",o:["A warm coat","A swimsuit","Flip-flops"],a:"A warm coat",why:"High mountains are cold."},
 {q:"🧭 You are lost on a trail. Which tool helps you find north?",o:["A compass","A spoon","A kite"],a:"A compass",why:"A compass points north."},
 {q:"🗺️ You want to find the lake in a park. What do you look at?",o:["A map","A clock","A menu"],a:"A map",why:"A map shows where places are."},
 {q:"🏝️ How can you get to an island?",o:["By boat","By bike","On a train over sand"],a:"By boat",why:"An island has water all around it."},
 {q:"🦆 A sign says \"Do not feed the ducks.\" What do you do?",o:["Watch them, but do not feed them","Throw them bread","Chase them"],a:"Watch them, but do not feed them",why:"We follow park signs to keep animals healthy."},
 {q:"🌊 Why can't we drink ocean water?",o:["It is salty","It is purple","It is too small"],a:"It is salty",why:"Ocean water has lots of salt in it."},
 {q:"🌱 Why do people plant trees?",o:["Trees help keep the air clean","Trees make noise","Trees eat litter"],a:"Trees help keep the air clean",why:"Trees give homes to animals and help clean the air."},
 {q:"🏞️ Which way does a river flow?",o:["Downhill","Uphill","Up into the sky"],a:"Downhill",why:"Water flows down to lower land."},
 {q:"💡 You leave your room. What saves energy?",o:["Turn off the light","Leave the light on","Open the fridge"],a:"Turn off the light",why:"Turning off lights saves energy."},
 {q:"🚲 Which way to school is kind to the air?",o:["Walk or ride a bike","Drive a car alone","Take a plane"],a:"Walk or ride a bike",why:"Walking and biking do not make smoke."},
 {q:"🌍 A globe is round. Why?",o:["Earth is round","Globes like to roll","Maps are round"],a:"Earth is round",why:"A globe is a round model of Earth."},
 {q:"🐋 Where does a whale live?",o:["In the ocean","In a desert","On a mountain"],a:"In the ocean",why:"Whales live in the sea."},
 {q:"🐪 Which animal is good at living in the desert?",o:["A camel","A penguin","A fish"],a:"A camel",why:"Camels can go a long time without water."},
 {q:"🌲 Where do you find lots of trees?",o:["In a forest","In the ocean","On an iceberg"],a:"In a forest",why:"A forest is a big place with many trees."},
 {q:"🧮 Ravi picks up 4 cans and 3 bottles. How many things does he pick up?",o:["7","6","8"],a:"7",why:"4 + 3 = 7."},
 {q:"🧮 There are 9 ducks on the lake. 4 fly away. How many are left?",o:["5","4","13"],a:"5",why:"9 − 4 = 5."},
 {q:"🧮 Our class plants 5 trees on Monday and 5 trees on Tuesday. How many trees in all?",o:["10","5","15"],a:"10",why:"5 + 5 = 10."},
 {q:"🧮 There are 7 continents. Amina has visited 2. How many has she not visited?",o:["5","9","4"],a:"5",why:"7 − 2 = 5."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["mountain","We climb the mountain.","moun-tain: ou, then ai"],["valley","The valley is green.","val-ley: a double l"],["river","We fish in the river.","riv-er"],["island","We sail to the island.","is-land: the s is quiet"],["ocean","Whales live in the ocean.","o-cean: the c says sh"],["beach","We play on the beach.","b-ea-ch"],["desert","The desert is dry.","des-ert: just one s"],["forest","Deer live in the forest.","for-est"],["compass","The compass points north.","com-pass: a double s"],["planet","Mars is a red planet.","plan-et"],["volcano","The volcano is very hot.","vol-ca-no"],["jungle","Monkeys live in the jungle.","jun-gle: it ends in le"],["country","Canada is my country.","coun-try: the ou says u"],["village","Tenzin lives in a village.","vil-lage: a double l"],["recycle","We recycle paper.","re-cy-cle: the y says long i"],["nature","We take walks in nature.","na-ture"],["protect","We protect the ducks.","pro-tect"],["waterfall","The waterfall is loud.","water + fall: two small words"],["iceberg","The iceberg is cold.","ice + berg"],["globe","Spin the globe.","g-l-o-b-e: the e is quiet"]]),
 CHOOSE:null,
 DETAIL:[
  ["The Kite","Ravi has a red kite. He flies it on a green hill with Grandpa. The wind is strong.",[["What colour is the kite?","Red",["Blue","Green"]],["Where does Ravi fly it?","On a green hill",["In a cave","On a boat"]],["Who is with Ravi?","Grandpa",["Ms. Diaz","Amina"]]]],
  ["The Big Lake","Lake Superior is a very big lake. It is in Canada and the United States. Its water is cold, even in summer.",[["What is Lake Superior?","A very big lake",["A mountain","A desert"]],["Where is it?","In Canada and the United States",["In Brazil","In Nepal"]],["What is its water like?","Cold",["Hot","Salty"]]]],
  ["Amina's Home","Amina lives near the Sahara Desert. In the day, it is very hot. Camels walk on the sand.",[["Where does Amina live?","Near the Sahara Desert",["By the Amazon River","On an island"]],["What is the day like?","Very hot",["Snowy","Rainy"]],["What walks on the sand?","Camels",["Yaks","Ducks"]]]],
  ["Tenzin's Yaks","Tenzin lives in Nepal. His family has three yaks. The yaks carry food up the mountain.",[["How many yaks does the family have?","Three",["One","Ten"]],["What do the yaks carry?","Food",["Snow","Fish"]],["Where does Tenzin live?","In Nepal",["In Morocco","In Canada"]]]],
  ["The Island","Aisha lives in the Maldives. She swims in the warm sea. She sees fish and coral.",[["Where does Aisha live?","In the Maldives",["In Nepal","In Canada"]],["What is the sea like?","Warm",["Icy","Dry"]],["What does she see?","Fish and coral",["Camels","Yaks"]]]],
  ["Lucas and the River","Lucas lives by the Amazon River. He rides a boat to school. He sees monkeys in the trees.",[["Which river does Lucas live by?","The Amazon",["The Nile","The Sahara"]],["How does he go to school?","By boat",["By bus","On a camel"]],["What does he see in the trees?","Monkeys",["Fish","Whales"]]]],
  ["The Volcano","A volcano is a kind of mountain. Hot lava can come out of the top. The lava glows red.",[["What is a volcano?","A kind of mountain",["A kind of lake","A kind of tree"]],["What comes out of the top?","Hot lava",["Cold water","Snow"]],["What colour does the lava glow?","Red",["Blue","Green"]]]],
  ["Clean-up Day","On Saturday, our class cleaned the beach. We picked up cans and bags. We put them in bins.",[["When did the class clean?","On Saturday",["On Monday","At night"]],["What did they clean?","The beach",["The school","The cave"]],["What did they pick up?","Cans and bags",["Shells and rocks","Fish"]]]],
  ["The Globe","Our class has a globe. It is round, like Earth. The blue parts show water.",[["What does the class have?","A globe",["A camel","A volcano"]],["What shape is it?","Round",["Flat","Square"]],["What do the blue parts show?","Water",["Land","Deserts"]]]],
  ["Iceberg Alley","In spring, icebergs float past Newfoundland. They come from the far north. People watch them from the shore.",[["What floats past Newfoundland?","Icebergs",["Wooden boats","Leaves"]],["When do they float past?","In spring",["Only at night","Never"]],["Where do they come from?","The far north",["The hot south","A volcano"]]]],
  ["The Map Key","Mia made a map of her room. Blue means bed. Green means rug.",[["What did Mia make?","A map of her room",["A kite","A cake"]],["What does blue mean?","Bed",["Rug","Door"]],["What does green mean?","Rug",["Bed","Window"]]]],
  ["The Waterfall","Niagara Falls is a big waterfall. It is in Ontario and New York. The water is loud as it falls.",[["What is Niagara Falls?","A big waterfall",["A desert","A city park"]],["Where is it?","In Ontario and New York",["In Brazil","In Nepal"]],["What is the water like as it falls?","Loud",["Silent","Frozen"]]]]
 ],
 MAIN:[
  ["A mountain is very high land. A hill is smaller and round. A valley is low land between hills.","There are many shapes of land.",["A hill is round.","Valleys are low."]],
  ["A river flows. A lake is still. An ocean is huge and salty.","There are many kinds of water.",["Rivers flow.","Lakes are still."]],
  ["We pick up litter. We recycle cans. We turn off the tap.","We can help take care of the Earth.",["Cans are metal.","Taps drip."]],
  ["Camels walk on the sand. The sun is hot. It hardly ever rains.","The desert is hot and dry.",["Camels walk.","The sun is round."]],
  ["The globe is round. It shows land and water. You can spin it.","A globe is a round model of Earth.",["You can spin it.","Water is wet."]],
  ["Tenzin lives in a high village. His yaks climb steep paths. Snow covers the mountain tops.","Tenzin lives high in the mountains.",["Yaks are hairy.","Snow is white."]],
  ["Lucas rides a boat on the Amazon. Fish swim in the river. Monkeys play in the trees by the water.","Lucas lives by a big river.",["Monkeys play.","Fish swim."]],
  ["The Maldives has many islands. Blue sea is all around them. Children swim and see coral.","The Maldives is a country of islands.",["Coral is pretty.","The sea is blue."]],
  ["A map shows where things are. A key tells what the colours mean. A compass rose shows north.","A map has parts that help us find places.",["Keys are small.","North is up."]],
  ["Lava comes out of a volcano. It is very hot. It turns into rock when it cools.","Volcanoes push out hot lava that becomes rock.",["Rock is hard.","Cooling takes time."]],
  ["Icebergs are huge. They float in cold seas. Most of an iceberg is under the water.","Icebergs are big pieces of floating ice.",["Seas are cold.","Water is wet."]],
  ["Trees give us shade. Trees help keep the air clean. Birds make nests in trees.","Trees are good for the Earth.",["Birds make nests.","Shade is cool."]],
  ["Ravi's kite got stuck. Ms. Diaz used a pole. She got the kite down.","A park ranger helped Ravi get his kite back.",["Poles are long.","Kites are red."]],
  ["Kite, bike and five have i_e. Night and light have igh. Fly and sky have y.","Long i can be spelled in different ways.",["Bikes have wheels.","Kites fly."]],
  ["One box, two boxes. One fox, two foxes. One dish, two dishes.","Some words add -es to mean more than one.",["Foxes are red.","Dishes break."]],
  ["One child, two children. One foot, two feet. One mouse, two mice.","Some words have special plurals.",["Mice are small.","Feet can run."]],
  ["Asia is a continent. Africa is a continent. There are seven in all.","Earth has seven continents.",["Africa is big.","Asia is far."]],
  ["The Pacific is an ocean. The Atlantic is an ocean. There are five oceans.","Earth has five oceans.",["The Pacific is big.","Oceans are wet."]],
  ["Ducks swim on the pond. Frogs sit on lily pads. Fish swim under the water.","Many animals live in and by the pond.",["Frogs jump.","Ducks quack."]],
  ["Stay on the trail. Take your litter home. Keep dogs on a leash.","These are rules for the park.",["Dogs like walks.","Trails are long."]],
  ["At night, the sky is dark. The moon is bright. The stars shine.","The night sky has a bright moon and stars.",["Stars are far.","Night is long."]],
  ["Canada has big lakes. It has tall mountains. It has wide forests.","Canada has many kinds of land and water.",["Forests are wide.","Lakes are wet."]],
  ["We dig a hole. We put in a small tree. We water it every day.","We plant a tree and care for it.",["Holes are deep.","Water is clear."]],
  ["A stream is small. It flows into a river. The river flows to the sea.","Streams and rivers flow to the sea.",["Streams are small.","The sea is blue."]]
 ],
 FACTS:["Earth is a planet.","Ocean water is salty.","There are seven continents.","A globe is round.","Rivers flow downhill.","Canada has many lakes.","Mount Everest is in Asia.","Camels live in deserts.","Lava is very hot.","An island has water all around it.","A compass shows north.","Nepal is a country.","The Amazon is a river.","Ice melts when it gets warm.","Brazil is in South America.","Trees grow from seeds.","Paper can be recycled.","Fish live in water.","The Pacific is an ocean.","A map shows places.","Snow is cold.","The Sahara is a desert.","Morocco is in Africa.","Whales live in the ocean.","The word kite has the long i sound."],
 OPIN:["Mountains are the prettiest places.","Beaches are more fun than lakes.","Deserts are boring.","Swimming in the ocean is the best.","Islands are the nicest places to live.","Hiking is too hard.","Maps are fun to read.","Volcanoes are the coolest mountains.","Snow is better than sand.","The forest is the best place for a walk.","Rivers are prettier than lakes.","Camels are the funniest animals.","Kites are the best toys.","Picnics are the most fun part of Earth Day.","Night is better than day.","Green is the nicest colour for a map.","Canoes are better than sailboats.","Picking up litter is fun.","Caves are too scary.","The beach is the best place in summer.","Rain is the worst weather.","Waterfalls are the most beautiful places.","Globes are better than maps.","Stars are prettier than the moon.","Everyone should love camping."],
 SEQ:[["Rain falls on the mountain","It runs into a stream","The stream flows into a river","The river flows to the sea"],["Ravi flies his kite","The string breaks","The kite gets stuck in a tree","Ms. Diaz gets it down"],["Stand at the door and look","Draw the walls","Draw the bed and desk","Make a map key"],["Dig a hole","Put the small tree in","Fill the hole with soil","Water the tree"],["Drink from a bottle","Put the empty bottle in the blue bin","A truck takes it away","It is made into something new"],["Pack a water bottle","Walk up the hill","Look out at the view","Walk back down"],["Put on gloves","Pick up litter on the beach","Put it in a bag","Put the bag in the bin"],["The sun sets","The sky gets dark","The stars come out","The sun rises again"],["Hot lava comes out","The lava runs down the side","The lava cools","It turns into hard rock"],["Spin the globe","Stop it with your finger","Look at the place you touched","Find its name"]],
 CE:[["The string broke, so the kite flew away.","the string broke","the kite flew away"],["The kite was stuck high, so Ms. Diaz used a pole.","the kite was stuck high","Ms. Diaz used a pole"],["Ocean water is salty, so we cannot drink it.","ocean water is salty","we cannot drink it"],["The sun is hot, so Amina wears long clothes.","the sun is hot","Amina wears long clothes"],["It rains a lot, so the rainforest is green.","it rains a lot","the rainforest is green"],["The river is by his home, so Lucas goes to school by boat.","the river is by his home","Lucas goes to school by boat"],["The mountain is cold, so Tenzin wears a warm coat.","the mountain is cold","Tenzin wears a warm coat"],["We turned off the tap, so we saved water.","we turned off the tap","we saved water"],["We picked up the litter, so the beach was clean.","we picked up the litter","the beach was clean"],["The sun came out, so the snow melted.","the sun came out","the snow melted"],["It was windy, so we flew our kites.","it was windy","we flew our kites"],["The path was steep, so we walked slowly.","the path was steep","we walked slowly"],["It was dark in the cave, so we used a flashlight.","it was dark in the cave","we used a flashlight"],["We got lost, so we looked at the map.","we got lost","we looked at the map"],["The wave was big, so we got wet.","the wave was big","we got wet"],["We planted trees, so birds had new homes.","we planted trees","birds had new homes"],["The lake froze, so we went skating.","the lake froze","we went skating"],["It did not rain for weeks, so the stream dried up.","it did not rain for weeks","the stream dried up"],["The night was clear, so we saw many stars.","the night was clear","we saw many stars"],["The bin was full, so Dad took it out.","the bin was full","Dad took it out"]],
 CMP:[
  ["A lake and an ocean are both water. A lake has land all around it. An ocean is huge and salty.","Both are water","A lake has land around it, but an ocean is huge and salty",["Both are deserts","A lake is huge and salty"]],
  ["A hill and a mountain are both high land. A hill is small. A mountain is very tall.","Both are high land","A hill is small, but a mountain is very tall",["Both are water","A hill is taller"]],
  ["A stream and a river both flow. A stream is small. A river is big.","Both flow","A stream is small, but a river is big",["Both are still","A stream is bigger"]],
  ["Amina and Aisha both live in warm places. Amina lives near a desert. Aisha lives on an island.","Both live in warm places","Amina lives near a desert, but Aisha lives on an island",["Both live in the snow","Aisha lives near a desert"]],
  ["A map and a globe both show Earth. A map is flat. A globe is round.","Both show Earth","A map is flat, but a globe is round",["Both are round","A globe is flat"]],
  ["A desert and a jungle can both be hot. A desert is dry. A jungle is wet.","Both can be hot","A desert is dry, but a jungle is wet",["Both are icy","A jungle is dry"]],
  ["A cave and a cliff are both made of rock. A cave is a hole. A cliff is a steep wall.","Both are made of rock","A cave is a hole, but a cliff is a steep wall",["Both are made of water","A cliff is a hole"]],
  ["An island and a beach both have sand and water. An island has water all around it. A beach is at the edge of the water.","Both have sand and water","An island has water all around, but a beach is at the edge",["Both are mountains","A beach has water all around"]],
  ["Kite and night both have long i. Kite uses i_e. Night uses igh.","Both have long i","Kite uses i_e, but night uses igh",["Both have short i","Night uses i_e"]],
  ["Box and hill are both nouns. Box adds -es to make boxes. Hill adds -s to make hills.","Both are nouns","Box adds -es, but hill adds -s",["Both are action words","Hill adds -es"]],
  ["Tenzin and Lucas both have animals near home. Tenzin has yaks. Lucas sees monkeys.","Both have animals near home","Tenzin has yaks, but Lucas sees monkeys",["Both have camels","Tenzin sees monkeys"]],
  ["A bike and a car both take you places. A bike uses your legs. A car uses fuel.","Both take you places","A bike uses your legs, but a car uses fuel",["Both can fly","A car uses your legs"]]
 ],
 GRP:{"land shapes":["hill","mountain","valley","cliff","cave"],"kinds of water":["river","lake","ocean","stream","pond"],"continents":["Asia","Africa","Europe","Antarctica","Australia"],"oceans":["Pacific","Atlantic","Indian","Arctic"],"map tools":["globe","map","compass","atlas"],"long i words":["bike","kite","night","fly","five"],"directions":["north","south","east","west"],"things we recycle":["cans","bottles","newspapers","cardboard"]},
 ANA:[["Hill is to mountain as stream is to ___.","river",["lake","rock"]],["Lake is to water as desert is to ___.","sand",["snow","fish"]],["Fish is to ocean as camel is to ___.","desert",["lake","sky"]],["North is to south as east is to ___.","west",["up","north"]],["Box is to boxes as fox is to ___.","foxes",["foxs","fox"]],["Child is to children as man is to ___.","men",["mans","mens"]],["Foot is to feet as tooth is to ___.","teeth",["tooths","teeths"]],["Map is to flat as globe is to ___.","round",["square","wet"]],["Hot is to desert as cold is to ___.","iceberg",["volcano","beach"]],["Kite is to sky as boat is to ___.","lake",["cave","desert"]],["Up is to high as down is to ___.","low",["tall","sky"]],["Day is to sun as night is to ___.","moon",["sand","cloud"]],["Yak is to mountain as monkey is to ___.","jungle",["iceberg","desert"]],["Wet is to river as dry is to ___.","desert",["ocean","stream"]],["Mouse is to mice as goose is to ___.","geese",["gooses","geeses"]],["Compass is to direction as clock is to ___.","time",["rain","sand"]],["Ice is to cold as lava is to ___.","hot",["wet","soft"]],["Canada is to country as Asia is to ___.","continent",["ocean","river"]],["Pacific is to ocean as Everest is to ___.","mountain",["river","lake"]],["Bat is to cave as bird is to ___.","nest",["sea","rock"]],["Snow is to mountain top as sand is to ___.","beach",["cave","iceberg"]]],
 SENT:["Ravi and I fly a kite.","Amina lives in Morocco.","Tenzin has three yaks.","Lucas lives in Brazil.","Aisha swims in the sea.","I live in Canada.","Can I go to the lake with Mia?","Mount Everest is in Asia.","My friend Ben likes maps.","I saw Niagara Falls.","Grandpa and I hiked up the hill.","Is Lake Superior big?","Sam and I picked up litter.","I like the Pacific Ocean.","Our class went to Pine Lake Park.","I read about the Sahara Desert.","Ms. Diaz is a park ranger.","Ana and I made a map.","Where is the Amazon River?","I want to visit Nepal."],
 ORDER:["The hill is green.","We swim in the lake.","The sea is blue.","Look at the map.","The kite flies high.","The river is wide.","We pick up litter.","The desert is dry.","Fish swim in the ocean.","The cave is dark.","We plant a tree.","The globe is round.","Turn off the tap.","The waves are big.","Birds fly in the sky.","The volcano is hot.","We ride our bikes.","The night is quiet.","Put it in the bin.","The island is small."],
 WP:[
  {q:"Write a sentence about a hill or a mountain.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Hh]ills?|[Mm]ountains?)\\b","Uses hill or mountain"]],model:"The mountain is tall and white."},
  {q:"Write a sentence about a lake, a river or the sea.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ll]akes?|[Rr]ivers?|[Ss]eas?)\\b","Uses lake, river or sea"]],model:"We swim in the lake."},
  {q:"Write a sentence with a long i word spelled <b>i_e</b>, like bike or kite.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Bb]ikes?|[Kk]ites?|[Ff]ive|[Nn]ine|[Pp]ines?|[Rr]ides?|[Hh]ide|[Tt]ime|[Ww]hite|[Ss]lides?|[Ss]miles?|[Hh]ikes?|[Ww]ide|[Ii]ce|[Mm]ice|[Ff]ire|[Ll]ines?|[Ll]ikes?|[Nn]ice|[Ss]ide|[Dd]ive|[Hh]ive|[Rr]ice|[Dd]ice)\\b","Uses an i_e word"]],model:"I ride my bike."},
  {q:"Write a sentence with a long i word spelled <b>igh</b>, like night or light.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["igh","Uses an igh word"]],model:"The light is bright."},
  {q:"Write a sentence with a long i word that ends in <b>y</b>, like fly or sky.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ff]ly|[Ss]ky|[Mm]y|[Bb]y|[Cc]ry|[Dd]ry|[Tt]ry|[Ww]hy|[Ss]hy|[Ss]py|[Ff]ry|[Bb]utterfly)\\b","Uses a y word"]],model:"Birds fly in the sky."},
  {q:"Write a sentence with a plural that ends in <b>-es</b>, like boxes or foxes.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["(s|x|ch|sh)es\\b","Uses an -es plural"]],model:"Two foxes ran by the lake."},
  {q:"Write a sentence with a plural that ends in <b>-s</b>, like hills or lakes.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Hh]ills|[Ll]akes|[Rr]ivers|[Rr]ocks|[Tt]rees|[Ss]tars|[Bb]irds|[Kk]ites|[Bb]ikes|[Mm]aps|[Ww]aves|[Bb]oats|[Ss]hells|[Cc]louds|[Cc]aves|[Ii]slands|[Mm]ountains|[Dd]ucks|[Ff]rogs|[Ss]hips|[Cc]amels)\\b","Uses an -s plural"]],model:"I see three boats."},
  {q:"Write a sentence with a special plural, like children, feet or mice.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Cc]hildren|[Ff]eet|[Mm]ice|[Mm]en|[Ww]omen|[Tt]eeth|[Gg]eese|[Pp]eople|[Ss]heep|[Dd]eer)\\b","Uses a special plural"]],model:"The children play on the beach."},
  {q:"Write a sentence about how you help the Earth.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I put cans in the blue bin."},
  {q:"Write a sentence about a place you would like to visit.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I want to visit the Maldives."},
  {q:"Write a question about the Earth. End it with <b>?</b>",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"Why is the sea salty?"},
  {q:"Write a sentence that uses the word <b>island</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Ii]slands?\\b","Uses island"]],model:"We took a boat to the island."},
  {q:"Write a sentence about a desert.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Dd]eserts?\\b","Uses desert"]],model:"The desert is hot and dry."},
  {q:"Write a sentence about what you see at night.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Nn]ight","Uses night"]],model:"I see the moon at night."},
  {q:"Write a sentence about water with a describing word, like blue, cold or wide.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b(blue|cold|wide|deep|warm|clear|salty|wet|big|calm)\\b","Uses a describing word"]],model:"The river is wide and deep."},
  {q:"Write a sentence about a map or a globe.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Mm]aps?|[Gg]lobes?)\\b","Uses map or globe"]],model:"A globe is round like Earth."},
  {q:"Write a sentence with the word <b>north</b> or <b>south</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Nn]orth|[Ss]outh)\\b","Uses north or south"]],model:"Some birds fly south in the fall."},
  {q:"Write one rule for a park.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"Please stay on the trail."},
  {q:"Write a sentence about a child in another country. Use the child's name.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,CHK.name],model:"Tenzin lives in Nepal."},
  {q:"Write a sentence with the word <b>children</b> or <b>people</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Cc]hildren|[Pp]eople)\\b","Uses children or people"]],model:"Many people live in the city."}
 ],
 SYN:[["big","huge"],["little","tiny"],["rock","stone"],["shout","yell"],["glad","happy"],["quick","fast"],["chilly","cold"],["wet","damp"],["start","begin"],["end","finish"],["trash","garbage"],["path","trail"],["afraid","scared"],["sleepy","tired"],["pick","choose"],["shiny","bright"],["grin","smile"],["sick","ill"],["above","over"],["below","under"]],
 OPP:[["high","low"],["wet","dry"],["deep","shallow"],["wide","narrow"],["hot","cold"],["north","south"],["east","west"],["day","night"],["up","down"],["top","bottom"],["inside","outside"],["clean","dirty"],["full","empty"],["tall","short"],["light","dark"],["rough","smooth"],["near","far"],["sink","float"],["find","lose"],["open","closed"]],
 COMP:[["water","fall"],["sun","set"],["sand","castle"],["snow","flake"],["moon","light"],["mountain","top"],["hill","side"],["sea","weed"],["foot","print"],["camp","fire"],["high","way"],["flash","light"],["earth","quake"],["rain","drop"],["grass","hopper"],["light","house"],["river","bank"],["sea","side"],["drift","wood"],["under","ground"],["rain","forest"]]
};
B.CHOOSE=G4.ch([["mountain","mountin","mowntain"],["valley","vally","valey"],["river","rivver","rivar"],["island","iland","ieland"],["ocean","oshun","ocian"],["beach","beche","beatch"],["desert","dezert","desirt"],["forest","forist","foreest"],["compass","cumpass","compas"],["planet","plannet","planit"],["volcano","volkano","valcano"],["jungle","jungel","jongle"],["country","cuntry","contry"],["village","villige","vilage"],["recycle","resycle","recicle"],["nature","nachure","natur"],["protect","pertect","protekt"],["waterfall","watterfall","waterfal"],["iceberg","iseberg","icebirg"],["globe","gloab","glowb"]],B.SP);

const L={
 which:"Long i can be spelled <b>i_e</b> (🚲 bike), <b>igh</b> (🌙 night) or <b>y</b> (🪰 fly). Look at the letters to see which one it is.",
 pic:"Say the picture word slowly: 🪁 kite. Then pick the spelling that looks right: <b>kite</b>, not kyte.",
 make:"Find the long i sound. Is it <b>i_e</b> (k-i-t-e), <b>igh</b> (n-igh-t) or <b>y</b> (f-l-y)? Fill in those letters.",
 long:"Long i says its name, like in 🪁 <b>kite</b>. Short i says /i/, like in 🐷 <b>pig</b>. A magic e can change kit into <b>kite</b>.",
 listen:"Listen for long i. Then think: is it i_e, igh or y? Example: n-igh-t spells <b>night</b>.",
 ses:"Add <b>-s</b> to most nouns: one hill, two <b>hills</b>. Add <b>-es</b> after s, x, ch or sh: one fox, two <b>foxes</b>.",
 pick:"A <b>plural</b> noun means more than one: one lake, three <b>lakes</b>.",
 spec:"Some plurals are special. They change: child → <b>children</b>, foot → <b>feet</b>, mouse → <b>mice</b>. Some stay the same: one sheep, two <b>sheep</b>.",
 mixed:"Use what you learned about plurals and long i.",
 lw:"Some places are <b>land</b>, like a hill or a desert. Some are <b>water</b>, like a lake or a river. An island is land with water all around it.",
 map:"On a map, <b>north</b> is up ⬆️, <b>south</b> is down ⬇️, <b>east</b> is right ➡️ and <b>west</b> is left ⬅️.",
 earth:"Think about how to stay safe and how to take care of the Earth."
};
u.review=G4.MIX(plSes,plPick,plSpecial,iWhich,iLong,lwQ,F.vocab(u.words));
u.cats=G4.std(u,{sets:["Land shapes","Water on Earth","Maps and our planet","Caring for the Earth"],B,
 reading:[{id:"r_map",t:"Read a map: north, south, east and west",learn:L.map,gen:mapQ}],
 vocab:[{id:"v_landwater",t:"Land and water words",learn:L.lw,gen:lwQ}],
 grammar:[{id:"g_ses",t:"Plurals: add -s or -es?",learn:L.ses,gen:plSes},{id:"g_plpick",t:"Choose the plural",learn:L.pick,gen:plPick},{id:"g_plspec",t:"Special plurals: children, feet, mice",learn:L.spec,gen:plSpecial},{id:"g_mixed",t:"Mixed review: plurals and long i",learn:L.mixed,gen:u.review}],
 spelling:[{id:"s_iwhich",t:"Long i: which spelling? (i_e, igh, y)",learn:L.which,gen:iWhich},{id:"s_ipic",t:"Long i: picture to word",learn:L.pic,gen:iPic},{id:"s_imake",t:"Long i: complete the word",learn:L.make,gen:iMake},{id:"s_ilong",t:"Long i or short i?",learn:L.long,gen:iLong},{id:"s_ilisten",t:"Long i words: listen and write",learn:L.listen,gen:F.listen(ILIST)}],
 thinking:[{id:"t_earth",t:"Earth smarts: what should you do?",learn:L.earth,gen:F.bank(ETH)}]});
})();
