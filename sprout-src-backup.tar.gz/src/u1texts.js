/* ===================== UNIT 1 · EXTRA READING TEXTS (original content) ===================== */
(function(){
const u=UNITS.find(x=>x.id==="me");
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});

u.stories[0].turn={q:"Write two sentences about your own family. Who is in it? What do you like to do together?",model:"There are four people in my family. We like to go to the park together on Sundays."};
u.stories[1].turn={q:"What makes YOUR family special? Write two sentences.",model:"My family speaks two languages at home. We always eat dinner together."};

u.stories.push(
{title:"Leo's Lost Football", e:"⚽", kind:"Story", pages:[
 {pic:"⚽😟", text:"On Saturday morning, Leo could not find his football. He looked under his bed. He looked behind the sofa. He even looked inside the fridge! \"Where is my ball?\" he cried.",
  qs:[f("Where did Leo NOT look?","On the roof",["Under his bed","Behind the sofa"],"He looked under his bed, behind the sofa and in the fridge, but not on the roof."),
      t("How did Leo feel?","Worried",["Sleepy","Proud"],"He cried, \"Where is my ball?\" He was worried.")]},
 {pic:"👵🔍", text:"Grandmother put on her glasses. \"Let's think like detectives,\" she said. \"Where did you play with it last?\" Leo thought hard. \"In the garden, after school yesterday.\"",
  qs:[f("Where did Leo play with the ball last?","In the garden",["At school","In the kitchen"],"Leo said, \"In the garden, after school yesterday.\""),
      t("Why did Grandmother ask where he played last?","The ball is probably near the last place he used it",["She wanted to play football","She was tired"],"Good detectives start looking where a thing was last seen.")]},
 {pic:"🌳🐈", text:"Leo and Grandmother went into the garden. They looked under the big tree and behind the flowers. No football. Then they heard a sound: \"Meow!\" Pepper the cat was sitting on top of the fence, looking very pleased with herself.",
  qs:[f("Who was sitting on the fence?","Pepper the cat",["Mia","A bird"],"\"Pepper the cat was sitting on top of the fence.\""),
      t("Why do you think Pepper looked pleased with herself?","She may know something about the ball",["She was hungry","She was asleep"],"The writer gives us a clue: Pepper might have played with the ball!")]},
 {pic:"🥬⚽", text:"Behind the fence was Mr. Ali's garden. Leo's football was lying in the middle of his vegetable patch! It had squashed two tomato plants. Leo's face went red. \"Oh no,\" he whispered.",
  qs:[f("Where was the football?","In Mr. Ali's vegetable patch",["In the fridge","Under the bed"],"It was lying in the middle of Mr. Ali's vegetable patch."),
      t("Why did Leo's face go red?","He felt embarrassed about the broken plants",["He was too hot","He was eating tomatoes"],"Our faces can go red when we feel embarrassed or sorry.")]},
 {pic:"🚪🙏", text:"Leo did not want to knock on Mr. Ali's door. He felt shy. But Grandmother said, \"When we make a mistake, we say sorry and try to fix it.\" So Leo knocked. \"I'm sorry, Mr. Ali. My ball broke your tomato plants. Can I help you fix them?\"",
  qs:[f("What does Grandmother say we should do after a mistake?","Say sorry and try to fix it",["Run away","Hide the ball"],"\"When we make a mistake, we say sorry and try to fix it.\""),
      t("Was it easy for Leo to knock on the door?","No, he felt shy",["Yes, it was very easy"],"Leo did not want to knock because he felt shy. He was brave to do it anyway.")]},
 {pic:"🍅😊", text:"Mr. Ali smiled. \"Thank you for being honest, Leo. Let's plant two new tomato plants together.\" They worked side by side in the garden. When the tomatoes grew big and red, Mr. Ali gave a basket of them to Leo's family. Leo gave Mr. Ali a big thank-you drawing.",
  qs:[f("What did Leo and Mr. Ali plant?","Two new tomato plants",["Sunflowers","An apple tree"],"\"Let's plant two new tomato plants together.\""),
      t("What is the lesson of this story?","Be honest and fix your mistakes",["Never play football","Cats are naughty"],"Leo was honest and helped fix the problem, and it turned out well.")]}
], turn:{q:"Write about a time you made a mistake. What did you do to make it better?",model:"Once I broke my sister's crayon. I said sorry and gave her one of mine."}},

{title:"How Babies Grow", e:"👶", kind:"Fact text", pages:[
 {pic:"👶🍼", text:"A newborn baby is very small and needs a lot of care. Newborn babies sleep for most of the day and night. When they are awake, they drink milk, and they cry to tell grown-ups they need something.",
  qs:[f("How do newborn babies tell grown-ups they need something?","They cry",["They talk","They write a note"],"Babies cannot talk yet, so they cry."),
      t("Why does a newborn baby need a lot of care?","It cannot do things for itself yet",["It is very strong","It can cook its own food"],"A newborn cannot feed itself, move around or talk yet.")]},
 {pic:"👀😊", text:"At first, babies can only see things that are close to their faces. They love looking at faces most of all! When they are about six weeks old, many babies give their first real smile.",
  qs:[f("About when do many babies give their first real smile?","At about six weeks old",["On the first day","At one year old"],"The text says about six weeks old."),
      f("What do babies love looking at most of all?","Faces",["Cars","Trees"],"\"They love looking at faces most of all!\"")]},
 {pic:"🧸🪑", text:"Babies grow stronger every month. They learn to hold up their heads, and then to roll over. At around six months, many babies can sit up. Many babies also get their first tooth at about this age.",
  qs:[f("What can many babies do at around six months?","Sit up",["Run","Read"],"At around six months, many babies can sit up."),
      t("Why does a baby hold up its head before it can sit?","Its neck and back must get stronger first",["Its head is very light","It is bored"],"Babies get stronger step by step, from the head down.")]},
 {pic:"🚼👣", text:"Next, most babies learn to crawl. Then they pull themselves up and hold on to the furniture. Around their first birthday, many babies take their first wobbly steps and say their first words, like \"mama\" or \"dada\".",
  qs:[f("About when do many babies take their first steps?","Around their first birthday",["At six weeks","At five years"],"Around their first birthday."),
      f("What do most babies learn BEFORE walking?","Crawling",["Running","Jumping"],"First they crawl, then they stand, then they walk.")]},
 {pic:"🌱💛", text:"Every baby grows at its own speed. Some babies walk early and some walk later, and that is perfectly normal. With love, food, sleep and lots of talking and playing, babies grow into strong, curious children, just like you!",
  qs:[t("A baby walks later than her cousin. Does that mean something is wrong?","Not usually: every baby grows at its own speed",["Yes, always"],"The text says some babies walk later, and that is perfectly normal."),
      f("What do babies need to grow well?","Love, food, sleep, talking and playing",["Only toys","Only milk"],"The text lists love, food, sleep, talking and playing.")]}
], turn:{q:"Ask a grown-up about something you did when you were a baby. Write one or two sentences about it.",model:"When I was a baby, I loved my yellow blanket."}},

{title:"Hazel and Fern (a fable)", e:"🐿️", kind:"Fable", pages:[
 {pic:"🐿️🌰🐿️", text:"Long ago, in a tall oak tree, there lived two squirrel sisters, Hazel and Fern. All autumn, they gathered acorns for the winter. Hazel worked hard and filled her store to the top. Fern worked hard too, but a storm knocked her store out of the tree.",
  qs:[f("What were the squirrels gathering?","Acorns",["Apples","Leaves"],"They gathered acorns for the winter."),
      f("What happened to Fern's store of acorns?","A storm knocked it out of the tree",["Hazel ate it","A bird took it"],"A storm knocked her store out of the tree.")]},
 {pic:"❄️😢", text:"When winter came, Fern was cold and hungry. She knocked on Hazel's door. \"Sister, may I have a few acorns?\" Hazel looked at her full store. \"These are mine,\" she said. \"I worked hard for them.\" And she closed the door.",
  qs:[t("How did Fern feel?","Cold, hungry and sad",["Happy and full","Proud"],"She had no food in winter, and her sister closed the door."),
      t("Was Hazel kind to her sister?","No, she did not share",["Yes, she was very kind"],"Hazel kept all her acorns and closed the door.")]},
 {pic:"🌨️🏠", text:"That night, a fierce snowstorm came. The wind shook the tree so hard that Hazel's door blew open. Snow filled her home, and she could not find her acorns under the ice. Now Hazel was the cold and hungry one.",
  qs:[f("What happened to Hazel's home?","Snow filled it",["It caught fire","A bear moved in"],"Her door blew open and snow filled her home."),
      t("How is Hazel's problem now like Fern's problem before?","Now Hazel has no food either",["Now Hazel has too much food","Now Hazel is happy"],"Both sisters lost their acorns because of a storm.")]},
 {pic:"🕯️🤝", text:"Hazel knocked on Owl's door, but Owl was asleep. Then she saw a light in a small hole lower down the tree. It was Fern's new home. Fern had found a few acorns under the snow. When she saw her sister, she said, \"Come in. We can share what I have.\"",
  qs:[t("Why is Fern's choice surprising?","Hazel did not share with her before",["Fern has lots of food","Fern does not like acorns"],"Fern shares even though Hazel would not share with her."),
      f("What did Fern say to Hazel?","\"Come in. We can share what I have.\"",["\"Go away.\"","\"These are mine.\""],"Fern invited her sister in.")]},
 {pic:"💛🌳", text:"That winter, the two sisters shared every acorn and kept each other warm. Hazel never forgot her sister's kindness. When spring came, they gathered acorns together and kept one big store for both of them. <b>Lesson: Kindness that you share comes back to you.</b>",
  qs:[t("What is the lesson of this fable?","Share with others, even when it is hard",["Keep everything for yourself","Never go out in the snow"],"A fable is a short story that teaches a lesson."),
      f("What did the sisters do in spring?","They gathered acorns together",["They moved away","They stopped talking"],"In spring, they gathered acorns together.")]}
], turn:{q:"Write about a time someone shared with you, or you shared with someone. How did it feel?",model:"My cousin shared his umbrella with me in the rain. It made me feel happy and safe."}},

{title:"Real-world reading: An invitation and a chore chart", e:"📬", kind:"Real-world text", pages:[
 {pic:"🎉✉️", text:"Mia's family made this invitation for Leo's birthday. Read it carefully.<div class=\"realdoc\"><b>🎈 You're invited! 🎈</b><br>Come to <b>Leo's 7th birthday party!</b><br><br>📅 <b>When:</b> Saturday, May 10, from 2:00 to 4:00 p.m.<br>📍 <b>Where:</b> Maple Park, next to the big slide<br>🎮 <b>Fun:</b> football games, face painting and cake<br>👟 Please wear sports shoes!<br><br>Please tell us if you can come by May 5.</div>",
  qs:[f("What time does the party start?","2:00 p.m.",["4:00 p.m.","10:00 a.m."],"From 2:00 to 4:00 p.m., so it starts at 2:00."),
      f("Where is the party?","Maple Park",["Leo's house","The school"],"Where: Maple Park, next to the big slide."),
      f("How old will Leo be?","7",["6","10"],"It is Leo's 7th birthday party."),
      t("Why should guests wear sports shoes?","There will be football games",["It will be very cold","It is a dance party"],"The invitation says there will be football games."),
      f("By what date should you say if you can come?","May 5",["May 10","May 1"],"Please tell us if you can come by May 5.")]},
 {pic:"🧹📋", text:"This is the chore chart on Mia's fridge. It shows who does each job.<table class=\"realtbl\"><tr><th>Day</th><th>Mia</th><th>Leo</th><th>Grandmother</th></tr><tr><td>Monday</td><td>Feed Pepper</td><td>Water plants</td><td>Fold clothes</td></tr><tr><td>Tuesday</td><td>Set the table</td><td>Feed Pepper</td><td>Water plants</td></tr><tr><td>Wednesday</td><td>Water plants</td><td>Set the table</td><td>Feed Pepper</td></tr><tr><td>Saturday</td><td>Tidy bedroom</td><td>Tidy bedroom</td><td>Rest!</td></tr></table>",
  qs:[f("Who feeds Pepper on Tuesday?","Leo",["Mia","Grandmother"],"Find Tuesday, then look in the column that says Feed Pepper: Leo."),
      f("What does Mia do on Wednesday?","Water plants",["Set the table","Feed Pepper"],"Wednesday row, Mia column: Water plants."),
      f("What does Grandmother do on Saturday?","She rests",["She tidies her bedroom","She feeds Pepper"],"Saturday row, Grandmother column: Rest!"),
      t("Why do families use a chore chart?","So everyone knows their jobs",["To draw pictures","To count the days"],"A chart makes it clear who does what, so nobody forgets.")]}
], turn:{q:"Make your own chore list. Write two jobs you could do at home this week.",model:"I can make my bed every morning. I can help set the table for dinner."}}
);

u.poems=[u.poem,{title:"Sunday Pancakes",
 lines:["Flip, flop, flip! The pancakes fly,","Up they go, up to the sky!","Dad mixes, Leo stirs the pot,","I catch the pancakes, nice and hot.","Grandma laughs and claps her hands,","Our kitchen is the best in all the lands!"],
 qs:[f("Which word rhymes with 'fly'?","sky",["flip","hot"],"Fly and sky end with the same sound: -y."),
     f("What does Grandma do?","She laughs and claps her hands",["She mixes","She stirs the pot"],"\"Grandma laughs and claps her hands.\""),
     t("Which words sound like the pancakes moving?","Flip, flop",["Laughs, claps","Mixes, stirs"],"Some words copy a sound or a movement. Flip and flop sound like pancakes turning in the pan.")]}];
})();
