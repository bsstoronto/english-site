/* ===================== GRADE 3 · UNIT 8 · AMAZING INVENTIONS (original content, plus one public-domain poem and one retold Aesop fable) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
const p=(q,a,o,why)=>({lv:"predict",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"inventions", num:8, emoji:"💡⚙️🚲", title:"Amazing Inventions", badge:"💡 Young Inventor",

stories:[
/* ---------- 1. LIFE STORY OF AN INVENTOR ---------- */
{title:"The Life of Alexander Graham Bell", e:"☎️", kind:"Life story (biography)", pages:[
 {pic:"🏴󠁧󠁢󠁳󠁣󠁴󠁿👦", text:"Alexander Graham Bell was born in Edinburgh, Scotland, in 1847. His family was very interested in sound and speech. His father taught people how to speak clearly, and his mother was almost completely deaf. Young Alexander wanted to help her hear. He often spoke close to her forehead in a low voice, so she could feel the sound.",
  qs:[f("Where was Alexander Graham Bell born?","Edinburgh, Scotland",["Toronto, Canada","London, England"],"He was born in Edinburgh, Scotland."),
      f("In which year was he born?","1847",["1947","1876"],"…in 1847."),
      t("Why was Alexander so interested in sound?","His mother was deaf and his family worked with speech",["He liked loud music","He wanted to be a singer"],"His father taught speech, and his mother was almost completely deaf.")]},
 {pic:"🐕🗣️", text:"Alexander was a curious boy who loved to experiment. When he was a teenager, he and his brother built a talking machine with a model head that could make a sound like \"Mama!\" He even tried to teach his dog to \"talk\" by moving its mouth while it growled. The dog seemed to say \"How are you, Grandma?\" The neighbours were amazed!",
  qs:[f("What did Alexander and his brother build?","A talking machine",["A boat","A telephone"],"He and his brother built a talking machine."),
      t("What do these stories show about young Alexander?","He was curious and loved to experiment",["He was lazy","He didn't like animals"],"Building a talking machine and teaching his dog are experiments.")]},
 {pic:"🍁🏡", text:"In 1870, when Alexander was 23, his family moved to Canada. They lived in Brantford, Ontario. The next year, he went to Boston, in the United States, to teach deaf students how to speak. He was a kind and patient teacher. At night, he worked on a new idea: could a wire carry a person's voice from one place to another?",
  qs:[f("Where did the Bell family live in Canada?","Brantford, Ontario",["Vancouver","Montreal"],"They lived in Brantford, Ontario."),
      f("Who did Alexander teach in Boston?","Deaf students",["Pilots","Doctors"],"He went to Boston… to teach deaf students how to speak."),
      p("What do you think Alexander's new idea will become?","The telephone",["The light bulb","The airplane"],"A wire that carries a voice from one place to another is a telephone!")]},
 {pic:"☎️⚡", text:"Alexander worked with a helper named Thomas Watson. For months, their experiments failed. But they did not give up. On March 10, 1876, Alexander spoke into his machine: \"Mr. Watson, come here. I want to see you.\" In the next room, Watson heard the words through the wire! It was the first telephone call. Alexander was only 29 years old.",
  qs:[f("Who was Alexander's helper?","Thomas Watson",["Thomas Edison","His brother"],"Alexander worked with a helper named Thomas Watson."),
      f("What were the first words on the telephone?","\"Mr. Watson, come here. I want to see you.\"",["\"Hello, world!\"","\"Can you hear me?\""],"Alexander spoke into his machine: \"Mr. Watson, come here. I want to see you.\""),
      t("What does this page teach us about inventing?","Inventors often fail many times before they succeed",["Inventions always work the first time","Inventors work alone"],"For months, their experiments failed. But they did not give up.")]},
 {pic:"📞🌍", text:"Soon, telephones spread across the world. People could talk to friends and family far away. Later in his life, Alexander spent his summers in Baddeck, Nova Scotia. There, he kept inventing: kites big enough to carry a person, and a very fast boat that skimmed above the water. He also kept helping deaf people. Alexander Graham Bell died in 1922. On the day of his funeral, telephones across North America were silent for one minute to honour him.",
  qs:[f("Where did Alexander spend his summers later in life?","Baddeck, Nova Scotia",["Edinburgh","Boston"],"Alexander spent his summers in Baddeck, Nova Scotia."),
      f("What happened on the day of his funeral?","Telephones were silent for one minute",["Everyone made a phone call","Kites flew over Canada"],"Telephones across North America were silent for one minute to honour him."),
      t("Put these events in order: (1) the first phone call, (2) moving to Canada, (3) being born in Scotland.","3, 2, 1",["1, 2, 3","2, 3, 1"],"Born 1847 → moved to Canada 1870 → first phone call 1876."),
      t("Which words best describe Alexander Graham Bell?","Curious, determined and kind",["Lazy and unkind","Bored and careless"],"He experimented, never gave up, and helped deaf people all his life.")]}
], turn:{q:"Imagine you could phone any inventor from history. Who would you call, and what would you ask? Write two sentences.",model:"I would call Alexander Graham Bell. I would ask him how he felt when Mr. Watson heard his voice."}},

/* ---------- 2. TRUE STORY ---------- */
{title:"The Boy Who Caught the Wind", e:"🌬️", kind:"True story", pages:[
 {pic:"🇲🇼🌽", text:"William Kamkwamba grew up in a small village in Malawi, a country in Africa. His family were farmers who grew maize, a kind of corn. In 2001, when William was about 14, there was very little rain. The crops died, and many families did not have enough food. William's family could not pay his school fees, so he had to leave school.",
  qs:[f("Which country did William grow up in?","Malawi",["Canada","India"],"…a small village in Malawi, a country in Africa."),
      f("What did William's family grow?","Maize (a kind of corn)",["Rice","Apples"],"His family were farmers who grew maize."),
      t("Why did William have to leave school?","His family could not pay the school fees",["He didn't like school","The school burned down"],"William's family could not pay his school fees.")]},
 {pic:"📚🔍", text:"William was sad, but he did not stop learning. He walked to a small library near his village. There, he found a science book with a picture of a windmill on the cover. He couldn't read all the English words, so he studied the pictures and diagrams carefully. He learned that a windmill could turn wind into electricity.",
  qs:[f("Where did William keep learning?","At a small library",["At a big university","On a farm only"],"He walked to a small library near his village."),
      f("What was on the cover of the book?","A windmill",["A rocket","A telephone"],"…a science book with a picture of a windmill on the cover."),
      t("How did William understand the book when he couldn't read all the words?","He studied the pictures and diagrams",["He asked the windmill","He guessed everything"],"He studied the pictures and diagrams carefully."),
      p("What do you think William will try to do?","Build his own windmill",["Sell the book","Give up and go to sleep"],"He just learned that a windmill can make electricity.")]},
 {pic:"🚲🔧", text:"William decided to build a windmill himself. He had no money, so he searched the scrapyard for old parts. He found a broken bicycle, the fan from an old tractor, plastic pipes and wires. He cut the pipes to make blades. He built a tall tower from tree trunks. Some people in the village laughed at him. They thought he was wasting his time.",
  qs:[f("Where did William find parts?","At the scrapyard",["At a big shop","In the library"],"He searched the scrapyard for old parts."),
      f("What did he use to make the blades?","Plastic pipes",["Paper","Leaves"],"He cut the pipes to make blades."),
      t("Why did some people laugh at William?","They thought he was wasting his time",["He told a funny joke","His windmill was pink"],"They thought he was wasting his time.")]},
 {pic:"💡😃", text:"At last, the windmill was ready. William climbed the tower and connected the wires. The wind blew, the blades began to spin, and a small light bulb flickered and then glowed brightly! Now his family had light at night, and William could read after dark. Later, he built another windmill to pump water for the village gardens.",
  qs:[f("What happened when the blades began to spin?","A light bulb glowed",["The tower fell down","It started to rain"],"A small light bulb flickered and then glowed brightly!"),
      f("What did his second windmill do?","Pumped water for the village gardens",["Made ice cream","Played music"],"He built another windmill to pump water for the village gardens."),
      t("How do you think the people who laughed felt now?","Surprised and impressed",["Bored","Angry at the wind"],"His windmill really worked and helped everyone.")]},
 {pic:"🌍🎤", text:"News of William's windmill spread around the world. He was invited to speak to scientists and inventors in other countries. He went back to school and later studied at a university in the United States. Today, he helps young people in Africa learn science and build their own inventions. His message is simple: <i>\"Trust yourself and believe. Whatever happens, don't give up.\"</i>",
  qs:[f("What is William's message?","\"Trust yourself and believe. Whatever happens, don't give up.\"",["\"Always laugh at others.\"","\"Windmills are boring.\""],"His message is simple: \"Trust yourself and believe. Whatever happens, don't give up.\""),
      t("What is the most important lesson from William's story?","You can solve big problems with curiosity and hard work",["You need lots of money to invent","Libraries are useless"],"William had no money, but he used books, scrap and determination."),
      t("How is William like Alexander Graham Bell?","Both kept trying and used their inventions to help people",["Both were born in Scotland","Both invented the telephone"],"Both were curious, didn't give up, and helped others.")]}
], turn:{q:"William used old, broken things to build something new. What could you build from things in your recycling bin? Write two or three sentences.",model:"I could build a bird feeder from an old plastic bottle. I would cut a hole in the side and fill it with seeds. Then I would hang it on a tree."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"Inventions That Changed the World", e:"⚙️", kind:"Fact text", pages:[
 {pic:"🛞🏺", text:"One of the most important inventions is the <b>wheel</b>. People in Mesopotamia, in the land that is now Iraq, were using wheels more than 5,000 years ago. At first, wheels were used to make pottery. Later, people put wheels on carts so they could carry heavy loads. Today, wheels are on cars, bicycles, trains, planes and even suitcases!",
  qs:[f("Where were wheels used more than 5,000 years ago?","Mesopotamia (now Iraq)",["Canada","Japan"],"People in Mesopotamia, in the land that is now Iraq…"),
      f("What were the first wheels used for?","Making pottery",["Cars","Bicycles"],"At first, wheels were used to make pottery."),
      t("Why was putting wheels on carts so useful?","People could carry heavy loads more easily",["Carts looked prettier","Wheels made carts fly"],"Wheels let people move heavy things without carrying them.")]},
 {pic:"📜🖨️", text:"About 2,000 years ago in China, an official named Cai Lun improved a way to make <b>paper</b> from tree bark, old rags and plants. Paper was cheaper and lighter than writing on silk or bamboo. Much later, around 1440, Johannes Gutenberg in Germany built a <b>printing press</b> that could print pages quickly. Before that, every book had to be copied by hand!",
  qs:[f("Where was paper-making improved about 2,000 years ago?","China",["Germany","Egypt"],"About 2,000 years ago in China, an official named Cai Lun…"),
      f("Who built the printing press around 1440?","Johannes Gutenberg",["Cai Lun","Thomas Watson"],"Johannes Gutenberg in Germany built a printing press."),
      t("How were books made before the printing press?","They were copied by hand",["Computers printed them","They were painted on walls"],"Before that, every book had to be copied by hand!"),
      t("Why did the printing press help people learn?","Books became cheaper and easier to get",["Books got heavier","People stopped reading"],"When books can be printed quickly, more people can own and read them.")]},
 {pic:"💡🌃", text:"For thousands of years, people used fire, candles and oil lamps to see at night. In the 1800s, many inventors worked on <b>electric light</b>. In 1879, Thomas Edison and his team made a light bulb that could glow for many hours. Soon, cities began to use electric lights. Streets became safer, and people could read, work and play after dark.",
  qs:[f("What did people use for light before electric lights?","Fire, candles and oil lamps",["Phones","Television"],"People used fire, candles and oil lamps to see at night."),
      f("In which year did Edison's team make a long-lasting light bulb?","1879",["1440","1903"],"In 1879, Thomas Edison and his team made a light bulb…"),
      t("Why did many inventors work on electric light, not just one?","Big inventions often need many people's ideas",["Only one person was allowed","Light bulbs are easy"],"In the 1800s, many inventors worked on electric light. Edison built on their work.")]},
 {pic:"✈️👬", text:"People dreamed of flying for thousands of years. In 1903, two American brothers, Orville and Wilbur Wright, flew the first powered airplane. The first flight lasted only 12 seconds! The brothers owned a bicycle shop, and they used what they knew about balance and machines to build their plane. Today, planes carry millions of people around the world every day.",
  qs:[f("Who flew the first powered airplane?","Orville and Wilbur Wright",["Alexander Graham Bell","Thomas Edison"],"…Orville and Wilbur Wright, flew the first powered airplane."),
      f("How long did the first flight last?","12 seconds",["12 hours","12 days"],"The first flight lasted only 12 seconds!"),
      t("How did the bicycle shop help the Wright brothers?","They already knew about balance and machines",["They sold bikes to buy a plane","Bicycles can fly"],"They used what they knew about balance and machines.")]},
 {pic:"💻🌐", text:"In 1989, a British scientist named Tim Berners-Lee invented the <b>World Wide Web</b>, a way to share pages of information on computers connected by the internet. He decided not to sell it, so that everyone could use it for free. Today, people use the web to learn, talk to friends and find information in seconds. Every invention on this page started with someone asking: <i>How can we make life better?</i>",
  qs:[f("Who invented the World Wide Web?","Tim Berners-Lee",["The Wright brothers","Johannes Gutenberg"],"…a British scientist named Tim Berners-Lee invented the World Wide Web."),
      f("Why can everyone use the web for free?","He decided not to sell it",["It was too expensive to sell","Nobody wanted it"],"He decided not to sell it, so that everyone could use it for free."),
      t("What is the main idea of this whole text?","Some inventions changed how everyone lives",["Wheels are round","Only one person invents things"],"Wheels, paper, light, planes and the web all changed the world.")]}
], turn:{q:"Which invention on these pages do you think is the most important? Write two sentences and use because.",model:"I think the printing press is the most important invention. It is important because it helped millions of people learn to read."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"Inventions from Canada and India", e:"🍁", kind:"Fact text", pages:[
 {pic:"🏀🍁", text:"Did you know that <b>basketball</b> was invented by a Canadian? In 1891, James Naismith, a teacher from Ontario, was working at a school in Massachusetts, in the United States. His students needed a game to play indoors during the cold winter. He nailed two peach baskets to the walls and wrote 13 rules. The first players had to climb a ladder to get the ball out of the basket!",
  qs:[f("Who invented basketball?","James Naismith",["Alexander Graham Bell","Thomas Edison"],"James Naismith, a teacher from Ontario…"),
      f("What did he use as the first baskets?","Peach baskets",["Buckets","Hats"],"He nailed two peach baskets to the walls."),
      t("Why did his students need a new game?","They needed to play indoors in the cold winter",["They were bored of reading","Their football broke"],"His students needed a game to play indoors during the cold winter.")]},
 {pic:"🧪💉", text:"In 1921, at the University of Toronto, Frederick Banting and Charles Best discovered how to make <b>insulin</b> into a medicine. Before that, people with a sickness called diabetes could become very ill. Insulin has saved millions of lives around the world. Banting and his team sold the rights to the university for just one dollar each, because they wanted the medicine to help everyone.",
  qs:[f("Where was insulin made into a medicine?","The University of Toronto",["A farm in India","A school in Scotland"],"…at the University of Toronto…"),
      f("For how much did Banting and his team sell the rights?","One dollar each",["One million dollars","Nothing at all"],"…for just one dollar each."),
      t("Why did they sell the rights so cheaply?","They wanted the medicine to help everyone",["They didn't like money","Insulin was useless"],"Because they wanted the medicine to help everyone.")]},
 {pic:"❄️🛷", text:"Canada is cold and snowy, so many Canadian inventions help people in winter. In Quebec, Joseph-Armand Bombardier built vehicles that could travel over deep snow. In 1959, his company made a small, fast <b>snowmobile</b>. Today, snowmobiles help people in the North travel, deliver supplies and reach places with no roads.",
  qs:[f("Who built vehicles that could travel over deep snow?","Joseph-Armand Bombardier",["James Naismith","Charles Best"],"In Quebec, Joseph-Armand Bombardier built vehicles…"),
      t("Why do so many Canadian inventions help in winter?","Canada is cold and snowy",["Canada has no summer","Canadians don't like walking"],"Canada is cold and snowy, so many Canadian inventions help people in winter.")]},
 {pic:"♟️🇮🇳", text:"Ancient India gave the world many ideas too. An early form of <b>chess</b>, called chaturanga, was played in India about 1,500 years ago. It had pieces for foot soldiers, horses, elephants and chariots. The game travelled to Persia and then to Europe, where it slowly changed into the chess we play today. Long before that, people in the Indus Valley used <b>rulers</b> with careful markings and made buttons from shells.",
  qs:[f("What was the early form of chess called?","Chaturanga",["Cricket","Kabaddi"],"An early form of chess, called chaturanga…"),
      f("Which animals were pieces in chaturanga?","Horses and elephants",["Lions and tigers","Cats and dogs"],"It had pieces for foot soldiers, horses, elephants and chariots."),
      t("How did chess reach Europe?","It travelled through Persia and changed over time",["Someone posted it","It was invented in Europe first"],"The game travelled to Persia and then to Europe.")]},
 {pic:"🧴🗣️", text:"Even the word <b>shampoo</b> comes from India! It comes from a Hindi word, <i>champo</i>, which means to press or massage. In the 1700s and 1800s, people in India washed and massaged their hair with oils and plants. Travellers took the idea to Britain, and the word became part of English. Inventions are not only machines. They can be games, medicines, ideas and even words!",
  qs:[f("Which language does the word 'shampoo' come from?","Hindi",["French","Japanese"],"It comes from a Hindi word, champo."),
      f("What does 'champo' mean?","To press or massage",["To swim","To laugh"],"…champo, which means to press or massage."),
      t("What is the main idea of the last sentence?","Inventions can be many things, not only machines",["Only machines are inventions","Words are boring"],"Inventions are not only machines. They can be games, medicines, ideas and even words!")]}
], turn:{q:"Which invention from these pages do you use or enjoy? Write two sentences about it.",model:"I love playing basketball with my friends. It is fun because we can play indoors when it is cold."}},

/* ---------- 5. FABLE ---------- */
{title:"The Crow and the Pitcher (an Aesop fable, retold)", e:"🐦‍⬛", kind:"Fable", pages:[
 {pic:"☀️🐦‍⬛", text:"It was the hottest day of the summer. The sun beat down on the dry fields, and there was not a drop of rain anywhere. A crow had been flying for hours. Her throat was so dry that she could hardly caw. \"I must find water soon,\" she thought, \"or I will not be able to fly any farther.\"",
  qs:[f("What was the weather like?","Very hot and dry",["Cold and snowy","Rainy and windy"],"It was the hottest day of the summer."),
      f("What did the crow need?","Water",["Food","A nest"],"\"I must find water soon.\""),
      p("What do you think will happen next?","She will find some water, but there will be a problem",["She will fall asleep","It will snow"],"Fables usually give the character a problem to solve.")]},
 {pic:"🏺💧", text:"At last, the crow saw a tall clay pitcher standing in a garden. She flew down and looked inside. There was water at the bottom! But the pitcher was tall and narrow, and the water was very low. She pushed her beak in as far as it would go, but she could not reach the water.",
  qs:[f("Where was the water?","At the bottom of a tall pitcher",["In a river","In a puddle"],"There was water at the bottom!"),
      t("What was the crow's problem?","Her beak could not reach the low water",["The water was too hot","The pitcher was empty"],"The water was very low… she could not reach the water.")]},
 {pic:"🤔🐦‍⬛", text:"The crow tried to tip the pitcher over, but it was too heavy. She pecked at the clay, but it was too strong. She almost gave up. Then she stopped and looked around. On the ground, there were lots of small pebbles. The crow tilted her head and thought very hard.",
  qs:[f("What did the crow try first?","To tip the pitcher over",["To fly away","To call for help"],"The crow tried to tip the pitcher over."),
      t("What did the crow do when her first ideas failed?","She stopped, looked around and thought",["She cried","She went to sleep"],"She stopped and looked around… and thought very hard."),
      p("How do you think the pebbles will help?","She will drop them into the pitcher to raise the water",["She will eat them","She will throw them at the pitcher"],"Think about what happens when you drop things into water.")]},
 {pic:"🪨💧", text:"One by one, the crow picked up the pebbles in her beak and dropped them into the pitcher. Plop! Plop! Plop! With every pebble, the water rose a little higher. It took a long time, but she kept going. At last, the water rose so high that she could drink. The crow drank and drank until she felt strong again.",
  qs:[f("What happened each time she dropped a pebble?","The water rose a little higher",["The pitcher broke","The water disappeared"],"With every pebble, the water rose a little higher."),
      t("Why did the water rise?","The pebbles took up space at the bottom",["The pebbles were made of water","It started to rain"],"The pebbles push the water up because they take up space."),
      t("Which word describes the crow?","Clever and patient",["Lazy and rude","Silly and careless"],"She thought of a smart idea and kept going for a long time.")]},
 {pic:"🧠✨", text:"The crow flew off happily into the blue sky. She had not been the biggest or the strongest bird, but she had used her brain. Scientists today have tested this with real crows and ravens, and many of them can solve the same puzzle! <b>Lesson: Little by little does the trick. When you have a problem, think it through.</b>",
  qs:[t("What is the lesson of this fable?","Little by little does the trick: think problems through",["Crows are noisy","Always take the easy way"],"The crow solved her problem with thinking and patience."),
      f("What have scientists found out about real crows?","Many can solve the same puzzle",["They cannot drink water","They are afraid of pebbles"],"…many of them can solve the same puzzle!"),
      t("How is the crow like an inventor?","She found a new way to solve a problem",["She built a telephone","She sold pebbles"],"Inventors look at a problem, try ideas, and find a clever solution.")]}
], turn:{q:"Write about a time you solved a problem by thinking carefully. What was the problem? What did you do?",model:"My kite was stuck in a tree. I tied my scarf to a long stick and gently pushed the kite until it fell down."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: Instructions and an invention fair poster", e:"📋", kind:"Real-world text", pages:[
 {pic:"🥤📞", text:"Here are instructions for a simple invention you can make at home.<div class=\"realdoc\" style=\"text-align:left\"><b>📞 How to Make a Cup Telephone</b><br><b>You will need:</b> 2 paper cups · a long piece of string (about 5 metres) · a sharp pencil · 2 paper clips<br><br><b>Steps:</b><br>1. Ask a grown-up to make a small hole in the bottom of each cup with the pencil.<br>2. Push one end of the string through the hole in the first cup.<br>3. Tie the string to a paper clip inside the cup, so it can't slip out.<br>4. Do the same with the second cup.<br>5. Walk apart until the string is pulled tight.<br>6. One person talks into a cup. The other person holds the other cup to their ear.<br><br><b>Why does it work?</b> Your voice makes the string <b>vibrate</b> (shake very fast). The vibrations travel along the string to the other cup.</div>",
  qs:[f("How many paper cups do you need?","2",["1","5"],"You will need: 2 paper cups…"),
      f("What do you do right after pushing the string through the hole?","Tie it to a paper clip inside the cup",["Walk apart","Talk into the cup"],"Step 3: Tie the string to a paper clip inside the cup."),
      t("Why must the string be pulled tight?","The vibrations travel best along a tight string",["So it looks neat","So the cups don't get wet"],"Vibrations travel along the string. A loose string doesn't carry them well."),
      t("Why does step 1 say to ask a grown-up?","Making a hole with a sharp pencil can be dangerous",["Grown-ups like cups","Children can't hold cups"],"Safety first with sharp things."),
      t("Which real invention works in a similar way?","The telephone",["The wheel","The printing press"],"Both carry the sound of a voice from one place to another.")]},
 {pic:"🏆🔬", text:"This poster is on the wall at Maple Street School.<div class=\"realdoc\"><b>💡 GRADE 3 INVENTION FAIR 💡</b><br>Thursday, May 14 · 1:00 to 3:00 p.m. · School Gym<br><br>Bring an invention that solves a problem!<br>✔ Your invention must be safe.<br>✔ Make a poster that shows: the <b>problem</b>, your <b>idea</b>, and <b>how it works</b>.<br>✔ Use recycled materials if you can.<br><br>🏅 Prizes: Most Useful · Most Creative · Best Use of Recycling<br><i>Families are welcome! Free entry.</i></div>",
  qs:[f("Where is the invention fair?","In the school gym",["In the library","At the park"],"School Gym"),
      f("What three things must the poster show?","The problem, your idea and how it works",["Your name, age and address","A picture of the teacher"],"Make a poster that shows: the problem, your idea, and how it works."),
      t("How long does the invention fair last?","Two hours",["One hour","All day"],"1:00 to 3:00 p.m. is two hours."),
      t("Which invention could win 'Best Use of Recycling'?","A pencil holder made from old cans",["A brand-new toy from a shop","A drawing of a robot"],"It uses recycled materials."),
      f("How much does it cost for families to come?","Nothing, it is free",["One dollar","Ten dollars"],"Families are welcome! Free entry.")]}
], turn:{q:"What invention would you bring to the invention fair? Write the problem and your idea.",model:"The problem is that my little brother loses his socks. My idea is a sock clip that keeps pairs together in the wash."}}
],

poems:[
 {title:"The Lamplighter (by Robert Louis Stevenson, 1885)",
  lines:["My tea is nearly ready and the sun has left the sky;","It's time to take the window to see Leerie going by;","For every night at teatime and before you take your seat,","With lantern and with ladder he comes posting up the street.","","Now Tom would be a driver and Maria go to sea,","And my papa's a banker and as rich as he can be;","But I, when I am stronger and can choose what I'm to do,","O Leerie, I'll go round at night and light the lamps with you!","","For we are very lucky, with a lamp before the door,","And Leerie stops to light it as he lights so many more;","And O! before you hurry by with ladder and with light,","O Leerie, see a little child and nod to him to-night!"],
  qs:[f("What is Leerie's job?","He lights the street lamps",["He drives a bus","He is a banker"],"\"O Leerie, I'll go round at night and light the lamps with you!\""),
      f("What does Leerie carry?","A lantern and a ladder",["A telephone","A basket of bread"],"\"With lantern and with ladder he comes posting up the street.\""),
      t("Why was there a lamplighter long ago?","Street lamps had to be lit by hand before electric lights",["People liked ladders","There was no Sun"],"Before electric street lights, someone had to light each gas lamp every evening."),
      t("What does the child want to be when he grows up?","A lamplighter",["A banker","A sailor"],"\"But I… O Leerie, I'll go round at night and light the lamps with you!\""),
      f("Which word rhymes with 'sky'?","by",["street","door"],"Sky and by end with the same sound.")]},
 {title:"If I Could Invent",
  lines:["If I could invent, I'd invent a machine","That tidies my bedroom and keeps it so clean.","I'd build a small robot that ties up my shoes,","And a hat that would tell me the weather and news.","I'd make an umbrella that flies over me,","And shoes with long springs to jump up to a tree.","But first I would sketch it, then test it, then try,","Like every inventor who dreams to the sky!"],
  qs:[f("What would the machine in the first lines do?","Tidy the bedroom",["Make dinner","Fly to the Moon"],"\"…a machine that tidies my bedroom and keeps it so clean.\""),
      f("Which word rhymes with 'shoes'?","news",["hat","tree"],"Shoes and news end with the same sound."),
      t("What steps does the poet say every inventor follows?","Sketch it, test it, then try",["Buy it, sell it, forget it","Sleep, eat, play"],"\"But first I would sketch it, then test it, then try.\"")]}
],

words:[
 /* inventing */
 {w:"invent",e:"💡",m:"to make or think of something new that did not exist before",ex:"Alexander Graham Bell helped invent the telephone.",fill:"I want to ___ a robot that does my homework."},
 {w:"inventor",e:"👩‍🔬",m:"a person who invents something new",ex:"The inventor tested her machine again and again.",fill:"An ___ is a person who creates new things."},
 {w:"idea",e:"💭",m:"a thought or a plan in your mind",ex:"William had an idea to build a windmill.",fill:"I have a great ___ for the science fair!"},
 {w:"design",e:"✏️",m:"a drawing or plan that shows how something will look or work",ex:"She drew a design for her new bike.",fill:"Draw a ___ before you start to build."},
 {w:"model",e:"🛩️",m:"a small copy of something bigger",ex:"Leo built a model of an airplane.",fill:"We made a ___ of a windmill out of paper."},
 {w:"experiment",e:"🧪",m:"a test to find out what happens or whether an idea works",ex:"Bell did many experiments with sound.",fill:"We did an ___ to see which paper plane flew farthest."},
 {w:"test",e:"✅",m:"to try something to see if it works",ex:"The Wright brothers tested their plane many times.",fill:"Always ___ your invention before you show it."},
 {w:"improve",e:"📈",m:"to make something better",ex:"Inventors keep trying to improve their machines.",fill:"I practise every day to ___ my reading."},
 {w:"patent",e:"📜",m:"an official paper that says only the inventor may make and sell an invention for some years",ex:"Margaret Knight got a patent for her paper bag machine.",fill:"An inventor can get a ___ so nobody can copy the idea."},
 {w:"solution",e:"🔑",m:"an answer to a problem",ex:"Using pebbles was the crow's solution.",fill:"We need a ___ to this problem."},
 /* machines and technology */
 {w:"machine",e:"🛠️",m:"a thing with moving parts that does work",ex:"A washing machine cleans our clothes.",fill:"This ___ can make one hundred paper bags a minute."},
 {w:"engine",e:"🚂",m:"the part of a vehicle that makes it move",ex:"The train's engine roared.",fill:"The car would not start because the ___ was broken."},
 {w:"wheel",e:"🛞",m:"a round object that turns to help things move",ex:"The wheel is one of the oldest inventions.",fill:"My bicycle has a flat ___."},
 {w:"gear",e:"⚙️",m:"a wheel with teeth that turns another wheel in a machine",ex:"The gears inside the clock turn slowly.",fill:"Change ___ to ride your bike up the hill."},
 {w:"battery",e:"🔋",m:"a small object that stores electricity",ex:"My flashlight needs a new battery.",fill:"The toy stopped because the ___ was empty."},
 {w:"electricity",e:"⚡",m:"a kind of energy that makes lights, machines and computers work",ex:"William's windmill made electricity.",fill:"Lamps and fridges need ___ to work."},
 {w:"telephone",e:"☎️",m:"a machine that lets you talk to someone far away",ex:"Bell made the first telephone call in 1876.",fill:"Grandma called us on the ___."},
 {w:"computer",e:"💻",m:"an electronic machine that stores information and follows instructions",ex:"We used a computer to find information.",fill:"I typed my story on the ___."},
 {w:"robot",e:"🤖",m:"a machine that can do jobs by itself",ex:"The robot cleaned the floor.",fill:"A ___ can build cars in a factory."},
 {w:"bulb",e:"💡",m:"the glass part of an electric lamp that gives light",ex:"The light bulb glowed brightly.",fill:"Change the light ___, please; it is broken."},
 /* history and people */
 {w:"history",e:"🏛️",m:"everything that happened in the past",ex:"The telephone is an important part of history.",fill:"In ___ class, we learn about the past."},
 {w:"ancient",e:"🏺",m:"very, very old; from a long time ago",ex:"Ancient people in Mesopotamia used wheels.",fill:"We saw ___ pots in the museum."},
 {w:"modern",e:"📱",m:"new; from the present time",ex:"A smartphone is a modern invention.",fill:"Our school has a ___ science lab with new computers."},
 {w:"discover",e:"🔍",m:"to find something for the first time",ex:"Banting and Best discovered how to make insulin a medicine.",fill:"Scientists hope to ___ new medicines."},
 {w:"create",e:"🎨",m:"to make something new",ex:"Artists and inventors create new things.",fill:"Let's ___ a poster for the fair."},
 {w:"library",e:"📚",m:"a place where you can read and borrow books",ex:"William learned about windmills at the library.",fill:"I borrowed three books from the ___."},
 {w:"factory",e:"🏭",m:"a building where things are made by machines",ex:"Margaret Knight worked in a factory.",fill:"Cars are built in a ___."},
 {w:"famous",e:"🌟",m:"known by many people",ex:"Thomas Edison is a famous inventor.",fill:"The ___ singer waved to the crowd."},
 {w:"problem",e:"❓",m:"something difficult that needs to be solved",ex:"The crow's problem was the low water.",fill:"Every invention starts with a ___ to solve."},
 {w:"tool",e:"🔧",m:"something you hold in your hand to help you do a job",ex:"A hammer is a useful tool.",fill:"Use the right ___ to fix the bike."},
 /* describing and doing */
 {w:"clever",e:"🧠",m:"quick to learn and good at thinking",ex:"The clever crow used pebbles.",fill:"That was a ___ idea!"},
 {w:"useful",e:"👍",m:"helpful; good for doing something",ex:"A wheel is a very useful invention.",fill:"A pencil is ___ for writing."},
 {w:"powerful",e:"💪",m:"very strong",ex:"The rocket has a powerful engine.",fill:"The ___ wind turned the windmill fast."},
 {w:"simple",e:"🟢",m:"easy to understand or do; not complicated",ex:"A cup telephone is a simple invention.",fill:"The instructions were ___, so I finished quickly."},
 {w:"complicated",e:"🧩",m:"having many parts; hard to understand",ex:"A computer is very complicated inside.",fill:"This puzzle is too ___ for me."},
 {w:"successful",e:"🏆",m:"doing well; getting what you wanted",ex:"After many tries, the experiment was successful.",fill:"The bake sale was ___; we raised fifty dollars."},
 {w:"determined",e:"😤",m:"not giving up, even when something is hard",ex:"William was determined to build his windmill.",fill:"She was ___ to finish the race."},
 {w:"brilliant",e:"✨",m:"very clever, or very bright",ex:"Using pebbles was a brilliant idea.",fill:"What a ___ invention!"},
 {w:"ordinary",e:"🥄",m:"normal; not special",ex:"He made a windmill from ordinary scrap.",fill:"It looked like an ___ box, but it was a secret machine."},
 {w:"connect",e:"🔌",m:"to join two things together",ex:"William connected the wires to the bulb.",fill:"___ the string to the paper cup."}
],

spelling:[
 {w:"invent",s:"I want to invent a robot."},
 {w:"machine",s:"The machine makes paper bags.",tip:"'ch' sounds like 'sh': ma-chine."},
 {w:"wheel",s:"The wheel is round.",tip:"'wh' at the start, double e."},
 {w:"engine",s:"The engine is loud.",tip:"en-gine. The 'g' sounds like 'j'."},
 {w:"idea",s:"I have an idea!",tip:"i-de-a."},
 {w:"light",s:"Turn on the light.",tip:"'igh' says long i."},
 {w:"phone",s:"The phone is ringing.",tip:"'ph' sounds like 'f'. Magic e at the end."},
 {w:"build",s:"Let's build a windmill.",tip:"'ui' sounds like short i: b-ui-ld."},
 {w:"robot",s:"The robot can walk."},
 {w:"battery",s:"The battery is empty.",tip:"Double t, ends with -ery."},
 {w:"design",s:"Draw a design first.",tip:"The 'g' is silent: de-si-g-n."},
 {w:"simple",s:"The answer is simple.",tip:"Ends with -le."},
 {w:"useful",s:"A wheel is useful.",tip:"use + ful (only one l)."},
 {w:"power",s:"The windmill makes power.",tip:"'ow' as in cow."},
 {w:"model",s:"I built a model plane.",tip:"Ends with -el."}
],

facts:[
 {e:"🛞",c:"The wheel is more than 5,000 years old.",t:true,x:"True! People in Mesopotamia used wheels more than 5,000 years ago, first for making pots and later on carts."},
 {e:"☎️",c:"The first telephone call was made in 1976.",t:false,x:"Not true! Alexander Graham Bell made the first telephone call in 1876, one hundred years earlier."},
 {e:"🏀",c:"Basketball was invented by a Canadian.",t:true,x:"True! James Naismith, from Ontario, invented basketball in 1891."},
 {e:"✈️",c:"The Wright brothers' first flight lasted 12 hours.",t:false,x:"Not true! It lasted only 12 seconds. But it was the start of flying."},
 {e:"📜",c:"Paper-making was improved in China about 2,000 years ago.",t:true,x:"True! Cai Lun improved a way to make paper from bark, rags and plants."},
 {e:"🖨️",c:"Before the printing press, books were copied by hand.",t:true,x:"True! It could take months to copy one book."},
 {e:"🔤",c:"Braille, the reading system for blind people, was invented by a teenager.",t:true,x:"True! Louis Braille, from France, created it when he was about 15 years old."},
 {e:"💉",c:"Insulin was first made into a medicine in Toronto.",t:true,x:"True! Banting and Best did this at the University of Toronto in 1921."},
 {e:"🌐",c:"The inventor of the World Wide Web sold it for a lot of money.",t:false,x:"Not true! Tim Berners-Lee gave it to the world for free."},
 {e:"🚗",c:"Windshield wipers were invented by a woman.",t:true,x:"True! Mary Anderson got a patent for windshield wipers in 1903."},
 {e:"🐦‍⬛",c:"Some real crows can solve the pebble-in-water puzzle.",t:true,x:"True! Scientists have tested it, and many crows and ravens drop stones in to raise the water."},
 {e:"🍪",c:"Every invention is a big, complicated machine.",t:false,x:"Not true! Inventions can be small and simple, like a paper clip, a zipper or a new game."}
],

writing:[
 {e:"🔌",t:"An invention I use every day",level:"Step 1 · Sentences",
  prompt:"Choose an invention you use every day (a bicycle, a fridge, a pencil, a light bulb…). Write at least 4 sentences: what it is, what it does, and why it is useful. Use the joining words because and so. Use at least 2 words from the word bank.",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["\\bbecause\\b","I used because"],["\\bso\\b","I used so"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["An invention I use every day is ","It helps me ","It is useful because ","so "],
  model:"An invention I use every day is the light bulb. It gives us light when it is dark outside. It is useful because I can read and do my homework at night. Before electricity, people used candles, so light bulbs made homes much safer. I think it is a brilliant invention."},
 {e:"🧩",t:"Problem and solution",level:"Step 2 · Planning an invention",
  prompt:"Think of a problem you or your family have. Then think of an invention that could solve it. Write at least 5 sentences. Use and, but, because and so to join your ideas.",
  minS:5,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["\\b[Pp]roblem\\b","I named the problem"],["\\band\\b","I used and"],["\\bbut\\b","I used but"],["\\bbecause\\b","I used because"],["\\bso\\b","I used so"]],
  starters:["One problem in my home is ","It is a problem because ","My idea is ","It would work because ","so "],
  model:"One problem in my home is that my grandma can't reach the top shelf. It is a problem because she has to stand on a chair, but that is unsafe. My idea is a shelf that moves down when you press a button. It would have a small, powerful motor and a strong gear. Grandma could reach her jars easily, so she would be safe and happy."},
 {e:"📝",t:"Report: My Invention",level:"Step 3 · Report",
  prompt:"Write a report about an invention you would like to create. Write at least 8 sentences in four parts: 1) the name of your invention, 2) the problem it solves, 3) how it works (its parts), and 4) why it would be useful. Use was or were if you write about the past, and use joining words.",
  minS:8,minWords:3,
  rx:[["\\b(My invention is called|My invention is named|I would invent|I want to invent)\\b","I named my invention"],["\\b[Pp]roblem\\b","I wrote about the problem"],["\\b(works|parts|has a|uses|button|motor|wheel|battery|gear)\\b","I explained how it works"],["\\b(useful|help|helps|would help)\\b","I explained why it is useful"],["\\bbecause\\b","I used because"],["\\b(and|but|so)\\b","I used and, but or so"],["[.!?]\\s*$","I ended with a full stop"]],
  starters:["My invention is called ","The problem is that ","It works like this: ","It has ","It would be useful because ","In the future, "],
  model:"My invention is called the Plant Pal. The problem is that many people forget to water their plants, so the plants wilt. It works like this: a small sensor in the soil checks if the soil is dry. If it is dry, a tiny pump gives the plant some water from a bottle. It has a battery and a small solar panel, so it doesn't need a plug. It also beeps when the bottle is empty. It would be useful because plants would stay healthy, even when families go on holiday. It is a simple machine, but I think it would help many people and their plants."}
]
});
})();
