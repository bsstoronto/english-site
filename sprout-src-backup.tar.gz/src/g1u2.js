/* ===================== GRADE 1 · UNIT 2 · MY SCHOOL ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:1,id:"g1_school",num:2,emoji:"🏫🎒✏️",title:"My School",short:"short a, nouns, sight words",badge:"🏫 School Star",
stories:[
/* 1 STORY: PROBLEM AND HAPPY ENDING */
{title:"Where Is My Bag?",e:"🎒",kind:"Story",pages:[
 {pic:"🏫🎒",text:"It is the first day of school. Pam has a new red bag. It has a cat tag on it. Pam puts her bag on a hook. Then she goes in to sit on the rug.",
  qs:[f("What is on Pam's bag?","A cat tag 🐱",["A dog tag 🐶","A star ⭐"],"It has a cat tag on it."),
      f("Where does Pam put her bag?","On a hook 🪝",["In a van 🚐","In a box 📦"],"Pam puts her bag on a hook.")]},
 {pic:"😟❓",text:"At home time, Pam looks at the hooks. Her bag is not there! Pam is sad. \"Where is my bag?\" she asks. Her teacher, Mr. Ali, pats her back. \"Do not be sad,\" he says. \"We can look for it.\"",
  qs:[f("Is Pam's bag on the hook?","No ❌",["Yes ✅","Yes, with a hat"],"Her bag is not there!"),
      p("What will Pam and Mr. Ali do next?","Look for the bag 🔍",["Go home without it 🏠","Take a nap 😴"],"Mr. Ali says, \"We can look for it.\"")]},
 {pic:"🔍🧒🏾",text:"Pam and Mr. Ali look and look. They look in the art room. They look by the map. They look under the mat. Then Pam sees Jamal. Jamal has a red bag with a cat tag!",
  qs:[f("Who has a red bag with a cat tag?","Jamal",["Mr. Ali","Pam's mom"],"Jamal has a red bag with a cat tag!"),
      t("Why do they look in so many places?","They want to find the bag",["They want to play tag","They are lost"],"They look and look because the bag is missing.")]},
 {pic:"🎒🎒😊",text:"Jamal has a red bag too! He took Pam's bag by mistake. His own bag has a hat tag. \"I am sorry,\" says Jamal. Pam and Jamal swap bags. Now they put their names on the tags. Pam is glad.",
  qs:[f("What tag is on Jamal's own bag?","A hat tag 🎩",["A cat tag 🐱","A map tag 🗺️"],"His own bag has a hat tag."),
      t("How can Pam and Jamal stop a mix-up next time?","Put their names on the bags 🏷️",["Throw the bags away","Never bring bags"],"Now they put their names on the tags.")]}
],turn:{q:"What do you keep in your school bag? Write one or two sentences.",model:"I keep a pencil and a book in my bag. My bag is blue."}},
/* 2 NON-FICTION */
{title:"What Is at School?",e:"🏫",kind:"Non-fiction",pages:[
 {pic:"🏫📚",text:"A school is a place to learn. Children go to school to read, write and count. A school has a room for each class. Some schools are very big. Some schools are small.",
  qs:[f("What is a school?","A place to learn 📚",["A place to sleep 🛏️","A shop 🛒"],"A school is a place to learn."),
      f("What do children do at school?","Read, write and count",["Cook and drive","Swim all day"],"Children go to school to read, write and count.")]},
 {pic:"🧑‍🏫👩🏽‍💼",text:"Many people work at a school. A teacher helps us learn. The principal is the leader of the school. A librarian helps us find books. A caretaker keeps the school clean.",
  qs:[f("Who is the leader of the school?","The principal",["The caretaker","A student"],"The principal is the leader of the school."),
      t("Who would help you find a book about cats?","The librarian 📚",["The caretaker 🧹","A bus driver 🚌"],"A librarian helps us find books.")]},
 {pic:"🏀📚🛝",text:"A school has many rooms. The gym is for running and games. The library has lots of books. The office is near the front door. Outside, there is a playground.",
  qs:[f("Where are lots of books?","In the library",["In the gym","On the playground"],"The library has lots of books."),
      p("The next page tells about things we use at school. What will it show?","Pencils, scissors and rulers ✏️",["Lions and bears 🦁","Cars and trucks 🚗"],"School tools help us do our work.")]},
 {pic:"✏️✂️📏",text:"At school, we use many tools. We write with pencils. We cut paper with scissors. We measure with a ruler. We keep our tools in a bin, so we can find them.",
  qs:[f("What do we cut paper with?","Scissors ✂️",["A ruler 📏","A book 📕"],"We cut paper with scissors."),
      t("Why do we keep our tools in a bin?","So we can find them",["So they get lost","So they get wet"],"We keep our tools in a bin, so we can find them.")]}
],turn:{q:"Name one room in your school and say what you do there.",model:"In the gym, we run and play games."}},
/* 3 PATTERNED TEXT */
{title:"Look Here!",e:"👀",kind:"Pattern book",pages:[
 {pic:"👀🎒🎩",text:"Look here! I see a bag. It is a big bag. Look here! I see a hat. The hat is in the bag. Can you see it?",
  qs:[f("What is in the bag?","A hat 🎩",["A cat 🐱","A van 🚐"],"The hat is in the bag."),
      t("Which words come again and again?","Look here!",["Go home!","Good night!"],"Look here! is said again and again. That is the pattern.")]},
 {pic:"🗺️🪭",text:"Look here! I see a map. It is on the wall. Look here! I see a fan. It is on the desk. Can you see it?",
  qs:[f("Where is the map?","On the wall",["In the bag","Under the desk"],"I see a map. It is on the wall."),
      f("What is on the desk?","A fan 🪭",["A map 🗺️","A ram 🐏"],"I see a fan. It is on the desk.")]},
 {pic:"🐱🚐",text:"Look here! I see a cat. A cat at school? It is not a real cat. It is a toy cat. It sits in a toy van. Can you see it?",
  qs:[t("Is the cat real?","No, it is a toy 🧸",["Yes, it is real","It is a ram"],"It is not a real cat. It is a toy cat."),
      p("What do you think the next page will show?","One more thing to look at 👀",["The end of school forever","A big storm"],"Each page shows a new thing to look at.")]},
 {pic:"🐏🫙👋",text:"Look here! I see a ram. It is on a jam jar. Look here! Here is my class. We wave at you. We see you! Can you see us?",
  qs:[f("Where is the ram?","On a jam jar 🫙",["In a van 🚐","On a map 🗺️"],"I see a ram. It is on a jam jar."),
      t("Which word rhymes with cat?","hat",["map","fan"],"Cat and hat both end in -at.")]}
],turn:{q:"Write your own pattern sentence: Look here! I see a ___.",model:"Look here! I see a big map."}},
/* 4 HOW-TO */
{title:"How to Pack Your Bag",e:"📋",kind:"How-to text",pages:[
 {pic:"🎒📕✏️",text:"Do you want to pack your school bag? It is easy! You need a bag. You need a book. You need a pencil case. Get them all. Let us start!",
  qs:[f("What do you need?","A bag, a book and a pencil case",["A cat and a hat","A van and a fan"],"You need a bag. You need a book. You need a pencil case."),
      p("What do you think the first step will be?","Open the bag 🎒",["Go to sleep 😴","Paint a picture 🎨"],"You must open the bag before you put things in.")]},
 {pic:"1️⃣2️⃣3️⃣",text:"First, open your bag. Look in it. Is it empty? Next, put in your book. Put it in flat. Then, put in your pencil case. Is it shut? Good!",
  qs:[f("What do you do first?","Open your bag",["Put in your book","Zip the bag"],"First, open your bag."),
      f("What goes in after the book?","The pencil case ✏️",["A hat 🎩","A cat 🐱"],"Then, put in your pencil case.")]},
 {pic:"4️⃣🏷️✅",text:"Last, zip up your bag. Look at the tag. Does it have your name? Now put your bag on your back. You are ready to go to school!",
  qs:[f("What do you do last?","Zip up your bag",["Open your bag","Put in a book"],"Last, zip up your bag."),
      t("Why does the tag need your name?","So no one mixes it up 🏷️",["To make it heavy","To hide the bag"],"A name tag shows whose bag it is.")]}
],turn:{q:"Write one step for getting ready for school. Start with First, Next, Then or Last.",model:"First, I put my book in my bag."}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Schools Around the World",e:"🌍",kind:"Children around the world",pages:[
 {pic:"🇧🇩⛵",text:"This is Rina. She lives in Bangladesh. In the rainy season, there is lots of water. Some roads are under water. So Rina goes to school on a boat! The boat is her classroom.",
  qs:[f("Where does Rina live?","Bangladesh 🇧🇩",["Canada 🇨🇦","Australia 🇦🇺"],"She lives in Bangladesh."),
      t("Why is Rina's school on a boat?","There is lots of water 🌊",["Boats are toys","She likes fish"],"In the rainy season, there is lots of water.")]},
 {pic:"🇮🇳🌳",text:"This is Arjun. He lives in India. On nice days, his class sits under a big tree. The tree gives them shade from the hot sun. They sit on mats on the grass. They read and sing.",
  qs:[f("Where does Arjun's class sit?","Under a big tree 🌳",["On a boat ⛵","In the snow ❄️"],"His class sits under a big tree."),
      f("What do they sit on?","Mats",["Chairs","Desks"],"They sit on mats on the grass.")]},
 {pic:"🇨🇦❄️",text:"This is Nuka. She lives in Nunavut, in the north of Canada. It is cold and snowy for many months. Nuka puts on a warm parka and boots. She walks to school in the snow.",
  qs:[f("What does Nuka put on?","A warm parka and boots 🧥",["A sun hat 👒","A swimsuit 🩱"],"Nuka puts on a warm parka and boots."),
      p("The next child lives very far from a school. How might she learn?","At home, on a computer 💻",["She never learns","On a boat in the snow"],"Some children learn at home when school is far away.")]},
 {pic:"🇦🇺💻",text:"This is Jess. She lives in Australia, far from any town. The nearest school is very far away. So Jess learns at home. Her teacher talks to her on a computer. It is called School of the Air.",
  qs:[f("How does Jess's teacher talk to her?","On a computer 💻",["On a boat ⛵","Under a tree 🌳"],"Her teacher talks to her on a computer."),
      t("How are Rina, Arjun, Nuka and Jess the same?","They all go to school and learn 📚",["They all live in the snow","They all ride boats"],"Schools look different, but all the children learn.")]}
],turn:{q:"Which school would you like to visit? Write one or two sentences.",model:"I would like to visit the boat school. I think it would be fun to learn on the water."}},
/* 6 REAL-WORLD TEXT */
{title:"Real-world reading: Our day and our class rules",e:"📅",kind:"Real-world text",pages:[
 {pic:"📅🕘",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>📅 ROOM 4 · OUR DAY</b><br><span style=\"font-size:22px;line-height:1.8\">🔔 9:00 Hello circle<br>📖 9:30 Reading<br>🍎 10:15 Snack<br>🛝 10:30 Recess<br>✏️ 11:00 Writing<br>🎨 1:00 Art<br>👋 3:00 Home time</span></div>",
  qs:[f("What comes first in the day?","Hello circle 🔔",["Art 🎨","Home time 👋"],"🔔 9:00 Hello circle is at the top."),
      f("What comes after Snack?","Recess 🛝",["Reading 📖","Writing ✏️"],"🍎 10:15 Snack, then 🛝 10:30 Recess.")]},
 {pic:"⭐📜",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>⭐ OUR CLASS RULES ⭐</b><br><span style=\"font-size:22px;line-height:1.8\">👂 Listen when others talk.<br>✋ Put up your hand to talk.<br>🚶 Walk inside.<br>🤝 Share and take turns.<br>🧹 Tidy up your things.</span></div>",
  qs:[f("What do you do when you want to talk?","Put up your hand ✋",["Shout 📢","Run 🏃"],"✋ Put up your hand to talk."),
      p("Jamal runs in the hall. What will his teacher say?","Please walk 🚶",["Run faster!","Go to sleep!"],"🚶 Walk inside is a class rule.")]}
],turn:{q:"Write one rule for your class.",model:"We walk in the hall."}}
],
poems:[
 {title:"A Diller, a Dollar (a traditional Mother Goose rhyme, more than 200 years old)",
  lines:["A diller, a dollar,","A ten o'clock scholar,","What makes you come so soon?","You used to come at ten o'clock,","But now you come at noon."],
  qs:[f("What time did the scholar use to come?","Ten o'clock 🕙",["Noon 🕛","Nine o'clock 🕘"],"\"You used to come at ten o'clock.\""),
      t("Is the scholar really early?","No, the scholar is late! ⏰",["Yes, very early","The scholar never comes"],"Noon is later than ten o'clock, so \"so soon\" is a joke. A scholar is a student."),
      f("Which word rhymes with soon?","noon",["ten","come"],"Soon and noon both end in -oon.")]},
 {title:"Off to School",
  lines:["I pack my bag, I grab my hat,","I wave goodbye to my old cat.","I see my class, I see my chair,","My friends are waiting for me there.","We read, we sing, we draw, we play,","I love my school day every day!"],
  qs:[f("What does the child pack?","A bag 🎒",["A cat 🐱","A van 🚐"],"\"I pack my bag.\""),
      f("Which word rhymes with hat?","cat",["chair","play"],"Hat and cat both end in -at."),
      t("How does the child feel about school?","Happy: they love school 😊",["Sad 😢","Angry 😠"],"\"I love my school day every day!\"")]}
],
words:[
 {w:"school",e:"🏫",m:"a place where children go to learn",ex:"I go to school every day.",fill:"We learn to read at ___."},
 {w:"chair",e:"🪑",m:"a seat with a back and legs",ex:"I sit on my chair.",fill:"Please sit on your ___."},
 {w:"computer",e:"💻",m:"a machine you use to type and learn",ex:"We read stories on the computer.",fill:"I type my name on the ___."},
 {w:"clock",e:"🕒",m:"it shows us what time it is",ex:"The clock says it is time for recess.",fill:"Look at the ___ to see the time."},
 {w:"bell",e:"🔔",m:"it rings to tell us it is time",ex:"The bell rings at recess.",fill:"Ding, ding! The ___ rings."},
 {w:"flag",e:"🚩",m:"a cloth with a special picture on a pole",ex:"Our school has a flag.",fill:"The ___ waves in the wind."},
 {w:"basket",e:"🧺",m:"a holder with a handle to carry things",ex:"The balls are in the basket.",fill:"Put the toys in the ___."},
 {w:"picture",e:"🖼️",m:"a drawing, a painting or a photo",ex:"I made a picture of my cat.",fill:"I drew a ___ of the sun."},
 {w:"alphabet",e:"🔤",m:"all the letters from A to Z",ex:"We sing the alphabet song.",fill:"The ___ starts with A, B, C."},
 {w:"magnet",e:"🧲",m:"a thing that pulls metal to it",ex:"The magnet picks up a paper clip.",fill:"A ___ sticks to the metal board."},
 {w:"bag",e:"🎒",m:"you carry your school things in it",ex:"My bag has a book in it.",fill:"I put my book in my ___."},
 {w:"pencil",e:"✏️",m:"a thin stick you write and draw with",ex:"I write my name with a pencil.",fill:"Sharpen your ___ before you write."},
 {w:"book",e:"📕",m:"pages with words and pictures to read",ex:"I read a book about a cat.",fill:"Open your ___ to page one."},
 {w:"crayon",e:"🖍️",m:"a stick of colour made of wax",ex:"I colour the sun with a yellow crayon.",fill:"Pass me the red ___, please."},
 {w:"ruler",e:"📏",m:"a flat stick to measure and draw lines",ex:"I draw a straight line with a ruler.",fill:"Use a ___ to measure the desk."},
 {w:"scissors",e:"✂️",m:"a tool with two blades to cut paper",ex:"I cut the paper with scissors.",fill:"Cut on the line with your ___."},
 {w:"paper",e:"📄",m:"a thin sheet you write or draw on",ex:"I draw on the paper.",fill:"Write your name on the ___."},
 {w:"notebook",e:"📓",m:"a book with empty pages to write in",ex:"I write words in my notebook.",fill:"Write the date in your ___."},
 {w:"glue",e:"🧴",m:"a sticky liquid that holds things together",ex:"I stick the paper down with glue.",fill:"Use ___ to stick the picture down."},
 {w:"paintbrush",e:"🖌️",m:"a stick with soft hairs for painting",ex:"I dip my paintbrush in blue paint.",fill:"Wash your ___ after art."},
 {w:"teacher",e:"🧑‍🏫",m:"a person who helps you learn",ex:"My teacher reads us a story.",fill:"Our ___ helps us read."},
 {w:"classmate",e:"👫",m:"a child in the same class as you",ex:"My classmate sits next to me.",fill:"Lin is in my class. She is my ___."},
 {w:"student",e:"🧑‍🎓",m:"a person who goes to school to learn",ex:"I am a student in Grade 1.",fill:"Every ___ has a desk."},
 {w:"playground",e:"🛝",m:"a place outside to play",ex:"We play on the playground at recess.",fill:"The slide is on the ___."},
 {w:"block",e:"🧱",m:"a small toy shape you build with",ex:"I build a tall tower with a block on top.",fill:"Put one more ___ on the tower."},
 {w:"rope",e:"🪢",m:"a long, thick string",ex:"We jump over the rope.",fill:"Hold the ___ and pull."},
 {w:"game",e:"🎲",m:"something fun you play with rules",ex:"We play a game at recess.",fill:"Tag is a fun ___."},
 {w:"song",e:"🎵",m:"words and music that you sing",ex:"We sing a song in music class.",fill:"Let us sing a happy ___."},
 {w:"music",e:"🎶",m:"sounds that we sing or play",ex:"We sing and clap in music class.",fill:"We dance to the ___."},
 {w:"art",e:"🎨",m:"making pictures by painting and drawing",ex:"We paint in art class.",fill:"In ___ class, we paint and draw."},
 {w:"line",e:"🧍‍♀️🧍",m:"people standing one behind another",ex:"We stand in a line.",fill:"Please get in a ___ at the door."},
 {w:"quiet",e:"🤫",m:"making little or no noise",ex:"We are quiet in the library.",fill:"Shh! Please be ___."},
 {w:"listen",e:"👂",m:"to use your ears to hear",ex:"Listen to the story.",fill:"___ when your teacher talks."},
 {w:"wait",e:"⏳",m:"to stay until it is time",ex:"I wait for my turn.",fill:"Please ___ in line for the slide."},
 {w:"tidy",e:"🧹",m:"neat, with things put away",ex:"I keep my desk tidy.",fill:"Put your toys away to make the room ___."},
 {w:"turn",e:"🔄",m:"your time to do something",ex:"It is my turn on the swing.",fill:"Take a ___ on the slide."},
 {w:"please",e:"🙏",m:"a kind word you say when you ask",ex:"May I have a pencil, please?",fill:"Say ___ when you ask for help."},
 {w:"walk",e:"🚶",m:"to move on your feet, not run",ex:"We walk in the hall.",fill:"Do not run. ___ in the hall."},
 {w:"rule",e:"📜",m:"something we must do or must not do",ex:"Our class rule is to be kind.",fill:"A ___ helps keep us safe."},
 {w:"world",e:"🌍",m:"the Earth and all the people on it",ex:"Children all over the world go to school.",fill:"There are schools all around the ___."}
],
spelling:[],
facts:[
 {e:"⛵",c:"Some children in Bangladesh go to school on a boat.",t:true,x:"True! When there is lots of water, boat schools pick children up."},
 {e:"🏫",c:"Every school in the world has walls and a roof.",t:false,x:"Not true! Some classes learn outside, under a big tree."},
 {e:"✏️",c:"Pencil lead is made of the metal lead.",t:false,x:"Not true! The dark part of a pencil is graphite, not lead."},
 {e:"🖍️",c:"Most crayons are made of wax.",t:true,x:"True! Wax and colour are mixed to make crayons."},
 {e:"🚌",c:"School buses in Canada are usually yellow.",t:true,x:"True! The bright colour is easy for drivers to see."},
 {e:"🧹",c:"In Japan, many children help clean their classroom.",t:true,x:"True! They sweep the floor and wipe the desks."},
 {e:"✂️",c:"It is safe to run with scissors.",t:false,x:"Not true! Always walk with scissors, points down."},
 {e:"📄",c:"Most paper is made from wood from trees.",t:true,x:"True! Wood is mashed up and pressed flat to make paper."},
 {e:"🇫🇮",c:"In Finland, children usually start Grade 1 when they are 7.",t:true,x:"True! That is a bit later than in Canada."},
 {e:"🗣️",c:"All children in the world speak the same language at school.",t:false,x:"Not true! Children learn in many different languages."},
 {e:"🌳",c:"Some children in India learn in classes under trees.",t:true,x:"True! The tree gives shade on hot days."},
 {e:"📏",c:"A ruler is a tool for cutting paper.",t:false,x:"Not true! A ruler measures. Scissors cut."}
],
writing:[
 {e:"🎒",t:"My school bag",level:"Step 1 · 2 sentences",
  prompt:"Write 2 sentences about your school bag. What colour is it? What is in it? Use a word from the word bank, like pencil or book.",
  minS:2,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Bb]ag|[Bb]ackpack)","I wrote about my bag"]],
  starters:["My bag is ","In my bag, I have "],
  model:"My bag is red. In my bag, I have a pencil and a book."},
 {e:"🧑‍🏫",t:"My teacher and my friends",level:"Step 2 · 3 sentences",
  prompt:"Write 3 sentences about your teacher and your friends at school. What do you do together?",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b[Tt]eacher","I wrote about my teacher"]],
  starters:["My teacher is ","At recess, we ","I like to "],
  model:"My teacher is kind and funny. At recess, we play ball on the playground. I like to sing songs with my classmates."},
 {e:"🏫",t:"Label and write: my class",level:"Step 3 · Label and 3 sentences",
  prompt:"Draw your classroom on paper. Label 3 things, like door, window and chair. Then write 3 sentences about your class.",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b[Cc]lass","I wrote about my class"],["(\\b(door|window|chair|desk|board|flag|basket|picture|bell|rug|shelf|clock|map|books?)\\b[\\s\\S]*){2}","I named 2 things in my class"]],
  starters:["My class is ","We have a ","I sit "],
  model:"My class is Room 4. We have a big window and a red door. I sit on a chair next to my friend."}
]};
UNITS.push(u);

/* ================= PHONICS: SHORT A ================= */
const big=e=>`<span style="font-size:44px">${e}</span>`;
const SAPIC=[["cat","🐱"],["bat","🦇"],["hat","🎩"],["rat","🐀"],["map","🗺️"],["cap","🧢"],["bag","🎒"],["fan","🪭"],["can","🥫"],["pan","🍳"],["man","👨"],["van","🚐"],["jam","🍓🫙"],["ram","🐏"],["tag","🏷️"],["cab","🚕"],["nap","😴"],["tap","🚰"],["sad","😢"],["gas","⛽"],["lab","🧪"],["mad","😠"],["zap","⚡"]];
const SAW=["cat","bat","hat","mat","rat","sat","pat","map","cap","nap","tap","lap","bag","tag","rag","wag","fan","can","pan","man","van","ran","jam","ram","dad","sad","mad","cab","lab","gas"];
const OTHW=["pig","sit","big","pin","lid","fox","pot","hot","dog","mop","bed","hen","web","red","net","sun","mud","bug","cup","hut"];
const OTHPIC=[["pig","🐷"],["fox","🦊"],["bed","🛏️"],["sun","☀️"],["bug","🐛"],["dog","🐶"],["hen","🐔"],["web","🕸️"],["cup","🥤"],["pot","🍲"],["net","🥅"],["pin","📌"],["box","📦"],["six","6️⃣"],["bus","🚌"]];
const saWhich=()=>{const r=Math.random();
  if(r<.4){const w=R(SAW);return mcQ(`Which word has the <b>short a</b> sound, like in 🐱 c<b>a</b>t?`,w,SAMPLE(OTHW,2),`<b>${w}</b> has the short a sound: ${w.split("").join("-")}.`,"Say each word. Listen for /a/ in the middle.",{say:"Which word has the short a sound, like in cat?"})}
  if(r<.7){const w=R(OTHW);return mcQ(`Which word does <b>NOT</b> have the short a sound?`,w,SAMPLE(SAW,2),`<b>${w}</b> does not have short a. The other words have /a/, like c-a-t.`,"Two words have /a/ in the middle. Find the one that does not.")}
  const x=R(SAPIC);return mcQ(`Which picture has the <b>short a</b> sound, like in c<b>a</b>t?`,x[1],SAMPLE(OTHPIC,2).map(y=>y[1]),`${x[1]} is <b>${x[0]}</b>: ${x[0].split("").join("-")}.`,"Say the name of each picture. Listen for /a/.")};
const swap=w=>["i","o","u","e"].map(v=>w.replace("a",v));
const saPic=()=>{const x=R(SAPIC);
  if(Math.random()<.55)return mcQ(`What is this? ${big(x[1])}`,x[0],SAMPLE(swap(x[0]),2),`${x[1]} is <b>${x[0]}</b>: ${x[0].split("").join("-")}.`,"Say the picture word slowly. Listen for the middle sound.");
  return mcQ(`Which picture shows <b>${x[0]}</b>?`,x[1],SAMPLE(SAPIC.filter(y=>y!==x),2).map(y=>y[1]),`<b>${x[0]}</b> is ${x[1]}.`,"Read the word sound by sound, then find the picture.",{say:x[0]})};
const saMake=()=>{const x=R(SAPIC),w=x[0],k=Math.floor(Math.random()*3);const shown=w.split("").map((c,i)=>i===k?"_":c).join(" ");
  return {type:"type",q:`🧩 Make the word. Fill the gap and type the <b>whole word</b>.<br>${big(x[1])}<br><b style="font-size:28px;letter-spacing:6px">${shown}</b>`,a:[w],why:`${x[1]} ${w.split("").join("-")} spells <b>${w}</b>.`,hint:"Say the picture word slowly. Which sound is missing?"}};
const FAM={"-at":["cat","bat","hat","mat","rat","sat","pat","fat"],"-an":["can","fan","man","pan","ran","van","tan","ban"],"-ap":["cap","map","nap","tap","lap","gap","zap","sap"]};
const saRhyme=()=>{const ks=Object.keys(FAM),k=R(ks),others=ks.filter(x=>x!==k),pair=SAMPLE(FAM[k],2),r=Math.random();
  if(r<.45)return mcQ(`Which word <b>rhymes</b> with <b>${pair[0]}</b>?`,pair[1],others.map(o=>R(FAM[o])),`<b>${pair[0]}</b> and <b>${pair[1]}</b> both end in <b>${k}</b>.`,`Listen to the end of the word: ${pair[0]}.`);
  if(r<.75)return mcQ(`Which word family is <b>${pair[0]}</b> in?`,k,others,`<b>${pair[0]}</b> ends in <b>${k}</b>, like ${FAM[k].filter(x=>x!==pair[0]).slice(0,2).join(" and ")}.`,"Look at the last two letters.");
  const o=R(FAM[R(others)]);return mcQ(`Which word does <b>NOT</b> rhyme with <b>${pair[0]}</b>?`,o,SAMPLE(FAM[k].filter(x=>x!==pair[0]),2),`<b>${o}</b> does not end in <b>${k}</b>.`,`Rhyming words with ${pair[0]} end in ${k}.`)};
const SALIST=G4.sp([["cat","My cat is on the mat.","c-a-t"],["map","We look at a map.","m-a-p"],["bag","Put the book in your bag.","b-a-g"],["hat","I have a red hat.","h-a-t"],["fan","Turn on the fan, please.","f-a-n"],["jam","I see a jar of jam.","j-a-m"],["van","We go in the van.","v-a-n"],["ram","The ram has big horns.","r-a-m"],["bat","Hit the ball with the bat.","b-a-t"],["cap","Put on your cap.","c-a-p"],["man","The man waves hello.","m-a-n"],["pan","The pan is hot.","p-a-n"],["nap","The baby takes a nap.","n-a-p"],["sad","Do not be sad.","s-a-d"],["tag","My name is on the tag.","t-a-g"],["can","I can hop.","c-a-n"],["mat","Sit on the mat.","m-a-t"],["rat","The rat is little.","r-a-t"],["tap","Tap the drum.","t-a-p"],["dad","My dad walks me to school.","d-a-d"],["lap","My cat sits on my lap.","l-a-p"],["ran","We ran to the swings.","r-a-n"],["pat","I pat the dog.","p-a-t"],["had","I had a fun day.","h-a-d"]]);

/* ================= SIGHT WORDS ================= */
const SW=["we","go","to","at","it","in","and","you","look","here"];
const SWF=[["___ sit on the rug.","We",["At","Here"]],["We ___ to school.","go",["it","at"]],["I walk ___ the gym.","to",["it","you"]],["Look ___ the map!","at",["you","and"]],["___ is a big bag.","It",["We","You"]],["The cat is ___ the box.","in",["and","go"]],["Pam ___ Jamal play ball.","and",["to","it"]],["Can ___ see the flag?","you",["at","and"]],["___ at my new hat!","Look",["Go","It"]],["Come ___! Sit by me.","here",["to","at"]],["We ___ out to play.","go",["at","in"]],["I sit ___ my desk.","at",["you","and"]],["Put ___ in your bag.","it",["at","go"]],["The map is ___.","here",["and","to"]],["I like ___!","you",["at","to"]],["We go ___ the park.","to",["it","you"]],["The pens are ___ the bin.","in",["you","and"]],["___ can sing and clap.","We",["At","To"]],["I have a pen ___ a pencil.","and",["to","you"]],["___ here, children!","Look",["It","And"]],["Look ___ my teacher.","at",["it","we"]],["Is ___ your cap?","it",["at","to"]],["Are ___ in my class?","you",["at","and"]],["Let us ___ to the library.","go",["it","and"]],["The ram is ___ the van.","in",["you","and"]],["Sit ___, next to me.","here",["you","and"]],["You ___ I are friends.","and",["to","at"]],["Can we go ___ the zoo?","to",["it","you"]]];
const swFill=()=>{const x=R(SWF);return mcQ(`Which <b>sight word</b> fits?<br><b>${x[0]}</b>`,x[1],x[2],`${x[0].replace("___","<b>"+x[1]+"</b>")}`,"Read the sentence with each word. Which one makes sense?",{say:x[0].replace("___","blank")})};
const swHear=()=>{const w=R(SW);return mcQ(`🎧 Listen. Tap the word you hear.`,w,SAMPLE(SW.filter(x=>x!==w),3),`You heard <b>${w}</b>.`,"Press the speaker and listen again.",{say:w,autoSay:true})};
const SWS=[["We go to school.","we"],["Look at the cat.","look"],["It is in the bag.","in"],["You and I can play.","and"],["Come here and sit.","here"],["Go to the gym.","to"],["Sit at the desk.","at"],["Can you see it?","you"],["We can go in.","go"],["Is it a map?","it"]];
const swFind=()=>{const x=R(SWS);const ws=x[0].replace(/[.?!]/g,"").split(" ").map(z=>z.toLowerCase());const others=SAMPLE(SW.filter(z=>!ws.includes(z)),2);
  return mcQ(`${G4.box("Read",x[0])}Which sight word is in this sentence?`,x[1],others,`<b>${x[1]}</b> is in the sentence: ${x[0]}`,"Look at each word in the sentence.",{say:x[0]})};

/* ================= GRAMMAR: NOUNS (PERSON, PLACE, THING) ================= */
const PERSON=[["teacher","🧑‍🏫"],["principal","👩🏽‍💼"],["student","🧑‍🎓"],["girl","👧"],["boy","👦"],["doctor","🧑‍⚕️"],["nurse","👩‍⚕️"],["pilot","🧑‍✈️"],["firefighter","🧑‍🚒"],["artist","🧑‍🎨"],["man","👨"],["woman","👩"],["singer","🧑‍🎤"],["scientist","🧑‍🔬"],["police officer","👮"],["coach","🏅"]];
const PLACE=[["school","🏫"],["park","🏞️"],["library","📚"],["playground","🛝"],["zoo","🦁"],["beach","🏖️"],["home","🏠"],["shop","🏪"],["gym","🏀"],["pool","🏊"],["city","🏙️"],["museum","🏛️"],["hospital","🏥"],["garden","🌷"],["office","🏢"],["camp","⛺"]];
const THING=[["pencil","✏️"],["book","📕"],["bag","🎒"],["ball","⚽"],["chair","🪑"],["crayon","🖍️"],["hat","🎩"],["map","🗺️"],["cup","🥤"],["kite","🪁"],["drum","🥁"],["bell","🔔"],["door","🚪"],["clock","🕒"],["ruler","📏"],["scissors","✂️"]];
const KIND={person:PERSON,place:PLACE,thing:THING},KE={person:"person 🧑",place:"place 🏫",thing:"thing ✏️"};
const pptQ=()=>{const k=R(["person","place","thing"]),x=R(KIND[k]);
  return mcQ(`Is <b>${x[0]}</b> ${x[1]} a person, a place or a thing?`,KE[k],Object.keys(KE).filter(z=>z!==k).map(z=>KE[z]),`<b>${x[0]}</b> is a <b>${k}</b>. It is a noun.`,"A person is someone. A place is somewhere. A thing is something.")};
const pptPick=()=>{const k=R(["person","place","thing"]),x=R(KIND[k]);const wr=Object.keys(KIND).filter(z=>z!==k).map(z=>{const y=R(KIND[z]);return y[1]+" "+y[0]});
  return mcQ(`Which one is a <b>${k.toUpperCase()}</b>?`,x[1]+" "+x[0],wr,`<b>${x[0]}</b> is a ${k}.`,k==="person"?"Find someone.":k==="place"?"Find somewhere you can go.":"Find something you can hold or touch.")};
const FINDN=[["The bag is big.","bag",["big","is"]],["I can see a map.","map",["see","can"]],["We sit on the rug.","rug",["sit","on"]],["Look at the cat.","cat",["Look","at"]],["It is a red hat.","hat",["red","is"]],["You can go in the van.","van",["go","in"]],["The fan is on.","fan",["on","is"]],["I like my teacher.","teacher",["like","my"]],["We go to school.","school",["go","to"]],["Here is my pencil.","pencil",["Here","my"]],["The ball is soft.","ball",["soft","is"]],["Look at the clock.","clock",["Look","at"]],["We can sing a song.","song",["sing","can"]],["The gym is big.","gym",["big","is"]],["My crayon is broken.","crayon",["broken","My"]],["Can you see the flag?","flag",["see","you"]],["We play in the park.","park",["play","in"]],["The door is open.","door",["open","is"]],["I read a book.","book",["read","I"]],["The bell is loud.","bell",["loud","is"]],["We sit in a line.","line",["sit","in"]],["You go and get the rope.","rope",["get","and"]],["Look at my ruler.","ruler",["Look","my"]],["It is in the box.","box",["It","in"]],["The girl is happy.","girl",["happy","is"]],["We go to the library.","library",["go","to"]],["The man is tall.","man",["tall","is"]],["Is the window open?","window",["open","Is"]]];
const findN=()=>{const x=R(FINDN);return mcQ(`${G4.box("Sentence",x[0])}Which word is the <b>noun</b>?`,x[1],x[2],`<b>${x[1]}</b> is the noun. It names a person, place or thing.`,"Find the word that names a person, place or thing.",{say:x[0]})};
const NOUNS=["teacher","girl","boy","pencil","book","bag","school","park","cat","map","hat","van","chair","desk","door","crayon","ruler","zoo","home","gym","cup","kite","bell","scissors","box","beach","doctor","pilot","library","man"];
const NOTN=["run","jump","sit","hop","big","sad","happy","soft","go","look","and","to","in","at","sing","read","swim","fast","tall","little","is","very","write","glad","under","red"];
const whichN=()=>{const n=R(NOUNS);return mcQ(`Which word is a <b>noun</b>? <span style="color:var(--muted);font-size:15px">(a person, place or thing)</span>`,n,SAMPLE(NOTN,2),`<b>${n}</b> is a noun. It names a person, place or thing.`,"Ask: is it someone, somewhere or something?")};
const notN=()=>{const w=R(NOTN);return mcQ(`Which word is <b>NOT</b> a noun?`,w,SAMPLE(NOUNS,2),`<b>${w}</b> is not a noun. The other two name a person, place or thing.`,"Two words name a person, place or thing. Find the other one.")};

/* ================= READING: A CLASS SCHEDULE ================= */
const ACTS=[["🔔","Hello circle"],["📖","Reading"],["🔢","Math"],["🍎","Snack"],["🛝","Recess"],["✏️","Writing"],["🎨","Art"],["🎵","Music"],["🏀","Gym"],["🔬","Science"],["📚","Library"]];
const sched=()=>{const s=SAMPLE(ACTS,5),lbl=a=>a[0]+" "+a[1];const doc=`<div class="realdoc" style="text-align:left;font-size:20px;line-height:1.8"><b>📅 Our day</b><br>${s.map((a,i)=>`${i+1}. ${lbl(a)}`).join("<br>")}</div>`;
  const r=Math.random();
  if(r<.25)return mcQ(`${doc}What comes <b>first</b>?`,lbl(s[0]),SAMPLE(s.slice(1),2).map(lbl),`<b>${lbl(s[0])}</b> is number 1, so it is first.`,"Look at number 1.");
  if(r<.45)return mcQ(`${doc}What comes <b>last</b>?`,lbl(s[4]),SAMPLE(s.slice(0,4),2).map(lbl),`<b>${lbl(s[4])}</b> is number 5, so it is last.`,"Look at the bottom of the list.");
  const k=Math.floor(Math.random()*4);
  if(r<.75)return mcQ(`${doc}What comes right <b>after</b> ${lbl(s[k])}?`,lbl(s[k+1]),SAMPLE(s.filter((_,i)=>i!==k&&i!==k+1),2).map(lbl),`${lbl(s[k])} → <b>${lbl(s[k+1])}</b>`,"Find it in the list, then look at the next line.");
  return mcQ(`${doc}What comes right <b>before</b> ${lbl(s[k+1])}?`,lbl(s[k]),SAMPLE(s.filter((_,i)=>i!==k&&i!==k+1),2).map(lbl),`<b>${lbl(s[k])}</b> → ${lbl(s[k+1])}`,"Find it in the list, then look at the line above.")};

/* ================= THINKING: SCHOOL SMARTS ================= */
const SCH=[
 {q:"🎒 You can't find your pencil. What can you do?",o:["Ask your teacher for help","Cry and stop working","Take a pencil without asking"],a:"Ask your teacher for help",why:"Asking for help is a smart choice."},
 {q:"✋ You want to talk in class. What do you do?",o:["Put up your hand","Shout out loud","Talk while others talk"],a:"Put up your hand",why:"Putting up your hand lets everyone have a turn."},
 {q:"🛝 Two children want the same swing. What is fair?",o:["Take turns","Push the other child","Nobody can play"],a:"Take turns",why:"Taking turns is fair for everyone."},
 {q:"🧒 A new child is alone at recess. What can you do?",o:["Ask them to play with you","Laugh at them","Walk away"],a:"Ask them to play with you",why:"Asking them to play makes them feel welcome."},
 {q:"🎨 Art time is over. What do you do?",o:["Tidy up your things","Leave a mess","Throw the paint"],a:"Tidy up your things",why:"A tidy room is ready for the next lesson."},
 {q:"🔔 The bell rings at the end of recess. What do you do?",o:["Line up and go in","Keep playing","Hide"],a:"Line up and go in",why:"The bell tells us it is time to go back to class."},
 {q:"✂️ How do you carry scissors?",o:["Walk with the points down","Run with them","Wave them in the air"],a:"Walk with the points down",why:"Points down keeps everyone safe."},
 {q:"📚 You see a book on the floor. What should you do?",o:["Pick it up and put it back","Step on it","Kick it"],a:"Pick it up and put it back",why:"We take care of our books."},
 {q:"🚶 How should you move in the hall?",o:["Walk slowly and quietly","Run fast","Jump and shout"],a:"Walk slowly and quietly",why:"Walking keeps the hall safe and calm."},
 {q:"🌧️ It is raining hard at recess. Where might you play?",o:["Inside the school","On the wet slide","In the street"],a:"Inside the school",why:"On rainy days, many classes play inside."},
 {q:"🤧 You need to sneeze. What do you do?",o:["Sneeze into a tissue or your sleeve","Sneeze on your friend","Sneeze on the book"],a:"Sneeze into a tissue or your sleeve",why:"Covering a sneeze stops germs from spreading."},
 {q:"😢 Your classmate is sad. What can you say?",o:["Are you OK? Can I help?","Go away!","Ha ha!"],a:"Are you OK? Can I help?",why:"Kind words help a sad friend."},
 {q:"🖌️ You spill paint on the table. What do you do?",o:["Tell the teacher and help clean it","Hide it","Say a friend did it"],a:"Tell the teacher and help clean it",why:"Telling the truth and helping is the right thing."},
 {q:"🗺️ Which one helps you find a place?",o:["A map","A hat","A fan"],a:"A map",why:"A map shows where places are."},
 {q:"⛵ Rina goes to school on a boat. Why?",o:["There is lots of water","Boats are toys","She can't walk"],a:"There is lots of water",why:"In the rainy season, roads in parts of Bangladesh can be under water."},
 {q:"❄️ What should Nuka wear to school in the snow?",o:["A warm parka","Shorts","A sun hat"],a:"A warm parka",why:"A parka keeps you warm in the cold."},
 {q:"🌳 Arjun's class learns under a tree. What does the tree give them?",o:["Shade from the sun","Snow","Pencils"],a:"Shade from the sun",why:"Trees make shade on hot days."},
 {q:"📏 Which tool tells how long a line is?",o:["A ruler","A crayon","A bell"],a:"A ruler",why:"A ruler measures how long things are."},
 {q:"🏷️ Why do we put our names on our bags?",o:["So we know whose bag it is","To make bags heavy","To make bags wet"],a:"So we know whose bag it is",why:"A name tag stops mix-ups."},
 {q:"👂 The teacher is reading a story. What should you do?",o:["Listen quietly","Talk to a friend","Sing loudly"],a:"Listen quietly",why:"Listening helps you enjoy the story."},
 {q:"🧮 Pam has 3 pencils. Jamal gives her 2 more. How many pencils does Pam have now?",o:["5","4","6"],a:"5",why:"3 + 2 = 5."},
 {q:"🧮 There are 6 children on the swings. 2 go inside. How many are still on the swings?",o:["4","8","3"],a:"4",why:"6 − 2 = 4."},
 {q:"🧮 A box has 4 red crayons and 4 blue crayons. How many crayons are there in all?",o:["8","4","7"],a:"8",why:"4 + 4 = 8."},
 {q:"🧮 There are 10 books on a shelf. Ali takes 3. How many are left?",o:["7","13","6"],a:"7",why:"10 − 3 = 7."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["pencil","I write with a pencil.","pen-cil"],["crayon","I colour with a crayon.","cray-on"],["ruler","A ruler is long and flat.","ru-ler"],["scissors","Cut the paper with scissors.","sc-iss-ors: a quiet c and a double s"],["paper","Draw on the paper.","pa-per"],["book","I read a book.","b-oo-k"],["school","I go to school.","sch-ool: ch says k here"],["chair","Sit on your chair.","ch-air"],["computer","I type on the computer.","com-pu-ter"],["clock","Look at the clock.","c-l-o-ck"],["teacher","My teacher reads to us.","teach-er"],["student","I am a student.","stu-dent"],["glue","I use glue to stick paper.","g-l-ue"],["rope","Jump over the rope.","r-o-p-e: the e is quiet"],["game","We play a game.","g-a-m-e: the e is quiet"],["song","We sing a song.","s-o-ng"],["quiet","Be quiet, please.","qu-i-et: q and u go together"],["notebook","I write in my notebook.","note-book: two small words"],["world","We live in a big world.","w-or-ld"],["please","Pass the glue, please.","pl-ea-se"]]),
 CHOOSE:null,
 DETAIL:[
  ["Recess","At recess, we go outside. We play on the slide and the swings. When the bell rings, we line up.",[["Where do we go at recess?","Outside",["To the office","To bed"]],["What do we play on?","The slide and the swings",["The desks","The bus"]],["What do we do when the bell rings?","Line up",["Go home","Sing"]]]],
  ["The Library","Our library has many books. Ms. Lee is the librarian. We can take home one book each week.",[["Who is the librarian?","Ms. Lee",["Mr. Ali","Pam"]],["How many books can we take home each week?","One",["Ten","None"]],["What does the library have?","Many books",["Many cats","Many cars"]]]],
  ["Pam's Pencil Case","Pam has a pencil case. It has two pencils and a ruler. It is red with a cat on it.",[["What is in the case?","Two pencils and a ruler",["A hat and a fan","A cup"]],["What colour is the case?","Red",["Blue","Green"]],["What is on the case?","A cat",["A ram","A van"]]]],
  ["Art Time","On Friday, we have art. We paint with big brushes. We hang our pictures on the wall.",[["When do we have art?","On Friday",["On Monday","At night"]],["What do we paint with?","Big brushes",["Spoons","Sticks"]],["Where do we hang our pictures?","On the wall",["On the floor","In a bag"]]]],
  ["The Boat School","In Bangladesh, some schools are on boats. The boat stops to pick up children. Then class starts on the water.",[["Where are some schools on boats?","In Bangladesh",["In Canada","In Japan"]],["Why does the boat stop?","To pick up children",["To get fish","To sleep"]],["Where does class start?","On the water",["In a gym","Under a tree"]]]],
  ["Gym Class","In gym, we run and jump. Coach Sam blows a whistle. Then we all stop and listen.",[["What do we do in gym?","Run and jump",["Paint","Sleep"]],["Who blows a whistle?","Coach Sam",["The principal","A cat"]],["What do we do when the whistle blows?","Stop and listen",["Run home","Sing"]]]],
  ["Jamal's Job","Jamal has a job in class. He feeds the class fish every day. He gives it just a little food.",[["What is Jamal's job?","Feeding the class fish",["Cleaning the board","Ringing the bell"]],["How often does he feed the fish?","Every day",["Once a year","Never"]],["How much food does he give?","Just a little",["A whole bag","None"]]]],
  ["School in Japan","In Japan, many children help clean their school. They sweep the floor. They wipe the desks.",[["Where do children help clean their school?","In Japan",["In Australia","In Bangladesh"]],["What do they sweep?","The floor",["The roof","The sky"]],["What do they wipe?","The desks",["The cars","The trees"]]]],
  ["Show and Tell","Today is show and tell. Lin brings a toy van. She tells the class how it rolls.",[["What does Lin bring?","A toy van",["A cat","A map"]],["Who does she tell?","The class",["Her dog","The bus driver"]],["What does she tell about?","How it rolls",["How it flies","How it swims"]]]],
  ["Snow Day School","In Nunavut, winter is very cold. Children wear warm parkas and boots. They still go to school in the snow.",[["Where is winter very cold?","In Nunavut",["In a desert","In a pool"]],["What do children wear?","Warm parkas and boots",["Swimsuits","Sun hats"]],["Do they still go to school?","Yes, in the snow",["No, never","Only in summer"]]]],
  ["Class Rules","Our class has three rules. Listen when others talk. Walk inside, and be kind.",[["How many rules are there?","Three",["Ten","One"]],["When should we listen?","When others talk",["Never","Only at recess"]],["Where should we walk?","Inside",["On the roof","In the street"]]]],
  ["Home Time","At three o'clock, school ends. We pack our bags. We wave goodbye to our teacher.",[["When does school end?","At three o'clock",["At noon","At nine o'clock"]],["What do we pack?","Our bags",["Our desks","The windows"]],["Who do we wave to?","Our teacher",["The fish","The moon"]]]]
 ],
 MAIN:[
  ["We read books. We write words. We count to ten.","We learn many things at school.",["We go to bed.","We count to ten."]],
  ["A pencil helps us write. A ruler helps us measure. Scissors help us cut.","School tools help us do our work.",["Scissors cut.","Pencils are long."]],
  ["The slide is fun. The swings go high. We play ball on the grass.","The playground is a fun place to play.",["The grass is green.","Swings go high."]],
  ["Our teacher reads to us. She helps us spell. She smiles when we try.","Our teacher helps us learn.",["She smiles.","We spell words."]],
  ["Rina's school is on a boat. The boat floats on the river. Rina learns on the water.","Rina goes to school on a boat.",["Rivers are wet.","Boats float."]],
  ["We walk in the hall. We put up our hands. We share with our classmates.","We follow our class rules.",["Halls are long.","We have hands."]],
  ["Arjun's class sits under a tree. The tree gives shade. They read and sing there.","Arjun's class learns under a tree.",["Trees are tall.","They sing."]],
  ["Nuka puts on a parka. She puts on boots. She walks to school in the snow.","Nuka gets ready for a snowy walk to school.",["Boots are warm.","Snow is white."]],
  ["Jess lives far from town. She learns at home. Her teacher talks to her on a computer.","Jess goes to school at home on a computer.",["Towns are big.","Computers are fun."]],
  ["Pam has a red bag. It has a cat tag. She puts her name on it.","Pam has a special school bag.",["Cats are cute.","Tags are small."]],
  ["We sing songs in music. We bang on drums. We clap to the beat.","We make music in music class.",["Drums are loud.","We clap."]],
  ["We paint pictures. We cut paper. We glue shapes.","We make things in art class.",["Paper is thin.","Glue is sticky."]],
  ["The principal helps the school. The caretaker keeps it clean. Teachers help us learn.","Many people work at a school.",["The school is clean.","We learn."]],
  ["We tidy our desks. We put crayons in the box. We push in our chairs.","We clean up the classroom.",["Crayons go in a box.","Chairs have legs."]],
  ["Look at the cat. Look at the hat. Look at the map.","The text shows many things to look at.",["A cat has a hat.","Maps are big."]],
  ["At recess, the bell rings. We line up. We go back to class.","Recess ends, and we go back to class.",["Bells ring.","Lines are long."]],
  ["Some schools are on boats. Some are under trees. Some are in the snow.","Schools around the world are different.",["Trees are big.","Snow is cold."]],
  ["Lin brings a toy van. She shows the class. She tells how it rolls.","Lin shares her toy at show and tell.",["Vans have wheels.","The class sits."]],
  ["We sit on the rug. The teacher opens a book. We listen to the story.","It is story time on the rug.",["Rugs are soft.","Books open."]],
  ["In gym, we run. We jump and hop. We throw balls.","We move a lot in gym.",["Balls are round.","We hop."]],
  ["The library has many books. We can sit and read. We can take a book home.","The library is a place for books.",["We sit.","Books are heavy."]],
  ["Jamal packs a pencil. He packs a book. He zips his bag.","Jamal packs his school bag.",["Books are fun.","Zips are shiny."]],
  ["We say hello to our classmates. We hang up our coats. We sit in the hello circle.","We start the school day.",["Coats are warm.","We say hello."]],
  ["Cat, hat and bat all end in -at. They rhyme. They have the short a sound.","Cat, hat and bat are rhyming short a words.",["Bats can fly.","Hats are fun."]]
 ],
 FACTS:["A pencil can write.","Scissors can cut paper.","A ruler is straight.","Crayons come in many colours.","A school has a principal.","Books have pages.","Some schools are on boats.","Nunavut is in Canada.","Bangladesh is a country.","Many schools have a gym.","A bell can ring.","The word cat has three letters.","The English alphabet has 26 letters.","A map shows places.","Japan is a country in Asia.","Australia is a country.","Paper can tear.","A circle is round.","Glue is sticky.","Two plus two is four.","A week has seven days.","A van has wheels.","A book can have pictures.","Snow is cold.","Many children ride a bus to school."],
 OPIN:["Art is the best class.","Recess is too short.","Red bags are the prettiest.","Math is easy.","Reading is more fun than writing.","Cats are the best pets.","The slide is the most fun.","Gym is boring.","Boat schools are the coolest.","Snow is the best weather.","Crayons are better than paint.","Music class is the most fun.","Hats look silly.","Mondays are the worst day.","Our school is the best school.","Books with pictures are better.","Singing is more fun than drawing.","Blue is the nicest colour.","Show and tell is the best part of the day.","Rulers are boring.","School should start later.","Recess should be all day.","The library is the nicest room.","Rhyming words are fun.","Toy vans are the best toys."],
 SEQ:[["Wake up","Get dressed","Pack your bag","Go to school"],["Open your bag","Put in your book","Put in your pencil case","Zip up your bag"],["The bell rings","We line up","We walk inside","We sit down"],["Get the paper","Draw a picture","Colour it in","Hang it on the wall"],["Pam puts her bag on a hook","Her bag is gone","Pam and Mr. Ali look for it","Jamal gives it back"],["Pick a book","Open it","Read the pages","Close the book"],["The boat picks up Rina","Class starts on the boat","School ends","The boat takes Rina home"],["Nuka puts on her parka","She puts on her boots","She walks in the snow","She gets to school"],["Fill a cup with water","Dip the brush in paint","Paint the paper","Wash the brush"],["Say hello","Hang up your coat","Sit on the rug","Start the lesson"],["Hear the fire alarm","Stop what you are doing","Walk outside in a line","Wait with your teacher"]],
 CE:[["Pam lost her bag, so she was sad.","Pam lost her bag","she was sad"],["It was raining, so we played inside.","it was raining","we played inside"],["The bell rang, so we lined up.","the bell rang","we lined up"],["Jamal took the wrong bag, so Pam could not find hers.","Jamal took the wrong bag","Pam could not find hers"],["There was lots of water, so Rina went to school on a boat.","there was lots of water","Rina went to school on a boat"],["It was snowy, so Nuka wore a parka.","it was snowy","Nuka wore a parka"],["The sun was hot, so the class sat in the shade.","the sun was hot","the class sat in the shade"],["Lin dropped her crayons, so they broke.","Lin dropped her crayons","they broke"],["We tidied up, so the room was clean.","we tidied up","the room was clean"],["Sam ran in the hall, so he fell down.","Sam ran in the hall","he fell down"],["The teacher read a funny book, so we laughed.","the teacher read a funny book","we laughed"],["Ali was tired, so he took a nap.","Ali was tired","he took a nap"],["I forgot my pencil, so I asked my teacher for one.","I forgot my pencil","I asked my teacher for one"],["The fan was on, so the paper blew away.","the fan was on","the paper blew away"],["We practised our song, so we sang well.","we practised our song","we sang well"],["The cat sat on the mat, so the mat was warm.","the cat sat on the mat","the mat was warm"],["Jess lives far from town, so she learns on a computer.","Jess lives far from town","she learns on a computer"],["My cap was too big, so it fell off.","my cap was too big","it fell off"],["We shared the ball, so everyone could play.","we shared the ball","everyone could play"],["The paint was wet, so we did not touch it.","the paint was wet","we did not touch it"]],
 CMP:[
  ["A pencil and a crayon both help us draw. A pencil is grey. A crayon can be many colours.","Both help us draw","A pencil is grey, but a crayon can be many colours",["Both are scissors","A crayon is always grey"]],
  ["Rina and Arjun both go to school. Rina learns on a boat. Arjun learns under a tree.","Both go to school","Rina learns on a boat, but Arjun learns under a tree",["Both learn in the snow","Arjun learns on a boat"]],
  ["A cat and a bat both have the short a sound. A cat says meow. A bat can fly.","Both have the short a sound","A cat says meow, but a bat can fly",["Both can fly","A cat can fly"]],
  ["A slide and a swing are both on the playground. You go down a slide. You go back and forth on a swing.","Both are on the playground","You go down a slide, but back and forth on a swing",["Both are in the office","You go down a swing"]],
  ["A book and a map both have pictures. A book tells a story. A map shows places.","Both have pictures","A book tells a story, but a map shows places",["Both are pencils","A map tells a story"]],
  ["Nuka and Jess both live far from big cities. Nuka lives where it is snowy. Jess lives where it is hot and dry.","Both live far from big cities","Nuka's home is snowy, but Jess's home is hot and dry",["Both live in big cities","Jess's home is snowy"]],
  ["A teacher and a principal both work at a school. A teacher helps one class. A principal leads the whole school.","Both work at a school","A teacher helps one class, but a principal leads the whole school",["Both are students","A teacher leads the whole school"]],
  ["A ruler and scissors are both school tools. A ruler measures. Scissors cut.","Both are school tools","A ruler measures, but scissors cut",["Both are toys","A ruler cuts"]],
  ["A hat and a cap are both things you wear. A hat can have a wide brim. A cap has a flap at the front.","Both are things you wear","A hat can have a wide brim, but a cap has a flap at the front",["Both are things you eat","A cap has a wide brim"]],
  ["Gym and recess are both times to move. Gym is inside with a coach. Recess is outside on the playground.","Both are times to move","Gym is inside, but recess is outside",["Both are times to sleep","Recess is inside with a coach"]],
  ["Art and music are both fun classes. In art, we paint. In music, we sing.","Both are fun classes","In art we paint, but in music we sing",["Both are math classes","In art we sing"]],
  ["Pam's bag and Jamal's bag are both red. Pam's bag has a cat tag. Jamal's bag has a hat tag.","Both bags are red","Pam's bag has a cat tag, but Jamal's has a hat tag",["Both bags are blue","Pam's bag has a hat tag"]]
 ],
 GRP:{"school tools":["pencil","crayon","ruler","scissors","eraser"],"people at school":["teacher","principal","student","librarian","coach"],"places in a school":["gym","library","office","hallway","music room"],"playground things":["slide","swing","seesaw","monkey bars"],"short a words":["cat","map","fan","van","jam"],"numbers":["one","two","three","four","five"],"shapes":["circle","square","oval","star","heart"]},
 ANA:[["Pencil is to write as scissors is to ___.","cut",["sing","sleep"]],["Book is to read as song is to ___.","sing",["cut","run"]],["Teacher is to school as doctor is to ___.","hospital",["beach","zoo"]],["Hot is to cold as up is to ___.","down",["top","high"]],["Cat is to cats as bag is to ___.","bags",["bag","bug"]],["Big is to small as happy is to ___.","sad",["glad","fun"]],["Crayon is to colour as ruler is to ___.","measure",["sing","jump"]],["Day is to night as in is to ___.","out",["at","on"]],["Fish is to water as bird is to ___.","sky",["desk","rug"]],["Boat is to water as car is to ___.","road",["sky","sea"]],["Bat is to cat as fan is to ___.","man",["map","fin"]],["Pen is to ink as paintbrush is to ___.","paint",["rope","bell"]],["Gym is to run as library is to ___.","read",["swim","shout"]],["Snow is to cold as sun is to ___.","hot",["wet","dark"]],["One is to two as three is to ___.","four",["one","ten"]],["Bag is to bags as box is to ___.","boxes",["boxs","bax"]],["Swing is to playground as desk is to ___.","classroom",["beach","sky"]],["Coach is to gym as librarian is to ___.","library",["pool","farm"]],["Cat is to c-a-t as map is to ___.","m-a-p",["m-o-p","n-a-p"]],["Start is to begin as end is to ___.","finish",["open","go"]],["Quiet is to whisper as loud is to ___.","shout",["sleep","read"]],["Cold is to parka as hot is to ___.","sun hat",["boots","mittens"]]],
 SENT:["Pam and I go to school.","Jamal has a red bag.","I sit next to Lin.","Rina lives in Bangladesh.","Nuka walks in the snow.","Arjun reads under a tree.","Jess lives in Australia.","I like art with Sam.","Can Ali come and play?","Look at the map, Pam.","Lin and I sing a song.","Our school is in Canada.","Sam has a cap.","I can see Jamal.","Ana has a cat named Max.","I am six years old.","Ben and Ravi play tag.","My friend Mei likes to paint.","Is Kofi in your class?","I live in Toronto."],
 ORDER:["The cat is sad.","We go to school.","My bag is red.","Look at the map.","The van is big.","We sit on the rug.","It is my hat.","You can sit here.","The fan is on.","We like our teacher.","The bell is loud.","Get your bag.","Come and see.","A ram has horns.","We play with the ball.","My pencil is short.","The book is new.","We line up.","Pat the cat.","We sing a song."],
 WP:[
  {q:"Write a sentence about your school bag.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Bb]ag|[Bb]ackpack)","Uses the word bag"]],model:"My bag is blue."},
  {q:"Write a sentence about your teacher.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Tt]eacher","Uses the word teacher"]],model:"My teacher is kind."},
  {q:"Write a sentence with a short a word, like cat, map or bag.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Cc]at|[Mm]ap|[Bb]ag|[Hh]at|[Ff]an|[Jj]am|[Vv]an|[Rr]am|[Bb]at|[Cc]ap|[Mm]an|[Pp]an|[Nn]ap|[Ss]ad|[Tt]ag|[Mm]at|[Rr]at|[Tt]ap|[Dd]ad)\\b","Uses a short a word"]],model:"I have a cat."},
  {q:"Write a sentence about what you play at recess.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Pp]lay|[Rr]ecess)","Tells about play"]],model:"I play ball at recess."},
  {q:"Write a sentence with a <b>person</b> noun, like teacher, girl or boy.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Tt]eacher|[Gg]irl|[Bb]oy|[Mm]an|[Ww]oman|[Pp]rincipal|[Ss]tudent|[Cc]lassmate|[Ff]riend|[Mm]om|[Dd]ad|[Bb]aby|[Cc]oach|[Dd]octor|[Nn]urse)","Uses a person noun"]],model:"The girl has a book."},
  {q:"Write a sentence with a <b>place</b> noun, like school, park or gym.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ss]chool|[Pp]ark|[Gg]ym|[Ll]ibrary|[Pp]layground|[Zz]oo|[Bb]each|[Hh]ome|[Hh]ouse|[Ss]hop|[Pp]ool|[Cc]lass)","Uses a place noun"]],model:"We go to the park."},
  {q:"Write a sentence with a <b>thing</b> noun, like pencil, ball or hat.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Pp]encil|[Bb]all|[Hh]at|[Bb]ook|[Bb]ag|[Cc]hair|[Cc]rayon|[Dd]esk|[Mm]ap|[Kk]ite|[Dd]rum|[Rr]uler|[Cc]up|[Pp]en|[Bb]ox)","Uses a thing noun"]],model:"My pencil is long."},
  {q:"Write a sentence that starts with <b>We</b>.",checks:[CHK.end,CHK.w3,CHK.I,["^\\s*We\\b","Starts with We"]],model:"We sit on the rug."},
  {q:"Write a sentence that uses the sight word <b>look</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Ll]ook","Uses look"]],model:"Look at my new hat."},
  {q:"Write a sentence that uses the sight word <b>here</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Hh]ere\\b","Uses here"]],model:"Come and sit here."},
  {q:"Write one rule for your class.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"We walk in the hall."},
  {q:"Write a question to ask a classmate. End it with <b>?</b>",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"Do you like art?"},
  {q:"Write a sentence with your name and the word <b>I</b>.",checks:[CHK.cap,CHK.end,CHK.I,CHK.name,["\\bI\\b","Uses I"]],model:"I am Pam."},
  {q:"Write a sentence about a school on a boat.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Bb]oat","Uses the word boat"]],model:"Rina goes to school on a boat."},
  {q:"Write a sentence about your favourite thing to do at school.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I like to paint at school."},
  {q:"Write a sentence that uses <b>and</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\band\\b","Uses and"]],model:"Pam and Jamal play tag."},
  {q:"Write a sentence about your classroom.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Cc]lass","Uses class or classroom"]],model:"My classroom has a big window."},
  {q:"Write a sentence that uses the sight word <b>you</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Yy]ou\\b","Uses you"]],model:"You can sit with me."},
  {q:"Write a sentence about something at school. Start with <b>I see</b>.",checks:[CHK.end,CHK.w3,["^\\s*I see\\b","Starts with I see"]],model:"I see a map on the wall."},
  {q:"Write a sentence about a friend at school.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ff]riend|[Cc]lassmate)","Uses friend or classmate"]],model:"My friend Lin likes to sing."}
 ],
 SYN:[["big","large"],["little","small"],["happy","glad"],["fast","quick"],["shut","close"],["start","begin"],["talk","speak"],["neat","tidy"],["sad","unhappy"],["nice","kind"],["yell","shout"],["jump","leap"],["pick","choose"],["mad","angry"],["gift","present"],["end","finish"],["right","correct"],["tired","sleepy"],["stone","rock"],["laugh","giggle"]],
 OPP:[["up","down"],["in","out"],["hot","cold"],["wet","dry"],["fast","slow"],["happy","sad"],["big","small"],["day","night"],["full","empty"],["loud","quiet"],["push","pull"],["yes","no"],["early","late"],["first","last"],["open","shut"],["near","far"],["front","back"],["clean","dirty"],["come","go"],["give","take"]],
 COMP:[["class","room"],["play","ground"],["note","book"],["paint","brush"],["back","pack"],["rain","bow"],["sun","flower"],["snow","man"],["bed","room"],["gold","fish"],["sand","box"],["home","work"],["black","board"],["out","side"],["in","side"],["birth","day"],["butter","fly"],["door","bell"],["side","walk"],["sea","shell"],["star","fish"],["mail","box"],["dog","house"]]
};
B.CHOOSE=G4.ch([["pencil","pensil","pencel"],["crayon","crayen","craon"],["ruler","rular","rooler"],["scissors","sizzors","scisors"],["paper","papper","payper"],["book","buk","boock"],["school","skool","scool"],["chair","chiar","chaer"],["computer","compooter","computor"],["clock","klock","clok"],["teacher","teecher","teachar"],["student","studant","stoodent"],["glue","gloo","glew"],["rope","roap","rowp"],["game","gaim","gayme"],["song","sogn","sonng"],["quiet","kwiet","quiat"],["notebook","notbook","noteboock"],["world","wurld","wrold"],["please","pleese","pleze"]],B.SP);

const L={
 sa:"In <b>cat</b>, the <b>a</b> says /a/, like at the start of 🐜 <b>a</b>nt. This is the <b>short a</b> sound: c-a-t, m-a-p, b-a-g.",
 pic:"Look at the picture and say its name slowly: 🎒 b-a-g. Then find the word that matches.",
 make:"Say each sound in the picture word: 🐱 c - a - t. Write a letter for each sound to make the word.",
 rhyme:"Rhyming words end with the same sound. <b>cat, hat, bat</b> end in <b>-at</b>. <b>fan, man, van</b> end in <b>-an</b>. <b>cap, map, nap</b> end in <b>-ap</b>.",
 listen:"Listen to the word. Say each sound, and write a letter for each one: v-a-n spells <b>van</b>.",
 sight:"Sight words are words we see a lot. Learn them by heart: <b>we, go, to, at, it, in, and, you, look, here</b>. Example: <i>We go to school.</i>",
 ppt:"A <b>noun</b> names a <b>person</b> (teacher), a <b>place</b> (school) or a <b>thing</b> (pencil).",
 find:"Look for the word that names a person, place or thing. In <i>The bag is big</i>, the noun is <b>bag</b>.",
 which:"Ask: is it someone, somewhere or something? Then it is a noun. <i>book</i> is a noun. <i>run</i> is not.",
 sched:"A schedule shows the order of the day. Read it from top to bottom. Number 1 is first.",
 sch:"Think about the class rules. What would a kind and safe classmate do?"
};
u.review=G4.MIX(pptQ,pptPick,findN,whichN,notN,saWhich,saRhyme,F.vocab(u.words));
u.cats=G4.std(u,{sets:["My classroom","School things","People and playtime","Rules and our world"],B,
 reading:[{id:"r_sched",t:"Read the class schedule",learn:L.sched,gen:sched}],
 vocab:[{id:"v_sight",t:"Sight words: we, go, to, at, it, in, and, you, look, here",learn:L.sight,gen:G4.MIX(swFill,swHear,swFind)}],
 grammar:[{id:"g_ppt",t:"Nouns: person, place or thing?",learn:L.ppt,gen:G4.MIX(pptQ,pptPick)},{id:"g_findn",t:"Find the noun in the sentence",learn:L.find,gen:findN},{id:"g_whichn",t:"Which word is a noun?",learn:L.which,gen:G4.MIX(whichN,notN)},{id:"g_mixed",t:"Mixed review: nouns and short a",learn:"Use what you learned about nouns and the short a sound.",gen:u.review}],
 spelling:[{id:"s_sa",t:"Short a: which word has short a?",learn:L.sa,gen:saWhich},{id:"s_sapic",t:"Short a: picture to word",learn:L.pic,gen:saPic},{id:"s_samake",t:"Short a: make the word (c _ t)",learn:L.make,gen:saMake},{id:"s_sarhyme",t:"Rhyming words: -at, -an, -ap",learn:L.rhyme,gen:saRhyme},{id:"s_salisten",t:"Short a words: listen and write",learn:L.listen,gen:F.listen(SALIST)}],
 thinking:[{id:"t_school",t:"School smarts: what should you do?",learn:L.sch,gen:F.bank(SCH)}]});
})();
