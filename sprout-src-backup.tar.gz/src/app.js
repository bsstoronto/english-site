/* ================= SETTINGS ================= */
const SITE_NAME = "Sprout English";   // placeholder name — change this one line later
const COMING=[];

/* ================= SAVED PROGRESS (this browser only) ================= */
const KEY="sprout_v5";
let S;
try{S=JSON.parse(localStorage.getItem(KEY))}catch(e){}
if(!S||!S.u)S={u:{}};
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
let U=UNITS[0];
function st(id){const k=id||U.id;const s=S.u[k]||(S.u[k]={});["sc","n","act","rv","read","write","seen"].forEach(x=>{if(!s[x])s[x]={}});return s}
function resetUnit(){if(confirm("Reset all progress for this unit?")){delete S.u[U.id];save();openUnit(U.id)}}

/* ================= HELPERS ================= */
const $=id=>document.getElementById(id);
const body=()=>$("pbody");
const norm=s=>s.toLowerCase().trim().replace(/[.!?]+$/,"").replace(/\s+/g," ");
function go(v){["home","grade","unit","part"].forEach(x=>$("v-"+x).classList.toggle("hidden",x!==v));window.scrollTo(0,0);try{speechSynthesis.cancel()}catch(e){}}
function say(t){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(String(t).replace(/<svg[\s\S]*?<\/svg>/g," ").replace(/<[^>]+>/g," ").replace(/_{3}/g,"blank").replace(/(_ )+_?/g,""));u.lang="en-US";u.rate=0.9;speechSynthesis.speak(u)}catch(e){}}
let toastT;
function toast(html){const t=$("toast");t.innerHTML=html;t.classList.remove("hidden");clearTimeout(toastT);toastT=setTimeout(()=>t.classList.add("hidden"),4500)}
function pick(a){return a[Math.floor(Math.random()*a.length)]}
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function sentenceCount(v){return (v.match(/[a-z][^.!?]*[.!?]/gi)||[]).length}
function vocabUsed(v){return U.words.filter(w=>new RegExp("\\b"+w.w,"i").test(v)).length}
function allItems(u){return (u||U).cats.flatMap(c=>c.items)}
function code(ci,ii){return String.fromCharCode(65+ci)+"."+(ii+1)}
function findItem(id){let r;U.cats.forEach((c,ci)=>c.items.forEach((it,ii)=>{if(it.id===id)r={it,c,ci,ii}}));return r}
function isMastered(it,uid){const s=st(uid);return it.act?!!s.act[it.id]:(s.sc[it.id]||0)>=100}
function unitStats(u){const items=allItems(u);return {done:items.filter(it=>isMastered(it,u.id)).length,total:items.length}}

/* ================= FSRS (v4.5 default weights) — used for daily review ================= */
const W=[0.4872,1.4003,3.7145,13.8206,5.1618,1.2298,0.8975,0.031,1.6474,0.1367,1.0461,2.1072,0.0793,0.3246,1.587,0.2272,2.8755];
const DAY=86400000,FACTOR=19/81,DECAY=-0.5;
const clampD=d=>Math.min(10,Math.max(1,d));
function fsrs(c,g,now){
  if(!c.s){c.s=W[g-1];c.d=clampD(W[4]-(g-3)*W[5])}
  else{const r=Math.pow(1+FACTOR*Math.max(0,(now-c.last)/DAY)/c.s,DECAY);
    if(g===1)c.s=W[11]*Math.pow(c.d,-W[12])*(Math.pow(c.s+1,W[13])-1)*Math.exp(W[14]*(1-r));
    else c.s=c.s*(1+Math.exp(W[8])*(11-c.d)*Math.pow(c.s,-W[9])*(Math.exp(W[10]*(1-r))-1));
    c.d=clampD(W[7]*W[4]+(1-W[7])*(c.d-W[6]*(g-3)));}
  c.last=now;c.due=g===1?now:now+Math.max(1,Math.round(c.s))*DAY;
}

/* ================= ONE QUESTION: show, check, give feedback ================= */
function writeChecks(it,v){return it.checks.map(c=>[new RegExp(c[0]).test(v),c[1]])}
function isRight(it,val){
  if(it.type==="write")return writeChecks(it,val).every(c=>c[0]);
  if(it.strict){const v=val.trim().replace(/\s+/g," ");return it.a.includes(v)}
  return it.a.map(norm).includes(norm(val));
}
function askQ(area,it,onAnswer){
  let answered=false;
  area.innerHTML=`<div class="row" style="justify-content:flex-end"><button class="btn ghost small" data-say>🔊 Listen</button></div>
    <div class="q">${it.q}</div><div data-qa></div>
    ${it.hint?`<button class="link" data-hint style="margin-top:10px">💡 Need a hint?</button><div data-hintbox></div>`:""}
    <div data-fb></div><div data-nx class="row" style="margin-top:14px;justify-content:flex-start"></div>`;
  const qa=area.querySelector("[data-qa]"),fb=area.querySelector("[data-fb]"),nx=area.querySelector("[data-nx]");
  area.querySelector("[data-say]").onclick=()=>say(it.say||it.q);
  if(it.autoSay)setTimeout(()=>say(it.say||it.q),250);
  const hb=area.querySelector("[data-hint]");if(hb)hb.onclick=()=>{area.querySelector("[data-hintbox]").innerHTML=`<div class="hintbox">💡 ${it.hint}</div>`;hb.remove()};
  function check(val,btn){
    if(answered)return;answered=true;
    const ok=isRight(it,val);
    qa.querySelectorAll("button,input,textarea").forEach(el=>el.disabled=true);
    if(it.type==="mc")qa.querySelectorAll(".opt").forEach(b=>{if(it.a.includes(b.dataset.v))b.classList.add("right");else if(b===btn)b.classList.add("wrong")});
    const h=area.querySelector("[data-hint]");if(h)h.remove();
    if(it.type==="write"){
      const list=writeChecks(it,val).map(c=>`${c[0]?"✅":"❌"} ${c[1]}`).join("<br>");
      fb.innerHTML=`<div class="fb ${ok?"ok":"no"}"><b>${ok?"Well written! ✏️⭐":"Almost! Look at the list."}</b><br>${list}<br><br>Example: <i>${esc(it.model)}</i></div>`;
    }else fb.innerHTML=`<div class="fb ${ok?"ok":"no"}"><b>${ok?pick(["Correct! 🎉","Great job! ⭐","Yes! 👏","Well done! 🌱","Excellent! 🌟"]):"Not quite. The correct answer is: "+esc(it.a[0])}</b><br>${it.why||""}</div>`;
    onAnswer(ok,nx);
  }
  if(it.type==="type"||it.type==="write"){
    const inp=document.createElement(it.type==="write"?"textarea":"input");
    if(it.type==="type")inp.className="ans";else inp.style.minHeight="90px";
    inp.placeholder=it.type==="write"?"Write here…":"Type your answer";
    inp.autocomplete="off";inp.setAttribute("autocapitalize","off");inp.setAttribute("spellcheck","false");
    if(it.type==="type")inp.onkeydown=e=>{if(e.key==="Enter"&&inp.value.trim()){e.preventDefault();check(inp.value)}};
    const b=document.createElement("button");b.className="btn";b.textContent="Check";b.style.marginTop="8px";b.onclick=()=>{if(inp.value.trim())check(inp.value)};
    qa.append(inp,b);setTimeout(()=>inp.focus(),30);
  }else{
    const box=document.createElement("div");box.className="opts";
    it.o.forEach(o=>{const b=document.createElement("button");b.className="opt";b.textContent=o;b.dataset.v=o;b.onclick=()=>check(o,b);box.appendChild(b)});
    qa.appendChild(box);
  }
}
function nextBtn(nx,label,fn){const b=document.createElement("button");b.className="btn";b.textContent=label;const t=Date.now();b.onclick=()=>{if(Date.now()-t>250)fn()};nx.appendChild(b);setTimeout(()=>b.focus(),60);return b}

/* ================= SKILL PRACTICE with a 0–100 mastery score ================= */
function gain(s){return s<30?8:s<60?6:s<80?4:s<90?3:2}
function loss(s){return s<30?3:s<60?5:s<80?7:s<90?9:12}
/* ---- no-repeat question picker ----
   Every question answered correctly is remembered (saved in the browser) and is not shown again
   until the learner has seen every question in that skill. Wrong answers come back a few questions later. */
const qk=q=>q.q+"|"+((q.a||[q.model])[0]);
function hsh(t){let h=5381;for(let i=0;i<t.length;i++)h=((h<<5)+h+t.charCodeAt(i))|0;return (h>>>0).toString(36)}
const recent=[],POOL={};
function poolSize(it){const k=U.id+"/"+it.id;if(POOL[k]==null){const s=new Set();for(let i=0;i<500;i++)s.add(hsh(qk(it.gen())));POOL[k]=s.size}return POOL[k]}
function newQ(it){
  const s=st(),key=it.id;const seen=new Set(s.seen[key]||[]);let q=null;
  for(let k=0;k<120;k++){const c=it.gen(),h=hsh(qk(c));if(!seen.has(h)&&!recent.includes(h)){q=c;break}}
  if(!q){s.seen[key]=[];save();for(let k=0;k<60;k++){const c=it.gen();if(!recent.includes(hsh(qk(c)))){q=c;break}}if(!q)q=it.gen()}
  q._h=hsh(qk(q));recent.push(q._h);if(recent.length>6)recent.shift();q._skill=key;return q;
}
function markSeen(q,ok){if(!ok||!q._skill)return;const s=st();const a=s.seen[q._skill]||(s.seen[q._skill]=[]);if(!a.includes(q._h)){a.push(q._h);if(a.length>800)a.shift()}}
/* how many correct answers mastery needs: never more than the number of different questions in the skill */
function needFactor(it){const n=Math.max(8,Math.min(22,Math.round(poolSize(it)*0.7)));return 22/n}
function practice(id){
  const f=findItem(id);if(!f)return;const it=f.it;
  if(it.act)return openActivity(it);
  $("partTag").textContent=f.c.n;go("part");
  body().innerHTML=`<div class="row"><div><span class="pill">${code(f.ci,f.ii)}</span> <b style="font-size:18px">${it.t}</b></div>
     <div class="scorebox"><div class="sclabel">Mastery</div><div class="scnum" id="scNum">0</div></div></div>
    <div class="bar" style="height:12px"><div id="scBar"></div></div>
    <div class="row" style="font-size:13px;color:var(--muted)"><span id="scInfo"></span><button class="link" id="learnBtn">📘 Learn how</button></div>
    <div id="learnBox"></div><div id="qArea" style="margin-top:6px"></div>`;
  $("learnBtn").onclick=()=>{const b=$("learnBox");b.innerHTML=b.innerHTML?"":`<div class="rule">${it.learn||""}</div>`};
  const s=st();
  function paint(){const sc=s.sc[id]||0;$("scNum").textContent=sc;$("scBar").style.width=sc+"%";
    $("scInfo").textContent=`${s.n[id]||0} question${(s.n[id]||0)===1?"":"s"} answered`+(sc>=90&&sc<100?" · 🔥 Challenge zone: keep going!":"")}
  function ask(){paint();
    if((s.sc[id]||0)>=100&&!s._keep){return mastered()}
    const cur=newQ(it);
    askQ($("qArea"),cur,(ok,nx)=>{
      markSeen(cur,ok);
      const before=s.sc[id]||0;
      s.sc[id]=Math.max(0,Math.min(100,before+(ok?Math.round(gain(before)*needFactor(it)):-loss(before))));
      s.n[id]=(s.n[id]||0)+1;
      if(before<100&&s.sc[id]>=100){if(!s.rv[id])s.rv[id]={};fsrs(s.rv[id],3,Date.now())}
      save();paint();
      nextBtn(nx,s.sc[id]>=100&&before<100?"Finish ⭐":"Next question →",ask);
    });
  }
  function mastered(){
    body().innerHTML=`<div style="text-align:center"><div class="big">🏆</div><h2 style="margin-top:0">Mastered!</h2>
     <p class="sub">You reached 100 in <b>${it.t}</b> after ${s.n[id]} questions.<br>This skill will come back in your Daily Review so you never forget it.</p>
     <p style="margin-top:20px"><button class="btn ghost" id="keepGo">Keep practising</button> <button class="btn" onclick="openUnit(U.id)">Back to the unit →</button></p></div>`;
    $("keepGo").onclick=()=>{practice2(id)};
  }
  s._keep=false;ask();
}
function practice2(id){ // extra practice after mastery (score stays 100)
  const f=findItem(id),it=f.it;
  body().innerHTML=`<div class="row"><div><span class="pill">${code(f.ci,f.ii)}</span> <b style="font-size:18px">${it.t}</b></div><span class="pill">Mastered ⭐ · extra practice</span></div><div id="qArea" style="margin-top:10px"></div>`;
  const loop=()=>{const cur=newQ(it);askQ($("qArea"),cur,(ok,nx)=>{markSeen(cur,ok);save();nextBtn(nx,"Next question →",loop)})};loop();
}

/* ================= DAILY REVIEW (spaced repetition on mastered skills) ================= */
function dueSkills(){const s=st(),now=Date.now();return allItems().filter(it=>it.gen&&s.rv[it.id]&&s.rv[it.id].due<=now)}
function reviewStart(){
  $("partTag").textContent="Daily review";go("part");
  const due=shuffle(dueSkills()).slice(0,8);
  if(!due.length){
    const s=st(),weak=allItems().filter(it=>it.gen&&(s.sc[it.id]||0)>0&&(s.sc[it.id]||0)<100).sort((a,b)=>(s.sc[a.id]||0)-(s.sc[b.id]||0));
    body().innerHTML=`<div style="text-align:center"><div class="big">🌙</div><h2 style="margin-top:0">Nothing to review today</h2>
     <p class="sub">Skills you master come back here on the right day, so you don't forget them.</p>
     ${weak.length?`<p style="margin-top:16px">Your weakest skill right now: <b>${weak[0].t}</b> (${s.sc[weak[0].id]})</p><p><button class="btn" onclick="practice('${weak[0].id}')">Practise it →</button></p>`:""}
     <p><button class="btn ghost" onclick="openUnit(U.id)">Back to the unit</button></p></div>`;return;
  }
  const queue=shuffle(due.flatMap(it=>[it,it])),res={};let i=0;
  body().innerHTML=`<div class="bar"><div id="rvBar"></div></div><div class="row"><span class="pill" id="rvInfo"></span><span class="pill" id="rvSkill"></span></div><div id="qArea"></div>`;
  const step=()=>{
    if(i>=queue.length)return finish();
    const it=queue[i];$("rvBar").style.width=(i/queue.length*100)+"%";$("rvInfo").textContent=`Question ${i+1} of ${queue.length}`;$("rvSkill").textContent=it.t;
    const cur=newQ(it);askQ($("qArea"),cur,(ok,nx)=>{markSeen(cur,ok);(res[it.id]=res[it.id]||[]).push(ok);i++;nextBtn(nx,i<queue.length?"Next →":"Finish ✓",step)});
  };
  const finish=()=>{const s=st(),now=Date.now();let kept=0,slip=[];
    due.forEach(it=>{const r=res[it.id]||[];const pass=r.filter(Boolean).length>=r.length-0&&r.every(Boolean);
      fsrs(s.rv[it.id],pass?3:1,now);if(pass)kept++;else{s.sc[it.id]=Math.min(s.sc[it.id]||0,85);slip.push(it)}});save();
    body().innerHTML=`<div style="text-align:center"><div class="big">🔁</div><h2 style="margin-top:0">Review done!</h2>
     <p class="sub">${kept} of ${due.length} skills still strong.${slip.length?"<br>These need a little more practice: <b>"+slip.map(x=>x.t).join(", ")+"</b>":""}</p>
     <p style="margin-top:18px">${slip.length?`<button class="btn ghost" onclick="practice('${slip[0].id}')">Practise ${esc(slip[0].t)}</button> `:""}<button class="btn" onclick="openUnit(U.id)">Back to the unit →</button></p></div>`};
  step();
}

/* ================= HOME / GRADE / UNIT PAGES ================= */
$("siteName").textContent=SITE_NAME;$("footName").textContent=SITE_NAME;document.title=SITE_NAME;
const GFILE={1:"grade1.html",2:"grade2.html",3:"index.html",4:"grade4.html",5:"grade5.html",6:"grade6.html",7:"grade7.html",8:"grade8.html",9:"grade9.html",10:"grade10.html"},GDESC={1:"Letter sounds, school, farm animals, food and more",2:"Friends, animals, our Earth, building and more",3:"Family, animals, plants, space and more",4:"Ecosystems, ancient worlds, energy, myths and more",5:"Body systems, oceans, space, mysteries and more",6:"Identity, ancient empires, climate and more",7:"Revolutions, genetics, media, forensics and more",8:"Identity, turning points, chemistry, stories and more",9:"Literature, epics, human origins, justice and more",10:"World literature, protest, climate solutions and more"};
$("gradeGrid").innerHTML=[...Array(12)].map((_,i)=>"Grade "+(i+1)).concat(["College"]).map((g,i)=>{const n=i+1,open=!!GFILE[n],here=n===GRADE;
  const act=here?'onclick="openGrade()"':open?`onclick="location.href='${GFILE[n]}#units'"`:"";
  return `<div class="card ${open?"click":"locked"}" ${act}><span class="pill">${open?"Open":"Coming soon"}</span><h3>${g}</h3><p>${open?GDESC[n]:"In progress"}</p></div>`}).join("");
$("gPill").textContent="Grade "+GRADE;$("gTitle").textContent="Grade "+GRADE+" English";$("gBack").textContent="← Grade "+GRADE+" units";
setTimeout(()=>{if(location.hash==="#units")openGrade()},0);
function openGrade(){
  const built=UNITS.map(u=>{const x=unitStats(u);
    return `<div class="card click" onclick="openUnit('${u.id}')"><div class="em">${u.emoji}</div>
      <span class="pill">Unit ${u.num} · ${x.done===x.total?"Complete ✓":x.done+"/"+x.total+" skills"}</span><h3>${u.title}</h3></div>`});
  const soon=COMING.map((c,i)=>`<div class="card locked"><div class="em">${c[0]}</div><span class="pill">Unit ${UNITS.length+i+1} · Coming soon</span><h3>${c[1]}</h3></div>`);
  $("unitGrid").innerHTML=built.concat(soon).join("");go("grade");
}
function openUnit(id){
  U=UNITS.find(u=>u.id===id)||UNITS[0];
  const s=st(),x=unitStats(U),due=dueSkills().length;
  $("unitEmoji").textContent=U.emoji;$("unitNum").textContent="Unit "+U.num;$("unitTitle").textContent=U.title;
  $("unitStars").textContent=`⭐ ${x.done} of ${x.total} skills mastered`;
  $("unitBadge").innerHTML=(x.done===x.total?`<div class="badge">${U.badge} badge earned!</div>`:"")+
    `<p style="margin:14px 0 0"><button class="btn" onclick="reviewStart()">🔁 Daily review${due?" ("+due+" due)":""}</button> <button class="btn ghost" onclick="openDict()">📖 Picture dictionary</button></p>`;
  $("partGrid").innerHTML=U.cats.map((c,ci)=>{const m=c.items.filter(it=>isMastered(it)).length;
    return `<div class="cat"><h3>${c.e} ${String.fromCharCode(65+ci)}. ${c.n} <span class="pill">${m}/${c.items.length}</span></h3>
     ${c.items.map((it,ii)=>{const sc=s.sc[it.id]||0,done=isMastered(it);
       const tag=done?"Mastered ⭐":it.act?(it.act==="write"?"Writing":it.act==="facts"?"Explore":"Read"):sc?sc+" / 100":"Start";
       return `<div class="skill ${done?"done":""}" onclick="practice('${it.id}')"><span class="code">${code(ci,ii)}</span><span class="st">${it.t}</span><span class="pill">${tag}</span></div>`}).join("")}</div>`}).join("");
  go("unit");
}

/* ================= ACTIVITIES: stories, poem, facts, writing ================= */
function openActivity(it){$("partTag").textContent=it.t;go("part");
  if(it.act==="story")storyPage(it.si,0,it.id);else if(it.act==="poem")poemPage(it.id,it.pi);else if(it.act==="facts")factsPart(0,0,it.id);else writeTask(it.wi,it.id)}
function finishAct(id){st().act[id]=true;save()}
function doneScreen(e,title,msg){
  body().innerHTML=`<div style="text-align:center"><div class="big">${e}</div><h2 style="margin-top:0">${title}</h2><p class="sub">${msg}</p>
  <p style="margin-top:20px"><button class="btn" onclick="openUnit(U.id)">Back to the unit →</button></p></div>`;
}
function hlOnce(html,w,i){let done=false;const rx=new RegExp("\\b"+w+"(s|es|d|ed)?\\b","i");
  return html.split(/(<[^>]+>)/).map(seg=>{if(done||seg.startsWith("<"))return seg;return seg.replace(rx,m=>{done=true;return `<button class="vw" onclick="showWord(${i})">${m}</button>`})}).join("")}
function highlight(text){let out=text;U.words.forEach((w,i)=>{out=hlOnce(out,w.w,i)});return out}
/* ================= PICTURE DICTIONARY ================= */
function dictSets(){const its=(U.cats.find(c=>c.n==="Vocabulary")||{items:[]}).items;let v=its.filter(it=>/^v_s[1-4]$/.test(it.id)).map(it=>it.t);if(v.length!==4)v=its.filter(it=>/^v_(fam|jobw|desc|home)$/.test(it.id)).map(it=>it.t);
  return v.length===4?v:["Words 1–10","Words 11–20","Words 21–30","Words 31–40"]}
let DSET=-1,DQ="";
function openDict(){$("partTag").textContent="📖 Picture dictionary";go("part");DSET=-1;DQ="";dictRender()}
function dictRender(){const sets=dictSets();
  const list=U.words.map((w,i)=>({w,i})).filter(x=>(DSET<0||Math.floor(x.i/10)===DSET)&&(!DQ||x.w.w.toLowerCase().startsWith(DQ)));
  body().innerHTML=`<h2 style="margin-top:0">📖 Picture dictionary</h2><p class="sub">${U.words.length} words from <b>${U.title}</b>. Tap a picture to hear the word and see what it means.</p>
   <div class="row" style="flex-wrap:wrap;gap:6px;justify-content:flex-start;margin:10px 0">
    <button class="btn small ${DSET<0?"":"ghost"}" onclick="DSET=-1;dictRender()">All</button>
    ${sets.map((t,k)=>`<button class="btn small ${DSET===k?"":"ghost"}" onclick="DSET=${k};dictRender()">${t}</button>`).join("")}</div>
   <div class="row" style="gap:8px;justify-content:flex-start;flex-wrap:wrap;margin-bottom:12px">
    <input id="dq" placeholder="🔍 Find a word" value="${DQ}" style="flex:1;min-width:160px;padding:10px 12px;border:2px solid var(--line,#cfe3d6);border-radius:12px;font-size:17px">
    <button class="btn" onclick="dictQuiz()">🎯 Picture quiz</button></div>
   <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px">
    ${list.map(x=>`<button onclick="dictCard(${x.i})" style="background:#fff;border:2px solid #d6eadd;border-radius:16px;padding:12px 6px;cursor:pointer;text-align:center;font:inherit">
      <div style="font-size:52px;line-height:1.15">${x.w.e}</div><div style="font-size:19px;font-weight:700;margin-top:6px;color:#1d3b2c">${x.w.w}</div></button>`).join("")||`<p class="sub">No words found.</p>`}
   </div>
   <p style="margin-top:20px"><button class="btn ghost" onclick="openUnit(U.id)">← Back to the unit</button></p>`;
  const dq=$("dq");dq.oninput=()=>{DQ=dq.value.trim().toLowerCase();const pos=dq.selectionStart;dictRender();const n=$("dq");n.focus();n.setSelectionRange(pos,pos)}}
function dictCard(i){const w=U.words[i],n=U.words.length;say(w.w+". "+w.m);
  const exHL=w.ex.replace(new RegExp("\\b("+w.w+"(s|es|d|ed)?)\\b","i"),"<b style=\"color:#2f6b4f\">$1</b>");
  body().innerHTML=`<div style="text-align:center">
   <div style="font-size:110px;line-height:1.1;margin-top:6px">${w.e}</div>
   <h2 style="margin:8px 0 2px;font-size:38px">${w.w}</h2>
   <p style="margin:6px 0 14px"><button class="btn ghost small" onclick="say(U.words[${i}].w)">🔊 Say the word</button> <button class="btn ghost small" onclick="say(U.words[${i}].w+'. '+U.words[${i}].ex)">🔊 Say the sentence</button></p>
   <div class="qbox" style="text-align:left;font-size:19px;line-height:1.6"><b>What it means:</b> ${w.m}<br><b>Example:</b> ${exHL}</div>
   <div class="row" style="justify-content:space-between;margin-top:16px">
    <button class="btn ghost" onclick="dictCard(${(i+n-1)%n})">← Back</button>
    <button class="btn ghost" onclick="dictRender()">All words</button>
    <button class="btn" onclick="dictCard(${(i+1)%n})">Next →</button></div></div>`}
let DQZ=null;
function dictQuiz(){const pool=DSET<0?U.words.map((_,i)=>i):U.words.map((_,i)=>i).filter(i=>Math.floor(i/10)===DSET);DQZ={order:SAMPLE(pool,Math.min(10,pool.length)),k:0,right:0};dictQ()}
function dictQ(){const z=DQZ;if(z.k>=z.order.length){body().innerHTML=`<div style="text-align:center"><div class="big">${z.right>=z.order.length-1?"🏆":"🌟"}</div><h2 style="margin-top:0">${z.right} out of ${z.order.length}!</h2><p class="sub">${z.right===z.order.length?"Perfect! You know all these words.":"Look at the dictionary again, then try another quiz."}</p>
   <p><button class="btn" onclick="dictQuiz()">🎯 Another quiz</button> <button class="btn ghost" onclick="dictRender()">📖 Dictionary</button></p></div>`;return}
  const i=z.order[z.k],w=U.words[i];const others=SAMPLE(U.words.filter(x=>x!==w&&x.e!==w.e),3);const opts=shuffle([w].concat(others));const pic=Math.random()<.5;
  body().innerHTML=`<div style="text-align:center"><p class="sub">Question ${z.k+1} of ${z.order.length} · ⭐ ${z.right}</p>
   ${pic?`<div style="font-size:100px;line-height:1.1">${w.e}</div><h3>Which word matches the picture?</h3>`:`<button class="btn ghost" onclick="say('${w.w.replace(/'/g,"\\'")}')" style="font-size:20px">🔊 Listen again</button><h3>Which picture shows the word you heard?</h3>`}
   <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;max-width:440px;margin:0 auto">
   ${opts.map(o=>`<button data-ok="${o===w?1:0}" style="background:#fff;border:2px solid #d6eadd;border-radius:16px;padding:14px 6px;cursor:pointer;font:inherit;${pic?"font-size:21px;font-weight:700":"font-size:56px"}">${pic?o.w:o.e}</button>`).join("")}</div>
   <p id="dfb" style="min-height:28px;font-size:18px;margin-top:12px"></p></div>`;
  if(!pic)setTimeout(()=>say(w.w),250);
  body().querySelectorAll("[data-ok]").forEach(b=>b.onclick=()=>{const ok=b.dataset.ok==="1";body().querySelectorAll("[data-ok]").forEach(x=>{x.disabled=true;if(x.dataset.ok==="1")x.style.borderColor="#2f9a5f",x.style.background="#e3f6ea"});
    if(!ok)b.style.borderColor="#d9534f",b.style.background="#fdecea";if(ok)z.right++;say(ok?"Yes! "+w.w:"It is "+w.w);
    $("dfb").innerHTML=`${ok?"✅ Yes!":"Not quite."} ${w.e} <b>${w.w}</b>: ${w.m}<br><button class="btn" style="margin-top:10px" onclick="DQZ.k++;dictQ()">Next →</button>`})}
function showWord(i){const w=U.words[i];say(w.w+". "+w.m);toast(`${w.e} <b>${w.w}</b>: ${w.m}`)}
function askMany(container,qs,onAll){
  let left=qs.length;
  qs.forEach(qq=>{
    const box=document.createElement("div");box.className="qbox";
    box.innerHTML=`${qq.lv?`<span class="lvtag">${qq.lv==="find"?"🔎 Find it":qq.lv==="predict"?"🔮 Predict":"💭 Think about it"}</span><br>`:""}<b>${qq.q}</b> <button class="link">🔊</button><div class="opts" style="margin-top:10px"></div><div></div>`;
    const kids=[...box.children].filter(x=>x.tagName!=="BR"&&!x.classList.contains("lvtag"));kids[1].onclick=()=>say(qq.q);
    const opts=kids[2],fb=kids[3];
    shuffle(qq.o.slice()).forEach(o=>{const b=document.createElement("button");b.className="opt";b.textContent=o;
      b.onclick=()=>{const ok=qq.a.includes(o);
        opts.querySelectorAll(".opt").forEach(x=>{x.disabled=true;if(qq.a.includes(x.textContent))x.classList.add("right");else if(x===b)x.classList.add("wrong")});
        fb.innerHTML=`<div class="fb ${ok?"ok":"no"}"><b>${ok?"Correct! 🎉":"Not quite."}</b> ${qq.why}</div>`;if(--left===0)onAll()};
      opts.appendChild(b)});
    container.appendChild(box)});
}
function storyPage(si,pg,id){
  const s=U.stories[si],p=s.pages[pg],n=s.pages.length;
  body().innerHTML=`<div class="bar"><div style="width:${pg/n*100}%"></div></div>
    <div class="storypic">${p.pic}</div>
    <div class="row"><span class="pill">${s.title} · Page ${pg+1} of ${n}</span><button class="btn ghost small" onclick="say(U.stories[${si}].pages[${pg}].text)">🔊 Read to me</button></div>
    <div class="story">${highlight(p.text)}</div>
    <p style="color:var(--muted);font-size:13px;margin:0">Tip: tap a <span class="vw">green word</span> to hear it and learn what it means.</p>
    <div id="qs"></div><div id="snext" style="margin-top:14px"></div>`;
  askMany($("qs"),p.qs,()=>nextBtn($("snext"),pg+1<n?"Next page →":s.turn?"Your turn ✍️ →":"Finish ✓",()=>{if(pg+1<n)storyPage(si,pg+1,id);else if(s.turn)turnPage(si,id);else storyDone(s,id)}));
}
function storyDone(s,id){finishAct(id);doneScreen(s.e,"Well read!",`You finished "${s.title}". Now try the other reading skills in this unit.`)}
function turnPage(si,id){
  const s=U.stories[si];
  body().innerHTML=`<div class="storypic">✍️</div><span class="lvtag">✍️ Your turn</span><div id="qArea"></div>`;
  askQ($("qArea"),{type:"write",q:s.turn.q,checks:[CHK.cap,CHK.end,CHK.w4,CHK.I],model:s.turn.model},(ok,nx)=>{
    if(ok)nextBtn(nx,"Finish ✓",()=>storyDone(s,id));else nextBtn(nx,"Try again",()=>turnPage(si,id));});
}
function poemPage(id,pi){
  pi=pi||0;const p=(U.poems||[U.poem])[pi];
  body().innerHTML=`<div class="row"><span class="pill">Poem</span><button class="btn ghost small" onclick="say((U.poems||[U.poem])[${pi}].lines.join(' '))">🔊 Read the poem</button></div>
    <h2 style="margin-top:14px">${p.title}</h2><div class="poem">${p.lines.join("<br>")}</div>
    <p class="sub">Now read it aloud yourself. Can you hear the rhymes?</p><div id="qs"></div><div id="snext" style="margin-top:14px"></div>`;
  askMany($("qs"),p.qs,()=>nextBtn($("snext"),"Finish ✓",()=>{finishAct(id);doneScreen("🎵","Poem complete!","Try reading it aloud to someone at home.")}));
}
function factsPart(fi,score,id){
  const f=U.facts[fi],n=U.facts.length;
  body().innerHTML=`<div class="bar"><div style="width:${fi/n*100}%"></div></div>
   <div class="flash"><div class="em">${f.e}</div><p style="color:var(--muted);margin:6px 0">Fact ${fi+1} of ${n} · Guess first: true or false?</p>
   <div class="q" style="font-weight:700">${f.c}</div>
   <div class="row" style="justify-content:center"><button class="btn" id="fT">True ✅</button><button class="btn" id="fF">False ❌</button></div>
   <div id="ffb"></div></div><div id="fnx" class="row" style="justify-content:center"></div>`;
  say(f.c);
  const ans=g=>{$("fT").disabled=$("fF").disabled=true;const ok=g===f.t;if(ok)score++;
    $("ffb").innerHTML=`<div class="fb ${ok?"ok":"no"}" style="text-align:left"><b>${ok?"You guessed right! 🎉":"Surprise! 😲"}</b><br>${f.x}</div>`;
    nextBtn($("fnx"),fi+1<n?"Next fact →":"Finish ✓",()=>{if(fi+1<n)factsPart(fi+1,score,id);else{finishAct(id);doneScreen("💡","Fact explorer!",`You guessed ${score} of ${n} right. Share one fact with your family today!`)}})};
  $("fT").onclick=()=>ans(true);$("fF").onclick=()=>ans(false);
}
function taskChecks(t,v){
  const c=[[sentenceCount(v)>=t.minS,`I wrote at least ${t.minS} sentences`]];
  if(t.minWords)c.push([vocabUsed(v)>=t.minWords,`I used at least ${t.minWords} word${t.minWords>1?"s":""} from the word bank`]);
  return c.concat(t.rx.map(r=>[new RegExp(r[0]).test(v),r[1]]));
}
let curTask=0,curTaskId="";
function writeTask(i,id){
  curTask=i;curTaskId=id;const t=U.writing[i],saved=(st().write[i]||{}).text||"";
  const prev=i>0&&!(st().act[allItems().filter(x=>x.act==="write")[i-1].id]);
  body().innerHTML=`${prev?`<div class="hintbox">Tip: finish the writing step before this one first. Each step builds on the last.</div>`:""}
   <div class="flash" style="text-align:left"><span class="pill">${t.level}</span><h2 style="text-align:left;margin:8px 0">${t.e} ${t.t}</h2>
   <p style="font-size:17px;line-height:1.5;margin:0">${t.prompt}</p>
   <p style="margin:10px 0 0"><button class="btn ghost small" onclick="say(U.writing[${i}].prompt)">🔊 Read to me</button> <button class="btn ghost small" id="exBtn">👀 See an example</button></p><div id="exBox"></div></div>
   <p style="margin:12px 0 4px"><b>Sentence starters</b> (tap to add):</p>
   <div>${t.starters.map((s,k)=>`<span class="chip" onclick="ins(U.writing[${i}].starters[${k}])">${esc(s.trim())}…</span>`).join("")}</div>
   <p style="margin:12px 0 4px"><b>Word bank</b> (tap to add):</p>
   <div>${U.words.map((w,k)=>`<span class="chip" onclick="ins(U.words[${k}].w+' ')">${w.e} ${w.w}</span>`).join("")}</div>
   <textarea id="wr" style="margin-top:14px;min-height:200px" placeholder="Write here…"></textarea>
   <div id="checks" style="margin:10px 0"></div>
   <div class="row"><button class="btn ghost" onclick="say($('wr').value||'Write something first!')">🔊 Read my writing</button>
   <button class="btn" onclick="saveWriting()">Save my writing ✓</button></div><div id="wfb"></div>`;
  $("exBtn").onclick=()=>{$("exBox").innerHTML=`<div class="hintbox" style="white-space:pre-line;margin-top:10px">${esc(t.model)}</div><p style="font-size:13px;color:var(--muted)">This is only an example. Write about YOUR life.</p>`};
  $("wr").value=saved;$("wr").oninput=updateChecks;updateChecks();
}
function ins(t){const a=$("wr"),s=a.selectionStart??a.value.length;a.value=a.value.slice(0,s)+t+a.value.slice(a.selectionEnd??s);a.focus();a.selectionStart=a.selectionEnd=s+t.length;updateChecks()}
function updateChecks(){$("checks").innerHTML=taskChecks(U.writing[curTask],$("wr").value).map(c=>`<div class="check">${c[0]?"✅":"⬜"} ${c[1]}</div>`).join("")}
function saveWriting(){
  const v=$("wr").value,t=U.writing[curTask],all=taskChecks(t,v).every(c=>c[0]);
  st().write[curTask]={text:v};if(all)finishAct(curTaskId);save();
  $("wfb").innerHTML=all?`<div class="fb ok"><b>Wonderful writing! ✏️⭐</b><br>Your writing is saved. Read it aloud to someone at home!<br><br><button class="btn" onclick="openUnit(U.id)">Back to the unit →</button></div>`
    :`<div class="fb no"><b>Saved!</b> Tick all the boxes above to finish this step.</div>`;
}
