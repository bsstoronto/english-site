/* ===================== UNIT 1 · SKILL BANKS AND SKILL LIST (original content) ===================== */
(function(){
const u=UNITS.find(x=>x.id==="me");
const set=k=>u.words.slice(k*10,k*10+10);
const MIX=(...g)=>()=>R(g)();

/* ---------- Sentence banks ---------- */
const SENT=["I visit my grandmother on Sunday.","Leo and I made a card for Mom.","I can ride a bike.","My cousin and I love pancakes.","I live in Canada.","Dad and I went to the market.","I have a cat named Pepper.","Ana and I are best friends.","I help Grandfather in the garden.","I speak English and Hindi.","Yesterday I lost a tooth.","Mia and I read a book together.","Mia lives in a yellow house.","My mother is a nurse.","My father bakes bread every morning.","Leo loves football.","Grandmother tells funny stories.","Ana and Ben are twins.","We eat dinner together.","I feed the cat every morning.","Pepper is a black cat.","My aunt lives in Toronto.","Leo and I play in the garden.","We visit Grandfather in July.","My cousin speaks Spanish.","The baby is sleeping.","I have two brothers.","My uncle is a pilot.","We make pancakes on Sunday.","Mia draws a tall tree.","My grandmother came from India.","I help my dad in the kitchen.","Ben has straight hair.","Ana has curly hair.","Our neighbour has a big dog.","My parents work hard.","I am eight years old.","Leo is six years old.","The librarian found a book for me.","My best friend is called Sam.","We celebrate Diwali with lamps.","I wash the dishes after dinner.","Our family went to Paris.","Mr. Lee is our teacher.","My sister and I share a room.","Grandfather calls us on Saturday.","The firefighter is very brave.","Dad and I walk to school.","We have a party in June.","Mia and Leo have chores.","My cousins live in London.","I love my family."];
const ASK=["Where do you live?","How old are you?","What is your name?","Do you have a brother?","Who is your teacher?","When is your birthday?","Can you ride a bike?","Is Leo six years old?","What does your mother do?","Why is the baby crying?","Where is my pencil?","Do you like pancakes?","How many cousins do you have?","Who made this cake?","Are Ana and Ben twins?","What is your favourite colour?","When does school start?","Can I help you?","Is your aunt a teacher?","Who lives next door?","Where does Grandfather live?","What time is dinner?"];
const EXCL=["What a big family!","Wow, that cake is huge!","Hooray, Grandfather is here!","What a funny story!","Oh no, I dropped my pancake!","Watch out!","How beautiful your drawing is!","Yay, it is my birthday!","What a loud noise!","I love this game so much!","Ouch, that hurts!","Wow, you are so tall!","What a lovely surprise!","Hurry up, we are late!","That is amazing!"];
const FRAG=["The big yellow house.","Every Sunday morning.","My funny little brother.","In the kitchen.","Bakes bread every morning.","Under the big tree.","Ana and her twin brother.","After dinner.","Tells stories every night.","With my grandmother.","Plays football in the garden.","A black cat named Pepper.","On a video call.","Very tall and kind.","Lives in Toronto.","At the hospital.","Because it was raining.","My aunt and my uncle.","Before school.","Feeds the cat.","The noisy playground.","Flips the pancakes.","Next to my house.","Laughs at the funny story."];

const complete=()=>{
  if(Math.random()<.5){const s=R(SENT);return mcQ(`Is this a complete sentence?<br><b>${s}</b>`,"Yes, it is complete",["No, something is missing"],"It tells <b>who</b> and <b>what they do or are</b>, so it makes complete sense.","Does it tell who, and what they do?")}
  const s=R(FRAG);return mcQ(`Is this a complete sentence?<br><b>${s}</b>`,"No, something is missing",["Yes, it is complete"],"It does not make complete sense. It is missing <b>who</b> or <b>what happens</b>.","Does it tell who, and what they do?");
};

/* ---------- Question words ---------- */
const QW=[
 ["Who","___ is your best friend?","Sam is my best friend."],["Who","___ made this cake?","Grandmother made it."],["Who","___ lives next door?","Mrs. Chen lives next door."],["Who","___ is your teacher?","Mr. Lee is my teacher."],["Who","___ is knocking at the door?","It is Uncle Raj."],
 ["What","___ is your name?","My name is Mia."],["What","___ is your favourite food?","I love rice and dal."],["What","___ are you drawing?","I am drawing a tree."],["What","___ colour is your bag?","It is blue."],["What","___ did you eat for lunch?","I ate a sandwich."],
 ["Where","___ do you live?","I live in Toronto."],["Where","___ is my book?","It is under your bed."],["Where","___ does your aunt work?","She works at the library."],["Where","___ did you put the keys?","I put them on the table."],["Where","___ is the park?","It is next to the school."],
 ["When","___ is your birthday?","It is in June."],["When","___ does school start?","It starts at nine o'clock."],["When","___ will Grandfather visit?","He will visit next week."],["When","___ do you eat dinner?","We eat at six o'clock."],["When","___ did you lose your tooth?","I lost it yesterday."],
 ["Why","___ is the baby crying?","Because she is hungry."],["Why","___ are you laughing?","Because the story is funny."],["Why","___ did you wake up so early?","Because I wanted to help Dad bake."],["Why","___ is Leo sad?","Because his team lost."],["Why","___ do we brush our teeth?","Because it keeps them healthy."],
 ["How","___ old are you?","I am eight."],["How","___ many cousins do you have?","I have four cousins."],["How","___ do you get to school?","I walk with my dad."],["How","___ are you today?","I am fine, thank you."],["How","___ do you spell your name?","M-I-A."]
];
const WH={Who:"a person",What:"a thing",Where:"a place",When:"a time",Why:"a reason",How:"the way, how many or how old"};
const qword=()=>{const x=R(QW);return mcQ(`Choose the question word:<br><b>${x[1]}</b><br><span style="color:var(--muted);font-size:16px">Answer: ${x[2]}</span>`,x[0],SAMPLE(Object.keys(WH).filter(k=>k!==x[0]),2),`<b>${x[0]}</b> asks about ${WH[x[0]]}: ${x[1].replace("___",x[0])}`,"Look at the answer. Is it a person, a thing, a place, a time or a reason?")};
const matchQ=()=>{const x=R(QW);const others=SAMPLE(QW.filter(y=>y[0]!==x[0]),2).map(y=>y[1].replace("___",y[0]));
  return mcQ(`The answer is: <b>${x[2]}</b><br>What was the question?`,x[1].replace("___",x[0]),others,`${x[0]} asks about ${WH[x[0]]}.`,"What kind of information is in the answer?")};

/* ---------- Turn into a question ---------- */
const MQ=[["The pancakes","are","hot",0],["Your cousin","is","eight",0],["Leo","can","swim",1],["The library","is","open",0],["We","can","play outside",0],["Mr. Lee","is","our teacher",1],["The twins","can","speak French",0],["Grandfather","is","at home",1],["Pepper","is","asleep",1],["They","can","come to the party",0],["Your dad","is","a baker",0],["The baby","can","walk",0],["Leo","is","six years old",1],["Ana","is","a twin",1],["My mother","is","a nurse",0],["The baby","is","asleep",0],["Mia","can","draw birds",1],["You","can","swim",0],["They","are","cousins",0],["Your aunt","is","a teacher",0],["The cat","is","hungry",0],["Grandmother","can","tell stories",1],["We","are","late",0],["The pancakes","are","ready",0],["Ben","can","ride a bike",1],["Your house","is","yellow",0],["The twins","are","eight",0],["Dad","is","in the kitchen",1],["She","can","speak two languages",0],["It","is","Sunday",0]];
const makeQ=()=>{const m=R(MQ);const st=`${m[0]} ${m[1]} ${m[2]}.`;const subj=m[3]?m[0]:m[0].charAt(0).toLowerCase()+m[0].slice(1);const qq=`${cap(m[1])} ${subj} ${m[2]}?`;
  return {type:"type",strict:true,q:`Turn this telling sentence into a question:<br><b>${st}</b>`,a:[qq],hint:`Move the word "${m[1]}" to the front, give it a capital letter, and end with a question mark.`,why:`<b>${qq}</b> We move "${m[1]}" to the front.`}};

/* ---------- Nouns ---------- */
const NS=[["The baker sells fresh bread.",["baker","bread"],["sells","fresh"]],["My cousin has a funny dog.",["cousin","dog"],["has","funny"]],["Grandmother reads a long story.",["Grandmother","story"],["reads","long"]],["The tall pilot flies a plane.",["pilot","plane"],["tall","flies"]],["Leo kicks the red ball.",["Leo","ball"],["kicks","red"]],["The nurse helps the sick boy.",["nurse","boy"],["helps","sick"]],["Mia paints a green tree.",["Mia","tree"],["paints","green"]],["The baby sleeps in a soft bed.",["baby","bed"],["sleeps","soft"]],["My uncle drives a big truck.",["uncle","truck"],["drives","big"]],["The kind teacher smiles at the class.",["teacher","class"],["kind","smiles"]],["Pepper chases a little mouse.",["Pepper","mouse"],["chases","little"]],["The farmer feeds the hungry cows.",["farmer","cows"],["feeds","hungry"]],["Dad cooks rice in the kitchen.",["Dad","rice","kitchen"],["cooks","in"]],["Ben quickly opens the door.",["Ben","door"],["quickly","opens"]],["The brave firefighter climbs a ladder.",["firefighter","ladder"],["brave","climbs"]],["Ana writes a happy letter.",["Ana","letter"],["writes","happy"]],["The librarian finds a new book.",["librarian","book"],["finds","new"]]];
const findNoun=()=>{const x=R(NS);if(Math.random()<.6){const n=R(x[1]);return mcQ(`Which word is a <b>noun</b> (a naming word)?<br><b>${x[0]}</b>`,n,x[2],`<b>${n}</b> names a person, place, animal or thing. Nouns here: ${x[1].join(", ")}.`,"A noun names a person, place, animal or thing.")}
  const o=R(x[2]);return mcQ(`Which word is NOT a noun?<br><b>${x[0]}</b>`,o,SAMPLE(x[1],2),`<b>${o}</b> is not a naming word. The nouns are: ${x[1].join(", ")}.`,"Two of these name a person, animal or thing.")};
const COMMON=["girl","boy","city","river","dog","cat","teacher","school","country","mountain","day","month","park","street","baker","doctor","book","family","brother","friend","lake","language","holiday","cousin"];
const PROPER=["Tuesday","Wednesday","Thursday","Saturday","January","March","April","August","September","October","November","Spanish","French","Eid","Christmas","Ottawa","Mexico","Japan","Ben","Mrs. Chen","Mia","Leo","Toronto","India","Canada","Paris","Monday","Sunday","July","June","Pepper","Mr. Lee","London","Africa","Diwali","English","Hindi","Lake Ontario","Ana","Ben","Kenji","Delhi","Friday","December"];
const commonProper=()=>{if(Math.random()<.5){const p=Math.random()<.5;const w=p?R(PROPER):R(COMMON);
   return mcQ(`Is <b>${w}</b> a common noun or a proper noun?`,p?"proper noun":"common noun",[p?"common noun":"proper noun"],p?`<b>${w}</b> is the name of one special person, place or thing, so it is proper and starts with a capital.`:`<b>${w}</b> names any ${w}, not one special one, so it is common.`,"Proper nouns are special names and start with a capital letter.")}
  const p=R(PROPER);return mcQ("Which word is a <b>proper noun</b>?",p,SAMPLE(COMMON,2),`<b>${p}</b> is a special name, so it is a proper noun.`,"Look for the special name.")};
const capName=()=>{const p=R(PROPER);return {type:"type",strict:true,q:`Type this name correctly, with capital letters:<br><b>${p.toLowerCase()}</b>`,a:[p],hint:"Names of people, pets, places, days, months, languages and festivals start with a capital letter.",why:`<b>${p}</b> is a proper noun, so it starts with a capital letter.`}};

/* ---------- Write your own sentence ---------- */
const D=[CHK.cap,CHK.end,CHK.w4,CHK.I];
const WP=[
 {q:"Write a sentence about your favourite food. Say why you like it.",checks:D,model:"My favourite food is mango because it is sweet."},
 {q:"Write a sentence about what your family does on the weekend.",checks:D,model:"On Saturday, my family goes to the park."},
 {q:"Write a sentence that uses the word <b>proud</b>.",checks:[CHK.cap,CHK.end,["\\bproud\\b","Uses the word proud"],CHK.I],model:"I was proud when I learned to swim."},
 {q:"Write a question you could ask your grandparent about when they were young.",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"What games did you play when you were a child?"},
 {q:"Write a sentence with the name of a month in it.",checks:[CHK.cap,CHK.end,CHK.I,["\\b(January|February|March|April|May|June|July|August|September|October|November|December)\\b","Has a month with a capital letter"]],model:"My birthday is in October."},
 {q:"Write a sentence that describes a friend. Use two describing words.",checks:D,model:"My friend Sam is funny and kind."},
 {q:"Write an exclaiming sentence about a surprise.",checks:[CHK.cap,["!\\s*$","Ends with an exclamation mark"],CHK.w3],model:"What a wonderful surprise!"},
 {q:"Write a question that starts with <b>How</b>.",checks:[["^\\s*How\\b","Starts with How"],CHK.q,CHK.w3],model:"How do you get to school?"},
 {q:"Write a sentence about someone in your family.",checks:D,model:"My aunt has curly hair."},
 {q:"Write a sentence about what you do every morning.",checks:D,model:"I brush my teeth and eat breakfast."},
 {q:"Write a question you could ask a new friend.",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"What is your favourite game?"},
 {q:"Write an exclaiming sentence about a birthday party.",checks:[CHK.cap,["!\\s*$","Ends with an exclamation mark"],CHK.w3],model:"What a fun party!"},
 {q:"Write a sentence with the name of a city or country in it.",checks:[CHK.cap,CHK.end,CHK.name,CHK.I],model:"My grandfather lives in Delhi."},
 {q:"Write a sentence that uses the word <b>kind</b>.",checks:[CHK.cap,CHK.end,["\\bkind\\b","Uses the word kind"],CHK.I],model:"My brother is kind to animals."},
 {q:"Write a sentence about a job you would like to do one day.",checks:D,model:"I want to be a pilot one day."},
 {q:"Write a sentence about your favourite family tradition.",checks:D,model:"We eat pancakes every Sunday."},
 {q:"Write a question that starts with <b>Where</b>.",checks:[["^\\s*Where\\b","Starts with Where"],CHK.q,CHK.w3],model:"Where does your cousin live?"},
 {q:"Write a question that starts with <b>Why</b>.",checks:[["^\\s*Why\\b","Starts with Why"],CHK.q,CHK.w3],model:"Why is the sky blue?"},
 {q:"Write a sentence with the word <b>I</b> and a day of the week.",checks:[CHK.cap,CHK.end,["\\bI\\b","Uses the word I"],CHK.I,["\\b(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\\b","Has a day of the week with a capital letter"]],model:"I play football on Saturday."},
 {q:"Write a sentence describing what someone in your family looks like.",checks:D,model:"My dad is tall and has short black hair."},
 {q:"Write a sentence about a chore you do at home.",checks:D,model:"I make my bed every morning."},
 {q:"Write a sentence using the word <b>together</b>.",checks:[CHK.cap,CHK.end,["\\btogether\\b","Uses the word together"],CHK.I],model:"We play games together after dinner."}
];

/* ---------- Vocabulary banks ---------- */
const RELW=["grandmother","grandfather","aunt","uncle","cousin","father","mother","parents","twins","relatives","sister","brother","niece","nephew"];
const REL=[["Your sister's son is your ___.","nephew"],["Your brother's son is your ___.","nephew"],["Your sister's daughter is your ___.","niece"],["Your brother's daughter is your ___.","niece"],["Your mother's husband is your ___.","father"],["Your father's wife is your ___.","mother"],["Your parents' other son is your ___.","brother"],["Your parents' other daughter is your ___.","sister"],["Your grandmother's husband is your ___.","grandfather"],["Your father's brother's son is your ___.","cousin"],["Your mother's mother is your ___.","grandmother"],["Your father's mother is your ___.","grandmother"],["Your mother's father is your ___.","grandfather"],["Your father's father is your ___.","grandfather"],["Your mother's sister is your ___.","aunt"],["Your father's sister is your ___.","aunt"],["Your uncle's wife is your ___.","aunt"],["Your mother's brother is your ___.","uncle"],["Your father's brother is your ___.","uncle"],["Your aunt's husband is your ___.","uncle"],["Your aunt's son is your ___.","cousin"],["Your uncle's daughter is your ___.","cousin"],["Your mother and father are your ___.","parents"],["Two children born to the same mother on the same day are ___.","twins"],["All the people in your family, near and far, are your ___.","relatives"],["Your grandmother's husband is your ___.","grandfather"]];
const rel=()=>{const r=R(REL);return mcQ(r[0],r[1],SAMPLE(RELW.filter(x=>x!==r[1]),3),`${r[0].replace("___","<b>"+r[1]+"</b>")}`,"Draw a little family tree in your head.")};
const JOBS=[["nurse",["cares for sick people in a hospital","gives patients medicine and bandages"]],["baker",["bakes bread and cakes","starts work very early to make fresh bread"]],["artist",["paints and draws pictures","makes art for people to enjoy"]],["scientist",["does tests to learn how the world works","looks at tiny things under a microscope"]],["farmer",["grows crops and raises animals","plants seeds and milks cows"]],["firefighter",["puts out fires","rescues people from burning buildings"]],["teacher",["helps children learn to read and write","works in a classroom"]],["pilot",["flies a plane","lands planes safely at the airport"]],["mechanic",["fixes cars","repairs engines and machines"]],["librarian",["helps people find books","works in a library"]],["dentist",["checks and cleans your teeth"]],["chef",["cooks food in a restaurant"]],["police officer",["keeps people safe and makes sure laws are followed"]],["vet",["is a doctor for animals"]],["bus driver",["drives people around town on a bus"]],["builder",["builds houses"]],["mail carrier",["brings letters and parcels to your home"]]];
const job=()=>{const j=R(JOBS);return mcQ(`Who <b>${R(j[1])}</b>?`,"a "+j[0],SAMPLE(JOBS.filter(x=>x!==j),3).map(x=>"a "+x[0]),`A <b>${j[0]}</b> ${j[1].join(" and ")}.`,"Think about where this person works.")};
const OPP=[["tall","short"],["noisy","quiet"],["brave","scared"],["kind","mean"],["happy","sad"],["curly","straight"],["gentle","rough"],["funny","serious"],["old","young"],["big","small"],["early","late"],["hot","cold"],["fast","slow"],["full","empty"],["clean","dirty"],["strong","weak"],["awake","asleep"],["patient","impatient"],["near","far"],["first","last"]];
const SYN=[["big","large"],["small","little"],["happy","glad"],["kind","nice"],["shout","yell"],["quick","fast"],["begin","start"],["angry","mad"],["tired","sleepy"],["scared","afraid"],["pretty","beautiful"],["speak","talk"],["close","shut"],["gift","present"],["smart","clever"],["noisy","loud"],["easy","simple"],["sad","unhappy"],["end","finish"],["jump","leap"]];
const COMP=[["sun","flower"],["grand","mother"],["bed","room"],["foot","ball"],["rain","bow"],["some","one"],["cup","cake"],["class","room"],["home","work"],["pan","cake"],["butter","fly"],["book","shelf"],["birth","day"],["sea","shell"],["snow","man"],["tooth","brush"],["hair","cut"],["play","ground"],["back","pack"],["sun","shine"],["fire","fighter"],["news","paper"],["door","bell"],["week","end"],["mail","box"],["class","mate"],["air","plane"],["gold","fish"],["grand","father"],["note","book"]];

/* ---------- Spelling banks ---------- */
const SP=u.spelling.concat([
 {w:"children",s:"The children play outside."},{w:"little",s:"Leo is my little brother.",tip:"Double t: li-tt-le."},{w:"together",s:"We cook together.",tip:"to-get-her: three small words."},
 {w:"kitchen",s:"Dad is in the kitchen.",tip:"The 't' is quiet: ki-t-ch-en."},{w:"garden",s:"Our garden has a big tree."},{w:"morning",s:"I feed the cat every morning."},
 {w:"night",s:"Grandmother tells stories at night.",tip:"n-igh-t. The 'gh' is silent."},{w:"write",s:"I write a letter to my cousin.",tip:"The 'w' is silent: w-rite."},
 {w:"again",s:"Please read the story again."},{w:"because",s:"I am happy because it is Sunday.",tip:"Big Elephants Can Always Understand Small Elephants."},
 {w:"they",s:"They are my cousins."},{w:"said",s:"Mom said hello.",tip:"'ai' sounds like 'e' in said."},{w:"there",s:"There is a cat on the bed."},
 {w:"would",s:"Would you like a pancake?",tip:"The 'l' is silent: w-ou-l-d."},{w:"birthday",s:"Today is my birthday."}
]);
const CVC="cat hat map bag jam van fan bed pen hen net leg red ten web wet pig sit lip win pin big six zip dog hop pot box log mop fox top sun cup bus run mud hug nut rug".split(" ")
  .map(w=>({w,tip:"short "+w.match(/[aeiou]/)[0]+" sound"}));
const CHOOSE=[["friend","freind","frend"],["people","peeple","poeple"],["because","becuase","becos"],["said","sed","siad"],["they","thay","tey"],["there","thier","ther"],["eight","eigth","aight"],["cousin","cusin","cousen"],["school","skool","shcool"],["family","famly","familly"],["again","agen","agian"],["little","litle","littel"],["together","togather","togeter"],["kitchen","kichen","kitchin"],["morning","mornig","morening"],["birthday","brithday","birthdey"],["would","wud","woud"],["night","nite","nigt"],["brother","bruther","brothr"],["mother","muther","mothre"],["father","fathre","fahter"],["uncle","unkle","uncel"],["house","hous","howse"],["happy","hapy","happey"],["children","childern","chilren"],["garden","gardn","gardin"],["teacher","techer","teecher"],["baby","babey","babby"]]
  .map(x=>({w:x[0],bad:[x[1],x[2]],tip:(SP.find(y=>y.w===x[0])||{}).tip}));

/* ---------- Reading banks ---------- */
const DETAIL=[
 ["Grandpa's Stories","Grandpa grew up in a small village in Kenya. Every evening, he tells Zuri stories about his childhood. He walked five kilometres to school every day. He had one pair of shoes, and he kept them clean for church on Sundays.",[["Where did Grandpa grow up?","In a village in Kenya",["In a big city","In Canada"]],["How far did Grandpa walk to school?","Five kilometres",["One kilometre","Ten kilometres"]],["When did he wear his shoes?","On Sundays for church",["Every day","Only at night"]]]],
 ["The Family Picnic","On Saturday, the Kim family had a picnic by the lake. Mom made rice balls, and Dad brought fruit. Little Joon fed bread crumbs to the ducks until Grandma said, \"Ducks should eat seeds, not bread!\" Then everyone played tag on the grass.",[["Where was the picnic?","By the lake",["At school","In the kitchen"]],["What did Mom make?","Rice balls",["Pizza","Sandwiches"]],["What did Grandma say ducks should eat?","Seeds",["Bread","Cake"]]]],
 ["A New Home","When Amira was seven, her family moved from Syria to Canada. Everything was new: the language, the food and the snow! At first, Amira felt shy at school. Then a girl named Lucy asked her to play, and soon they were best friends.",[["Where did Amira's family move from?","Syria",["Mexico","Japan"]],["How did Amira feel at first?","Shy",["Angry","Bored"]],["Who asked Amira to play?","Lucy",["Her teacher","Her brother"]]]],
 ["Sunday Market","Every Sunday, Tom and his mother walk to the farmers' market. They buy fresh vegetables, eggs and bread. Tom's job is to carry the basket. His favourite stall sells honey from a farmer who keeps fifty beehives.",[["When do they go to the market?","Every Sunday",["Every Monday","Once a year"]],["What is Tom's job?","Carrying the basket",["Paying the money","Driving the car"]],["How many beehives does the farmer keep?","Fifty",["Five","Five hundred"]]]],
 ["Sam's Grandma","Sam visits his grandma every Friday. She lives in a small blue flat near the park. They feed the ducks together and then drink warm milk. Grandma always saves the biggest cookie for Sam.",[["When does Sam visit his grandma?","Every Friday",["Every Monday","Every day"]],["What colour is Grandma's flat?","Blue",["Yellow","Red"]],["What do they feed together?","Ducks",["Cats","Fish"]]]],
 ["The New Baby","Priya has a new baby brother. His name is Arjun. He is very small and sleeps most of the day. When he cries, Priya sings him a soft song, and he stops crying.",[["Who is Arjun?","Priya's baby brother",["Priya's cousin","Priya's dad"]],["What does Priya do when Arjun cries?","She sings him a soft song",["She shouts","She leaves the room"]]]],
 ["Moving Day","Today the Lopez family is moving to a new house. Dad carries the big boxes. Mom packs the plates. Rosa carries her favourite teddy bear. The new house has a garden with an apple tree.",[["What does Dad carry?","The big boxes",["The plates","The teddy bear"]],["What is in the new garden?","An apple tree",["A pool","A swing"]],["What does Rosa carry?","Her teddy bear",["The plates","A box"]]]],
 ["Two Languages","Omar speaks Arabic with his grandparents and English at school. At home, he helps his little sister learn English words. She can already count to ten in both languages!",[["Which language does Omar speak at school?","English",["Arabic","French"]],["Who does Omar help?","His little sister",["His teacher","His grandfather"]]]],
 ["Uncle Tom","Uncle Tom is a farmer. Every morning he drives his old green truck to the market. He sells eggs, carrots and potatoes. On Saturdays, I go with him and help him count the money.",[["What is Uncle Tom's job?","He is a farmer",["He is a pilot","He is a chef"]],["What colour is the truck?","Green",["Red","Blue"]],["Which food does Uncle Tom NOT sell?","Apples",["Eggs","Carrots"]]]],
 ["The Lost Tooth","Last night, Ben's front tooth fell out while he was eating an apple. He put the tooth under his pillow. In the morning, he found a shiny coin and a note that said, \"Well done, brave boy!\"",[["When did Ben's tooth fall out?","While he was eating an apple",["While he was playing football","While he was sleeping"]],["What did Ben find in the morning?","A shiny coin and a note",["His tooth","A new apple"]]]],
 ["Game Night","Every Friday is game night in Lily's family. They turn off the TV and play board games. Lily's dad always loses, but he laughs anyway. The winner gets to choose the dessert.",[["What do they turn off?","The TV",["The lights","The oven"]],["What does the winner get?","To choose the dessert",["A gold medal","A new game"]],["How does Dad feel when he loses?","He laughs anyway",["He gets angry","He goes to bed"]]]],
 ["Helping Hands","Mrs. Chen, our neighbour, is very old. Her legs hurt when she walks. Every week, my mom and I bring her groceries. Mrs. Chen gives us tea and tells us about her life in China.",[["Why do they bring Mrs. Chen groceries?","Her legs hurt when she walks",["She is a baker","She lives far away"]],["Where did Mrs. Chen live before?","China",["India","Canada"]]]],
 ["Dad's Bakery","Mia's dad opens his bakery at six o'clock. The first customer is always Mr. Brown, who buys two loaves of bread. By nine o'clock, all the cinnamon rolls are sold out!",[["Who is the first customer?","Mr. Brown",["Mia","Grandmother"]],["What is sold out by nine o'clock?","The cinnamon rolls",["The bread","The cakes"]],["What time does the bakery open?","Six o'clock",["Nine o'clock","Four o'clock"]]]],
 ["Different Twins","Ana and Ben are twins, but they like different things. Ana loves reading books about space. Ben loves building things with blocks. They both love their dog, Biscuit.",[["What does Ana love?","Reading books about space",["Building with blocks","Playing football"]],["What do the twins BOTH love?","Their dog, Biscuit",["Space books","Blocks"]]]]
];
const box=(t,txt)=>`<div class="qbox" style="margin:0 0 12px;font-size:18px;line-height:1.6;font-weight:400"><b>${t}</b><br>${txt}</div>`;
const detail=()=>{const p=R(DETAIL),x=R(p[2]);return mcQ(`${box(p[0],p[1])}${x[0]}`,x[1],x[2],`Look back at the text: the answer is there.`,"Read the text again and find the words.",{say:p[1]+" "+x[0]})};
const MAIN=[
 ["Everyone in a family can help. Little children can put away their toys. Older children can set the table. Grown-ups can cook and shop. When everyone helps, home is a happier place.","Everyone in a family can help at home.",["Toys go in boxes.","Grown-ups go shopping."]],
 ["Many families have special celebrations. Some light candles. Some eat special food. Some sing songs or dance. Celebrations bring families together.","Celebrations bring families together.",["Candles are bright.","Songs are fun."]],
 ["A good neighbour is a gift. Good neighbours say hello. They help carry heavy bags. They look after your pets when you are away.","Good neighbours help each other.",["Pets need care.","Bags can be heavy."]],
 ["Reading together is good for families. Parents and children can share stories. Children learn new words. Everyone spends happy time together.","Reading together is good for families.",["Stories have pictures.","Words are long."]],
 ["Grandparents and grandchildren can learn from each other. Grandparents teach old songs and recipes. Children teach grandparents how to use phones and tablets.","Grandparents and grandchildren learn from each other.",["Phones are useful.","Recipes are old."]],
 ["Some jobs help keep us safe. Firefighters put out fires. Police officers help people in trouble. Lifeguards watch swimmers at the pool.","Some jobs help keep us safe.",["Pools have water.","Fires are hot."]],
 ["Twins are born on the same day. Some twins look exactly alike. Others look very different. Twins can like different things, just like other brothers and sisters.","Twins can be alike or different.",["Babies are small.","Birthdays are fun."]],
 ["Saying sorry is important. When we hurt someone, saying sorry shows we care. It helps fix friendships. It also helps us learn from our mistakes.","Saying sorry is important.",["Friends play together.","Mistakes happen."]],
 ["A daily routine helps children. When you wake, eat and sleep at the same times, your body feels better. You also remember to do important things, like brushing your teeth.","A daily routine helps children.",["Teeth need brushing.","Sleep is at night."]],
 ["Pets can be part of a family. Children love playing with them. Pets give comfort when someone is sad. But pets also need food, water, exercise and love every day.","Pets are part of the family and need care.",["Dogs like to play.","Water is wet."]],
 ["Families can be big or small. Some families have many children, and some have just one. Some children live with their grandparents. Every family is different.","Every family is different.",["Grandparents are old.","Children like toys."]],
 ["In Mia's house, everyone helps. Mia feeds the cat. Leo waters the plants. Mom and Dad cook and clean.","Everyone in Mia's family helps at home.",["Mia has a cat.","Plants need water."]],
 ["Dogs make great pets. They are loyal and friendly. They love to play and go for walks. Many families have a dog.","Dogs make great pets.",["Dogs like walks in the rain.","Cats are better than dogs."]],
 ["Grandparents can teach us many things. They tell stories about the past. They share family recipes. They teach us old songs and games.","Grandparents teach us many things.",["Grandparents like recipes.","Old songs are boring."]],
 ["Breakfast is an important meal. It gives your body energy for the morning. Children who eat breakfast can think better at school.","Breakfast is important.",["School starts in the morning.","Eggs are tasty."]],
 ["There are many ways to say hello. In Spanish, people say \"hola\". In Hindi, people say \"namaste\". In French, people say \"bonjour\".","People say hello in many languages.",["Spanish is easy.","Everyone speaks French."]],
 ["Being a good friend is important. Good friends share and take turns. They listen to each other and help when someone is sad.","Good friends are kind to each other.",["Friends are always happy.","Taking turns is hard."]],
 ["Bees are very busy insects. They fly from flower to flower to collect nectar. They use it to make honey. Bees also help plants grow by carrying pollen.","Bees are busy, helpful insects.",["Flowers are pretty.","Honey is sticky."]],
 ["Libraries are wonderful places. You can borrow books for free. You can read quietly, use computers and join story time. Librarians are always ready to help.","Libraries are wonderful places to visit.",["Computers are fast.","Story time is short."]],
 ["Washing your hands keeps you healthy. Germs can live on your hands. Soap and water wash the germs away, so you are less likely to get sick.","Washing your hands keeps you healthy.",["Soap smells nice.","Water is wet."]],
 ["Many people help a town run well. Bus drivers take people to work. Mail carriers bring letters. Garbage collectors keep the streets clean.","Many people help a town run well.",["Buses are big.","Letters come in envelopes."]],
 ["Moving to a new school can feel scary. You might not know anyone. But after a few days, you learn your way around and start to make friends.","A new school feels scary at first, but it gets better.",["Schools are big buildings.","Friends are fun."]],
 ["Grandma's garden is full of life. Tomatoes grow up tall poles. Bees buzz around the sunflowers. A little frog lives near the pond.","Grandma's garden is full of life.",["Frogs are green.","Tomatoes are red."]],
 ["Sleep is very important for children. While you sleep, your body grows and your brain stores what you learned. Most children need between nine and twelve hours of sleep every night.","Sleep is important for children.",["Beds are soft.","Night is dark."]],
 ["Families share many jobs at home. Someone cooks, someone cleans, and someone takes out the rubbish. When everyone helps, the home runs smoothly.","Families share the jobs at home.",["Cooking is fun.","Rubbish smells bad."]],
 ["Firefighters have a dangerous job. They rush into burning buildings to save people. They wear special clothes to protect them from heat and smoke.","Firefighters do a brave and dangerous job.",["Smoke is grey.","Some buildings are tall."]]
];
const mainIdea=()=>{const m=R(MAIN);return mcQ(`${box("Read",m[0])}What is the <b>main idea</b>? (What is it mostly about?)`,m[1],m[2],`The main idea is what the whole text is about: <b>${m[1]}</b>`,"Which answer fits ALL the sentences, not just one?",{say:m[0]})};
const FACTS=["A year has twelve months.","Ottawa is the capital city of Canada.","A baby kangaroo is called a joey.","Most people have ten fingers.","Monday comes after Sunday.","A firefighter puts out fires.","Some people speak three languages.","Bread is made from flour.","Mia is eight years old.","A week has seven days.","Toronto is a city in Canada.","Most babies are born without teeth.","Cats have four legs.","Water turns to ice when it gets very cold.","There are twelve months in a year.","The Sun rises in the morning.","Spiders have eight legs.","Paris is in France.","A baker makes bread.","Leo is six years old.","Your heart pumps blood around your body.","Some families speak two languages at home.","July comes after June."];
const OPIN=["Little brothers are annoying.","Saturday is better than Sunday.","Grandmothers make the best food.","Being a pilot is the coolest job.","Short hair looks better than long hair.","Birthdays are the best days of the year.","Doing chores is boring.","Libraries are the most peaceful places.","Pancakes are the best breakfast.","Football is the most fun sport.","Green is the prettiest colour.","Cats are better than dogs.","Homework is boring.","Summer is the best season.","My grandmother tells the funniest stories.","Pizza tastes better than rice.","Drawing is easy.","Rainy days are sad.","Big families are more fun.","Maths is the hardest subject.","Dogs are the cutest animals.","Sunday is the best day of the week."];
const factOp=()=>{const f=Math.random()<.5;const s=f?R(FACTS):R(OPIN);return mcQ(`Is this a <b>fact</b> or an <b>opinion</b>?<br><b>${s}</b>`,f?"Fact":"Opinion",[f?"Opinion":"Fact"],f?"A <b>fact</b> can be checked and is true for everyone.":"An <b>opinion</b> is what someone thinks or feels. Other people may think differently.","Could you check it? Or do people feel differently about it?")};
const SEQ=[["Wake up","Brush your teeth","Eat breakfast","Walk to school"],["Mix the batter","Pour it into the pan","Flip the pancake","Eat the pancake"],["Plant a seed","Water it every day","A small shoot grows","A flower opens"],["Fill the bath","Get into the bath","Wash with soap","Dry yourself with a towel"],["Put on your socks","Put on your shoes","Tie your laces"],["Write a letter","Put it in an envelope","Add a stamp","Post the letter"],["The baby is born","The baby learns to crawl","The baby learns to walk","The child goes to school"],["Wash the dishes","Dry the dishes","Put the dishes away"],["Get on the bus","Ride to your stop","Get off the bus"],["Buy a cake","Put candles on the cake","Light the candles","Blow out the candles"],["Leo kicks the ball","The ball flies through the air","The ball goes into the goal","Everyone cheers"],["An egg","A caterpillar","A chrysalis","A butterfly"],["Wet your hands","Rub them with soap","Rinse with water","Dry your hands"]];
const order=()=>{const s=R(SEQ),t=R(["first","last","next"]);
  if(t==="first")return mcQ(`What happens <b>FIRST</b>?`,s[0],SAMPLE(s.slice(1),2),`Order: ${s.join(" → ")}`,"Think about what must happen before everything else.");
  if(t==="last")return mcQ(`What happens <b>LAST</b>?`,s[s.length-1],SAMPLE(s.slice(0,-1),2),`Order: ${s.join(" → ")}`,"Think about what happens at the very end.");
  const k=Math.floor(Math.random()*(s.length-1));return mcQ(`What happens right <b>AFTER</b> this?<br><b>${s[k]}</b>`,s[k+1],SAMPLE(s.filter((_,i)=>i!==k&&i!==k+1),2),`Order: ${s.join(" → ")}`,"What is the very next step?")};

/* ---------- Thinking banks ---------- */
const PUZ=u.think.map(t=>({q:t.q,o:t.o,a:t.a[0],why:t.why})).concat([
 {q:"🧩 Riddle: I am your father's father. Who am I?",o:["Your grandfather","Your uncle","Your brother"],a:"Your grandfather",why:"Your father's father is your grandfather."},
 {q:"🧩 Riddle: I am your aunt's daughter. Who am I?",o:["Your cousin","Your sister","Your niece"],a:"Your cousin",why:"Your aunt's children are your cousins."},
 {q:"🔑 You are home alone and someone you don't know knocks on the door. What should you do?",o:["Don't open the door, and call a grown-up you trust","Open the door","Tell them your parents are out"],a:"Don't open the door, and call a grown-up you trust",why:"Never open the door to a stranger when you are alone."},
 {q:"📞 In Canada and the USA, which number do you call in an emergency?",o:["911","123","100"],a:"911",why:"911 is the emergency number in Canada and the USA. (It is different in other countries, like 112 in India and Europe.)"},
 {q:"🤒 Your little brother feels very sick and hot. What should you do first?",o:["Tell a grown-up straight away","Give him your medicine","Wait until tomorrow"],a:"Tell a grown-up straight away",why:"A grown-up can decide how to help. Never give medicine yourself."},
 {q:"🧓 Your grandmother is carrying heavy shopping bags. What is a kind thing to do?",o:["Offer to help carry them","Walk away","Laugh"],a:"Offer to help carry them",why:"Helping family members shows kindness."},
 {q:"🍰 There are 4 people in your family and 1 cake. Into how many pieces should you cut it so everyone gets the same?",o:["4","2","10"],a:"4",why:"4 people need 4 equal pieces."},
 {q:"🕰️ School starts at 9 o'clock. It takes 30 minutes to walk there. When should you leave home?",o:["8:30","9:30","10 o'clock"],a:"8:30",why:"30 minutes before 9:00 is 8:30."},
 {q:"🧽 Leo spilled juice on the floor. What should he do?",o:["Clean it up or tell a grown-up","Leave it","Hide it under a rug"],a:"Clean it up or tell a grown-up",why:"Taking responsibility for accidents is the right thing to do."},
 {q:"👟 Which comes LAST when you get dressed?",o:["Tie your shoes","Put on your socks","Put on your shirt"],a:"Tie your shoes",why:"Socks and shirt go on before your shoes are tied."},
 {q:"🧒 Mia is older than Leo. Leo is older than the baby. Who is the oldest?",o:["Mia","Leo","The baby"],a:"Mia",why:"Mia is older than Leo, and Leo is older than the baby."},
 {q:"🎂 Today is Ana's 8th birthday. How old was she last year?",o:["7","8","9"],a:"7",why:"Last year she was one year younger: 8 − 1 = 7."},
 {q:"🗣️ A new boy in your class doesn't speak much English yet. What could you do?",o:["Smile, be patient and help him","Ignore him","Make fun of him"],a:"Smile, be patient and help him",why:"Learning a new language is hard. Kindness helps a lot."},
 {q:"📅 Which month comes BEFORE March?",o:["February","April","January"],a:"February",why:"January, February, March."},
 {q:"🍎 Which is the healthiest snack?",o:["An apple","A bag of candy","A can of soda"],a:"An apple",why:"Fruit gives your body vitamins and energy."},
 {q:"🧩 Riddle: I am your mother's sister. Who am I?",o:["Your aunt","Your cousin","Your grandmother"],a:"Your aunt",why:"Your mother's sister is your aunt."},
 {q:"🌧️ It is raining. What should Leo take to school?",o:["An umbrella","Sunglasses","A swimsuit"],a:"An umbrella",why:"An umbrella keeps you dry in the rain."},
 {q:"🔥 You are at home and you smell smoke. What is the best thing to do?",o:["Get out of the house and tell a grown-up","Hide under your bed","Open the oven to look"],a:"Get out of the house and tell a grown-up",why:"Get out fast and tell a grown-up. Never hide from a fire."},
 {q:"🔢 What comes next? 2, 4, 6, 8, ___",o:["10","9","12"],a:"10",why:"The numbers go up by 2 each time: 8 + 2 = 10."},
 {q:"🗓️ Today is Monday. What day is tomorrow?",o:["Tuesday","Sunday","Wednesday"],a:"Tuesday",why:"Monday, then Tuesday."},
 {q:"🗓️ Today is Friday. What day was yesterday?",o:["Thursday","Saturday","Wednesday"],a:"Thursday",why:"Thursday comes before Friday."},
 {q:"🧓 Grandfather is older than Dad. Dad is older than Mia. Who is the youngest?",o:["Mia","Dad","Grandfather"],a:"Mia",why:"Mia is younger than Dad, and Dad is younger than Grandfather."},
 {q:"🧥 What is the best thing to wear on a very cold, snowy day?",o:["A warm coat","Shorts","Sandals"],a:"A warm coat",why:"A warm coat keeps your body warm in the snow."},
 {q:"😢 Your friend is sad because she lost her pencil. What is a kind thing to do?",o:["Lend her one of your pencils","Laugh at her","Ignore her"],a:"Lend her one of your pencils",why:"Sharing is a kind way to help a friend."},
 {q:"🧦 Which one does NOT belong in a kitchen?",o:["A bed","A pan","A spoon"],a:"A bed",why:"Pans and spoons are used in the kitchen. A bed belongs in a bedroom."},
 {q:"📅 Which month comes after June?",o:["July","May","August"],a:"July",why:"June, then July."}
]);
const NAMES=["Mia","Leo","Ana","Ben","Sam","Priya","Omar","Lily"];
const maths=()=>{const t=R(["older","younger","share","total","left"]);let q,ans,why;const n=R(NAMES),m=R(NAMES.filter(x=>x!==n));
  if(t==="older"){const a=4+Math.floor(Math.random()*6),d=1+Math.floor(Math.random()*5);ans=a+d;q=`${n} is ${a} years old. ${m} is ${d} years older. How old is ${m}?`;why=`Older means more: ${a} + ${d} = ${ans}.`}
  else if(t==="younger"){const a=8+Math.floor(Math.random()*5),d=1+Math.floor(Math.random()*5);ans=a-d;q=`${n} is ${a} years old. ${m} is ${d} years younger. How old is ${m}?`;why=`Younger means fewer years: ${a} − ${d} = ${ans}.`}
  else if(t==="share"){const p=2+Math.floor(Math.random()*3),k=2+Math.floor(Math.random()*4);ans=k;q=`${n} has ${p*k} cookies. ${n} shares them equally between ${p} children. How many cookies does each child get?`;why=`${p*k} shared equally between ${p} is ${k} each, because ${p} × ${k} = ${p*k}.`}
  else if(t==="total"){const a=3+Math.floor(Math.random()*5),b=2+Math.floor(Math.random()*6);ans=a+b;q=`There are ${a} people in ${n}'s family and ${b} people in ${m}'s family. They all go to the park. How many people go to the park?`;why=`${a} + ${b} = ${ans}.`}
  else{const a=8+Math.floor(Math.random()*12),b=2+Math.floor(Math.random()*(a-3));ans=a-b;q=`Dad baked ${a} loaves of bread. He sold ${b}. How many loaves are left?`;why=`${a} − ${b} = ${ans}.`}
  const wr=uniq([ans+1,ans-1,ans+2,ans+10].filter(x=>x>0&&x!==ans)).slice(0,2);
  return mcQ("🔢 "+q,String(ans),wr.map(String),why,"Draw it or count on your fingers.")};
const CATS={"family members":["mother","father","sister","brother","aunt","uncle","cousin","grandmother"],"jobs":["nurse","baker","pilot","farmer","teacher","mechanic","librarian","chef"],"feelings":["happy","sad","angry","scared","proud","shy"],"colours":["red","blue","green","yellow","purple","pink"],"animals":["cat","dog","cow","horse","rabbit","duck"],"foods":["bread","rice","apple","pancake","soup","cheese"],"days of the week":["Monday","Tuesday","Friday","Sunday","Saturday"],"months":["January","March","June","July","October"]};
const odd=()=>{const ks=Object.keys(CATS);const a=R(ks),b=R(ks.filter(k=>k!==a));const three=SAMPLE(CATS[a],3),o=R(CATS[b]);
  return mcQ(`🤔 Which word does NOT belong?`,o,three,`${three.join(", ")} are all ${a}. <b>${o}</b> is not.`,"Find what three of them have in common.")};
const ANA=[["Aunt is to uncle as sister is to ___.","brother",["cousin","father"]],["Mother is to mom as father is to ___.","dad",["uncle","son"]],["Nurse is to hospital as librarian is to ___.","library",["farm","kitchen"]],["Chef is to kitchen as farmer is to ___.","farm",["school","plane"]],["Old is to young as grandfather is to ___.","grandson",["uncle","father"]],["Tall is to short as noisy is to ___.","quiet",["loud","happy"]],["Hand is to glove as foot is to ___.","sock",["hat","scarf"]],["Breakfast is to morning as dinner is to ___.","evening",["noon","sunrise"]],["Write is to pencil as cut is to ___.","scissors",["glue","book"]],["Happy is to smile as sad is to ___.","cry",["laugh","jump"]],["Baker is to bread as artist is to ___.","picture",["bus","soup"]],["Mother is to daughter as father is to ___.","son",["aunt","baby"]],["Uncle is to aunt as grandfather is to ___.","grandmother",["cousin","brother"]],["Pilot is to plane as driver is to ___.","bus",["bread","book"]],["Doctor is to hospital as teacher is to ___.","school",["kitchen","farm"]],["Big is to small as tall is to ___.","short",["huge","funny"]],["Hot is to cold as happy is to ___.","sad",["glad","warm"]],["Day is to night as morning is to ___.","evening",["breakfast","lunch"]],["Bird is to nest as person is to ___.","house",["tree","egg"]],["Pen is to write as scissors are to ___.","cut",["draw","read"]],["Eyes are to see as ears are to ___.","hear",["smell","taste"]],["Cat is to kitten as dog is to ___.","puppy",["calf","cub"]],["Librarian is to books as farmer is to ___.","crops",["letters","cars"]],["Teeth are to dentist as fire is to ___.","firefighter",["chef","pilot"]],["Morning is to breakfast as evening is to ___.","dinner",["lunch","sunrise"]],["Fish is to water as bird is to ___.","sky",["sand","grass"]],["Foot is to shoe as hand is to ___.","glove",["hat","sock"]],["Cow is to milk as hen is to ___.","egg",["wool","honey"]],["Winter is to cold as summer is to ___.","hot",["snowy","dark"]],["Book is to read as song is to ___.","sing",["cook","paint"]]];
const analogy=()=>{const x=R(ANA);return mcQ("🔗 "+x[0],x[1],x[2],`${x[0].replace("___","<b>"+x[1]+"</b>")} Think about how the first two words are linked.`,"How are the first two words linked? Use the same link.")};

/* old fixed grammar questions become one mixed-review skill */
const OLD=u.grammar.flatMap(g=>g.tries);
const mixedGrammar=()=>{const t=Object.assign({},R(OLD));if(t.o)t.o=shuffle(t.o.slice());return t};

/* ---------- Learn notes ---------- */
const L={
 detail:"Read the short text carefully. The answer is <b>in the text</b>. Go back and find the words that match the question.",
 main:"The <b>main idea</b> is what the whole text is mostly about. It fits <b>all</b> the sentences, not just one of them.",
 factop:"A <b>fact</b> is true and can be checked: <i>A week has seven days.</i><br>An <b>opinion</b> is what someone thinks or feels: <i>Sunday is the best day.</i> Words like <b>best, worst, prettiest, boring</b> often show an opinion.",
 order:"Stories and instructions happen in <b>order</b>. Look for what must happen first, next and last. Words like <b>first, next, then, after that, finally</b> help.",
 vocab:"Read the word, say it aloud, and think of a sentence that uses it. If you are not sure, go back to the word cards in the stories.",
 rel:"<b>Grandmother/grandfather</b> = your parent's mother/father.<br><b>Aunt/uncle</b> = your parent's sister/brother.<br><b>Cousin</b> = your aunt's or uncle's child.",
 jobs:"Every job helps people in a different way. Think about <b>where</b> the person works and <b>what</b> they do there.",
 opp:"<b>Opposites</b> mean very different things: big ↔ small, noisy ↔ quiet.",
 syn:"<b>Synonyms</b> mean almost the same thing: big = large, happy = glad. Using synonyms makes your writing more interesting.",
 comp:"A <b>compound word</b> is two small words joined together to make a new word: sun + flower = <b>sunflower</b>.",
 complete:"A <b>complete sentence</b> tells <b>who</b> (or what) and <b>what they do or are</b>.<br>✅ <i>Leo plays football.</i><br>❌ <i>Plays football.</i> (Who?)",
 capStart:"Every sentence starts with a <b>capital letter</b>. Other words only get capitals if they are <b>names</b> or the word <b>I</b>.",
 capI:"The word <b>I</b> is always a capital letter, wherever it is in the sentence: <i>Leo and I play.</i>",
 marks:"<b>.</b> full stop → telling<br><b>?</b> question mark → asking<br><b>!</b> exclamation mark → strong feeling",
 qword:"<b>Who</b> → a person · <b>What</b> → a thing · <b>Where</b> → a place · <b>When</b> → a time · <b>Why</b> → a reason · <b>How</b> → the way, how many, how old",
 makeQ:"To turn some sentences into questions, move <b>is, are</b> or <b>can</b> to the front:<br><i>Leo is six.</i> → <i>Is Leo six?</i>",
 noun:"A <b>noun</b> names a <b>person</b> (nurse), <b>place</b> (garden), <b>animal</b> (cat) or <b>thing</b> (bread).",
 proper:"<b>Common nouns</b> name any person, place or thing: city, girl.<br><b>Proper nouns</b> name one special one and start with a capital: Toronto, Mia, Monday, July, English, Diwali.",
 fix:"Check 3 things: <b>1.</b> capital letter at the start, <b>2.</b> capitals for names and I, <b>3.</b> a mark at the end.",
 orderW:"Find the word with the capital letter: it goes first. Then think: <b>who? does what? where or when?</b> Add the end mark.",
 write:"Plan in your head first. Then write: capital letter, complete idea, end mark. Read it aloud to check.",
 spell:"Use <b>Look → Say → Cover → Write → Check</b>. Say the word slowly and listen to each sound.",
 cvc:"Short vowel words have a <b>consonant–vowel–consonant</b> pattern: c-<b>a</b>-t, b-<b>e</b>-d, p-<b>i</b>-g, d-<b>o</b>-g, s-<b>u</b>-n.",
 choose:"Say the word slowly in your head and picture it. Which one <b>looks</b> right? Tricky words often have silent letters (eight, write, would).",
 think:"Read the question twice. Think about what you <b>know</b>, then choose. In real-life questions, choose the <b>safe and kind</b> answer.",
 maths:"Find the numbers. Decide: is it <b>more</b> (add), <b>less</b> (take away), or <b>sharing equally</b>? Then work it out.",
 odd:"Three words belong to the same group. Find the group, then find the word that is <b>not</b> in it.",
 ana:"Find how the first two words are linked (a baker <b>makes</b> bread). Use the <b>same link</b> for the next pair (an artist <b>makes</b> pictures)."
};

/* exported for spiral review in later units */
u.review=MIX(complete,G.capStart(SENT),G.capI(SENT),G.endMark(SENT,ASK,EXCL),G.kind(SENT,ASK,EXCL),qword,matchQ,makeQ,findNoun,commonProper,capName,G.fix(SENT.concat(ASK)),F.word(u.words),F.fill(u.words));
/* ---------- The skill list ---------- */
u.cats=[
 {n:"Reading",e:"📖",items:[
  {id:"r_story1",t:"Story: Meet Mia",act:"story",si:0},
  {id:"r_story3",t:"Story: Leo's Lost Football",act:"story",si:2},
  {id:"r_story2",t:"Fact text: Families Around the World",act:"story",si:1},
  {id:"r_story4",t:"Fact text: How Babies Grow",act:"story",si:3},
  {id:"r_story5",t:"Fable: Hazel and Fern",act:"story",si:4},
  {id:"r_story6",t:"Real-world reading: An invitation and a chore chart",act:"story",si:5},
  {id:"r_poem",t:"Poem: My Family Tree",act:"poem",pi:0},
  {id:"r_poem2",t:"Poem: Sunday Pancakes",act:"poem",pi:1},
  {id:"r_detail",t:"Read and find the details",learn:L.detail,gen:detail},
  {id:"r_main",t:"Find the main idea",learn:L.main,gen:mainIdea},
  {id:"r_factop",t:"Fact or opinion?",learn:L.factop,gen:factOp},
  {id:"r_order",t:"Order of events",learn:L.order,gen:order}]},
 {n:"Vocabulary",e:"🔤",items:[
  {id:"v_fam",t:"Family words",learn:L.vocab,gen:F.vocab(set(0))},
  {id:"v_rel",t:"Family relationships",learn:L.rel,gen:rel},
  {id:"v_jobw",t:"Job words",learn:L.vocab,gen:F.vocab(set(1))},
  {id:"v_jobs",t:"Who does this job?",learn:L.jobs,gen:job},
  {id:"v_desc",t:"Words that describe people",learn:L.vocab,gen:F.vocab(set(2))},
  {id:"v_home",t:"Home and daily life words",learn:L.vocab,gen:F.vocab(set(3))},
  {id:"v_fill",t:"Use the right word in a sentence",learn:L.vocab,gen:F.fill(u.words)},
  {id:"v_opp",t:"Opposites",learn:L.opp,gen:F.pairs(OPP,"opposite")},
  {id:"v_syn",t:"Synonyms (words that mean the same)",learn:L.syn,gen:F.pairs(SYN,"synonym")},
  {id:"v_comp",t:"Compound words",learn:L.comp,gen:MIX(F.compoundJoin(COMP),F.compoundPick(COMP))}]},
 {n:"Grammar",e:"🧩",items:[
  {id:"g_complete",t:"Is it a complete sentence?",learn:L.complete,gen:complete},
  {id:"g_capstart",t:"Capital letter at the start",learn:L.capStart,gen:G.capStart(SENT)},
  {id:"g_capi",t:"The word I is always a capital",learn:L.capI,gen:G.capI(SENT)},
  {id:"g_marks",t:"End marks: . ? !",learn:L.marks,gen:G.endMark(SENT,ASK,EXCL)},
  {id:"g_kind",t:"Telling, asking or exclaiming?",learn:L.marks,gen:G.kind(SENT,ASK,EXCL)},
  {id:"g_qword",t:"Choose the question word",learn:L.qword,gen:qword},
  {id:"g_match",t:"Match the question to the answer",learn:L.qword,gen:matchQ},
  {id:"g_makeq",t:"Turn a sentence into a question",learn:L.makeQ,gen:makeQ},
  {id:"g_noun",t:"Find the noun",learn:L.noun,gen:findNoun},
  {id:"g_cp",t:"Common or proper noun?",learn:L.proper,gen:commonProper},
  {id:"g_capname",t:"Capitals for names, places, days and months",learn:L.proper,gen:capName},
  {id:"g_fix",t:"Fix the sentence",learn:L.fix,gen:G.fix(SENT.concat(ASK))},
  {id:"g_order",t:"Put the words in order",learn:L.orderW,gen:G.order(SENT)},
  {id:"g_write",t:"Write your own sentences",learn:L.write,gen:F.write(WP)},
  {id:"g_mixed",t:"Mixed grammar review",learn:L.fix,gen:mixedGrammar}]},
 {n:"Spelling",e:"🎧",items:[
  {id:"s_family",t:"Family and tricky words: listen and write",learn:L.spell,gen:F.listen(SP)},
  {id:"s_cvc",t:"Short vowel words: listen and write",learn:L.cvc,gen:F.listen(CVC)},
  {id:"s_choose",t:"Choose the correct spelling",learn:L.choose,gen:F.chooseSpelling(CHOOSE)},
  {id:"s_missing",t:"Missing letters",learn:L.spell,gen:F.missing(SP)}]},
 {n:"Thinking",e:"🧠",items:[
  {id:"t_puz",t:"Puzzles and real-life questions",learn:L.think,gen:F.bank(PUZ)},
  {id:"t_maths",t:"Family maths stories",learn:L.maths,gen:maths},
  {id:"t_odd",t:"Odd one out",learn:L.odd,gen:odd},
  {id:"t_ana",t:"Word links (analogies)",learn:L.ana,gen:analogy}]},
 {n:"Explore and write",e:"✏️",items:[
  {id:"x_facts",t:"Did you know? Amazing facts",act:"facts"},
  {id:"x_w1",t:"Writing step 1: Introduce yourself",act:"write",wi:0},
  {id:"x_w2",t:"Writing step 2: A special person",act:"write",wi:1},
  {id:"x_w3",t:"Writing step 3: A letter to a pen pal",act:"write",wi:2}]}
];
})();
