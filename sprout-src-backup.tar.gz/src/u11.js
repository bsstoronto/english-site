/* ===================== GRADE 3 · UNIT 11 · MY HEALTHY BODY (original content, plus one public-domain poem) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
const p=(q,a,o,why)=>({lv:"predict",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"health", num:11, emoji:"🍎💪🫀", title:"My Healthy Body", badge:"💪 Health Hero",

stories:[
/* ---------- 1. FACT PAGE: FOOD ---------- */
{title:"Food Fuels Your Body", e:"🥗", kind:"Fact page", pages:[
 {pic:"🚗⛽", text:"A car needs fuel to go. Your body needs fuel too, and that fuel is <b>food</b>. Food gives you energy to run, play, think and grow. It also helps your body fix itself when you get a scrape or a cold. Different foods do different jobs, so the best way to eat is to have a <b>variety</b>, which means lots of different kinds.",
  qs:[f("What is the body's fuel?","Food",["Petrol","Sunlight only"],"Your body needs fuel too, and that fuel is food."),
      f("What does 'variety' mean?","Lots of different kinds",["Only one kind","Nothing at all"],"…a variety, which means lots of different kinds."),
      t("Why is it good to eat many different foods?","Different foods do different jobs in the body",["It is the law","One food has everything"],"Different foods do different jobs.")]},
 {pic:"🥦🍓", text:"<b>Vegetables and fruits</b> are full of vitamins, minerals and fibre. Vitamins help your eyes see, your skin heal and your body fight germs. Try to make half your plate vegetables and fruits. A smart trick is to <b>eat the rainbow</b>: red tomatoes, orange carrots, yellow corn, green spinach, blue blueberries and purple grapes. Each colour gives your body something special.",
  qs:[f("What do vitamins help your body do?","See, heal and fight germs",["Fly","Grow wings"],"Vitamins help your eyes see, your skin heal and your body fight germs."),
      f("How much of your plate should be vegetables and fruits?","Half",["None","A tiny bit"],"Try to make half your plate vegetables and fruits."),
      t("What does 'eat the rainbow' mean?","Eat fruits and vegetables of many colours",["Eat only sweets","Eat colourful paint"],"Each colour gives your body something special.")]},
 {pic:"🍞🥚", text:"<b>Whole grains</b>, like brown rice, oats, whole-wheat bread and roti, give you long-lasting energy. <b>Protein foods</b>, like beans, lentils, eggs, fish, nuts, tofu, chicken and dal, help build strong muscles. Milk, yogurt and cheese, or calcium-rich foods like fortified soy drinks, help build strong bones and teeth. Families around the world combine these foods in delicious ways.",
  qs:[f("Which foods give long-lasting energy?","Whole grains",["Candy","Fizzy drinks"],"Whole grains… give you long-lasting energy."),
      f("Which foods help build muscles?","Protein foods like beans, eggs and fish",["Juice only","Butter only"],"Protein foods… help build strong muscles."),
      t("Which meal has a vegetable, a grain and a protein?","Rice with dal and spinach",["A bag of chips","A glass of juice"],"Rice is a grain, dal is a protein and spinach is a vegetable.")]},
 {pic:"💧🥤", text:"Your body is more than half water! You lose water when you breathe, sweat and go to the bathroom, so you need to drink water every day, and more when it is hot or when you exercise. <b>Water is the best drink.</b> Sweet drinks like pop have lots of sugar, which isn't good for your teeth. They are a 'sometimes' drink, not an everyday drink.",
  qs:[f("How much of your body is water?","More than half",["None","A tiny drop"],"Your body is more than half water!"),
      f("What is the best drink?","Water",["Pop","Juice"],"Water is the best drink."),
      t("When should you drink more water?","When it is hot or when you exercise",["Only at night","Never"],"…more when it is hot or when you exercise.")]},
 {pic:"🍰🎉", text:"Is cake bad? No food is 'bad'! Treats like cake, chips and candy are <b>sometimes foods</b>. They are fun at birthday parties and festivals, and it is fine to enjoy them. <b>Everyday foods</b>, like vegetables, fruits, grains and proteins, are the ones that help your body most, so we eat them every day. Listen to your body: eat when you are hungry and stop when you feel full.",
  qs:[f("What are 'sometimes foods'?","Treats like cake, chips and candy",["Vegetables","Water"],"Treats like cake, chips and candy are sometimes foods."),
      t("Is it okay to enjoy a treat at a party?","Yes, sometimes foods can be enjoyed now and then",["No, never","Only if nobody sees"],"It is fine to enjoy them."),
      t("What does 'listen to your body' mean?","Eat when you're hungry and stop when you're full",["Put your ear on your tummy","Never eat"],"Eat when you are hungry and stop when you feel full."),
      t("What is the main idea of this whole fact page?","Eating a variety of foods gives your body what it needs",["Only eat cake","Food isn't important"],"Every page shows how different foods help the body.")]}
], turn:{q:"Describe a healthy meal you love. Which foods does it have from different groups?",model:"I love chicken curry with brown rice and a cucumber salad. It has protein, a whole grain and a vegetable."}},

/* ---------- 2. FACT PAGE: EXERCISE ---------- */
{title:"Move Your Body!", e:"🏃", kind:"Fact page", pages:[
 {pic:"❤️🏃", text:"When you run, jump or dance, your heart beats faster. Your heart is a muscle, and exercise makes it stronger, just like lifting a backpack makes your arms stronger. A strong heart pumps blood around your body more easily. Doctors say children should be active for about <b>60 minutes</b> every day. That can be in small pieces: walking to school, playing tag at recess and riding your bike after school.",
  qs:[f("What kind of body part is your heart?","A muscle",["A bone","A lung"],"Your heart is a muscle."),
      f("How long should children be active every day?","About 60 minutes",["About 5 minutes","Ten hours"],"Children should be active for about 60 minutes every day."),
      t("Does the 60 minutes have to be all at once?","No, it can be in small pieces",["Yes, all at once","Only on Sundays"],"That can be in small pieces.")]},
 {pic:"🦴💪", text:"Exercise is good for more than your heart. Jumping and running help make your <b>bones</b> strong. Climbing and swimming build your <b>muscles</b>. Stretching keeps you <b>flexible</b>, so you can bend and reach easily. Exercise also helps your brain! After you play outside, it is often easier to focus in class.",
  qs:[f("Which activities help make bones strong?","Jumping and running",["Watching TV","Sleeping"],"Jumping and running help make your bones strong."),
      f("What does stretching do?","Keeps you flexible",["Makes you taller instantly","Makes you sleepy"],"Stretching keeps you flexible."),
      t("Why might it be easier to focus after playing outside?","Exercise helps your brain",["You are too tired to talk","The teacher is happier"],"Exercise also helps your brain!")]},
 {pic:"😊🌳", text:"Moving your body is good for your feelings too. When you exercise, your brain makes chemicals that help you feel happy and calm. Playing a sport with friends teaches teamwork. Even a short walk outside in nature can help when you feel worried or grumpy.",
  qs:[f("How does exercise help your feelings?","It helps you feel happy and calm",["It makes you angry","It doesn't help"],"…chemicals that help you feel happy and calm."),
      f("What does playing a sport with friends teach?","Teamwork",["Spelling","Cooking"],"Playing a sport with friends teaches teamwork.")]},
 {pic:"🏏⚽", text:"Children around the world love to move. In India and Pakistan, many children play <b>cricket</b>. In Brazil, <b>soccer</b> is played on beaches and streets. In Canada, children skate and play <b>hockey</b> on frozen ponds. In China, many people practise <b>tai chi</b>, slow and graceful movements. In Kenya, some of the world's greatest long-distance runners train on high mountain roads.",
  qs:[f("Which sport do many children play in India and Pakistan?","Cricket",["Hockey","Tai chi"],"In India and Pakistan, many children play cricket."),
      f("What is tai chi?","Slow and graceful movements",["A fast car race","A kind of food"],"…tai chi, slow and graceful movements."),
      t("Why do children in Canada play hockey on ponds?","The ponds freeze in winter",["Ponds are warm","There are no schools"],"…skate and play hockey on frozen ponds.")]},
 {pic:"🧘💤", text:"Your body also needs <b>rest</b>. After exercise, drink water and stretch. Muscles grow stronger while you rest and sleep. Remember to stay safe: wear a helmet when you ride a bike or scooter, warm up before sports, and stop if something hurts. Then tell a grown-up. Find a way to move that you love, and do it every day!",
  qs:[f("When do muscles grow stronger?","While you rest and sleep",["Only while you eat candy","Never"],"Muscles grow stronger while you rest and sleep."),
      f("What should you wear when you ride a bike?","A helmet",["Flip-flops only","Nothing on your head"],"Wear a helmet when you ride a bike or scooter."),
      t("What should you do if something hurts during exercise?","Stop and tell a grown-up",["Keep going even harder","Hide it"],"Stop if something hurts. Then tell a grown-up."),
      t("What is the main idea of this fact page?","Exercise helps your heart, bones, muscles, brain and feelings",["Exercise is boring","Only grown-ups exercise"],"Every page shows a different way moving helps you.")]}
], turn:{q:"What is your favourite way to move your body? Write two sentences about how it makes you feel.",model:"My favourite way to move is dancing to music. It makes me feel happy and full of energy."}},

/* ---------- 3. FACT TEXT: BODY ---------- */
{title:"Amazing Body Systems", e:"🫀", kind:"Fact text", pages:[
 {pic:"🫀🩸", text:"Your <b>heart</b> is about the size of your fist. It pumps blood all around your body through tubes called blood vessels. Blood carries oxygen and food to every part of you. Your heart beats about 100,000 times a day, without you even thinking about it! You can feel your heartbeat, called your <b>pulse</b>, on your wrist or your neck.",
  qs:[f("How big is your heart?","About the size of your fist",["The size of a watermelon","The size of a pea"],"Your heart is about the size of your fist."),
      f("About how many times does your heart beat each day?","About 100,000 times",["About 10 times","About 100 times"],"Your heart beats about 100,000 times a day."),
      f("Where can you feel your pulse?","On your wrist or your neck",["On your hair","On your teeth"],"You can feel… your pulse, on your wrist or your neck.")]},
 {pic:"🫁🌬️", text:"Your <b>lungs</b> are like two big, spongy balloons in your chest. When you breathe in, they fill with air, and oxygen goes into your blood. When you breathe out, you get rid of a gas called carbon dioxide. Plants use that gas to make food, and they give us oxygen back. We are a team!",
  qs:[f("What do your lungs look like?","Two big, spongy balloons",["Two hard rocks","One long tube"],"Your lungs are like two big, spongy balloons."),
      f("What gas do you breathe out?","Carbon dioxide",["Oxygen","Helium"],"When you breathe out, you get rid of a gas called carbon dioxide."),
      t("Why does the text say people and plants are a team?","Plants use the gas we breathe out and give us oxygen",["Plants can play sports","People eat all plants"],"Plants use carbon dioxide and give us oxygen back.")]},
 {pic:"🦴🦵", text:"Your <b>skeleton</b> is made of bones. It holds you up, gives you shape and protects your soft insides. Your skull protects your brain, and your ribs protect your heart and lungs. A grown-up has 206 bones. A baby is born with more, about 270, but some of them join together as the baby grows! Places where bones meet, like your knees and elbows, are called <b>joints</b>.",
  qs:[f("How many bones does a grown-up have?","206",["20","1,000"],"A grown-up has 206 bones."),
      f("What protects your brain?","Your skull",["Your ribs","Your knees"],"Your skull protects your brain."),
      t("Why does a baby have more bones than a grown-up?","Some baby bones join together as they grow",["Grown-ups lose bones","Babies are bigger"],"Some of them join together as the baby grows!")]},
 {pic:"💪🧠", text:"You have more than 600 <b>muscles</b>. They pull on your bones to make you move. Some muscles work without you thinking, like your heart. Your <b>brain</b> is the boss of your whole body. It sends messages along nerves faster than a racing car. It helps you think, remember, feel and move. That's why you should always protect your head with a helmet!",
  qs:[f("How many muscles do you have?","More than 600",["Six","Sixty"],"You have more than 600 muscles."),
      f("Which body part is the boss of your body?","The brain",["The stomach","The thumb"],"Your brain is the boss of your whole body."),
      t("Why does the text say to wear a helmet?","To protect your brain",["To look cool","To keep your hair dry"],"Your brain is so important that you should always protect your head.")]},
 {pic:"🍽️😴", text:"When you eat, your food goes on a long journey. You chew it with your teeth, swallow it, and it travels down to your <b>stomach</b>, where it is mashed into a soupy mix. Then your intestines take out the goodness for your body. Your <b>skin</b> is the biggest organ of all! It keeps germs out, helps you feel hot and cold, and sweats to cool you down. All these parts work together every second to keep you alive and well.",
  qs:[f("What happens to food in your stomach?","It is mashed into a soupy mix",["It turns into bones","It disappears"],"…your stomach, where it is mashed into a soupy mix."),
      f("What is the biggest organ of the body?","Your skin",["Your heart","Your thumb"],"Your skin is the biggest organ of all!"),
      t("Why do you sweat?","To cool your body down",["To make your skin shiny","Because you are sad"],"Your skin… sweats to cool you down."),
      t("What is the main idea of this whole text?","Many body parts work together to keep you alive and well",["The heart is the only important part","Bones are soft"],"All these parts work together every second.")]}
], turn:{q:"Which body part do you think is the most amazing? Write two sentences and explain why.",model:"I think the brain is the most amazing body part. It helps me think, remember and feel everything."}},

/* ---------- 4. STORY: GERMS ---------- */
{title:"The Glitter Germ Experiment", e:"✨", kind:"Story", pages:[
 {pic:"🤧🏫", text:"It was flu season, and half of Mr. Ali's class had colds. \"Achoo!\" sneezed Leo, right into his hands. Then he picked up a marker and passed it to Mia. Mr. Ali smiled. \"Today, class, we are going to be germ detectives. Germs are tiny living things that can make us sick. They are so small that you can't see them. So we'll use glitter to pretend.\"",
  qs:[f("Why were so many children sick?","It was flu season",["It was summer","They ate too much"],"It was flu season, and half of Mr. Ali's class had colds."),
      f("What are germs?","Tiny living things that can make us sick",["Small toys","A kind of glitter"],"Germs are tiny living things that can make us sick."),
      p("What do you think the glitter will show?","How germs spread from person to person",["How to make art","How to clean glitter"],"Mr. Ali said they will use glitter to pretend to be germs.")]},
 {pic:"✨🤝", text:"Mr. Ali sprinkled glitter on Leo's hands. \"Leo, please shake hands with Mia.\" Then Mia gave a pencil to Ada. Ada opened the door. Ten minutes later, there was glitter everywhere: on six children's hands, on the door handle, on the pencils and even on Wei's nose! \"Wow,\" said Leo. \"It started with just my hands.\"",
  qs:[f("Whose hands got glitter first?","Leo's",["Mia's","Wei's"],"Mr. Ali sprinkled glitter on Leo's hands."),
      f("How many children had glitter on their hands after ten minutes?","Six",["One","Twenty"],"…on six children's hands…"),
      t("What did the glitter show the class?","Germs spread easily from hands to things and people",["Glitter is pretty","Doors are dirty"],"It started with one person's hands and spread everywhere.")]},
 {pic:"🧼💧", text:"\"Now let's try to get it off,\" said Mr. Ali. First, the children rinsed their hands with water only. Most of the glitter stayed. Then Mr. Ali gave instructions: \"Wet your hands. Put on soap. Rub your palms, the backs of your hands, between your fingers and under your nails. Scrub for 20 seconds. Then rinse and dry.\" This time, the glitter washed away.",
  qs:[f("What happened when they used water only?","Most of the glitter stayed",["All the glitter came off","The glitter grew"],"…with water only. Most of the glitter stayed."),
      f("How long should you scrub your hands?","20 seconds",["2 seconds","20 minutes"],"Scrub for 20 seconds."),
      t("What does this experiment show about soap?","Soap helps wash germs away much better than water alone",["Soap is useless","Water is better than soap"],"With soap, the glitter washed away.")]},
 {pic:"🎶⏱️", text:"\"How do we know when 20 seconds are up?\" asked Ada. \"Sing 'Happy Birthday' twice!\" said Mr. Ali. The class laughed and sang. Then Mr. Ali showed them how to sneeze into their elbow instead of their hands. \"If you cough or sneeze into your elbow, the germs don't get on your hands, so you don't pass them to your friends.\"",
  qs:[f("How can you count 20 seconds while washing?","Sing 'Happy Birthday' twice",["Count to two","Clap once"],"\"Sing 'Happy Birthday' twice!\""),
      f("Where should you sneeze?","Into your elbow",["Into your hands","On a friend"],"…how to sneeze into their elbow instead of their hands."),
      t("Why is sneezing into your elbow better than into your hands?","Germs don't get on your hands and spread",["It is louder","Elbows are softer"],"If you cough or sneeze into your elbow, the germs don't get on your hands.")]},
 {pic:"🏆🧴", text:"The class made a poster for the hallway: <b>BE A GERM BUSTER! Wash your hands. Sneeze into your elbow. Don't share cups. Stay home when you are sick.</b> Over the next weeks, fewer children got sick. Leo was proud. \"I started the glitter mess,\" he said, \"but now I'm the best germ buster in the class!\"",
  qs:[f("What did the class make?","A poster",["A cake","A robot"],"The class made a poster for the hallway."),
      t("Why did fewer children get sick?","They washed their hands and sneezed into their elbows",["The glitter scared the germs","They stopped going to school"],"Following the germ-buster rules stopped germs spreading."),
      t("What kind of sentences are on the poster?","Instructions that tell people what to do",["Questions","Jokes"],"Wash your hands. Sneeze into your elbow. These are instructions.")]}
], turn:{q:"Write three instructions to stop germs from spreading. Start each one with a verb.",model:"Wash your hands with soap. Cover your cough with your elbow. Stay home when you are sick."}},

/* ---------- 5. STORY: SLEEP ---------- */
{title:"Sam's Super Sleep Plan", e:"😴", kind:"Story", pages:[
 {pic:"📱🌙", text:"Sam loved his tablet. Every night, after Mom said \"Lights out!\", he secretly played games under his blanket. He stayed up until ten, eleven, sometimes even later. In the morning, Sam's alarm rang and rang, but he could hardly open his eyes. He yawned all the way to school.",
  qs:[f("What did Sam do after 'Lights out'?","Played games on his tablet",["Read a book","Went to sleep"],"…he secretly played games under his blanket."),
      t("Why was Sam so tired in the morning?","He stayed up too late",["He ate too much","He ran a race"],"He stayed up until ten, eleven, sometimes even later."),
      p("What do you think will happen at school?","Sam will have trouble paying attention",["Sam will win a prize for being awake","Nothing will happen"],"Being very tired makes it hard to focus.")]},
 {pic:"😩⚽", text:"At school, Sam couldn't focus on his spelling test. He forgot the answers he knew yesterday. At recess, he missed an easy goal and snapped at his friend Dev. \"Leave me alone!\" Dev looked hurt. By lunch, Sam had a headache. The school nurse, Ms. Okafor, asked him kindly, \"How much did you sleep last night, Sam?\"",
  qs:[f("Who did Sam snap at?","Dev",["Mr. Ali","His mom"],"…snapped at his friend Dev."),
      f("Who is Ms. Okafor?","The school nurse",["The principal","Sam's aunt"],"The school nurse, Ms. Okafor…"),
      t("How did being tired affect Sam?","He couldn't focus, got grumpy and had a headache",["He felt full of energy","He was happier"],"He forgot answers, snapped at Dev and had a headache.")]},
 {pic:"🩺🧠", text:"Ms. Okafor explained, \"Children your age need about 9 to 12 hours of sleep every night. While you sleep, your body grows, your muscles repair, and your brain sorts out everything you learned that day. Without enough sleep, it's harder to remember, harder to stay calm, and easier to get sick.\" Sam's eyes went wide. \"So sleep is like charging a battery?\" \"Exactly!\"",
  qs:[f("How much sleep do children Sam's age need?","About 9 to 12 hours",["About 3 hours","About 20 hours"],"Children your age need about 9 to 12 hours of sleep every night."),
      f("What does your brain do while you sleep?","Sorts out what you learned that day",["Turns off forever","Plays games"],"…your brain sorts out everything you learned that day."),
      t("Why did Sam compare sleep to charging a battery?","Sleep gives your body and brain new energy",["Sleep needs a plug","Batteries are sleepy"],"Like a battery, your body recharges while you sleep.")]},
 {pic:"📋🛁", text:"That night, Sam and his mom made a <b>Super Sleep Plan</b> and stuck it on his door:<br>1. Put the tablet in the kitchen at 7:30.<br>2. Have a warm bath and brush your teeth.<br>3. Read a book or listen to quiet music.<br>4. Turn off the light at 8:30.<br>5. Wake up at 7:00, feeling great!",
  qs:[f("Where does the tablet go at 7:30?","In the kitchen",["Under the pillow","In Sam's bed"],"Put the tablet in the kitchen at 7:30."),
      f("What time does Sam turn off the light?","8:30",["10:30","7:00"],"Turn off the light at 8:30."),
      t("How many hours of sleep will Sam get from 8:30 p.m. to 7:00 a.m.?","Ten and a half hours",["Two hours","Fifteen hours"],"From 8:30 to 7:00 is ten and a half hours."),
      t("Why does the plan say to put the tablet away?","Screens can keep you awake",["Tablets need sleep too","The kitchen is lonely"],"Bright screens and exciting games make it harder to fall asleep.")]},
 {pic:"🌞😃", text:"The first few nights were hard. Sam missed his games. But after a week, something amazing happened. He woke up before his alarm! He got a perfect score on his spelling test and scored two goals at recess. He even said sorry to Dev for snapping at him. \"My Super Sleep Plan is my superpower,\" Sam told the class. \"Who knew that the best way to get stronger was to go to sleep?\"",
  qs:[f("What happened after a week?","Sam woke up before his alarm",["Sam stopped sleeping","Sam lost his tablet"],"He woke up before his alarm!"),
      f("What did Sam do about snapping at Dev?","He said sorry",["He ignored Dev","He snapped again"],"He even said sorry to Dev for snapping at him."),
      t("What is the lesson of this story?","Getting enough sleep helps your body and brain",["Games are bad","Alarms are loud"],"Once Sam slept enough, he felt and did better in every way.")]}
], turn:{q:"Write your own bedtime routine with three or four steps. Start each step with a verb.",model:"Brush your teeth. Put on your pyjamas. Read a book with Mom. Turn off the light at eight o'clock."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A recipe card and a bike safety poster", e:"📋", kind:"Real-world text", pages:[
 {pic:"🍓🍌", text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🌈 Rainbow Fruit Skewers</b> · Makes 6 skewers · Time: 15 minutes<br><br><b>You will need:</b><br>• 6 strawberries (red) • 1 orange, peeled (orange) • 1 banana (yellow) • 2 kiwis, peeled (green) • 12 blueberries (blue) • 12 purple grapes • 6 wooden skewers<br><br><b>Steps:</b><br>1. Wash your hands with soap.<br>2. Wash the fruit.<br>3. Ask a grown-up to help you cut the fruit into bite-sized pieces.<br>4. Slide the fruit onto each skewer in rainbow order: red, orange, yellow, green, blue, purple.<br>5. Serve right away, or keep them cold in the fridge.<br><br>⚠️ <i>Skewers are sharp. Be careful, and always have a grown-up nearby.</i></div>",
  qs:[f("How many skewers does the recipe make?","6",["12","1"],"Makes 6 skewers."),
      f("What is the first step?","Wash your hands with soap",["Cut the fruit","Eat the skewers"],"1. Wash your hands with soap."),
      f("Which fruit is green?","Kiwi",["Banana","Grape"],"2 kiwis, peeled (green)"),
      t("Why should a grown-up help with step 3?","Cutting with a knife can be dangerous",["Grown-ups like fruit","Children can't wash fruit"],"Knives are sharp. Safety first."),
      t("What kind of sentences are the steps?","Instructions",["Questions","Exclamations"],"Each step starts with a verb and tells you what to do.")]},
 {pic:"🚲⛑️", text:"<div class=\"realdoc\"><b>🚲 RIDE SAFE, RIDE SMART! 🚲</b><br><br>✅ <b>Always wear a helmet.</b> It should sit level on your head, just above your eyebrows.<br>✅ <b>Check your brakes</b> before you ride.<br>✅ <b>Wear bright colours</b> so drivers can see you.<br>✅ <b>Ride on the right side</b> of the road, in the same direction as cars.<br>✅ <b>Stop and look</b> both ways at every corner.<br>❌ <b>Don't wear headphones</b> while you ride.<br>❌ <b>Don't ride at night</b> without lights.<br><br><i>A helmet can protect your brain in a fall. You only get one brain. Protect it!</i></div>",
  qs:[f("Where should your helmet sit?","Level on your head, just above your eyebrows",["On the back of your head","Around your neck"],"It should sit level on your head, just above your eyebrows."),
      f("Why should you wear bright colours?","So drivers can see you",["To match your bike","Because it's warm"],"Wear bright colours so drivers can see you."),
      t("Why shouldn't you wear headphones while riding?","You need to hear cars and other sounds",["Headphones are heavy","Music is too quiet"],"Hearing traffic helps keep you safe."),
      f("Which side of the road should you ride on (in Canada)?","The right side",["The left side","The middle"],"Ride on the right side of the road."),
      t("What does 'You only get one brain' mean?","Your brain is precious and can't be replaced",["You have two brains","Brains are cheap"],"That's why protecting your head matters so much.")]}
], turn:{q:"Write three instructions for staying safe at the playground. Start each with a verb.",model:"Wait for your turn on the slide. Hold on tightly on the climbing frame. Tie your shoelaces before you run."}}
],

poems:[
 {title:"The Land of Counterpane (by Robert Louis Stevenson, 1885)",
  lines:["When I was sick and lay a-bed,","I had two pillows at my head,","And all my toys beside me lay,","To keep me happy all the day.","","And sometimes for an hour or so","I watched my leaden soldiers go,","With different uniforms and drills,","Among the bed-clothes, through the hills;","","And sometimes sent my ships in fleets","All up and down among the sheets;","Or brought my trees and houses out,","And planted cities all about.","","I was the giant great and still","That sits upon the pillow-hill,","And sees before him, dale and plain,","The pleasant land of counterpane."],
  qs:[f("Why was the child in bed?","He was sick",["It was night","He was lazy"],"\"When I was sick and lay a-bed.\""),
      f("What did the child have beside him?","His toys",["His dog","His homework"],"\"And all my toys beside me lay.\""),
      t("What is a 'counterpane'?","A bedspread (a blanket on top of the bed)",["A window","A kind of pain"],"The bed covers become a pretend land of hills and cities."),
      t("How did the child stay happy while sick?","He used his imagination to play with his toys",["He watched TV","He went to school"],"He turned the sheets into seas and hills."),
      f("Which word rhymes with 'head'?","a-bed",["lay","day"],"Head and a-bed end with the same sound.")]},
 {title:"My Body Can",
  lines:["My legs can run, my arms can swing,","My lungs can breathe, my voice can sing.","My heart goes thump, a steady drum,","My tummy rumbles: \"Food, please, come!\"","So I should eat a rainbow plate,","And drink my water, sleep till late…","Well, not TOO late, but eight or nine,","Then wake up feeling super-fine!"],
  qs:[f("What does the heart sound like in the poem?","A steady drum",["A whistle","A bell"],"\"My heart goes thump, a steady drum.\""),
      f("Which word rhymes with 'swing'?","sing",["run","drum"],"Swing and sing end with the same sound."),
      t("What does 'My tummy rumbles: Food, please, come!' mean?","The child is hungry",["The child is sleepy","The child has a drum"],"A rumbling tummy is a sign of hunger."),
      t("Which healthy habits does the poem mention?","Eating a rainbow plate, drinking water and sleeping",["Watching TV all day","Skipping meals"],"\"So I should eat a rainbow plate, and drink my water, sleep…\"")]}
],

words:[
 /* body */
 {w:"heart",e:"🫀",m:"the muscle in your chest that pumps blood",ex:"Your heart beats faster when you run.",fill:"My ___ is beating fast after the race."},
 {w:"lungs",e:"🫁",m:"the two organs in your chest that fill with air when you breathe",ex:"Your lungs fill with air when you breathe in.",fill:"Take a deep breath and fill your ___ with air."},
 {w:"brain",e:"🧠",m:"the organ in your head that controls your body and helps you think",ex:"Your brain is the boss of your body.",fill:"Use your ___ to solve the puzzle."},
 {w:"muscle",e:"💪",m:"a part of the body that pulls on bones to make you move",ex:"Climbing builds strong muscles.",fill:"Your heart is a ___ that never stops working."},
 {w:"bone",e:"🦴",m:"one of the hard parts that make up your skeleton",ex:"Milk helps build strong bones.",fill:"He broke a ___ in his arm."},
 {w:"skeleton",e:"💀",m:"all the bones of the body together",ex:"Your skeleton holds you up.",fill:"The ___ in the science room has 206 bones."},
 {w:"stomach",e:"🍽️",m:"the part inside your body where food goes after you swallow it",ex:"Food is mashed up in your stomach.",fill:"My ___ is full after that big lunch."},
 {w:"skin",e:"✋",m:"the outer covering of your body",ex:"Your skin keeps germs out.",fill:"Wear sunscreen to protect your ___."},
 {w:"blood",e:"🩸",m:"the red liquid that carries oxygen around your body",ex:"Your heart pumps blood all around your body.",fill:"A small cut can make a drop of ___."},
 {w:"joint",e:"🦵",m:"a place where two bones meet, like your knee or elbow",ex:"Your knee is a joint.",fill:"Your elbow is a ___ that lets your arm bend."},
 /* food */
 {w:"vegetable",e:"🥦",m:"a plant or part of a plant that we eat, like a carrot or spinach",ex:"Broccoli is a green vegetable.",fill:"A carrot is a crunchy orange ___."},
 {w:"protein",e:"🥚",m:"a part of food that helps build muscles, found in beans, eggs, fish and nuts",ex:"Lentils are full of protein.",fill:"Eggs and beans give you ___ to build muscles."},
 {w:"grain",e:"🌾",m:"seeds like rice, wheat and oats that we eat",ex:"Brown rice is a whole grain.",fill:"Oats are a healthy ___ for breakfast."},
 {w:"vitamin",e:"🍊",m:"something in food that your body needs to stay healthy",ex:"Oranges have lots of vitamin C.",fill:"Fruits and vegetables are full of ___s."},
 {w:"balanced",e:"⚖️",m:"having the right amount of different things",ex:"A balanced meal has foods from different groups.",fill:"Rice, dal and vegetables make a ___ meal."},
 {w:"snack",e:"🥕",m:"a small amount of food eaten between meals",ex:"An apple is a healthy snack.",fill:"I had yogurt for a ___ after school."},
 {w:"nutritious",e:"🥗",m:"full of the good things your body needs",ex:"Vegetable soup is very nutritious.",fill:"Fruit is a ___ snack."},
 {w:"digest",e:"🔄",m:"to break down food in your body so it can be used",ex:"Your stomach helps you digest food.",fill:"It takes hours to ___ a big meal."},
 {w:"hydrated",e:"💧",m:"having enough water in your body",ex:"Drink water to stay hydrated.",fill:"On hot days, drink lots of water to stay ___."},
 {w:"fibre",e:"🌽",m:"a part of plant foods that helps your body digest",ex:"Whole grains and beans have lots of fibre.",fill:"Fruits and vegetables are full of ___.",alt:["fiber"]},
 /* exercise */
 {w:"exercise",e:"🏃",m:"activity that moves your body and keeps it healthy",ex:"Exercise makes your heart stronger.",fill:"Riding a bike is great ___."},
 {w:"stretch",e:"🤸",m:"to make your body long by reaching out your arms or legs",ex:"Stretch before you play sports.",fill:"___ your arms up high to the sky."},
 {w:"breathe",e:"🌬️",m:"to take air into your lungs and let it out",ex:"Breathe in slowly through your nose.",fill:"___ in deeply and count to four."},
 {w:"sweat",e:"💦",m:"to make salty water on your skin when you are hot",ex:"We sweat when we run on a hot day.",fill:"Running in the sun made me ___."},
 {w:"balance",e:"🧍",m:"to stay steady without falling",ex:"Can you balance on one foot?",fill:"It is hard to ___ on a skateboard."},
 {w:"strength",e:"🏋️",m:"how strong someone is",ex:"Climbing builds strength.",fill:"It takes ___ to lift a heavy box."},
 {w:"pulse",e:"💓",m:"the beat of your heart that you can feel in your wrist or neck",ex:"Put two fingers on your wrist to feel your pulse.",fill:"After running, my ___ was very fast."},
 {w:"flexible",e:"🧘",m:"able to bend easily",ex:"Stretching keeps you flexible.",fill:"Gymnasts are very ___."},
 {w:"active",e:"⚽",m:"moving around and doing things",ex:"Children should be active every day.",fill:"Stay ___ by playing outside."},
 {w:"rest",e:"🛌",m:"to stop doing things and relax or sleep",ex:"Muscles grow stronger while you rest.",fill:"After the race, sit down and ___."},
 /* hygiene, safety and silent letters */
 {w:"germ",e:"🦠",m:"a tiny living thing that can make you sick",ex:"Washing your hands removes germs.",fill:"A ___ is too small to see without a microscope."},
 {w:"hygiene",e:"🧼",m:"keeping yourself and things around you clean to stay healthy",ex:"Brushing your teeth is good hygiene.",fill:"Washing your hands is an important part of ___."},
 {w:"soap",e:"🧴",m:"something you use with water to wash and clean",ex:"Use soap to wash away germs.",fill:"Wash your hands with ___ and water."},
 {w:"cough",e:"😷",m:"to push air out of your throat with a sudden noise",ex:"Cough into your elbow.",fill:"Please ___ into your elbow, not your hand."},
 {w:"sneeze",e:"🤧",m:"to blow air out of your nose suddenly, with an 'achoo!'",ex:"Leo sneezed into his hands.",fill:"Pepper makes me ___!"},
 {w:"knee",e:"🦵",m:"the joint in the middle of your leg",ex:"I scraped my knee on the playground.",fill:"Bend your ___ and jump!"},
 {w:"thumb",e:"👍",m:"the short, thick finger on the side of your hand",ex:"Give me a thumbs-up!",fill:"Your ___ helps you hold a pencil."},
 {w:"wrist",e:"⌚",m:"the joint between your hand and your arm",ex:"You can feel your pulse on your wrist.",fill:"I wear my watch on my ___."},
 {w:"knuckle",e:"✊",m:"one of the joints in your fingers",ex:"He knocked on the door with his knuckles.",fill:"Make a fist and look at each ___."},
 {w:"helmet",e:"⛑️",m:"a hard hat that protects your head",ex:"Always wear a helmet on your bike.",fill:"Put on your ___ before you ride your scooter."}
],

spelling:[
 {w:"body",s:"Take care of your body."},
 {w:"head",s:"Wear a helmet on your head.",tip:"'ea' sounds like short e."},
 {w:"heart",s:"My heart is beating.",tip:"It has 'ear' inside: h-ear-t."},
 {w:"knee",s:"I bent my knee.",tip:"Silent k! k-nee."},
 {w:"thumb",s:"Give me a thumbs-up.",tip:"Silent b at the end."},
 {w:"wash",s:"Wash your hands.",tip:"'a' sounds like 'o': w-a-sh."},
 {w:"hands",s:"Clean hands stop germs."},
 {w:"teeth",s:"Brush your teeth twice a day.",tip:"Double e."},
 {w:"sleep",s:"I need to sleep.",tip:"Double e."},
 {w:"water",s:"Drink water every day."},
 {w:"healthy",s:"Eat healthy food.",tip:"health + y."},
 {w:"food",s:"Food gives us energy.",tip:"Double o."},
 {w:"strong",s:"Exercise makes you strong."},
 {w:"doctor",s:"The doctor checked my ears.",tip:"It ends with -or."},
 {w:"exercise",s:"Exercise is good for you.",tip:"ex-er-cise."}
],

facts:[
 {e:"🫀",c:"Your heart beats about 100,000 times a day.",t:true,x:"True! And it never takes a break, even while you sleep."},
 {e:"🦴",c:"Babies have more bones than grown-ups.",t:true,x:"True! Babies have about 270 bones. Some of them join together as they grow, so adults have 206."},
 {e:"👃",c:"You can taste food better when your nose is blocked.",t:false,x:"Not true! Smell helps you taste. That's why food tastes boring when you have a cold."},
 {e:"💧",c:"Your body is more than half water.",t:true,x:"True! That's why drinking water every day is so important."},
 {e:"🦷",c:"Tooth enamel is the hardest substance in the human body.",t:true,x:"True! It is even harder than bone. But sugar can still damage it, so brush twice a day."},
 {e:"🧼",c:"Rinsing with water alone removes germs as well as soap does.",t:false,x:"Not true! Soap and scrubbing for 20 seconds remove far more germs."},
 {e:"😴",c:"Your body grows and repairs itself while you sleep.",t:true,x:"True! That's one reason children need 9 to 12 hours of sleep."},
 {e:"👣",c:"More than a quarter of your bones are in your feet.",t:true,x:"True! Each foot has 26 bones, so your two feet have 52 of your 206 bones."},
 {e:"🧠",c:"Your brain stops working when you sleep.",t:false,x:"Not true! Your brain is busy at night, sorting memories and helping you learn."},
 {e:"💪",c:"You have more than 600 muscles.",t:true,x:"True! Even smiling uses many muscles in your face."},
 {e:"🍰",c:"Some foods are 'bad' and must never be eaten.",t:false,x:"Not true! Treats are 'sometimes foods' that can be enjoyed now and then. Everyday foods help your body most."},
 {e:"✋",c:"Your skin is the biggest organ of your body.",t:true,x:"True! It protects you from germs and helps you feel hot, cold and touch."}
],

writing:[
 {e:"🌞",t:"My healthy day",level:"Step 1 · Sentences",
  prompt:"Write at least 5 sentences about a healthy day in your life, from morning to night. Write about food, exercise, cleanliness and sleep. Use at least 2 words from the word bank, and use can or should at least once.",
  minS:5,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["\\b(can|should)\\b","I used can or should"],["\\b(eat|ate|breakfast|lunch|dinner|fruit|vegetable|rice|water)\\w*","I wrote about food or drink"],["\\b(run|play|walk|ride|swim|dance|exercise|jump|soccer|cricket|bike|active)\\w*","I wrote about moving my body"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["In the morning, I ","For breakfast, I ","At recess, I ","Before lunch, I wash ","At night, I should "],
  model:"In the morning, I brush my teeth and eat oatmeal with blueberries. I walk to school with my brother, so I am active before class even starts. At recess, I play soccer until I sweat. Before lunch, I wash my hands with soap for 20 seconds. After school, I drink water and have an apple for a snack. At night, I should turn off my tablet early so I can sleep for ten hours."},
 {e:"🪥",t:"How to… (instructions)",level:"Step 2 · Instructions",
  prompt:"Choose a healthy habit (brushing your teeth, washing your hands, making a healthy snack, getting ready for bed). Write clear instructions with at least 5 steps. Start each step with a verb, like Wet, Put, Scrub, Rinse. Use order words: First, Next, Then, Finally.",
  minS:5,minWords:2,
  rx:[["\\b(First|Start)\\b","I used First"],["\\b(Next|Then|After that)\\b","I used Next or Then"],["\\b(Finally|Last)\\b","I used Finally"],["(\\b(First|Next|Then|After that|Finally)\\b,?\\s+(wash|wet|put|scrub|rinse|dry|brush|squeeze|spit|take|cut|add|mix|pour|turn|read|get|go|choose|place|open|hold|move|rub)\\b[\\s\\S]*){3}","At least 3 steps start with a verb after the order word"],["[.!?]\\s*$","I ended with a full stop"]],
  starters:["How to Brush Your Teeth\n","First, put ","Next, brush ","Then, ","Finally, rinse "],
  model:"How to Brush Your Teeth\nFirst, put a small dab of toothpaste on your toothbrush. Next, brush the front of your teeth in small circles. Then, brush the backs and the tops of your teeth. After that, gently brush your tongue to get rid of germs. Spit out the toothpaste, but don't swallow it. Finally, rinse your toothbrush and put it away. Brush for two minutes, twice a day! Good hygiene stops every germ from hurting your teeth."},
 {e:"📢",t:"Healthy-tips poster",level:"Step 3 · Poster",
  prompt:"Make a poster to help children be healthy. Give it a catchy title. Then write at least 6 tips, each on its own line. Most tips should be instructions that start with a verb (Eat…, Drink…, Wash…). Include at least one tip with should and one with can. Finish with an exciting sentence that ends with !",
  minS:6,minWords:2,
  rx:[["^\\s*\\S.*\\n","I wrote a title on the first line"],["(\\n\\s*[^a-z\\n]{0,3}\\s*(Eat|Drink|Wash|Sleep|Play|Move|Brush|Wear|Get|Go|Try|Turn|Cover|Stretch|Choose|Take|Ride|Walk|Run|Remember|Stay|Put|Have|Don't)\\b[^\\n]*){4}","At least 4 tips start with an instruction verb"],["\\bshould\\b","I used should"],["\\bcan\\b","I used can"],["!","I used an exclamation mark"]],
  starters:["BE A HEALTH HERO!\n","Eat a rainbow of fruits and vegetables.\n","Drink ","Wash ","You should ","You can "],
  model:"BE A HEALTH HERO!\nEat a rainbow of fruits and vegetables every day.\nDrink water instead of pop.\nWash your hands with soap for 20 seconds.\nPlay outside for at least an hour.\nYou should sleep for 9 to 12 hours every night.\nWear a helmet when you ride your bike.\nCover your cough with your elbow.\nYou can be strong, smart and healthy. Start today!"}
]
});
})();
