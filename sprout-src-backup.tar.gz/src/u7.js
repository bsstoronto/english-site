/* ===================== GRADE 3 · UNIT 7 · TIME, SHAPES AND MONEY (original content, plus one traditional rhyme) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
const p=(q,a,o,why)=>({lv:"predict",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"maths", num:7, emoji:"⏰🔺🪙", title:"Time, Shapes and Money", badge:"🧮 Problem Solver",

stories:[
/* ---------- 1. PROBLEM-SOLVING STORY ---------- */
{title:"The Lemonade Stand", e:"🍋", kind:"Problem-solving story", pages:[
 {pic:"🐶🛏️", text:"Priya and her little brother Sam visited the animal shelter in their neighbourhood in Toronto. A volunteer named Mr. Lopez showed them the dogs. \"Winter is coming,\" he said, \"and the dogs need warm blankets. Each blanket costs ten dollars, but we don't have enough money.\" On the way home, Priya stopped walking. \"Sam,\" she said, \"I have an idea. Let's raise money to buy blankets!\"",
  qs:[f("What do the dogs at the shelter need?","Warm blankets",["New toys","Bigger bowls"],"\"The dogs need warm blankets.\""),
      f("How much does one blanket cost?","Ten dollars",["One dollar","One hundred dollars"],"\"Each blanket costs ten dollars.\""),
      p("How do you think Priya and Sam will raise money?","They will sell something, like a lemonade stand",["They will take money from the shelter","They will forget about it"],"The title of the story is a big clue: The Lemonade Stand!")]},
 {pic:"📝🛒", text:"\"Let's have a lemonade stand,\" said Priya. \"We want to buy three blankets. Three blankets at ten dollars each is thirty dollars.\" First, they needed a plan. Priya wrote a shopping list:<div class=\"realdoc\" style=\"text-align:left\"><b>🛒 Shopping list</b><br>• 1 bag of lemons ........ $4<br>• 1 bag of sugar ......... $2<br>• 1 pack of paper cups ... $3<br><b>Total ................... $9</b></div>Mom lent them a ten-dollar bill. \"You must pay me back,\" she said with a smile.",
  qs:[f("How many blankets do they want to buy?","Three",["One","Ten"],"\"We want to buy three blankets.\""),
      f("How much does the bag of lemons cost?","$4",["$2","$9"],"1 bag of lemons ... $4"),
      t("Mom gave them $10, and the shopping cost $9. How much change did they get?","$1",["$9","$19"],"$10 − $9 = $1. Change is the money you get back."),
      t("Why did Priya write a shopping list?","To plan what to buy and how much it would cost",["To practise her handwriting only","Because Sam asked for a story"],"A list helps you remember everything and add up the cost before you shop.")]},
 {pic:"🧮💭", text:"Back home, Sam asked, \"How much should we charge for one cup?\" Priya thought hard. \"If one cup costs one dollar, we need to sell thirty cups for the blankets.\" Then she frowned. \"But wait. We also have to pay Mom back ten dollars. So we need forty dollars in total. That means forty cups!\" Sam's eyes went wide. \"Forty cups is a lot of lemonade!\"",
  qs:[f("How much will one cup of lemonade cost?","One dollar",["Ten dollars","Fifty dollars"],"\"If one cup costs one dollar…\""),
      t("Why do they need forty dollars, not thirty?","They must also pay Mom back ten dollars",["Blankets got more expensive","Sam wants a toy"],"$30 for blankets + $10 for Mom = $40."),
      t("Which maths did Priya use to find the total?","She added 30 and 10",["She took 10 away from 30","She counted the lemons"],"30 + 10 = 40.")]},
 {pic:"☀️🍋", text:"On Saturday, they opened their stand at ten o'clock in the morning. Sam held up a sign: <b>LEMONADE $1 · ALL MONEY HELPS SHELTER DOGS!</b> Neighbours came one by one. By twelve o'clock, they had sold eighteen cups. \"Only twenty-two more to go!\" Priya said. But then, at one o'clock, dark clouds rolled across the sky, and big drops of rain began to fall. Everyone hurried home.",
  qs:[f("What time did they open the stand?","Ten o'clock in the morning",["Twelve o'clock","One o'clock"],"They opened their stand at ten o'clock in the morning."),
      f("How many cups had they sold by twelve o'clock?","Eighteen",["Forty","Twenty-two"],"By twelve o'clock, they had sold eighteen cups."),
      t("How long was the stand open before twelve o'clock?","Two hours",["Ten hours","Half an hour"],"From ten o'clock to twelve o'clock is two hours."),
      p("What problem has just happened, and what might they do?","It is raining, so they will need a new plan",["It is sunny, so they will sell more","The neighbours will all come back right away"],"Rain makes people go home. Problem-solvers look for a new plan.")]},
 {pic:"🌧️🍪", text:"Sam's lip wobbled. \"It's over.\" But Priya looked at the porch of their house. \"Not yet! Let's move the stand under the roof.\" Then Grandma came out with a big tray. \"I baked oatmeal cookies,\" she said. \"Sell them too!\" Sam made a new sign: <b>LEMONADE $1 · COOKIES 50¢</b>. People with umbrellas came back to buy warm cookies and cold lemonade. By four o'clock, the money box was full.",
  qs:[f("Where did they move the stand?","Under the roof of the porch",["Into the park","To the shelter"],"\"Let's move the stand under the roof.\""),
      f("How much did one cookie cost?","50¢ (fifty cents)",["$5","$1"],"COOKIES 50¢"),
      t("How many cookies could you buy with one dollar?","Two",["One","Ten"],"50¢ + 50¢ = $1, so one dollar buys two cookies."),
      t("What did Priya do when the problem happened?","She found a new plan instead of giving up",["She cried and went to bed","She blamed Sam"],"Problem-solvers try another way.")]},
 {pic:"🧺🐕", text:"They counted the money together: forty-three dollars! First, they paid Mom back ten dollars. That left thirty-three dollars. On Monday, they bought three blankets for thirty dollars and took them to the shelter. They put the last three dollars in the donation box. Mr. Lopez smiled. \"You two are real problem-solvers.\" That night, a little brown dog named Biscuit slept on a soft, warm, blue blanket.",
  qs:[f("How much money did they make altogether?","Forty-three dollars",["Thirty dollars","Ten dollars"],"They counted the money together: forty-three dollars!"),
      t("After paying Mom back, how much money was left?","$33",["$43","$53"],"$43 − $10 = $33."),
      t("After buying three blankets, how much was left for the donation box?","$3",["$13","$30"],"$33 − $30 = $3."),
      t("What is the most important lesson of this story?","Make a plan, and when a problem comes, try a new way",["Lemonade is the best drink","Never ask for help"],"Priya planned, counted, and solved the rain problem with a new idea.")]}
], turn:{q:"Imagine you want to raise money to help someone. What would you sell, and how much would it cost? Write two or three sentences.",model:"I would sell bookmarks that I paint myself. Each bookmark would cost two dollars. I would give the money to the children's hospital."}},

/* ---------- 2. STORY ---------- */
{title:"Arjun and Grandpa's Clock", e:"🕰️", kind:"Story", pages:[
 {pic:"⏰😟", text:"Arjun lived with his family in Delhi, in India. Every morning, the school bus came at a quarter past eight. And every morning, Arjun asked, \"Is it time yet?\" He could read the numbers on his mother's phone, but the big old clock in the hall was a mystery. It had no numbers that changed, just two black hands that moved so slowly he couldn't see them move at all. One morning, he missed the bus.",
  qs:[f("Where did Arjun live?","Delhi, in India",["Toronto, in Canada","London, in England"],"Arjun lived with his family in Delhi, in India."),
      f("When did the school bus come?","At a quarter past eight",["At nine o'clock","At half past seven"],"The school bus came at a quarter past eight."),
      t("Why was the hall clock a mystery to Arjun?","He did not know how to read a clock with hands",["It was broken","It was too high"],"He could read the numbers on a phone, but not the clock's hands.")]},
 {pic:"👴🕰️", text:"That evening, Grandpa took Arjun to the hall clock. \"A clock has two hands,\" he said. \"The short hand is the hour hand. It tells us the hour. The long hand is the minute hand. It tells us how many minutes have passed.\" He pointed. \"Now the short hand points to 6, and the long hand points straight up to 12. That means it is six o'clock.\"",
  qs:[f("Which hand is the hour hand?","The short hand",["The long hand","The red hand"],"\"The short hand is the hour hand.\""),
      f("Where does the long hand point when it is exactly six o'clock?","Straight up to 12",["To 6","To 3"],"The long hand points straight up to 12."),
      t("The short hand points to 9 and the long hand points to 12. What time is it?","Nine o'clock",["Twelve o'clock","Half past nine"],"When the long hand is on 12, it is exactly 'o'clock'. The short hand shows the hour: 9.")]},
 {pic:"🔢🖐️", text:"\"There are sixty minutes in one hour,\" Grandpa said. \"The long hand goes all the way around the clock in one hour. Each number stands for five minutes. Count with me: five, ten, fifteen, twenty…\" Arjun counted by fives all the way around: \"…fifty-five, sixty!\" \"When the long hand points to 6,\" said Grandpa, \"it has gone halfway around. That's thirty minutes. We say <b>half past</b>.\"",
  qs:[f("How many minutes are in one hour?","Sixty",["Twelve","One hundred"],"\"There are sixty minutes in one hour.\""),
      f("How many minutes does each number on the clock stand for?","Five",["One","Ten"],"\"Each number stands for five minutes.\""),
      t("The long hand points to 6 and the short hand is between 3 and 4. What time is it?","Half past three",["Six o'clock","Three o'clock"],"Long hand on 6 = 30 minutes = half past. The short hand has passed 3.")]},
 {pic:"🍕🕰️", text:"\"Now, here is a trick,\" said Grandpa. He cut a paper circle into four pieces, like a pizza. \"When the long hand points to 3, it has gone one quarter of the way around. That's fifteen minutes. We say <b>quarter past</b>. When it points to 9, there is only one quarter left before the next hour. We say <b>quarter to</b>.\" Arjun grinned. \"So the bus comes at quarter past eight. The long hand will be on 3 and the short hand just after 8!\"",
  qs:[f("What do we say when the long hand points to 3?","Quarter past",["Half past","Quarter to"],"\"When the long hand points to 3… we say quarter past.\""),
      f("How many minutes is a quarter of an hour?","Fifteen",["Thirty","Twenty-five"],"One quarter of the way around is fifteen minutes."),
      t("Why did Grandpa cut the circle into four pieces?","To show what a quarter means",["To eat it","To make a hat"],"A quarter is one of four equal parts.")]},
 {pic:"🚌😄", text:"The next morning, Arjun stood by the hall clock with his school bag. The short hand was just after 8. The long hand crept towards the 3. \"It's almost quarter past eight!\" he shouted. He ran outside just as the yellow bus turned the corner. From the window, he waved at Grandpa. That afternoon, Arjun drew a clock in his notebook and wrote under it: <i>Learning something new takes a little time, and time is worth learning!</i>",
  qs:[f("Where was the long hand moving towards?","The 3",["The 12","The 9"],"The long hand crept towards the 3."),
      t("Did Arjun catch the bus this time?","Yes, because he could read the clock",["No, he was late again","He walked instead"],"He ran outside just as the bus turned the corner."),
      t("How did Arjun change from the start of the story to the end?","He learned to read a clock and became on time",["He became taller","He stopped going to school"],"At first he missed the bus. At the end, he could read the clock and catch it.")]}
], turn:{q:"What time do you wake up, and what time do you go to bed? Write two sentences using o'clock, half past or quarter past.",model:"I wake up at half past six. I go to bed at eight o'clock."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"Shapes All Around Us", e:"🔺", kind:"Fact text", pages:[
 {pic:"⭕🔺🟥", text:"Look around you. Shapes are everywhere! A <b>circle</b> is perfectly round, with no sides and no corners. A <b>triangle</b> has three straight sides and three corners. A <b>square</b> has four equal sides and four corners. A <b>rectangle</b> also has four sides and four corners, but two of its sides are longer than the other two. Flat shapes like these are called 2D shapes.",
  qs:[f("How many sides does a triangle have?","Three",["Four","None"],"A triangle has three straight sides."),
      f("Which shape has no sides and no corners?","A circle",["A square","A triangle"],"A circle is perfectly round, with no sides and no corners."),
      t("What is the difference between a square and a rectangle?","A square's sides are all equal, but a rectangle has two longer sides",["A rectangle has three sides","A square is round"],"Both have four sides, but only a square has four equal sides.")]},
 {pic:"🐝⬡", text:"Some shapes have more sides. A <b>pentagon</b> has five sides. A <b>hexagon</b> has six sides. Honeybees build their honeycombs out of hexagons! Hexagons fit together with no gaps, so the bees can store lots of honey without wasting wax. An <b>octagon</b> has eight sides. Look for one on a stop sign.",
  qs:[f("Which shape do honeybees use to build honeycombs?","Hexagons",["Circles","Triangles"],"Honeybees build their honeycombs out of hexagons."),
      f("How many sides does an octagon have?","Eight",["Six","Five"],"An octagon has eight sides."),
      t("Why are hexagons good for honeycombs?","They fit together with no gaps",["They are round","They are easy to eat"],"Hexagons fit together with no gaps, so no wax is wasted.")]},
 {pic:"🌉🔺", text:"Engineers love triangles. A triangle is a very strong shape because it does not bend easily when you push on it. That is why many bridges, towers and roofs are built with triangles. The Eiffel Tower in Paris is full of them! If you push on a square made of straws, it squashes into a different shape. A triangle made of straws stays strong.",
  qs:[f("Why do engineers love triangles?","Triangles are very strong and don't bend easily",["Triangles are pretty","Triangles are round"],"A triangle is a very strong shape because it does not bend easily."),
      f("Which famous tower is full of triangles?","The Eiffel Tower",["The CN Tower only","A sandcastle"],"The Eiffel Tower in Paris is full of them!"),
      t("What happens when you push on a square made of straws?","It squashes into a different shape",["It becomes a circle","Nothing at all"],"A square can lean over and squash, but a triangle holds its shape.")]},
 {pic:"🎲⚽🥫", text:"Some shapes are not flat. They are solid, and we call them 3D shapes. A dice is a <b>cube</b>: it has six square faces. A ball is a <b>sphere</b>: it is round all over, like a globe. A can of soup is a <b>cylinder</b>: it has two circle faces and one curved side. An ice cream cone is a <b>cone</b>: it has one circle face and a point at the top.",
  qs:[f("What shape is a dice?","A cube",["A sphere","A cone"],"A dice is a cube."),
      f("How many faces does a cube have?","Six",["Four","Eight"],"It has six square faces."),
      t("Which 3D shape can roll in any direction?","A sphere",["A cube","A cone that is standing up"],"A sphere is round all over, so it rolls every way.")]},
 {pic:"❄️⭐🌻", text:"Nature makes shapes too. Every snowflake has six points. Most sea stars have five arms. The seeds in a sunflower make spiral patterns, and the Moon and Sun look like circles in the sky. Shapes help us build, measure, make art and understand the world. Next time you go for a walk, see how many shapes you can find!",
  qs:[f("How many points does every snowflake have?","Six",["Five","Eight"],"Every snowflake has six points."),
      f("What pattern do sunflower seeds make?","Spirals",["Squares","Straight lines"],"The seeds in a sunflower make spiral patterns."),
      t("What is the main idea of this whole text?","Shapes are all around us, in things people make and in nature",["Only bees use shapes","Shapes are only in maths books"],"Every page shows shapes in a different place.")]}
], turn:{q:"Look around the room. Write three sentences about shapes you can see.",model:"The clock on the wall is a circle. My book is a rectangle. The roof in the picture is a triangle."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"The Story of Money", e:"🪙", kind:"Fact text", pages:[
 {pic:"🐄🌾", text:"Long, long ago, there was no money at all. If a farmer had extra wheat but needed a cow, she had to find someone with a cow who wanted wheat. This is called <b>trading</b>, or bartering. But trading was hard. What if the person with the cow didn't want wheat? People needed something that everyone would accept.",
  qs:[f("What did people do before money?","They traded things",["They used cards","They used phones"],"This is called trading, or bartering."),
      t("Why was trading hard?","The other person might not want what you had",["Cows were too small","Wheat was too heavy to eat"],"What if the person with the cow didn't want wheat?")]},
 {pic:"🐚💰", text:"So people began using special objects as money. In parts of Africa and Asia, people used small, shiny <b>cowrie shells</b> for hundreds of years. In other places, people used salt, beads or even big stones. These objects were easy to count and everyone agreed they had value.",
  qs:[f("Which shells were used as money in parts of Africa and Asia?","Cowrie shells",["Clam shells","Snail shells"],"People used small, shiny cowrie shells."),
      t("Why were shells good to use as money?","They were easy to count and everyone agreed they had value",["They could swim","They were very big"],"These objects were easy to count and everyone agreed they had value.")]},
 {pic:"🪙📜", text:"About 2,600 years ago, in a land that is now part of Turkey, people made some of the first metal <b>coins</b>. Coins were small, strong and easy to carry. Later, about 1,000 years ago, people in China began to use <b>paper money</b>, because carrying lots of heavy coins was hard. Today, many people also pay with cards or phones.",
  qs:[f("Where were some of the first metal coins made?","In a land that is now part of Turkey",["In Canada","On the Moon"],"In a land that is now part of Turkey."),
      f("Who began using paper money about 1,000 years ago?","People in China",["People in Canada","Pirates"],"People in China began to use paper money."),
      t("Why did people start using paper money?","Lots of coins were heavy to carry",["Paper is tasty","Coins disappeared"],"Carrying lots of heavy coins was hard.")]},
 {pic:"🌍💵", text:"Different countries use different money, called <b>currencies</b>. Canada and the United States use dollars. India uses the rupee. Many countries in Europe use the euro. Japan uses the yen, and Mexico uses the peso. One dollar is made of one hundred cents, and one rupee is made of one hundred paise.",
  qs:[f("What is the money of India called?","The rupee",["The yen","The euro"],"India uses the rupee."),
      f("How many cents make one dollar?","One hundred",["Ten","Twelve"],"One dollar is made of one hundred cents."),
      t("Which country uses the yen?","Japan",["Mexico","Canada"],"Japan uses the yen.")]},
 {pic:"🐷🎁", text:"Money is a tool. We can <b>spend</b> it on things we need, like food, and things we want, like toys. We can <b>save</b> it in a piggy bank or a bank account for later. And we can <b>share</b> it to help others. A smart plan is to do all three. Before you buy something, ask yourself: <i>Is this a need or a want?</i>",
  qs:[f("What are the three things we can do with money?","Spend, save and share",["Eat, sleep and play","Throw, hide and lose"],"We can spend it… save it… and share it."),
      t("Which of these is a NEED?","Food",["A new video game","A toy car"],"We need food to live. A game is a want."),
      t("Why is it smart to save some money?","So you have money for later",["Because coins are heavy","So you can never spend it"],"Saving means keeping money for something later.")]}
], turn:{q:"If someone gave you ten dollars, how much would you spend, save and share? Explain why.",model:"I would save five dollars for a new bike. I would spend three dollars on a book. I would share two dollars with the animal shelter."}},

/* ---------- 5. FABLE ---------- */
{title:"Later-Later Lula (a fable)", e:"🐿️", kind:"Fable", pages:[
 {pic:"🐿️🍂", text:"In a maple forest lived a squirrel named Lula. Lula was fun and fast and full of jokes, but she had one bad habit. Whenever someone said, \"Lula, it's time to gather nuts for winter,\" she always answered the same way: \"Later, later!\" So the other animals called her Later-Later Lula.",
  qs:[f("What kind of animal was Lula?","A squirrel",["A rabbit","An owl"],"In a maple forest lived a squirrel named Lula."),
      f("What did Lula always say?","\"Later, later!\"",["\"Right now!\"","\"No, thank you!\""],"She always answered the same way: \"Later, later!\""),
      p("What do you think will happen if Lula keeps saying 'later'?","She won't have enough food when winter comes",["She will have the most nuts","Winter will never come"],"Squirrels must gather nuts before winter. Saying 'later' is a warning sign.")]},
 {pic:"🪵🐦", text:"Her neighbour Tock was a woodpecker. Every morning, Tock tapped on the old oak tree: tock, tock, tock, sixty taps, like the ticking of a clock. \"Each day has the same number of hours for everyone,\" Tock said. \"Some use them, and some lose them.\" Lula laughed. \"There are lots of days before winter, Tock!\" And she went off to play.",
  qs:[f("How many times did Tock tap each morning?","Sixty",["Ten","One hundred"],"Sixty taps, like the ticking of a clock."),
      t("What did Tock mean by \"Some use them, and some lose them\"?","Some animals use their time well, and others waste it",["Some animals lose their tails","Hours can be found under trees"],"Everyone has the same time. What matters is how we use it."),
      t("Why did Lula laugh?","She thought there was plenty of time",["Tock told a joke","She found a nut"],"\"There are lots of days before winter, Tock!\"")]},
 {pic:"🍁❄️", text:"September went by. October went by. The red maple leaves fell to the ground. One cold November morning, Lula woke up and saw white flakes falling. Snow! She raced around the forest looking for nuts, but the other animals had already gathered them. She found only a few, just three acorns and one pine cone.",
  qs:[f("What did Lula see one November morning?","Snow falling",["A rainbow","A big nut tree"],"She saw white flakes falling. Snow!"),
      f("How many acorns did she find?","Three",["Thirty","None"],"Just three acorns and one pine cone."),
      t("Put the months in the story in order.","September, October, November",["November, October, September","October, September, November"],"September went by. October went by… One cold November morning…")]},
 {pic:"🥶🐦", text:"Lula shivered in her nest, with a cold, empty tummy. Then she heard a tap: tock, tock, tock. It was Tock, with a little bag of seeds. \"I gathered extra,\" he said kindly. \"You may share mine this winter.\" Lula's eyes filled with tears. \"Thank you, Tock. I wasted so much time. I'm sorry I laughed at you.\"",
  qs:[f("What did Tock bring?","A little bag of seeds",["A blanket","A clock"],"It was Tock, with a little bag of seeds."),
      t("What kind of friend is Tock?","Kind and generous",["Mean and selfish","Lazy"],"He shared his food even though Lula had laughed at him."),
      t("How did Lula feel?","Sorry and thankful",["Proud","Angry"],"\"Thank you… I'm sorry I laughed at you.\"")]},
 {pic:"🌸🐿️", text:"When spring came, Lula was a different squirrel. Every morning, when she heard Tock's sixty taps, she jumped up and worked first and played after. By autumn, her nest was so full of nuts that she gave a big bag to Tock. The animals stopped calling her Later-Later Lula. Now they called her Right-Now Lula. <b>Lesson: Don't put off until tomorrow what you can do today.</b>",
  qs:[t("What is the lesson of this fable?","Don't put off until tomorrow what you can do today",["Play all day","Woodpeckers are noisy"],"Lula learned to do her work on time."),
      f("What did the animals call her at the end?","Right-Now Lula",["Later-Later Lula","Lazy Lula"],"Now they called her Right-Now Lula."),
      t("How did Lula change?","She learned to work first and play after",["She stopped eating nuts","She moved away"],"Every morning she worked first and played after.")]}
], turn:{q:"Is there something you often say 'later' to? Write what it is and how you could do it on time.",model:"I often say later to tidying my room. I could tidy it for ten minutes every day after school."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A market price board and a school timetable", e:"🧾", kind:"Real-world text", pages:[
 {pic:"🥕🍎", text:"Priya and Grandma went to the Saturday farmers' market. Here is the price board at Green Valley Farm.<table class=\"realtbl\"><tr><th>Item</th><th>Price</th></tr><tr><td>🍎 Apples</td><td>3 for $1</td></tr><tr><td>🥕 Carrots (1 bunch)</td><td>$2</td></tr><tr><td>🍞 Bread (1 loaf)</td><td>$3</td></tr><tr><td>🥚 Eggs (12)</td><td>$5</td></tr><tr><td>🍯 Honey (1 jar)</td><td>$6</td></tr><tr><td>💐 Flowers</td><td>$4</td></tr></table><i>Open Saturdays, 8:00 a.m. to 1:00 p.m. · We accept cash and cards.</i>",
  qs:[f("How much is one loaf of bread?","$3",["$5","$1"],"🍞 Bread (1 loaf): $3"),
      f("What is the most expensive item on the board?","Honey",["Bread","Apples"],"Honey costs $6, the most on the board."),
      t("How many apples can you buy for $2?","Six",["Three","Two"],"3 apples for $1, so $2 buys 3 + 3 = 6 apples."),
      t("Grandma buys bread and eggs. How much does she spend?","$8",["$2","$15"],"$3 + $5 = $8."),
      t("Can you go to this market at 2:00 p.m. on Saturday?","No, it closes at 1:00 p.m.",["Yes, it is open all day","Only on Sunday"],"Open Saturdays, 8:00 a.m. to 1:00 p.m.")]},
 {pic:"🏫🕘", text:"This is the Monday timetable for Priya's Grade 3 class.<table class=\"realtbl\"><tr><th>Time</th><th>Subject</th></tr><tr><td>8:30</td><td>📖 Reading</td></tr><tr><td>9:30</td><td>➗ Maths</td></tr><tr><td>10:30</td><td>⚽ Recess (15 minutes)</td></tr><tr><td>10:45</td><td>🔬 Science</td></tr><tr><td>12:00</td><td>🍱 Lunch</td></tr><tr><td>1:00</td><td>🎨 Art</td></tr><tr><td>2:00</td><td>🏃 Gym</td></tr><tr><td>3:15</td><td>🏠 Home time</td></tr></table>",
  qs:[f("What subject starts at 9:30?","Maths",["Reading","Art"],"9:30: Maths"),
      f("How long is recess?","15 minutes",["One hour","Five minutes"],"10:30: Recess (15 minutes)"),
      t("How long is the Reading lesson?","One hour",["Half an hour","Two hours"],"Reading starts at 8:30 and Maths starts at 9:30: that's one hour."),
      t("What comes right after lunch?","Art",["Gym","Science"],"12:00 Lunch, then 1:00 Art."),
      t("Priya has a dentist appointment at 2:30. Which subject will she miss?","Gym",["Art","Reading"],"Gym is from 2:00 until home time at 3:15.")]}
], turn:{q:"Make a short list of three things you would buy at the market, with their prices. Then write the total.",model:"I would buy carrots for $2, apples for $1 and flowers for $4. The total is $7."}}
],

poems:[
 {title:"Thirty Days Hath September (a traditional rhyme, first printed more than 400 years ago)",
  lines:["Thirty days hath September,","April, June, and November;","All the rest have thirty-one,","Excepting February alone,","Which hath but twenty-eight days clear,","And twenty-nine in each leap year."],
  qs:[f("How many days does November have?","Thirty",["Thirty-one","Twenty-eight"],"\"Thirty days hath September, April, June, and November.\""),
      f("Which month has twenty-eight days (or twenty-nine in a leap year)?","February",["April","December"],"\"Excepting February alone, which hath but twenty-eight days clear.\""),
      t("How many days does July have?","Thirty-one",["Thirty","Twenty-eight"],"July is not in the thirty-day list, so it is one of \"all the rest\" with thirty-one."),
      t("What does the old word 'hath' mean?","Has",["Hates","Hides"],"Long ago, people said 'hath' for 'has'."),
      f("Which word rhymes with 'September'?","November",["April","June"],"September and November end with the same sound.")]},
 {title:"Shapes on My Street",
  lines:["The wheels on the bus are circles that spin,","The doors are rectangles to let people in.","The roof on the house is a triangle high,","The kite is a diamond that dances on high.","The stop sign's an octagon, red as can be,","The window's a square where the cat watches me.","I count them, I name them, I find them each day,","There are shapes on my street in every way!"],
  qs:[f("Which shape are the wheels on the bus?","Circles",["Squares","Triangles"],"\"The wheels on the bus are circles that spin.\""),
      f("Which shape is the stop sign?","An octagon",["A circle","A square"],"\"The stop sign's an octagon.\""),
      f("Which word rhymes with 'spin'?","in",["bus","door"],"Spin and in end with the same sound."),
      t("What is the poet doing in the last two lines?","Finding and naming shapes every day",["Sleeping on the bus","Painting the house"],"\"I count them, I name them, I find them each day.\"")]}
],

words:[
 /* time */
 {w:"clock",e:"🕰️",m:"a machine that shows the time",ex:"The clock on the wall says three o'clock.",fill:"Look at the ___ to see what time it is."},
 {w:"hour",e:"⏳",m:"sixty minutes",ex:"The film lasted one hour.",fill:"There are sixty minutes in one ___."},
 {w:"minute",e:"⏱️",m:"sixty seconds",ex:"Wait one minute, please.",fill:"There are sixty seconds in one ___."},
 {w:"second",e:"⚡",m:"a very short time; sixty of them make one minute",ex:"A blink takes less than a second.",fill:"Count to one quickly: that is about one ___."},
 {w:"calendar",e:"📅",m:"a chart that shows the days, weeks and months of a year",ex:"I marked my birthday on the calendar.",fill:"Look at the ___ to see what day it is."},
 {w:"schedule",e:"🗓️",m:"a plan that shows what happens at what time",ex:"Our class schedule shows gym at two o'clock.",fill:"The bus ___ tells us when each bus comes."},
 {w:"early",e:"🌅",m:"before the usual or planned time",ex:"I woke up early to watch the sunrise.",fill:"The bus came ___, so we had to run."},
 {w:"late",e:"🏃",m:"after the usual or planned time",ex:"Arjun was late and missed the bus.",fill:"Hurry, or you will be ___ for school!"},
 {w:"quarter",e:"🍕",m:"one of four equal parts; fifteen minutes",ex:"The bus comes at a quarter past eight.",fill:"Fifteen minutes is a ___ of an hour."},
 {w:"century",e:"💯",m:"one hundred years",ex:"The old clock is more than a century old.",fill:"One hundred years is called a ___."},
 /* shapes */
 {w:"circle",e:"⭕",m:"a perfectly round flat shape",ex:"A wheel is a circle.",fill:"A coin is shaped like a ___."},
 {w:"triangle",e:"🔺",m:"a flat shape with three sides and three corners",ex:"The roof is shaped like a triangle.",fill:"A slice of pizza often looks like a ___."},
 {w:"square",e:"🟥",m:"a flat shape with four equal sides and four corners",ex:"Each box on the chessboard is a square.",fill:"A ___ has four sides that are all the same length."},
 {w:"rectangle",e:"🚪",m:"a flat shape with four sides and four corners, with two sides longer than the others",ex:"A door is a rectangle.",fill:"My book is shaped like a ___."},
 {w:"hexagon",e:"⬡",m:"a flat shape with six sides",ex:"Bees build honeycombs from hexagons.",fill:"A ___ has six sides."},
 {w:"cube",e:"🎲",m:"a solid shape with six square faces",ex:"A dice is a cube.",fill:"An ice ___ is shaped like a box."},
 {w:"sphere",e:"⚽",m:"a solid shape that is round all over, like a ball",ex:"The Earth is almost a sphere.",fill:"A football is a ___."},
 {w:"cylinder",e:"🥫",m:"a solid shape with two circle ends and a curved side",ex:"A can of soup is a cylinder.",fill:"A tin can is shaped like a ___."},
 {w:"side",e:"📏",m:"one of the straight lines that make the edge of a shape",ex:"A triangle has three sides.",fill:"A square has four equal ___s."},
 {w:"corner",e:"📐",m:"the point where two sides or edges meet",ex:"A rectangle has four corners.",fill:"The cat sat in the ___ of the room."},
 /* money */
 {w:"coin",e:"🪙",m:"a small, flat, round piece of metal money",ex:"I found a shiny coin on the floor.",fill:"I put a ___ in my piggy bank."},
 {w:"price",e:"🏷️",m:"how much money you must pay for something",ex:"The price of the bread is three dollars.",fill:"What is the ___ of this book?"},
 {w:"cost",e:"💲",m:"to have a price of",ex:"The blankets cost ten dollars each.",fill:"How much does this pen ___?"},
 {w:"change",e:"🔁",m:"the money you get back when you pay too much",ex:"I paid with ten dollars and got one dollar in change.",fill:"The shopkeeper gave me my ___."},
 {w:"cent",e:"¢",m:"a small unit of money; one hundred of them make a dollar",ex:"One cookie costs fifty cents.",fill:"One hundred ___s make one dollar."},
 {w:"save",e:"🐷",m:"to keep money to use later",ex:"I save my coins in a piggy bank.",fill:"I want to ___ money for a new bike."},
 {w:"spend",e:"🛍️",m:"to use money to buy things",ex:"Grandma will spend eight dollars at the market.",fill:"Don't ___ all your money at once!"},
 {w:"budget",e:"📒",m:"a plan for how to use your money",ex:"Our budget for the party is twenty dollars.",fill:"We made a ___ so we wouldn't spend too much."},
 {w:"earn",e:"💪",m:"to get money by working",ex:"Priya and Sam earned money with their lemonade stand.",fill:"You can ___ money by doing jobs."},
 {w:"total",e:"🧾",m:"the whole amount when everything is added together",ex:"The total for our shopping is nine dollars.",fill:"Add up all the prices to find the ___."},
 /* maths words */
 {w:"add",e:"➕",m:"to put numbers together to find how many in all",ex:"If you add 3 and 4, you get 7.",fill:"___ 5 and 5 to get 10."},
 {w:"subtract",e:"➖",m:"to take one number away from another",ex:"If you subtract 2 from 9, you get 7.",fill:"___ 3 from 10 and you get 7."},
 {w:"equal",e:"🟰",m:"the same in amount or size",ex:"Cut the cake into four equal pieces.",fill:"Two plus two is ___ to four."},
 {w:"double",e:"✌️",m:"two times as much",ex:"Double 6 is 12.",fill:"If you ___ 4, you get 8."},
 {w:"half",e:"🌗",m:"one of two equal parts",ex:"Half of ten is five.",fill:"I ate ___ of the apple and gave the rest to Sam."},
 {w:"estimate",e:"🤔",m:"to make a careful guess about a number or amount",ex:"I estimate there are about fifty beans in the jar.",fill:"Can you ___ how many people are in the room?"},
 {w:"pattern",e:"🔁",m:"something that repeats in a regular way",ex:"Red, blue, red, blue is a pattern.",fill:"2, 4, 6, 8 is a number ___."},
 {w:"measure",e:"📏",m:"to find out the size, length or amount of something",ex:"We measure the table with a ruler.",fill:"Use a ruler to ___ the line."},
 {w:"altogether",e:"🧺",m:"in total; when everything is counted together",ex:"They made forty-three dollars altogether.",fill:"I have 3 apples and 2 pears. How many fruits do I have ___?"},
 {w:"difference",e:"↔️",m:"the amount left when you subtract one number from another",ex:"The difference between 10 and 7 is 3.",fill:"The ___ between 9 and 5 is 4."}
],

spelling:[
 {w:"clock",s:"The clock is on the wall.",tip:"'ck' at the end after a short vowel."},
 {w:"hour",s:"Lunch is in one hour.",tip:"The 'h' is silent: h-our."},
 {w:"minute",s:"Wait a minute.",tip:"min-ute."},
 {w:"shape",s:"A circle is a round shape.",tip:"Magic e: sh-a-pe."},
 {w:"circle",s:"Draw a circle.",tip:"Starts with 'c' that sounds like 's', and ends with '-le'."},
 {w:"square",s:"A square has four equal sides.",tip:"'squ' then 'are'."},
 {w:"money",s:"I save my money.",tip:"'mon' sounds like 'mun': m-o-n-ey."},
 {w:"coin",s:"I found a coin.",tip:"'oi' as in oil."},
 {w:"price",s:"What is the price?",tip:"'ce' at the end sounds like 's'."},
 {w:"count",s:"Let's count the coins.",tip:"'ou' as in out."},
 {w:"plus",s:"Two plus two is four."},
 {w:"minus",s:"Ten minus three is seven."},
 {w:"half",s:"Half of four is two.",tip:"The 'l' is silent: ha-l-f."},
 {w:"total",s:"What is the total?"},
 {w:"twelve",s:"There are twelve months in a year.",tip:"'tw' at the start and 've' at the end."}
],

facts:[
 {e:"🗓️",c:"There are 365 days in a normal year.",t:true,x:"True! And in a leap year, every four years, there are 366, because February gets an extra day."},
 {e:"⏰",c:"A day has 12 hours.",t:false,x:"Not true! A whole day has 24 hours. A clock face shows 12 hours, so the hour hand goes around twice each day."},
 {e:"🐝",c:"Honeybees build honeycombs out of hexagons.",t:true,x:"True! Hexagons fit together with no gaps, so bees waste no wax."},
 {e:"❄️",c:"Every snowflake has six points or sides.",t:true,x:"True! Snowflakes are all different, but each one grows with six arms."},
 {e:"🛑",c:"A stop sign is shaped like a hexagon.",t:false,x:"Not true! A stop sign is an octagon, with eight sides."},
 {e:"🐚",c:"People once used shells as money.",t:true,x:"True! Cowrie shells were used as money in parts of Africa and Asia for hundreds of years."},
 {e:"📜",c:"Paper money was first used in China.",t:true,x:"True! People in China began using paper money about 1,000 years ago."},
 {e:"🔺",c:"The triangle is one of the strongest shapes for building.",t:true,x:"True! That's why bridges, towers and roofs use triangles."},
 {e:"⚽",c:"A football is shaped like a cube.",t:false,x:"Not true! A football is a sphere. A dice is a cube."},
 {e:"0️⃣",c:"The idea of zero as a number was developed in ancient India.",t:true,x:"True! Mathematicians in India wrote about zero as a number around 1,400 years ago, and the idea spread around the world."},
 {e:"🌍",c:"Every country in the world uses the same money.",t:false,x:"Not true! Countries use different currencies: dollars, rupees, euros, yen, pesos and many more."},
 {e:"⏳",c:"Before clocks, people used shadows, sand and water to measure time.",t:true,x:"True! Sundials used shadows, hourglasses used sand, and water clocks used dripping water."}
],

writing:[
 {e:"🛒",t:"Write a shopping list with prices",level:"Step 1 · List",
  prompt:"You are going shopping for a picnic. Write a shopping list of at least 4 things, one on each line, with a number and a price for each (like: 2 apples - $1). Then write a sentence with the total. Use at least 2 words from the word bank.",
  minS:1,minWords:2,
  rx:[["(\\n[^\\n]*\\d[^\\n]*){3}","I wrote at least 4 lines with numbers"],["(\\$|¢|cents?|dollars?|rupees?)[\\s\\S]*(\\$|¢|cents?|dollars?|rupees?)[\\s\\S]*(\\$|¢|cents?|dollars?|rupees?)","I wrote prices"],["\\b[Tt]otal\\b","I wrote the total"],["[.!?]\\s*$","My last sentence ends with a full stop"]],
  starters:["Picnic shopping list\n","2 apples - $1\n","1 loaf of bread - $3\n","The total is "],
  model:"Picnic shopping list\n6 apples - $2\n1 loaf of bread - $3\n12 eggs - $5\n1 bunch of carrots - $2\n1 jar of honey - $6\nThe total cost is $18, so our budget of $20 is enough and we will get $2 in change."},
 {e:"❓",t:"Write your own word problem",level:"Step 2 · Word problem",
  prompt:"Write a maths word problem about money, time or shapes. Tell a short story with numbers, then ask a question that ends with a question mark. After that, write the answer and explain how you solved it.",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["\\d|\\b(one|two|three|four|five|six|seven|eight|nine|ten|twelve|twenty|thirty|fifty|hundred)\\b","I used numbers"],["\\?","I asked a question with a question mark"],["\\b(How many|How much|How long|What time)\\b","My question uses How many, How much, How long or What time"],["\\b([Aa]nswer|[Ss]o|[Tt]otal|equals|is)\\b","I wrote the answer"]],
  starters:["Sam has ","He buys ","How much money ","The answer is ","I solved it by "],
  model:"Sam has ten dollars. He buys a book for six dollars and a pen for one dollar. How much money does Sam have left? The answer is three dollars. I solved it by adding 6 and 1 to get 7, and then I subtracted 7 from 10."},
 {e:"⏰",t:"My day, hour by hour",level:"Step 3 · Schedule writing",
  prompt:"Write at least 6 sentences about your day from morning to night. Use a time in each part of your day (at seven o'clock, at half past eight, at quarter past three…). Use time-order words like First, Then, After that and Finally.",
  minS:6,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["(\\b(o'clock|half past|quarter past|quarter to|\\d{1,2}:\\d{2})\\b[\\s\\S]*){4}","I used at least 4 times"],["\\b(First|Then|After that|Next)\\b","I used First, Then, After that or Next"],["\\b(Finally|At last|In the end)\\b","I used Finally, At last or In the end"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["First, I wake up at ","Then, at ","After that, ","At lunchtime, ","Finally, at "],
  model:"First, I wake up at seven o'clock and brush my teeth. Then, at half past seven, I eat breakfast with my family. After that, I catch the bus at quarter past eight. School starts at 8:30, and my favourite lesson is maths. I come home at quarter to four and play outside for one hour. Finally, at eight o'clock, I read a book and go to sleep."}
]
});
})();
