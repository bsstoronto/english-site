/* ===================== UNIT 2 · SKILL BANKS AND SKILL LIST (original content) ===================== */
(function(){
const u=UNITS.find(x=>x.id==="animals");
const set=k=>u.words.slice(k*10,k*10+10);
const MIX=(...g)=>()=>R(g)();
const box=(t,txt)=>`<div class="qbox" style="margin:0 0 12px;font-size:18px;line-height:1.6;font-weight:400"><b>${t}</b><br>${txt}</div>`;
const NUM=["two","three","four","five","six","seven","eight","nine","ten"];

/* ================= GRAMMAR: PLURALS ================= */
const PL_S=[...["camel","bird","frog","lion","tiger","snake","horse","zebra","monkey","donkey","turtle","shark","whale","seal","rabbit","elephant","kangaroo","parrot","penguin","giraffe","dolphin","owl","eagle","beaver","koala","nest","egg","claw","tusk","feather"].map(w=>[w,w+"s","Most words: just add -s."]),
 ...["fox","box","bus","dish","brush","peach","lunch","glass","bench","bush","finch","ostrich","walrus","octopus"].map(w=>[w,w+"es","Words ending in -s, -x, -sh or -ch: add -es."])];
const PL_IES=[["puppy","puppies"],["bunny","bunnies"],["baby","babies"],["pony","ponies"],["butterfly","butterflies"],["berry","berries"],["city","cities"],["story","stories"],["fly","flies"],["lady","ladies"],["family","families"],["daisy","daisies"],["party","parties"],["cherry","cherries"],["country","countries"]].map(p=>[p[0],p[1],"Consonant + y: change the y to i and add -es."]);
const PL_YS=[["monkey","monkeys"],["donkey","donkeys"],["day","days"],["toy","toys"],["boy","boys"],["key","keys"],["turkey","turkeys"],["jay","jays"]].map(p=>[p[0],p[1],"Vowel + y (ay, ey, oy): just add -s."]);
const PL_VES=[["wolf","wolves"],["leaf","leaves"],["calf","calves"],["half","halves"],["shelf","shelves"],["knife","knives"],["loaf","loaves"],["wife","wives"],["life","lives"],["thief","thieves"],["scarf","scarves"],["hoof","hooves"]].map(p=>[p[0],p[1],"Many words ending in -f or -fe: change to -ves."]);
const SPECIAL=[["mouse","mice"],["goose","geese"],["sheep","sheep"],["deer","deer"],["moose","moose"],["child","children"],["foot","feet"],["tooth","teeth"],["man","men"],["woman","women"],["ox","oxen"],["person","people"]].map(p=>[p[0],p[1],"This is a special word. Learn it by heart."]);
function wrongPl(w,c){return SAMPLE(uniq([w,w+"s",w+"es",w.replace(/y$/,"ies"),w.replace(/y$/,"ys"),w.replace(/fe?$/,"ves"),w.replace(/fe$/,"fs")]).filter(x=>x!==c),2)}
function plQ(list){return ()=>{const p=R(list);const why=`${p[2]} One ${p[0]}, two <b>${p[1]}</b>.`;const n=R(NUM);
  const r=Math.random();
  if(r<.4)return {type:"type",q:`Write the plural:<br><b>one ${p[0]} → ${n} ___</b>`,a:[p[1]],why,hint:p[2]};
  if(r<.8){const w=wrongPl(p[0],p[1]);while(w.length<2)w.push(p[0]+(w.length?"z":"s"));return mcQ(`One ${p[0]}, ${n} ___.`,p[1],w.filter(x=>x!==p[1]),why,p[2])}
  const s=R(list.filter(x=>x!==p));return mcQ(`Which plural is spelled correctly?`,p[1],[wrongPl(p[0],p[1])[0]||p[0]+"s",wrongPl(s[0],s[1])[0]||s[0]+"es"].filter(x=>x!==p[1]),why,p[2])}}
const PLACES=["in the forest","at the zoo","by the river","in the tree","on the farm","in the field","near the pond","on the beach"];
const plFix=()=>{const p=R(PL_S.concat(PL_IES,PL_VES,SPECIAL,PL_YS));const n=R(NUM);const pl=R(PLACES);
  return {type:"type",q:`Fix the mistake. Type the correct plural word:<br><b>There are ${n} ${p[0]} ${pl}.</b>`,a:[p[1]],why:`There are ${n} <b>${p[1]}</b> ${pl}. ${p[2]}`,hint:`More than one ${p[0]}: what is the plural?`}};
const SING=["The camel","A lion","My puppy","The baby elephant","The octopus","This turtle","The fox","The mouse","The sheep","Pip"];
const PLUR=["The camels","Two lions","My puppies","The elephants","The foxes","These turtles","The mice","The geese","The wolves","Three bunnies"];
const COMPL=["thirsty","asleep","in the water","very fast","hungry","hiding in the grass","in the tree","very noisy","tired","happy"];
const isAre=()=>{const pl=Math.random()<.5;let s=R(pl?PLUR:SING);if(s==="The sheep")s="The little sheep";const c=R(COMPL);const ans=pl?"are":"is";
  return mcQ(`Choose <b>is</b> or <b>are</b>:<br><b>${s} ___ ${c}.</b>`,ans,[pl?"is":"are"],`<b>${s}</b> is ${pl?"more than one (plural), so we use <b>are</b>":"just one (singular), so we use <b>is</b>"}.`,"Is it one, or more than one?")};
const sp=()=>{const all=PL_S.concat(PL_IES,PL_VES,SPECIAL);const p=R(all);const asP=Math.random()<.5;const w=asP?p[1]:p[0];
  if(p[0]===p[1])return sp();
  return mcQ(`Is <b>${w}</b> singular (one) or plural (more than one)?`,asP?"plural (more than one)":"singular (one)",[asP?"singular (one)":"plural (more than one)"],`<b>${p[0]}</b> is singular and <b>${p[1]}</b> is plural.`,"Think: one, or more than one?")};

/* ================= GRAMMAR: PAST TENSE ================= */
const REG=[["walk","walked"],["jump","jumped"],["play","played"],["climb","climbed"],["look","looked"],["kick","kicked"],["laugh","laughed"],["help","helped"],["open","opened"],["cook","cooked"],["watch","watched"],["clean","cleaned"],["pull","pulled"],["push","pushed"],["roar","roared"],["hunt","hunted"],["crawl","crawled"],["splash","splashed"],["rest","rested"],["howl","howled"],["paint","painted"],["visit","visited"],["listen","listened"],["follow","followed"]];
const RULES=[["smile","smiled","Ends in e: just add -d."],["wave","waved","Ends in e: just add -d."],["dance","danced","Ends in e: just add -d."],["bake","baked","Ends in e: just add -d."],["live","lived","Ends in e: just add -d."],["chase","chased","Ends in e: just add -d."],["hope","hoped","Ends in e: just add -d."],["race","raced","Ends in e: just add -d."],["hop","hopped","Short word, one vowel, one last consonant: double it and add -ed."],["stop","stopped","Short word, one vowel, one last consonant: double it and add -ed."],["clap","clapped","Short word, one vowel, one last consonant: double it and add -ed."],["hug","hugged","Short word, one vowel, one last consonant: double it and add -ed."],["drop","dropped","Short word, one vowel, one last consonant: double it and add -ed."],["grab","grabbed","Short word, one vowel, one last consonant: double it and add -ed."],["flap","flapped","Short word, one vowel, one last consonant: double it and add -ed."],["trot","trotted","Short word, one vowel, one last consonant: double it and add -ed."],["cry","cried","Consonant + y: change y to i and add -ed."],["carry","carried","Consonant + y: change y to i and add -ed."],["try","tried","Consonant + y: change y to i and add -ed."],["hurry","hurried","Consonant + y: change y to i and add -ed."],["copy","copied","Consonant + y: change y to i and add -ed."],["dry","dried","Consonant + y: change y to i and add -ed."]];
const IRR=[["fly","flew"],["see","saw"],["swim","swam"],["eat","ate"],["run","ran"],["go","went"],["come","came"],["sing","sang"],["drink","drank"],["give","gave"],["take","took"],["sleep","slept"],["find","found"],["catch","caught"],["make","made"],["sit","sat"],["write","wrote"],["get","got"],["have","had"],["tell","told"],["meet","met"],["ride","rode"],["dig","dug"],["hide","hid"],["grow","grew"],["bite","bit"],["fall","fell"],["hold","held"],["know","knew"],["wake","woke"],["feed","fed"],["build","built"],["swing","swung"],["throw","threw"]];
const SUBJ=["the elephants","the birds","we","they","the kangaroos","the monkeys","I","the penguins","the turtles","the foxes"];
const OBJ={walk:"to the river",jump:"over the log",play:"in the park",climb:"the tree",look:"at the clouds",kick:"the ball",laugh:"at the joke",help:"the zookeeper",open:"the box",cook:"dinner",watch:"the stars",clean:"the cage",pull:"the rope",push:"the cart",roar:"loudly",hunt:"for food",crawl:"under the log",splash:"in the water",rest:"in the shade",howl:"at the moon",paint:"a picture",visit:"the zoo",listen:"to the birds",follow:"the path",smile:"at the baby",wave:"hello",dance:"in the rain",bake:"bread",live:"near the sea",chase:"the ball",hope:"for rain",race:"to the tree",hop:"over the rock",stop:"at the river",clap:"loudly",hug:"each other",drop:"the ball",grab:"the rope",flap:"in the wind",trot:"along the path",cry:"at the sad story",carry:"the bags",try:"again",hurry:"home",copy:"the words",dry:"the dishes",fly:"over the sea",see:"a rainbow",swim:"in the lake",eat:"some fruit",run:"to the river",go:"to the forest",come:"home",sing:"a song",drink:"cold water",give:"us a gift",take:"a nap",sleep:"in the den",find:"a shiny shell",catch:"a fish",make:"a nest",sit:"under the tree",write:"a letter",get:"wet",have:"lunch",tell:"a story",meet:"a new friend",ride:"on a boat",dig:"a hole",hide:"behind a rock",grow:"bigger",bite:"the apple",fall:"asleep",hold:"the baby",know:"the way",wake:"up early",feed:"the ducks",build:"a dam",swing:"on the branches",throw:"the ball"};
const pastWrong=(v,c)=>SAMPLE(uniq([v,v+"s",v+"ed",v+v.slice(-1)+"ed",v.replace(/e$/,"")+"ed",v.replace(/y$/,"ied"),v+"d"]).filter(x=>x!==c),2);
function pastQ(list,ruleOf){return ()=>{const v=R(list),s=R(SUBJ);const rule=ruleOf(v);const why=`${v[0]} → <b>${v[1]}</b>. ${rule}`;const o=OBJ[v[0]]?" "+OBJ[v[0]]:"";
  if(Math.random()<.5)return {type:"type",q:`Today ${s} ${v[0]}${o}.<br>Yesterday ${s} ___${o}.`,a:[v[1]],why,hint:rule};
  return mcQ(`Yesterday ${s} ___${o}.<br><span style="color:var(--muted);font-size:16px">(${v[0]})</span>`,v[1],pastWrong(v[0],v[1]),why,rule)}}
const regRule=()=>"Most verbs: add -ed.";
const irrRule=()=>"This is a special (irregular) verb. It does not use -ed. Learn it by heart.";
const pastFix=()=>{const all=REG.concat(RULES.map(x=>[x[0],x[1]]),IRR);const v=R(all);const s=R(["the bear","the monkey","the owl","Pip","the zebra","my cat","the baby turtle","the fox"]);const o=OBJ[v[0]]||R(["at the zoo","in the forest","by the river"]);
  const verb3=v[0]==="have"?"has":/(s|sh|ch|x|o)$/.test(v[0])?v[0]+"es":/[^aeiou]y$/.test(v[0])?v[0].replace(/y$/,"ies"):v[0]+"s";
  return {type:"type",q:`Fix the verb. This happened yesterday, so it must be in the past:<br><b>Yesterday ${s} ${verb3} ${o}.</b><br>Type only the correct verb.`,a:[v[1]],why:`Yesterday ${s} <b>${v[1]}</b> ${o}.`,hint:`What is the past tense of "${v[0]}"?`}};
const INTR=[["walk","walked"],["jump","jumped"],["play","played"],["climb","climbed"],["swim","swam"],["fly","flew"],["run","ran"],["sleep","slept"],["sing","sang"],["hide","hid"],["hop","hopped"],["crawl","crawled"],["splash","splashed"],["roar","roared"],["hunt","hunted"],["rest","rested"],["dance","danced"],["eat","ate"],["dig","dug"],["howl","howled"]];
const SUBJ2=["the monkeys","the birds","the lions","the frogs","the children","the penguins","the wolves","the dolphins"];
const PRES_T=["Every day,","Every morning,","Usually,","Each night,","Every summer,"],PAST_T=["Yesterday,","Last night,","Last week,","Long ago,","Last summer,"];
const tense=()=>{const v=R(INTR),s=R(SUBJ2),pl=R(PLACES);const k=Math.random();
  if(k<.5){const past=Math.random()<.5;const sent=`${past?R(PAST_T):R(PRES_T)} ${s} ${past?v[1]:v[0]} ${pl}.`;
    return mcQ(`Does this sentence tell about the <b>present</b> (it happens now or often) or the <b>past</b> (it already happened)?<br><b>${sent}</b>`,past?"past":"present",[past?"present":"past"],past?`It already happened. Look at the time words and the verb <b>${v[1]}</b>.`:`It happens often. Look at the time words and the verb <b>${v[0]}</b>.`,"Look at the time words at the start.")}
  const past=Math.random()<.5;const tw=past?R(PAST_T):R(PRES_T);
  return mcQ(`Choose the verb that matches the time words:<br><b>${tw} ${s} ___ ${pl}.</b>`,past?v[1]:v[0],[past?v[0]:v[1]],`<b>${tw}</b> tells us it ${past?"already happened, so we use the past: <b>"+v[1]+"</b>":"happens often, so we use the present: <b>"+v[0]+"</b>"}.`,"Do the time words tell about the past or about now?")};
const WSING=["The lion","The baby elephant","I","My cat","The octopus","Pip","She","He","It","The camel","Our teacher"];
const WPLUR=["The lions","We","They","You","The penguins","My cats","The baby turtles","The zebras","Ravi and his aunt"];
const WCOMP=["hungry","very tired","in the water","asleep","happy","under the tree","cold","noisy","at the zoo","excited"];
const wasWere=()=>{const pl=Math.random()<.5;const s=R(pl?WPLUR:WSING);const ans=(pl||s==="You")?"were":"was";const disp=/^(Pip|Ravi|I)\b/.test(s)?s:s.charAt(0).toLowerCase()+s.slice(1);
  return mcQ(`Choose <b>was</b> or <b>were</b>:<br><b>Yesterday, ${disp} ___ ${R(WCOMP)}.</b>`,ans,[ans==="was"?"were":"was"],ans==="was"?`Use <b>was</b> with one person or thing (and with I).`:`Use <b>were</b> with more than one, and with <b>you</b>, <b>we</b> and <b>they</b>.`,"One, or more than one? (Remember: I was, you were.)")};

/* ================= GRAMMAR: SENTENCES (review from Unit 1 with animal sentences) ================= */
const SENT=["Dev saw a tiger in India.","The kangaroo lives in Australia.","Pip met Nanuk in the Arctic.","Mia fed the ducks on Sunday.","Our class visited the Toronto Zoo.","I saw a moose in Canada.","Giant pandas live in China.","Leo has a dog named Biscuit.","The monarch flies to Mexico in autumn.","I read a book about sharks.","Pip flew to Australia.","The camel lives in the Sahara Desert.","Kamal has a big hump.","The elephants walked to the river.","Nanuk is a polar bear.","Ravi helped the baby turtles.","Aunt Leela is a scientist.","Monarch butterflies fly to Mexico.","The joey sleeps in the pouch.","Tembo sprayed water on Pip.","Penguins live in Antarctica.","I saw a whale in the ocean.","The fox hid in its den.","My cat has sharp claws.","Kiko changed colour.","The owl hunts at night.","We visited Green Hill Zoo on Saturday.","The bear sleeps all winter.","Flora the flamingo is pink.","I fed the ducks at the pond.","The cheetah ran very fast.","Sloths live in the rainforest.","The zebra has black and white stripes.","Leo and I watched the monkeys."];
const fix=()=>{const s=R(SENT);return {type:"type",strict:true,q:`Fix this sentence. Add the capital letters and the full stop:<br><b>${breakSentence(s)}</b>`,a:[s],hint:"Capital letter at the start, capitals for names, places and I, and a full stop at the end.",why:`Correct: <b>${s}</b>`}};

/* ================= WRITE YOUR OWN ================= */
const PASTV="\\b(\\w+ed|flew|saw|went|swam|ate|ran|came|found|took|had|was|were|made|got|told|sang|slept|caught|dug|hid|met|fed|built|grew|fell|held|knew|woke|rode|sat|gave|drank|bit|swung|threw|said)\\b";
const D=[CHK.cap,CHK.end,CHK.w4,CHK.I];
const WP=[
 {q:"Write a sentence about your favourite animal. Say where it lives.",checks:D,model:"My favourite animal is the snow leopard, which lives in the mountains."},
 {q:"Write a sentence using <b>were</b>.",checks:[...D,["\\bwere\\b","Uses were"]],model:"The baby turtles were very small."},
 {q:"Write a sentence about two or more baby animals. Use a plural word.",checks:[...D,["\\b\\w+(s|ies|ves)\\b|\\b(mice|geese|sheep|deer|children|teeth|feet)\\b","Uses a plural word"]],model:"The puppies played in the garden."},
 {q:"Write a sentence about what an animal ate. Use the past tense.",checks:[...D,[PASTV,"Uses a past-tense verb"]],model:"The bear caught a fish and ate it."},
 {q:"Write a sentence that uses the word <b>habitat</b>.",checks:[...D,["\\bhabitats?\\b","Uses habitat"]],model:"The ocean is the habitat of the octopus."},
 {q:"Write a sentence about how to look after a pet.",checks:D,model:"You should give your dog fresh water every day."},
 {q:"Write a sentence using <b>hibernate</b>, <b>migrate</b> or <b>camouflage</b>.",checks:[...D,["\\b(hibernat|migrat|camouflag)\\w*","Uses one of the words"]],model:"Some birds migrate south in the winter."},
 {q:"Write a question you would like to ask a scientist about animals.",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"How long can a whale hold its breath?"},
 {q:"Write a sentence about something you saw at a zoo or a farm. Use the past tense.",checks:[...D,[PASTV,"Uses a past-tense verb"]],model:"At the farm, I fed the goats."},
 {q:"Write a sentence using <b>was</b>.",checks:[...D,["\\bwas\\b","Uses was"]],model:"The lion was asleep under the tree."},
 {q:"Write a sentence about an animal and its habitat.",checks:D,model:"Camels live in the hot desert."},
 {q:"Write a sentence using a <b>plural</b> animal word (more than one animal).",checks:[...D,["\\b\\w+(s|ies|ves)\\b|\\b(mice|geese|sheep|deer|children|teeth|feet)\\b","Uses a plural word"]],model:"Three foxes ran into the forest."},
 {q:"Write a sentence about something you did <b>yesterday</b>. Use the past tense.",checks:[...D,[PASTV,"Uses a past-tense verb"]],model:"Yesterday I played football with my brother."},
 {q:"Write a sentence about something an animal did. Use a <b>special</b> past verb like flew, swam, ate or ran.",checks:[...D,["\\b(flew|saw|went|swam|ate|ran|came|found|took|made|caught|dug|hid|slept|sang|grew|fell|built)\\b","Uses a special past-tense verb"]],model:"The duck swam across the pond."},
 {q:"Write a sentence with <b>was</b> or <b>were</b>.",checks:[...D,["\\b(was|were)\\b","Uses was or were"]],model:"The penguins were very noisy."},
 {q:"Write a sentence describing an animal's body. Use a word like fur, feathers, scales, claws or beak.",checks:[...D,["\\b(fur|feathers?|scales?|claws?|beak|fins?|trunk|hump|tusks?|pouch|tail|wings?|shell)\\b","Names a body part"]],model:"The parrot has bright green feathers."},
 {q:"Write a question you would like to ask a zookeeper.",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"What do the giraffes eat every day?"},
 {q:"Write a sentence explaining how one animal survives. Use the word <b>because</b>.",checks:[...D,["\\bbecause\\b","Uses because"]],model:"Polar bears stay warm because they have thick fur."},
 {q:"Write a sentence using the word <b>predator</b> or <b>prey</b>.",checks:[...D,["\\b(predators?|prey)\\b","Uses predator or prey"]],model:"The owl is a predator that hunts mice."},
 {q:"Write an exclaiming sentence about an amazing animal.",checks:[CHK.cap,["!\\s*$","Ends with an exclamation mark"],CHK.w3],model:"Wow, that whale is enormous!"}
];

/* ================= VOCABULARY ================= */
const HOME=[["camel","desert"],["lizard","desert"],["scorpion","desert"],["fennec fox","desert"],["polar bear","Arctic"],["Arctic fox","Arctic"],["walrus","Arctic"],["octopus","ocean"],["whale","ocean"],["shark","ocean"],["sea turtle","ocean"],["lion","grassland"],["zebra","grassland"],["giraffe","grassland"],["cheetah","grassland"],["monkey","rainforest"],["sloth","rainforest"],["toucan","rainforest"],["jaguar","rainforest"],["frog","pond"],["duck","pond"],["dragonfly","pond"]];
const HAB=uniq(HOME.map(x=>x[1]));
const homeQ=()=>{const h=R(HOME);if(Math.random()<.6)return mcQ(`Which habitat is home to the <b>${h[0]}</b>?`,h[1],SAMPLE(HAB.filter(x=>x!==h[1]),3),`The ${h[0]} lives in the <b>${h[1]}</b>.`,"Think: hot or cold? Wet or dry? Land or water?");
  const others=SAMPLE(HOME.filter(x=>x[1]!==h[1]),3).map(x=>x[0]);return mcQ(`Which animal lives in the <b>${h[1]}</b>?`,h[0],others,`The <b>${h[0]}</b> lives in the ${h[1]}.`,"Picture the habitat. Which animal fits there?")};
const BABY=[["elephant","calf"],["cow","calf"],["whale","calf"],["giraffe","calf"],["bear","cub"],["lion","cub"],["tiger","cub"],["fox","cub"],["kangaroo","joey"],["koala","joey"],["hen","chick"],["penguin","chick"],["cat","kitten"],["dog","puppy"],["horse","foal"],["zebra","foal"],["sheep","lamb"],["frog","tadpole"],["duck","duckling"],["goat","kid"],["pig","piglet"],["goose","gosling"]];
const BN=uniq(BABY.map(x=>x[1]));
const babyQ=()=>{const b=R(BABY);if(Math.random()<.6)return mcQ(`What is a baby <b>${b[0]}</b> called?`,b[1],SAMPLE(BN.filter(x=>x!==b[1]),3),`A baby ${b[0]} is called a <b>${b[1]}</b>.`,"Think of the story words: Tembo the calf, the joey in the pouch…");
  const wrong=SAMPLE(BABY.filter(x=>x[1]!==b[1]),3).map(x=>x[0]);return mcQ(`A <b>${b[1]}</b> is the baby of which animal?`,b[0],wrong,`A <b>${b[1]}</b> is a baby ${BABY.filter(x=>x[1]===b[1]).map(x=>x[0]).join(" or ")}.`,"Which animal has babies with this name?")};
const GROUP=[["geese","gaggle"],["kangaroos","mob"],["owls","parliament"],["puppies","litter"],["kittens","litter"],["elephants","herd"],["cows","herd"],["zebras","herd"],["birds","flock"],["sheep","flock"],["wolves","pack"],["fish","school"],["lions","pride"],["bees","swarm"],["ants","colony"],["penguins","colony"],["dolphins","pod"],["whales","pod"],["monkeys","troop"]];
const GN=uniq(GROUP.map(x=>x[1]));
const groupQ=()=>{const g=R(GROUP);return mcQ(`A group of <b>${g[0]}</b> is called a ___.`,g[1],SAMPLE(GN.filter(x=>x!==g[1]),3),`A <b>${g[1]}</b> of ${g[0]}.`,"Some groups have special names. Which one fits?")};
const SOUND=[["lion","roars"],["dog","barks"],["cow","moos"],["snake","hisses"],["bee","buzzes"],["duck","quacks"],["horse","neighs"],["wolf","howls"],["mouse","squeaks"],["owl","hoots"],["pig","oinks"],["sheep","baas"],["frog","croaks"],["elephant","trumpets"],["cat","purrs"],["hen","clucks"]];
const SN=uniq(SOUND.map(x=>x[1]));
const soundQ=()=>{const s=R(SOUND);if(Math.random()<.6)return mcQ(`What sound does a <b>${s[0]}</b> make? A ${s[0]} ___.`,s[1],SAMPLE(SN.filter(x=>x!==s[1]),3),`A ${s[0]} <b>${s[1]}</b>.`,"Say the sound out loud!");
  return mcQ(`Which animal <b>${s[1]}</b>?`,s[0],SAMPLE(SOUND.filter(x=>x!==s),3).map(x=>x[0]),`A <b>${s[0]}</b> ${s[1]}.`,"Imagine the sound.")};
const BODY=[["a black mask and a striped bushy tail","raccoon"],["a big horn on its nose","rhinoceros"],["black-and-white fur and it eats bamboo","panda"],["webbed feet and a flat bill","duck"],["huge antlers","moose"],["orange fur with black stripes","tiger"],["a trunk","elephant"],["a hump","camel"],["a pouch for its baby","kangaroo"],["a hard shell on its back","turtle"],["a big furry mane","lion"],["a curved beak and colourful feathers","parrot"],["fins and gills","shark"],["a very long neck","giraffe"],["black-and-white stripes","zebra"],["eight arms","octopus"],["no legs at all","snake"],["thick white fur","polar bear"],["sharp spines on its back","hedgehog"],["wings made of skin","bat"]];
const bodyQ=()=>{const b=R(BODY);return mcQ(`Which animal has <b>${b[0]}</b>?`,"the "+b[1],SAMPLE(BODY.filter(x=>x!==b),3).map(x=>"the "+x[1]),`The <b>${b[1]}</b> has ${b[0]}.`,"Picture each animal in your head.")};
const OPP=[["big","small"],["fast","slow"],["fierce","gentle"],["hot","cold"],["wet","dry"],["day","night"],["predator","prey"],["loud","quiet"],["rough","smooth"],["heavy","light"],["long","short"],["deep","shallow"],["rare","common"],["asleep","awake"],["safe","dangerous"],["above","below"],["strong","weak"],["young","old"],["full","empty"]];
const SYN=[["big","large"],["tiny","little"],["swift","fast"],["fierce","savage"],["curious","nosy"],["scared","afraid"],["shout","yell"],["look","see"],["hop","jump"],["home","house"],["amazed","surprised"],["protect","guard"],["discover","find"],["sleepy","tired"],["wild","untamed"],["happy","glad"],["rest","relax"],["noisy","loud"]];

/* ================= SPELLING ================= */
const SP=u.spelling.concat([
 {w:"tiger",s:"The tiger has orange and black stripes."},{w:"zebra",s:"The zebra ran across the grass."},{w:"rabbit",s:"The rabbit hid in its burrow.",tip:"Double b: ra-bb-it."},
 {w:"penguin",s:"A penguin cannot fly.",tip:"pen-gu-in. The 'u' is quiet."},{w:"giraffe",s:"The giraffe has a long neck.",tip:"g sounds like j. Double f and an e at the end: gi-ra-ffe."},
 {w:"dolphin",s:"The dolphin jumped out of the water.",tip:"'ph' sounds like 'f': dol-ph-in."},{w:"jungle",s:"Monkeys live in the jungle."},{w:"forest",s:"The fox lives in the forest."},
 {w:"nest",s:"The bird built a nest."},{w:"eagle",s:"The eagle flew high in the sky.",tip:"'ea' says its name: ea-gle."},{w:"octopus",s:"The octopus has eight arms."},
 {w:"insect",s:"A bee is an insect."},{w:"wild",s:"Lions are wild animals."},{w:"claws",s:"The cat has sharp claws.",tip:"'aw' as in saw: cl-aw-s."},{w:"lion",s:"The lion roared loudly."}
]);
const SPP=[{w:"boxes",s:"The zookeeper carried three boxes.",tip:"Ends in x: add -es."},{w:"benches",s:"We sat on the benches.",tip:"Ends in ch: add -es."},{w:"ponies",s:"The ponies ate hay.",tip:"y → ies."},{w:"stories",s:"Grandmother tells animal stories.",tip:"y → ies."},{w:"halves",s:"Cut the apple into halves.",tip:"f → ves."},{w:"loaves",s:"Dad baked two loaves of bread.",tip:"f → ves."},{w:"shelves",s:"The books are on the shelves.",tip:"f → ves."},{w:"women",s:"Two women fed the giraffes.",tip:"Special plural: woman → women."},{w:"people",s:"Many people visit the zoo.",tip:"Special plural: person → people."},{w:"peaches",s:"The monkeys ate the peaches.",tip:"Ends in ch: add -es."},{w:"foxes",s:"Three foxes ran into the forest.",tip:"Ends in x: add -es."},{w:"puppies",s:"The puppies are playing.",tip:"y → ies."},{w:"wolves",s:"The wolves howled at the moon.",tip:"f → ves."},{w:"mice",s:"The mice ate the cheese.",tip:"Special plural: mouse → mice."},{w:"leaves",s:"The leaves fell from the tree.",tip:"f → ves."},{w:"geese",s:"The geese flew south.",tip:"Special plural: goose → geese."},{w:"butterflies",s:"The butterflies landed on the flowers.",tip:"y → ies."},{w:"buses",s:"Two buses went to the zoo.",tip:"Ends in s: add -es."},{w:"babies",s:"The babies are sleeping.",tip:"y → ies."},{w:"teeth",s:"The shark has sharp teeth.",tip:"Special plural: tooth → teeth."},{w:"feet",s:"Ducks have webbed feet.",tip:"Special plural: foot → feet."},{w:"children",s:"The children watched the penguins.",tip:"Special plural: child → children."},{w:"dishes",s:"The zookeeper washed the food dishes.",tip:"Ends in sh: add -es."},{w:"calves",s:"The calves walked with their mothers.",tip:"f → ves."},{w:"bunnies",s:"The bunnies hopped away.",tip:"y → ies."},{w:"monkeys",s:"The monkeys swung in the trees.",tip:"Vowel + y: just add -s."},{w:"lunches",s:"We ate our lunches at the zoo.",tip:"Ends in ch: add -es."},{w:"knives",s:"The cooks used sharp knives.",tip:"fe → ves."},{w:"sheep",s:"The sheep are on the hill.",tip:"Sheep stays the same."},{w:"cherries",s:"The birds ate the cherries.",tip:"y → ies."}];
const CHOOSE=[["tiger","tigre","tyger"],["zebra","zeebra","zebrah"],["squirrel","squirel","squrrel"],["leopard","lepard","leperd"],["cheetah","cheeta","cheetha"],["koala","kowala","koalla"],["beaver","beever","bever"],["parrot","parot","parrott"],["shark","sharc","sharck"],["whale","wale","whail"],["butterfly","buterfly","butterfley"],["animal","aminal","animel"],["elephant","elefant","eliphant"],["giraffe","jiraffe","girafe"],["penguin","pengwin","pengin"],["kangaroo","kangaru","kangeroo"],["dolphin","dolfin","dolphen"],["ocean","oshun","ocian"],["rabbit","rabit","rabbitt"],["turtle","turtel","tirtle"],["monkey","monkee","munkey"],["feather","fether","feathre"],["camel","camle","cammel"],["octopus","octopuss","ocktopus"],["desert","dessert","dezert"],["world","wurld","whorld"],["eagle","eegle","egle"],["insect","insekt","insecd"],["habitat","habbitat","habitate"],["puppies","puppys","puppyes"],["wolves","wolfs","wolfes"],["foxes","foxs","foxies"],["mice","mouses","mices"],["butterflies","butterflys","buterflies"],["leaves","leafs","leafes"]].map(x=>({w:x[0],bad:[x[1],x[2]],tip:(SP.concat(SPP).find(y=>y.w===x[0])||{}).tip||(x[0]==="desert"?"desert (one s) is sandy; dessert (two s) is the sweet food after dinner!":undefined)}));

/* ================= READING ================= */
const DETAIL=[
 ["Sea Otters","Sea otters live in the cold Pacific Ocean. They have the thickest fur of any animal, which keeps them warm. They float on their backs and use rocks to crack open shells. At night, they wrap themselves in seaweed so they don't drift away.",[["What keeps sea otters warm?","Their thick fur",["A layer of ice","Hot water"]],["What do sea otters use to crack open shells?","Rocks",["Their teeth only","Sticks"]],["Why do they wrap themselves in seaweed?","So they don't drift away",["To eat it","To hide from people"]]]],
 ["Snails","A snail carries its shell on its back for its whole life. It moves on one big muscle called a foot. The snail makes slime so it can slide along smoothly. When it is dry or dangerous, the snail hides inside its shell.",[["What is the snail's big muscle called?","A foot",["A fin","A wing"]],["Why does a snail make slime?","So it can slide along smoothly",["To scare birds","To make its shell"]]]],
 ["Hummingbirds","Hummingbirds are the smallest birds in the world. They beat their wings so fast that they make a humming sound. They drink nectar from flowers using their long, thin beaks. They can even fly backwards!",[["Why are they called hummingbirds?","Their fast wings make a humming sound",["They sing songs","They hum at night"]],["What do hummingbirds drink?","Nectar from flowers",["Milk","Salt water"]]]],
 ["The Busy Beaver","Beavers live near rivers and streams. They cut down small trees with their strong front teeth. Then they use sticks and mud to build a dam across the water. A beaver's front teeth never stop growing, so chewing wood keeps them the right size.",[["What do beavers use to cut down trees?","Their strong front teeth",["Their claws","Their tails"]],["What do beavers build across the water?","A dam",["A nest","A bridge of stones"]],["Why is chewing wood good for a beaver's teeth?","It keeps them the right size",["It makes them white","It makes them fall out"]]]],
 ["Owls at Night","Most owls hunt at night. They have huge eyes that help them see in the dark. Their soft feathers let them fly without making a sound, so mice do not hear them coming. An owl cannot move its eyes, so it turns its head instead.",[["When do most owls hunt?","At night",["In the morning","At lunchtime"]],["Why don't mice hear owls coming?","Owls fly without making a sound",["Owls are very small","Mice cannot hear"]],["What does an owl do because it cannot move its eyes?","It turns its head",["It closes its eyes","It flies away"]]]],
 ["The Giant Panda","Giant pandas live in the mountain forests of China. They are black and white and very round. Pandas eat bamboo for many hours every day. A newborn panda is pink, tiny and about the size of a stick of butter.",[["Where do giant pandas live?","In the mountain forests of China",["In the Sahara","In the Arctic"]],["What do pandas eat for many hours every day?","Bamboo",["Fish","Grass"]],["What colour is a newborn panda?","Pink",["Black and white","Brown"]]]],
 ["Penguin Dads","Emperor penguins live in Antarctica. After the mother lays an egg, the father holds it on his feet under a warm fold of skin. He keeps it warm for about two months while the mother goes to the sea to eat. The dads huddle together to stay warm in the freezing wind.",[["Who keeps the egg warm?","The father penguin",["The mother penguin","A seal"]],["Where does the father hold the egg?","On his feet",["In a nest","In the water"]],["Why do the dads huddle together?","To stay warm",["To play a game","To catch fish"]]]],
 ["Honeybees","Honeybees live together in a hive. Worker bees fly from flower to flower to collect a sweet juice called nectar. They turn the nectar into honey. When a bee finds good flowers, it does a special dance to tell the other bees where to go.",[["What is the sweet juice in flowers called?","Nectar",["Honey","Pollen"]],["Where do honeybees live?","In a hive",["In a burrow","In a den"]],["How does a bee tell others where the flowers are?","It does a special dance",["It sings","It draws a map"]]]],
 ["The Cheetah","The cheetah is the fastest land animal in the world. It can run as fast as a car on a highway, but only for a short time. Cheetahs have spots that help them hide in the long, dry grass. They hunt in the daytime, when lions are often resting.",[["What is special about the cheetah?","It is the fastest land animal",["It is the biggest cat","It can fly"]],["How long can a cheetah run very fast?","Only for a short time",["All day","All night"]],["What helps cheetahs hide?","Their spots",["Their long tails","Their loud roar"]]]],
 ["The Blue Whale","The blue whale is the biggest animal that has ever lived. It is longer than two buses. Its heart is about the size of a small car! But blue whales eat tiny animals called krill. They gulp huge mouthfuls of water and krill, then push the water out.",[["What is the blue whale's heart about the size of?","A small car",["A football","A house"]],["What do blue whales eat?","Tiny animals called krill",["Big sharks","Seaweed only"]],["How long is a blue whale?","Longer than two buses",["About as long as a pencil","As long as a cat"]]]],
 ["The Monarch Butterfly","Monarch butterflies are orange and black. Their caterpillars eat only one kind of plant, called milkweed. Every autumn, millions of monarchs fly from Canada and the United States to Mexico. They rest together in the same forests every year.",[["What colours are monarch butterflies?","Orange and black",["Blue and white","Green and yellow"]],["What do monarch caterpillars eat?","Milkweed",["Grass","Leaves of any tree"]],["Where do monarchs fly in autumn?","To Mexico",["To the Arctic","To Africa"]]]],
 ["Koalas","Koalas live in Australia. They spend almost all their lives in eucalyptus trees and eat the leaves. Koalas sleep for up to 20 hours a day. Many people call them koala bears, but they are not bears at all. Like kangaroos, they carry their babies in a pouch.",[["Where do koalas live?","In Australia",["In Canada","In China"]],["Are koalas bears?","No",["Yes"]],["How are koalas like kangaroos?","They carry their babies in a pouch",["They hop","They live in the ocean"]]]],
 ["Clever Crows","Crows are some of the cleverest birds in the world. Some crows use sticks as tools to pull insects out of holes in trees. Crows can also remember people's faces for years. If a person is kind to them, they may even bring small gifts like shiny buttons!",[["What do some crows use sticks for?","To pull insects out of holes",["To build a fire","To scratch their backs"]],["What can crows remember for years?","People's faces",["Songs","Phone numbers"]],["What might a crow bring to a kind person?","Small gifts like shiny buttons",["Fish","Flowers"]]]]
];
const detail=()=>{const p=R(DETAIL),x=R(p[2]);return mcQ(`${box(p[0],p[1])}${x[0]}`,x[1],x[2],`Look back at the text: the answer is there.`,"Read the text again and find the words.",{say:p[1]+" "+x[0]})};
const MAIN=[
 ["Sloths move very slowly. They hang upside down in trees for most of the day. They sleep for many hours. They only climb down to the ground about once a week.","Sloths are very slow, sleepy tree animals.",["Trees are tall.","The ground is hard."]],
 ["Many animals live together in groups. Elephants live in herds. Wolves hunt in packs. Fish swim in schools. Living in a group helps animals stay safe.","Many animals live in groups to stay safe.",["Wolves hunt.","Fish swim."]],
 ["Baby animals need care. Mother birds bring worms to their chicks. Kangaroo mothers carry joeys in their pouches. Elephant families protect their calves.","Baby animals are cared for by their families.",["Birds eat worms.","Pouches are warm."]],
 ["Some animals can change colour. Arctic foxes turn white in winter. Some octopuses change colour in seconds. Chameleons change colour with their mood and temperature.","Some animals can change colour.",["Foxes are white.","Octopuses are clever."]],
 ["Dolphins are very clever animals. They talk to each other with clicks and whistles. They can learn tricks. They work together to catch fish.","Dolphins are clever animals.",["Dolphins swim.","Fish are food."]],
 ["Animals use their senses in amazing ways. Dogs have a very strong sense of smell. Owls can hear tiny sounds in the dark. Eagles can see a mouse from high in the sky.","Animals have amazing senses.",["Dogs like walks.","Eagles fly high."]],
 ["Animals can help keep nature healthy. Bees carry pollen to flowers. Birds spread seeds. Earthworms make the soil rich for plants.","Animals help keep nature healthy.",["Worms are long.","Flowers are pretty."]],
 ["Some animals sleep through the winter. Bears rest in dens. Hedgehogs curl up in nests of leaves. Some frogs even freeze and then thaw in spring.","Some animals sleep through the winter.",["Bears live in dens.","Spring is warm."]],
 ["Animals have different kinds of homes. Birds build nests in trees. Rabbits dig burrows underground. Beavers build lodges in ponds.","Animals have different kinds of homes.",["Rabbits dig.","Ponds have water."]],
 ["Many sea animals are in danger from plastic. Turtles mistake bags for jellyfish. Seabirds feed bits of plastic to their chicks. We can help by using less plastic.","Plastic is dangerous for sea animals.",["Turtles swim.","Birds have chicks."]],
 ["Cheetahs are built for speed. They have long legs and a light body. Their long tail helps them balance when they turn. They can run faster than any other land animal.","Cheetahs are built for speed.",["Cheetahs have tails.","Legs help you walk."]],
 ["Zoos and wildlife parks can help animals. They care for animals that are hurt. They help rare animals have babies. They teach visitors why animals need protecting.","Zoos and wildlife parks can help animals.",["Visitors buy tickets.","Babies are small."]],
 ["Camels have long eyelashes to keep out sand. Their wide feet do not sink into the sand. Their humps store fat for energy. They can go a long time without water.","Camels are well suited to life in the desert.",["Camels have long eyelashes.","Sand is very hot."]],
 ["Dogs help people in many ways. Some dogs guide people who cannot see. Some dogs help find people who are lost. Others work on farms to look after sheep.","Dogs help people in many ways.",["Some dogs live on farms.","Sheep are fluffy."]],
 ["Bees are very busy insects. They collect nectar from flowers to make honey. While they do this, they carry pollen from one flower to another, which helps plants grow fruit.","Bees are busy and helpful insects.",["Honey is sticky.","Flowers are colourful."]],
 ["Many animals live in the ocean. Tiny shrimp swim near the surface. Colourful fish live on coral reefs. Giant whales travel through the deep, dark water.","Many different animals live in the ocean.",["Whales are giant.","Coral reefs are colourful."]],
 ["Sea turtles are in danger. Plastic bags in the sea look like jellyfish, and turtles try to eat them. Bright lights on beaches confuse the babies. People are working hard to help them.","Sea turtles are in danger, and people are trying to help.",["Jellyfish live in the sea.","Beaches have bright lights."]],
 ["Penguins are birds, but they cannot fly. Instead, they are amazing swimmers. Their wings work like flippers, and their smooth bodies glide through the water.","Penguins cannot fly, but they swim very well.",["Penguins have wings.","Water is cold."]],
 ["A spider's web is a clever trap. The spider spins sticky silk between branches. When an insect flies into the web, it gets stuck. Then the spider comes to eat it.","A spider's web is a clever trap for insects.",["Branches are made of wood.","Insects can fly."]],
 ["Some animals sleep in the day and wake up at night. Owls, bats and foxes come out in the dark to find food. These animals are called nocturnal animals.","Nocturnal animals are awake at night.",["Bats are animals.","It is dark at night."]],
 ["Elephants are very caring animals. They live in family groups led by the oldest female. The adults protect the babies, and the whole herd helps if one elephant is hurt.","Elephants are caring animals that look after each other.",["Elephants are big and grey.","The oldest female is the leader."]],
 ["Frogs change a lot as they grow. They start as tiny eggs in a pond. The eggs hatch into tadpoles with tails. Slowly, the tadpoles grow legs and lose their tails, and become frogs.","Frogs change a lot as they grow.",["Ponds have water.","Tadpoles have tails."]],
 ["Pets need a lot of care. They need fresh food and water every day. They need a safe, clean place to sleep. They also need exercise, love and visits to the vet.","Pets need a lot of care.",["Vets are doctors for animals.","Water is important."]],
 ["The Arctic is one of the coldest places on Earth. The sea freezes into ice. Snow covers the land for most of the year. In winter, the sun does not rise for weeks.","The Arctic is a very cold place.",["The sun is hot.","Snow is white."]]
];
const mainIdea=()=>{const m=R(MAIN);return mcQ(`${box("Read",m[0])}What is the <b>main idea</b>? (What is it mostly about?)`,m[1],m[2],`The main idea is what the whole text is about: <b>${m[1]}</b>`,"Which answer fits ALL the sentences, not just one?",{say:m[0]})};
const FACTS=["A baby elephant is called a calf.","Bats are mammals.","Snakes have no legs.","Kangaroos live in Australia.","An insect has six legs.","Sharks are fish.","Owls hunt at night.","Penguins cannot fly.","A spider has eight legs.","Penguins live in Antarctica.","A baby kangaroo is called a joey.","Camels store fat in their humps.","Whales breathe air.","The cheetah is the fastest land animal.","Bees make honey.","Frogs start life as tadpoles.","An octopus has eight arms.","Polar bears live in the Arctic.","Some birds migrate in winter.","Fish breathe with gills.","Elephants are mammals.","A group of lions is called a pride.","Monarch butterflies fly to Mexico."];
const OPIN=["Tigers are cooler than lions.","Frogs are slimy and gross.","Pandas are the best animals at the zoo.","Hamsters are the easiest pets.","Giraffes look funny.","Rabbits are cuter than guinea pigs.","Sharks are the scariest animals.","Bird songs are the nicest sounds.","Pandas are the cutest animals.","Snakes are scary.","Dogs make better pets than cats.","Penguins are the funniest birds.","Lions are the most beautiful animals.","Going to the zoo is the best day out.","Spiders are disgusting.","Parrots are more fun than fish.","Elephants are the smartest animals.","Horses are boring.","Butterflies are the prettiest insects.","Monkeys are the best animals to watch.","Owls are more interesting than eagles.","Cats are lazy."];
const factOp=()=>{const f=Math.random()<.5;const s=f?R(FACTS):R(OPIN);return mcQ(`Is this a <b>fact</b> or an <b>opinion</b>?<br><b>${s}</b>`,f?"Fact":"Opinion",[f?"Opinion":"Fact"],f?"A <b>fact</b> can be checked in a book or by a scientist, and it is true for everyone.":"An <b>opinion</b> is what someone thinks or feels. Other people may think differently.","Could you check it in a science book? Or do people feel differently about it?")};
const SEQ=[["A frog lays eggs in a pond","The eggs hatch into tadpoles","The tadpoles grow legs","The young frog leaves the water"],["A butterfly lays an egg on a leaf","A caterpillar hatches and eats leaves","The caterpillar makes a chrysalis","A butterfly comes out"],["A hen lays an egg","The chick grows inside the egg","The chick hatches","The chick grows into a hen"],["The mother turtle lays eggs in the sand","The eggs stay warm for about two months","The baby turtles hatch","The babies crawl to the sea"],["Pip leaves the bird shop","Pip meets Kamal the camel","Pip meets Nanuk the polar bear","Pip flies home"],["The bear eats a lot in autumn","The bear goes into her den","The bear sleeps all winter","The bear wakes up in spring"],["The beaver cuts down small trees","The beaver drags the sticks to the river","The beaver piles up sticks and mud","The dam holds back the water"],["Kiko wishes to be pink","Kiko tries to feel nothing","Kiko helps the baby bird","Kiko is proud of his colours"],["The bee finds a flower","The bee collects nectar","The bee flies back to the hive","The bees make honey"],["The sun helps the grass grow","The zebra eats the grass","The lion hunts the zebra"]];
const order=()=>{const s=R(SEQ),t=R(["first","last","next"]);
  if(t==="first")return mcQ(`What happens <b>FIRST</b>?`,s[0],SAMPLE(s.slice(1),2),`Order: ${s.join(" → ")}`,"What must happen before everything else?");
  if(t==="last")return mcQ(`What happens <b>LAST</b>?`,s[s.length-1],SAMPLE(s.slice(0,-1),2),`Order: ${s.join(" → ")}`,"What happens at the very end?");
  const k=Math.floor(Math.random()*(s.length-1));return mcQ(`What happens right <b>AFTER</b> this?<br><b>${s[k]}</b>`,s[k+1],SAMPLE(s.filter((_,i)=>i!==k&&i!==k+1),Math.min(2,s.length-2)),`Order: ${s.join(" → ")}`,"What is the very next step?")};
const CE=[["Because the night was very cold, the puppies curled up together.","the night was very cold","the puppies curled up together"],["The baby turtles turned the wrong way because the hotel lights were too bright.","the hotel lights were too bright","the baby turtles turned the wrong way"],["The pond froze, so the ducks flew south.","the pond froze","the ducks flew south"],["Because Pip was shivering, Nanuk told him to fly somewhere warmer.","Pip was shivering","Nanuk told him to fly somewhere warmer"],["The monkey dropped its banana because a loud noise scared it.","a loud noise scared it","the monkey dropped its banana"],["It rained for many days, so the river flooded.","it rained for many days","the river flooded"],["Because the zebra heard a lion, it ran away.","the zebra heard a lion","it ran away"],["The bird built a nest, so it had a safe place for its eggs.","the bird built a nest","it had a safe place for its eggs"],["Kiko felt sorry for the baby bird, so his skin turned brown.","Kiko felt sorry for the baby bird","his skin turned brown"],["The camel could not find water, so it used the fat in its hump.","the camel could not find water","it used the fat in its hump"],["Because the cat was hungry, it meowed loudly.","the cat was hungry","it meowed loudly"],["The manager turned off the lights, so the turtles found the sea.","the manager turned off the lights","the turtles found the sea"],["Because winter was coming, the squirrel buried acorns.","winter was coming","the squirrel buried acorns"],["The dog rolled in the mud, so it needed a bath.","the dog rolled in the mud","it needed a bath"],["Because the snow melted, the Arctic fox's coat turned brown.","the snow melted","the Arctic fox's coat turned brown"],["The elephant was thirsty, so it walked to the river.","the elephant was thirsty","it walked to the river"]];
const cause=()=>{const c=R(CE),other=R(CE.filter(x=>x!==c));const askCause=Math.random()<.5;
  return mcQ(`${box("Read",c[0])}What is the <b>${askCause?"cause":"effect"}</b>? <span style="color:var(--muted);font-size:15px">(${askCause?"WHY it happened":"WHAT happened"})</span>`,askCause?c[1]:c[2],[askCause?c[2]:c[1],askCause?other[1]:other[2]],`Cause (why): <b>${c[1]}</b>. Effect (what happened): <b>${c[2]}</b>.`,"Look for the words because and so. The cause comes after because, and the effect comes after so.",{say:c[0]})};

/* ================= THINKING ================= */
const PUZ=[
 {q:"🧩 Riddle: I have a very long neck and spots, and I eat leaves from tall trees. Who am I?",o:["A giraffe","A zebra","A camel"],a:"A giraffe",why:"Giraffes have long necks and spotted coats."},
 {q:"🧩 Riddle: I have black-and-white fur, and I eat bamboo all day. Who am I?",o:["A panda","A skunk","A penguin"],a:"A panda",why:"Giant pandas eat bamboo."},
 {q:"🧩 Riddle: I hang upside down to sleep, and I fly at night. Who am I?",o:["A bat","An owl","A parrot"],a:"A bat",why:"Bats sleep upside down and are nocturnal."},
 {q:"🧩 Riddle: I have a pouch, but I am not a kangaroo. I eat eucalyptus leaves. Who am I?",o:["A koala","A panda","A sloth"],a:"A koala",why:"Koalas carry their babies in a pouch, like kangaroos."},
 {q:"🧩 Riddle: I have a big furry mane and a loud roar. Who am I?",o:["A lion","A tiger","A bear"],a:"A lion",why:"Male lions have big manes."},
 {q:"🧩 Riddle: I was a caterpillar, then I made a chrysalis, and now I have wings. Who am I?",o:["A butterfly","A bee","A bird"],a:"A butterfly",why:"This is the butterfly's life cycle."},
 {q:"🧩 Riddle: I start life as a tadpole in a pond. Who am I?",o:["A frog","A fish","A duck"],a:"A frog",why:"Frogs begin as tadpoles."},
 {q:"🐝 A bee is buzzing near you at a picnic. What should you do?",o:["Stay calm and move away slowly","Swat it hard","Scream and wave your arms"],a:"Stay calm and move away slowly",why:"Bees usually only sting when they feel scared."},
 {q:"🐶 You find a lost puppy wearing a collar with a phone number. What should you do?",o:["Tell a grown-up so they can call the number","Take it home and keep it","Ignore it"],a:"Tell a grown-up so they can call the number",why:"The owner is probably looking for it."},
 {q:"🦆 Why should we not feed bread to ducks?",o:["Bread is not healthy food for them","Ducks cannot see bread","Bread makes them fly too fast"],a:"Bread is not healthy food for them",why:"Bread fills ducks up without giving them the food they need. Seeds or peas are better."},
 {q:"🥚 Which animal lays eggs?",o:["A hen","A cow","A dog"],a:"A hen",why:"Birds, like hens, lay eggs."},
 {q:"🐟 Which animal breathes underwater with gills?",o:["A fish","A whale","A dolphin"],a:"A fish",why:"Fish have gills. Whales and dolphins breathe air."},
 {q:"🦆 What helps a duck swim well?",o:["Its webbed feet","Its beak","Its eyes"],a:"Its webbed feet",why:"Webbed feet push through water like paddles."},
 {q:"🦎 Why do some animals have camouflage?",o:["To hide from predators or sneak up on prey","To look pretty for people","To keep warm"],a:"To hide from predators or sneak up on prey",why:"Blending in helps animals survive."},
 {q:"🐳 Which is the largest animal that has ever lived?",o:["The blue whale","The elephant","The dinosaur T. rex"],a:"The blue whale",why:"Blue whales are even bigger than the biggest dinosaurs."},
 {q:"🦇 Which animal is nocturnal (awake at night)?",o:["A bat","An eagle","A butterfly"],a:"A bat",why:"Bats sleep in the day and hunt at night."},
 {q:"🐸 Which animal can live both in water and on land?",o:["A frog","A fish","A camel"],a:"A frog",why:"Frogs are amphibians: they live in water when young and on land too."},
 {q:"🐼 Why is it important to protect endangered animals?",o:["So they do not disappear forever","Because they are expensive","So zoos can sell them"],a:"So they do not disappear forever",why:"Once an animal is extinct, it is gone forever."},
 {q:"🐢 A turtle is slowly crossing a busy road. What is the best thing to do?",o:["Tell a grown-up who can help it safely","Run into the road","Throw things at it"],a:"Tell a grown-up who can help it safely",why:"Never go into a road yourself. A grown-up can help safely."},
 {q:"🦷 Why do lions have sharp teeth?",o:["To catch and eat meat","To eat grass","To look scary for photos"],a:"To catch and eat meat",why:"Lions are carnivores: they eat meat."},
 {q:"🧩 Riddle: I have a long trunk and big ears, but I am not a tree. Who am I?",o:["An elephant","A giraffe","A mouse"],a:"An elephant",why:"A trunk and big ears: an elephant!"},
 {q:"🧩 Riddle: I carry my house on my back and move very slowly. Who am I?",o:["A snail","A rabbit","An eagle"],a:"A snail",why:"A snail's shell is its home, and it moves slowly."},
 {q:"🧩 Riddle: I have black-and-white stripes and I look like a horse. Who am I?",o:["A zebra","A tiger","A panda"],a:"A zebra",why:"Stripes and a horse shape: a zebra."},
 {q:"🧩 Riddle: I have eight legs and I spin a web. Who am I?",o:["A spider","An ant","A crab"],a:"A spider",why:"Spiders have eight legs and spin webs."},
 {q:"🧩 Riddle: I am a bird, but I cannot fly. I swim in icy water. Who am I?",o:["A penguin","A parrot","An owl"],a:"A penguin",why:"Penguins cannot fly but are great swimmers."},
 {q:"🐕 You see a dog you don't know in the park. What should you do?",o:["Ask its owner before you touch it","Run up and hug it","Pull its tail"],a:"Ask its owner before you touch it",why:"Always ask the owner first. Even friendly-looking dogs can get scared."},
 {q:"🦝 You see a wild animal, like a raccoon, near your home. What should you do?",o:["Stay away and tell a grown-up","Try to pick it up","Give it your sandwich"],a:"Stay away and tell a grown-up",why:"Wild animals can bite and carry germs. Never touch or feed them."},
 {q:"🐹 Your class hamster's water bottle is empty. What should you do?",o:["Tell the teacher so it can be filled","Ignore it","Give it juice"],a:"Tell the teacher so it can be filled",why:"Pets need fresh water every day."},
 {q:"🐦 You find a baby bird on the ground. What is the best thing to do?",o:["Tell a grown-up and don't take it home","Put it in your pocket","Feed it bread"],a:"Tell a grown-up and don't take it home",why:"A grown-up can check if it needs help. Its parents are often close by."},
 {q:"🌊 Why is it bad to throw plastic bags into the sea?",o:["Sea animals can eat them and get sick","They make the water warm","Fish like to play with them"],a:"Sea animals can eat them and get sick",why:"Turtles think plastic bags are jellyfish and try to eat them."},
 {q:"🦒 Why does a giraffe have such a long neck?",o:["To reach leaves high in the trees","To see the ocean","To swim"],a:"To reach leaves high in the trees",why:"A long neck lets giraffes eat leaves other animals cannot reach."},
 {q:"🐧 Polar bears and penguins: do they meet in the wild?",o:["No: polar bears live in the north and penguins in the south","Yes, every day","Only in summer"],a:"No: polar bears live in the north and penguins in the south",why:"The Arctic is at the top of the world, and Antarctica is at the bottom."},
 {q:"🐆 A cheetah is very fast but gets tired quickly. When is the best time for it to start chasing?",o:["When it is very close to its prey","From very far away","After it has eaten"],a:"When it is very close to its prey",why:"Cheetahs creep close first, because they can only run fast for a short time."},
 {q:"🐫 Which animal would be BEST at living in the desert?",o:["A camel","A penguin","A dolphin"],a:"A camel",why:"Camels can survive with very little water."},
 {q:"🌙 Which animal is MOST likely to be awake at midnight?",o:["An owl","A butterfly","A chicken"],a:"An owl",why:"Owls are nocturnal: they are awake at night."},
 {q:"🐋 A whale lives in the ocean. Is a whale a fish?",o:["No, it is a mammal that breathes air","Yes, it is a big fish"],a:"No, it is a mammal that breathes air",why:"Whales breathe air and feed their babies milk, so they are mammals."},
 {q:"🍂 It is autumn. A squirrel is burying lots of nuts. Why?",o:["To have food in winter","To grow new trees on purpose","Because it is bored"],a:"To have food in winter",why:"Food is hard to find in winter, so squirrels save nuts in autumn."},
 {q:"🦎 Which animal is LEAST likely to be seen in the snow?",o:["A lizard","An Arctic fox","A polar bear"],a:"A lizard",why:"Lizards need warmth from the sun. Arctic foxes and polar bears live in the snow."}
];
const LEGS=[["bird",2],["duck",2],["hen",2],["cat",4],["dog",4],["horse",4],["cow",4],["ant",6],["bee",6],["beetle",6],["spider",8],["snake",0]];
const pl=(n,w)=>n===1?w:(w==="mouse"?"mice":w.endsWith("ch")?w+"es":w+"s");
const maths=()=>{const t=R(["legs1","legs2","feed","group","eggs"]);let q,ans,why;
  if(t==="legs1"){const a=R(LEGS.filter(x=>x[1])),n=2+Math.floor(Math.random()*4);ans=a[1]*n;q=`A ${a[0]} has ${a[1]} legs. How many legs do ${n} ${pl(n,a[0])} have?`;why=`${n} × ${a[1]} = ${ans}.`}
  else if(t==="legs2"){const a=R(LEGS.filter(x=>x[1]===2)),b=R(LEGS.filter(x=>x[1]===4)),n=1+Math.floor(Math.random()*3),m=1+Math.floor(Math.random()*3);ans=n*2+m*4;q=`On a farm there ${n===1?"is":"are"} ${n} ${pl(n,a[0])} and ${m} ${pl(m,b[0])}. How many legs are there altogether?`;why=`${n} × 2 = ${n*2} and ${m} × 4 = ${m*4}. ${n*2} + ${m*4} = ${ans}.`}
  else if(t==="feed"){const k=2+Math.floor(Math.random()*4),p=2+Math.floor(Math.random()*4);ans=p;q=`A zookeeper has ${k*p} fish. She gives ${k} fish to each penguin. How many penguins get fish?`;why=`${k*p} ÷ ${k} = ${p}, because ${p} × ${k} = ${k*p}.`}
  else if(t==="group"){const a=3+Math.floor(Math.random()*8),b=2+Math.floor(Math.random()*8);ans=a+b;q=`A herd has ${a} elephants. ${b} more elephants join the herd. How many elephants are in the herd now?`;why=`${a} + ${b} = ${ans}.`}
  else{const a=6+Math.floor(Math.random()*10),b=1+Math.floor(Math.random()*(a-2));ans=a-b;q=`A turtle laid ${a} eggs. ${b} eggs have hatched. How many eggs have not hatched yet?`;why=`${a} − ${b} = ${ans}.`}
  const wr=uniq([ans+1,ans-1,ans+2,ans*2,ans+4].filter(x=>x>=0&&x!==ans)).slice(0,3);
  return mcQ("🔢 "+q,String(ans),SAMPLE(wr,2).map(String),why,"Draw it, or count in groups.")};
const CLASS={mammal:["elephant","camel","polar bear","kangaroo","whale","dolphin","bat","lion","monkey","koala","zebra","giraffe"],bird:["penguin","eagle","parrot","owl","ostrich","hummingbird","duck","flamingo"],fish:["shark","goldfish","salmon","tuna","clownfish"],reptile:["snake","lizard","crocodile","turtle","chameleon"],amphibian:["frog","toad","salamander"],insect:["ant","bee","butterfly","beetle","ladybug","grasshopper"]};
const CDESC={mammal:"Mammals have hair or fur, breathe air and feed their babies milk.",bird:"Birds have feathers, a beak and lay eggs.",fish:"Fish live in water, breathe with gills and have fins.",reptile:"Reptiles have dry, scaly skin and most lay eggs on land.",amphibian:"Amphibians start life in water and can live on land too. They have smooth, wet skin.",insect:"Insects have six legs and three body parts."};
const classify=()=>{const k=R(Object.keys(CLASS)),a=R(CLASS[k]);
  if(Math.random()<.6)return mcQ(`What kind of animal is a <b>${a}</b>?`,k,SAMPLE(Object.keys(CLASS).filter(x=>x!==k),2),`A ${a} is a <b>${k}</b>. ${CDESC[k]}`,"Think: fur? feathers? scales? gills? six legs?");
  const wrong=SAMPLE(Object.keys(CLASS).filter(x=>x!==k),2).map(x=>R(CLASS[x]));return mcQ(`Which animal is a <b>${k}</b>?`,a,wrong,`The <b>${a}</b> is a ${k}. ${CDESC[k]}`,CDESC[k])};
const odd=()=>{const ks=Object.keys(CLASS);const k=R(ks.filter(x=>CLASS[x].length>=4)),k2=R(ks.filter(x=>x!==k));const three=SAMPLE(CLASS[k],3),o=R(CLASS[k2]);
  return mcQ(`🤔 Which animal does NOT belong?`,o,three,`${three.join(", ")} are all ${k}s. The <b>${o}</b> is a ${k2}.`,"Find what three of them have in common: fur, feathers, scales, gills or six legs?")};
const CHAIN=[
 {q:"Food chain: sun → leaves → ___ → lion",a:"giraffe",o:["shark","owl"],why:"Giraffes eat leaves, and lions can hunt giraffes."},
 {q:"Food chain: sun → grass → zebra → ___",a:"lion",o:["grass","rabbit"],why:"The lion hunts the zebra."},
 {q:"Food chain: sun → seaweed → sea urchin → ___",a:"sea otter",o:["cow","eagle"],why:"Sea otters crack open sea urchins and eat them."},
 {q:"Food chain: sun → grass → mouse → ___",a:"snake",o:["carrot","butterfly"],why:"Many snakes eat mice."},
 {q:"Food chain: sun → nuts → squirrel → ___",a:"fox",o:["leaf","worm"],why:"Foxes hunt squirrels."},
 {q:"Which animal is a plant-eater (a herbivore)?",a:"a zebra",o:["a lion","a shark"],why:"Herbivores eat only plants. Zebras eat grass."},
 {q:"Which animal is a meat-eater (a carnivore)?",a:"a lion",o:["a cow","a rabbit"],why:"Carnivores eat other animals."},
 {q:"Bears eat berries AND fish. An animal that eats both plants and animals is called…",a:"an omnivore",o:["a herbivore","a carnivore"],why:"Omnivores eat both plants and animals. People are often omnivores too!"},
 {q:"Why do food chains start with a plant?",a:"Plants make their own food using sunlight",o:["Plants are the biggest living things","Animals do not like meat"],why:"Animals cannot make their own food, but plants can."},
 {q:"Which animal is at the TOP of this chain: grass → rabbit → fox?",a:"the fox",o:["the rabbit","the grass"],why:"Nothing in this chain eats the fox."},
 {q:"If there were no grass, what would happen to the zebras?",a:"They would not have enough food",o:["They would grow bigger","Nothing would change"],why:"Zebras depend on grass for food."},
 {q:"Which animal eats only plants?",a:"a panda",o:["an owl","a shark"],why:"Pandas eat bamboo, a plant."},
 {q:"Food chain: sun → grass → ___ → lion",a:"zebra",o:["shark","acorn"],why:"The zebra eats grass, and the lion eats the zebra."},
 {q:"Food chain: sun → grass → ___ → fox",a:"rabbit",o:["whale","eagle"],why:"Rabbits eat grass, and foxes hunt rabbits."},
 {q:"Food chain: sun → seeds → ___ → owl",a:"mouse",o:["lion","fish"],why:"Mice eat seeds, and owls hunt mice."},
 {q:"Food chain: sun → leaves → ___ → bird",a:"caterpillar",o:["zebra","seal"],why:"Caterpillars eat leaves, and birds eat caterpillars."},
 {q:"Food chain: sun → tiny sea plants → small fish → ___ → polar bear",a:"seal",o:["grass","mouse"],why:"Seals eat fish, and polar bears hunt seals."},
 {q:"Food chain: sun → acorns → ___ → hawk",a:"squirrel",o:["shark","cow"],why:"Squirrels eat acorns, and hawks hunt squirrels."},
 {q:"Food chain: sun → ___ → zebra → lion",a:"grass",o:["fish","mouse"],why:"Zebras eat grass. Plants are at the start of food chains."},
 {q:"Food chain: sun → grass → rabbit → ___",a:"fox",o:["flower","caterpillar"],why:"A fox hunts rabbits. It is the predator at the end of this chain."},
 {q:"Food chain: sun → leaves → grasshopper → frog → ___",a:"snake",o:["leaf","seed"],why:"Snakes eat frogs."},
 {q:"What gives energy to the plants at the start of every food chain?",a:"the sun",o:["the moon","the lion"],why:"Plants use sunlight to make their food."},
 {q:"In the chain grass → zebra → lion, which one is the PREY?",a:"the zebra",o:["the lion","the sun"],why:"The zebra is hunted by the lion, so it is the prey."},
 {q:"In the chain seeds → mouse → owl, which one is the PREDATOR?",a:"the owl",o:["the mouse","the seeds"],why:"The owl hunts the mouse, so it is the predator."},
 {q:"In a food chain, what do the arrows (→) mean?",a:"is eaten by",o:["is bigger than","lives with"],why:"grass → zebra means grass is eaten by the zebra."},
 {q:"If all the rabbits disappeared, what would happen to the foxes that eat them?",a:"They would have less food",o:["They would have more food","Nothing would change"],why:"Every living thing in a food chain is connected."}
];
const ANA=[["Kangaroo is to hop as snake is to ___.","slither",["fly","gallop"]],["Bird is to fly as fish is to ___.","swim",["run","crawl"]],["Cow is to moo as duck is to ___.","quack",["roar","hiss"]],["Fur is to bear as feathers are to ___.","bird",["fish","snake"]],["Gills are to fish as lungs are to ___.","people",["leaves","rocks"]],["Lion is to pride as wolf is to ___.","pack",["herd","school"]],["Duck is to duckling as frog is to ___.","tadpole",["chick","calf"]],["Spider is to web as bird is to ___.","nest",["den","hive"]],["Elephant is to big as mouse is to ___.","small",["loud","tall"]],["Owl is to night as butterfly is to ___.","day",["moon","winter"]],["Camel is to hump as kangaroo is to ___.","pouch",["trunk","shell"]],["Cheetah is to run as eagle is to ___.","fly",["swim","dig"]],["Bird is to nest as bear is to ___.","den",["pond","hump"]],["Fish is to fins as bird is to ___.","wings",["fur","gills"]],["Cat is to kitten as dog is to ___.","puppy",["calf","cub"]],["Cow is to calf as sheep is to ___.","lamb",["foal","chick"]],["Lion is to roar as dog is to ___.","bark",["moo","hiss"]],["Camel is to desert as polar bear is to ___.","Arctic",["rainforest","pond"]],["Elephant is to trunk as bird is to ___.","beak",["tail","claws"]],["Fish is to scales as bird is to ___.","feathers",["fur","fins"]],["Bee is to hive as rabbit is to ___.","burrow",["nest","pond"]],["Big is to enormous as small is to ___.","tiny",["fierce","swift"]],["Predator is to hunt as prey is to ___.","hide",["roar","eat"]],["Cub is to lion as joey is to ___.","kangaroo",["horse","penguin"]],["Wolves are to pack as fish are to ___.","school",["herd","flock"]],["Day is to awake as night is to ___.","asleep",["hungry","fast"]],["Cheetah is to fast as snail is to ___.","slow",["tall","loud"]],["Hen is to egg as cow is to ___.","milk",["wool","honey"]]];
const analogy=()=>{const x=R(ANA);return mcQ("🔗 "+x[0],x[1],x[2],`${x[0].replace("___","<b>"+x[1]+"</b>")} Think about how the first two words are linked.`,"How are the first two words linked? Use the same link.")};

/* ================= LEARN NOTES ================= */
const L={
 detail:"Read the short text carefully. The answer is <b>in the text</b>. Go back and find the words that match the question.",
 main:"The <b>main idea</b> is what the whole text is mostly about. It fits <b>all</b> the sentences, not just one of them.",
 factop:"A <b>fact</b> can be checked and is true for everyone: <i>A spider has eight legs.</i><br>An <b>opinion</b> is what someone thinks or feels: <i>Spiders are scary.</i> Words like <b>cutest, best, scary, boring</b> often show an opinion.",
 order:"Life cycles and stories happen in <b>order</b>. Think about what must happen <b>first</b>, <b>next</b> and <b>last</b>.",
 cause:"The <b>cause</b> is <b>why</b> something happened. The <b>effect</b> is <b>what</b> happened.<br><i>Because the pond froze</i> (cause), <i>the ducks flew south</i> (effect).<br>Look for <b>because</b> and <b>so</b>.",
 vocab:"Read the word, say it aloud, and think of a sentence that uses it. If you are not sure, look for it in the stories.",
 home:"A <b>habitat</b> is an animal's natural home: <b>desert</b> (dry), <b>Arctic</b> (freezing), <b>ocean</b> (salty water), <b>rainforest</b> (hot and wet), <b>grassland</b> (open grass), <b>pond</b> (small, still water).",
 baby:"Many baby animals have special names: calf (elephant, cow, whale), cub (bear, lion, fox), joey (kangaroo, koala), chick (birds), foal (horse), lamb (sheep), tadpole (frog), duckling (duck).",
 group:"Groups of animals have special names: a <b>herd</b> of elephants, a <b>flock</b> of birds, a <b>pack</b> of wolves, a <b>school</b> of fish, a <b>pride</b> of lions, a <b>swarm</b> of bees, a <b>pod</b> of dolphins.",
 sound:"Animal sounds are action words: the lion <b>roars</b>, the snake <b>hisses</b>, the bee <b>buzzes</b>, the horse <b>neighs</b>, the owl <b>hoots</b>.",
 body:"Animal bodies help them survive: an elephant's <b>trunk</b> drinks and smells, a camel's <b>hump</b> stores fat, a fish's <b>gills</b> breathe underwater.",
 opp:"<b>Opposites</b> mean very different things: enormous ↔ tiny, predator ↔ prey.",
 syn:"<b>Synonyms</b> mean almost the same thing: big = large, swift = fast. Synonyms make your writing more interesting.",
 plS:"<b>Most words:</b> add <b>-s</b> (camel → camels).<br><b>Words ending in s, x, sh, ch:</b> add <b>-es</b> (fox → foxes, bus → buses, dish → dishes, peach → peaches).",
 plIes:"<b>Consonant + y:</b> change y to <b>i</b> and add <b>-es</b> (puppy → puppies).<br><b>Vowel + y</b> (ay, ey, oy): just add <b>-s</b> (monkey → monkeys, toy → toys).",
 plVes:"Many words ending in <b>f</b> or <b>fe</b>: change to <b>-ves</b> (wolf → wolves, leaf → leaves, knife → knives).",
 plSp:"Some plurals are special. Learn them by heart: mouse → <b>mice</b>, goose → <b>geese</b>, child → <b>children</b>, foot → <b>feet</b>, tooth → <b>teeth</b>, person → <b>people</b>. Some never change: <b>sheep, deer, moose</b>.",
 sp:"<b>Singular</b> means one (a fox). <b>Plural</b> means more than one (three foxes).<br>With one, use <b>is</b>: The fox is hungry. With more than one, use <b>are</b>: The foxes are hungry.",
 plFix:"When there is more than one, the noun must be plural: <i>three fox</i> ❌ → <i>three foxes</i> ✅. Use the plural rules you learned.",
 pastReg:"The <b>past tense</b> tells about things that already happened. Most verbs add <b>-ed</b>: walk → walked, jump → jumped.",
 pastRules:"<b>Ends in e:</b> add <b>-d</b> (smile → smiled).<br><b>Short word, one vowel, one last consonant:</b> double it, add <b>-ed</b> (hop → hopped).<br><b>Consonant + y:</b> change y to i, add <b>-ed</b> (cry → cried).",
 pastIrr:"<b>Special (irregular) verbs</b> do not use -ed. They change in their own way: go → <b>went</b>, see → <b>saw</b>, fly → <b>flew</b>, eat → <b>ate</b>, swim → <b>swam</b>, catch → <b>caught</b>.",
 tense:"<b>Present:</b> happens now or often. Time words: <i>every day, usually, each night</i>.<br><b>Past:</b> already happened. Time words: <i>yesterday, last night, last week, long ago</i>.",
 wasWere:"Use <b>was</b> with one person or thing: <i>The lion was hungry. I was tired.</i><br>Use <b>were</b> with more than one and with <b>you</b>: <i>The lions were hungry. You were late.</i>",
 pastFix:"If something happened <b>yesterday</b> or <b>last week</b>, the verb must be in the past tense: <i>Yesterday the bear catches a fish</i> ❌ → <i>Yesterday the bear caught a fish</i> ✅.",
 fix:"Check 3 things: <b>1.</b> capital letter at the start, <b>2.</b> capitals for names, places and I, <b>3.</b> a full stop at the end.",
 orderW:"Find the word with the capital letter: it goes first. Then think: <b>who? does what? where or when?</b> Add the full stop.",
 write:"Plan in your head first. Then write: capital letter, complete idea, end mark. Read it aloud to check.",
 spell:"Use <b>Look → Say → Cover → Write → Check</b>. Say the word slowly and listen to each sound.",
 spellPl:"Listen carefully to the end of the word. Is it <b>-s</b>, <b>-es</b>, <b>-ies</b>, <b>-ves</b>, or a special plural like <b>mice</b>?",
 choose:"Say the word slowly in your head and picture it. Which one <b>looks</b> right? Watch out for <b>ph</b> (elephant, dolphin) and double letters (rabbit, giraffe).",
 think:"Read the question twice. Think about what you <b>know</b>, then choose. In real-life questions, choose the <b>safe and kind</b> answer.",
 maths:"Find the numbers. Is it <b>more</b> (add), <b>less</b> (take away), <b>groups of</b> (multiply) or <b>sharing equally</b> (divide)?",
 classify:"<b>Mammals:</b> fur or hair, feed babies milk (whales too!).<br><b>Birds:</b> feathers and beaks.<br><b>Fish:</b> gills and fins.<br><b>Reptiles:</b> dry scaly skin.<br><b>Amphibians:</b> start in water, smooth wet skin.<br><b>Insects:</b> six legs.",
 odd:"Three animals belong to the same group. Find the group, then find the animal that is <b>not</b> in it.",
 chain:"A <b>food chain</b> shows who eats what. It starts with the <b>sun</b> and a <b>plant</b>. The arrow → means <b>is eaten by</b>: grass → zebra → lion.",
 ana:"Find how the first two words are linked (a bird <b>lives in</b> a nest). Use the <b>same link</b> for the next pair (a bear <b>lives in</b> a den)."
};

/* exported for spiral review in later units */
u.review=MIX(plQ(PL_S),plQ(PL_IES.concat(PL_YS)),plQ(PL_VES),plQ(SPECIAL),isAre,pastQ(REG,regRule),pastQ(RULES,v=>v[2]),pastQ(IRR,irrRule),tense,wasWere,pastFix,plFix,homeQ,babyQ,groupQ,classify,F.word(u.words),F.fill(u.words));
/* ================= THE SKILL LIST ================= */
u.cats=[
 {n:"Reading",e:"📖",items:[
  {id:"r_t1",t:"Story: Pip's Trip Around the World",act:"story",si:0},
  {id:"r_t2",t:"Story: Ravi and the Baby Turtles",act:"story",si:1},
  {id:"r_t3",t:"Fact text: Animal Homes Around the World",act:"story",si:2},
  {id:"r_t4",t:"Fact text: Clever Ways Animals Survive",act:"story",si:3},
  {id:"r_t5",t:"Fable: Kiko the Chameleon",act:"story",si:4},
  {id:"r_t6",t:"Real-world reading: A day at the zoo",act:"story",si:5},
  {id:"r_p1",t:"Poem: Around the World with Pip",act:"poem",pi:0},
  {id:"r_p2",t:"Poem: Winter Sleep",act:"poem",pi:1},
  {id:"r_detail",t:"Read and find the details",learn:L.detail,gen:detail},
  {id:"r_main",t:"Find the main idea",learn:L.main,gen:mainIdea},
  {id:"r_factop",t:"Fact or opinion?",learn:L.factop,gen:factOp},
  {id:"r_order",t:"Order of events and life cycles",learn:L.order,gen:order},
  {id:"r_cause",t:"Cause and effect",learn:L.cause,gen:cause}]},
 {n:"Vocabulary",e:"🔤",items:[
  {id:"v_s1",t:"Habitat words",learn:L.vocab,gen:F.vocab(set(0))},
  {id:"v_s2",t:"Animal body words",learn:L.vocab,gen:F.vocab(set(1))},
  {id:"v_s3",t:"Survival words",learn:L.vocab,gen:F.vocab(set(2))},
  {id:"v_s4",t:"Describing and adventure words",learn:L.vocab,gen:F.vocab(set(3))},
  {id:"v_fill",t:"Use the right word in a sentence",learn:L.vocab,gen:F.fill(u.words)},
  {id:"v_home",t:"Which animal lives where?",learn:L.home,gen:homeQ},
  {id:"v_body",t:"Which animal has this body part?",learn:L.body,gen:bodyQ},
  {id:"v_baby",t:"Baby animal names",learn:L.baby,gen:babyQ},
  {id:"v_group",t:"Animal group names",learn:L.group,gen:groupQ},
  {id:"v_sound",t:"Animal sounds",learn:L.sound,gen:soundQ},
  {id:"v_opp",t:"Opposites",learn:L.opp,gen:F.pairs(OPP,"opposite")},
  {id:"v_syn",t:"Synonyms",learn:L.syn,gen:F.pairs(SYN,"synonym")}]},
 {n:"Grammar",e:"🧩",items:[
  {id:"g_sp",t:"Singular or plural?",learn:L.sp,gen:sp},
  {id:"g_pls",t:"Plurals: add -s or -es",learn:L.plS,gen:plQ(PL_S)},
  {id:"g_plies",t:"Plurals: words ending in y",learn:L.plIes,gen:plQ(PL_IES.concat(PL_YS))},
  {id:"g_plves",t:"Plurals: f and fe → ves",learn:L.plVes,gen:plQ(PL_VES)},
  {id:"g_plsp",t:"Special plurals",learn:L.plSp,gen:plQ(SPECIAL)},
  {id:"g_isare",t:"Is or are?",learn:L.sp,gen:isAre},
  {id:"g_plfix",t:"Fix the plural in a sentence",learn:L.plFix,gen:plFix},
  {id:"g_preg",t:"Past tense: add -ed",learn:L.pastReg,gen:pastQ(REG,regRule)},
  {id:"g_prules",t:"Past tense spelling rules (-d, double, -ied)",learn:L.pastRules,gen:pastQ(RULES,v=>v[2])},
  {id:"g_pirr",t:"Past tense: special verbs",learn:L.pastIrr,gen:pastQ(IRR,irrRule)},
  {id:"g_tense",t:"Present or past?",learn:L.tense,gen:tense},
  {id:"g_waswere",t:"Was or were?",learn:L.wasWere,gen:wasWere},
  {id:"g_pfix",t:"Fix the verb in a sentence",learn:L.pastFix,gen:pastFix},
  {id:"g_fix",t:"Fix the sentence (capitals and full stops)",learn:L.fix,gen:fix},
  {id:"g_order",t:"Put the words in order",learn:L.orderW,gen:G.order(SENT.filter(x=>(x.match(/\b[A-Z]/g)||[]).length===1))},
  {id:"g_write",t:"Write your own sentences",learn:L.write,gen:F.write(WP)},
  {id:"g_mixed",t:"Mixed grammar review",learn:"Use all the plural and past-tense rules you have learned.",gen:MIX(plQ(PL_S),plQ(PL_IES),plQ(PL_VES),plQ(SPECIAL),isAre,pastQ(REG,regRule),pastQ(RULES,v=>v[2]),pastQ(IRR,irrRule),tense,wasWere,pastFix,plFix)}]},
 {n:"Spelling",e:"🎧",items:[
  {id:"s_animals",t:"Animal words: listen and write",learn:L.spell,gen:F.listen(SP)},
  {id:"s_plurals",t:"Plural words: listen and write",learn:L.spellPl,gen:F.listen(SPP)},
  {id:"s_choose",t:"Choose the correct spelling",learn:L.choose,gen:F.chooseSpelling(CHOOSE)},
  {id:"s_missing",t:"Missing letters",learn:L.spell,gen:F.missing(SP)}]},
 {n:"Thinking and science",e:"🧠",items:[
  {id:"t_puz",t:"Animal puzzles and real-life questions",learn:L.think,gen:F.bank(PUZ)},
  {id:"t_class",t:"Mammal, bird, fish, reptile, amphibian or insect?",learn:L.classify,gen:classify},
  {id:"t_odd",t:"Odd one out",learn:L.odd,gen:odd},
  {id:"t_chain",t:"Food chains",learn:L.chain,gen:F.bank(CHAIN)},
  {id:"t_maths",t:"Animal maths stories",learn:L.maths,gen:maths},
  {id:"t_ana",t:"Word links (analogies)",learn:L.ana,gen:analogy}]},
 {n:"Explore and write",e:"✏️",items:[
  {id:"x_facts",t:"Did you know? Amazing animal facts",act:"facts"},
  {id:"x_w1",t:"Writing step 1: Imagine you are an animal",act:"write",wi:0},
  {id:"x_w2",t:"Writing step 2: An animal fact report",act:"write",wi:1},
  {id:"x_w3",t:"Writing step 3: Pip's new adventure (story)",act:"write",wi:2}]}
];
})();
