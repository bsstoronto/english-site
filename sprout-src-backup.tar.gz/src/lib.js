/* ================= SHARED HELPERS + QUESTION GENERATORS ================= */
const UNITS=[];
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function R(a){return a[Math.floor(Math.random()*a.length)]}
function SAMPLE(a,n){return shuffle(a.slice()).slice(0,n)}
function cap(w){return w.charAt(0).toUpperCase()+w.slice(1)}
function uniq(a){return [...new Set(a)]}
function mcQ(q,correct,wrongs,why,hint,extra){
  const o=shuffle(uniq([correct].concat(wrongs.filter(x=>x!==correct))));
  return Object.assign({type:"mc",q,o,a:[correct],why:why||"",hint},extra||{});
}
function blankWord(sentence,word){return sentence.replace(new RegExp("\\b"+word+"(s|es|d|ed)?\\b","i"),"___")}

/* Writing checks shared by many skills */
const CHK={
  cap:["^\\s*[\"“‘']?[A-Z]","Starts with a capital letter"],
  end:["[.!?][\"”’']?\\s*$","Ends with a full stop (or ? or !)"],
  q:["\\?[\"”’']?\\s*$","Ends with a question mark"],
  I:["^(?![\\s\\S]*\\bi\\b)","Writes I as a capital letter"],
  w4:["^\\s*(\\S+\\s+){3,}\\S+","Has at least 4 words"],
  w3:["^\\s*(\\S+\\s+){2,}\\S+","Has at least 3 words"],
  name:["\\s[A-Z][a-z]+","Has a name with a capital letter"]
};

/* ---------- Generator factories ---------- */
const F={
  // vocabulary
  meaning:words=>()=>{const w=R(words);return mcQ(`What does <b>${w.w}</b> mean?`,w.m,SAMPLE(words.filter(x=>x!==w),3).map(x=>x.m),`${w.e} <b>${w.w}</b> means ${w.m}. Example: ${w.ex}`)},
  word:words=>()=>{const w=R(words);return mcQ(`Which word means: <b>${w.m}</b>?`,w.w,SAMPLE(words.filter(x=>x!==w),3).map(x=>x.w),`${w.e} <b>${w.w}</b>: ${w.ex}`)},
  fill:words=>()=>{const w=R(words);const s=Math.random()<.5?w.fill:blankWord(w.ex,w.w);
    return {type:"type",q:`Type the missing word: <b>${s}</b>`,a:[w.w].concat(w.alt||[]),why:`${w.e} <b>${w.w}</b> = ${w.m}`,hint:`It starts with "${w.w[0]}" and has ${w.w.length} letters.`}},
  // any fixed bank of {q,o,a,why,hint}
  // five question types per word: word→meaning, meaning→word, two different fill-in sentences, type the word from its meaning
  vocab:words=>()=>{const w=R(words),t=Math.floor(Math.random()*5);
    if(t===0)return mcQ(`What does <b>${w.w}</b> mean?`,w.m,SAMPLE(words.filter(x=>x!==w),3).map(x=>x.m),`${w.e} <b>${w.w}</b> means ${w.m}. Example: ${w.ex}`);
    if(t===1)return mcQ(`Which word means: <b>${w.m}</b>?`,w.w,SAMPLE(words.filter(x=>x!==w),3).map(x=>x.w),`${w.e} <b>${w.w}</b>: ${w.ex}`);
    if(t===2)return {type:"type",q:`Type the missing word: <b>${w.fill}</b>`,a:[w.w].concat(w.alt||[]),why:`${w.e} <b>${w.w}</b> = ${w.m}`,hint:`It starts with "${w.w[0]}" and has ${w.w.length} letters.`};
    if(t===3){const mm=w.ex.match(new RegExp("\\b"+w.w+"(s|es|d|ed)?\\b","i"));if(!mm)return {type:"type",q:`Type the missing word: <b>${w.fill}</b>`,a:[w.w].concat(w.alt||[]),why:`${w.e} <b>${w.w}</b> = ${w.m}`,hint:`It starts with "${w.w[0]}" and has ${w.w.length} letters.`};return {type:"type",q:`Type the missing word: <b>${blankWord(w.ex,w.w)}</b>`,a:[mm[0]].concat(w.alt||[]),why:`${w.e} ${w.ex}`,hint:`It starts with "${w.w[0]}" and has ${w.w.length} letters.`};}
    return {type:"type",q:`Type the word that means: <b>${w.m}</b>`,a:[w.w].concat(w.alt||[]),why:`${w.e} <b>${w.w}</b>: ${w.ex}`,hint:`It starts with "${w.w[0]}" and has ${w.w.length} letters.`}},
  bank:bank=>()=>{const b=R(bank);return mcQ(b.q,b.a,b.o.filter(x=>x!==b.a),b.why,b.hint)},
  // spelling
  listen:list=>()=>{const x=R(list);const s=x.s?blankWord(x.s,x.w):"_ ".repeat(x.w.length).trim();
    return {type:"type",q:`🎧 Listen, then write the word:<br><b>${s}</b>`,a:[x.w],say:x.s?`${x.w}. ${x.s} ${x.w}.`:`${x.w}. ${x.w}.`,autoSay:true,
      why:`<b>${x.w}</b>${x.tip?" — "+x.tip:""}`,hint:`It has ${x.w.length} letters and starts with "${x.w[0]}".`}},
  chooseSpelling:list=>()=>{const x=R(list);return mcQ(`Which spelling is correct?`,x.w,x.bad,`<b>${x.w}</b>${x.tip?" — "+x.tip:""}`,"Say the word slowly and picture it.",{say:x.w,autoSay:true})},
  missing:list=>()=>{const x=R(list.filter(y=>y.w.length>=4));const w=x.w;const idx=SAMPLE([...Array(w.length).keys()].slice(1),Math.min(2,w.length-2));
    const shown=w.split("").map((c,i)=>idx.includes(i)?"_":c).join(" ");
    return {type:"type",q:`🎧 Fill in the missing letters and type the whole word:<br><b style="letter-spacing:4px">${shown}</b>`,a:[w],say:x.s?`${w}. ${x.s}`:w,autoSay:true,why:`<b>${w}</b>${x.tip?" — "+x.tip:""}`}},
  // writing your own sentence
  write:prompts=>()=>{const p=R(prompts);return {type:"write",q:p.q,checks:p.checks,model:p.model,why:"Check the list, then read your sentence aloud."}},
  // compound words
  compoundJoin:list=>()=>{const c=R(list);return {type:"type",q:`Join the two words to make one compound word:<br><b>${c[0]} + ${c[1]} = ?</b>`,a:[c[0]+c[1]],why:`${c[0]} + ${c[1]} = <b>${c[0]+c[1]}</b>`}},
  compoundPick:list=>()=>{const c=R(list),w=c[0]+c[1];const others=SAMPLE(list.filter(x=>x!==c),2).map(x=>x[0]+x[1]);
    const fake=R(list.filter(x=>x!==c))[0]+R(list.filter(x=>x!==c))[0];
    return mcQ(`Which word is a <b>compound word</b> made of <b>${c[0]}</b> and <b>${c[1]}</b>?`,w,others.concat([fake]).filter(x=>x!==w),`${c[0]} + ${c[1]} = <b>${w}</b>`)},
  // pairs: opposites / synonyms
  pairs:(list,label)=>()=>{const p=R(list),flip=Math.random()<.5;const a=flip?p[1]:p[0],b=flip?p[0]:p[1];
    const wrong=SAMPLE(list.filter(x=>x!==p).flat().filter(x=>x!==a&&x!==b),3);
    return mcQ(`Which word is the <b>${label}</b> of <b>${a}</b>?`,b,wrong,`<b>${a}</b> and <b>${b}</b> are ${label==="opposite"?"opposites":"synonyms (they mean almost the same)"}.`)}
};

/* ---------- Grammar helpers that build questions from correct sentences ---------- */
function breakSentence(s){ // lower first letter + proper nouns + I, remove end mark
  const words=s.replace(/[.!?]$/,"").split(" ");
  return words.map((w,i)=>i===0?w.charAt(0).toLowerCase()+w.slice(1):(/^[A-Z]/.test(w)?w.charAt(0).toLowerCase()+w.slice(1):w)).join(" ");
}
const G={
  fix:sentences=>()=>{const s=R(sentences);return {type:"type",strict:true,q:`Fix this sentence. Add the capital letters and the end mark:<br><b>${breakSentence(s)}</b>`,a:[s],
    hint:"Capital letter at the start, capitals for names and I, and a mark at the end.",why:`Correct: <b>${s}</b>`}},
  order:sentences=>()=>{const s=R(sentences.filter(x=>x.split(" ").length<=8));const words=s.replace(/[.!?]$/,"").split(" ");let sh;do{sh=shuffle(words.slice())}while(sh.join(" ")===words.join(" ")&&words.length>2);
    return {type:"type",strict:true,q:`Put the words in order to make a sentence. Remember the end mark!<br><b>${sh.join(" / ")}</b>`,a:[s],hint:"Start with the word that has a capital letter. Who? Does what?",why:`Correct: <b>${s}</b>`}},
  capStart:sentences=>()=>{const s=R(sentences);const low=s.charAt(0).toLowerCase()+s.slice(1);
    const ws=s.split(" ");const k=1+Math.floor(Math.random()*(ws.length-1));const odd=ws.map((w,i)=>i===k&&/^[a-z]/.test(w)?cap(w):w).join(" ");
    return mcQ("Which sentence is written correctly?",s,[low,odd===s?low.replace(/[.!?]$/,""):odd],"A sentence starts with a capital letter. Other words only get capitals if they are names or I.","Look at the first letter of each choice.")},
  capI:sentences=>()=>{const s=R(sentences.filter(x=>/\bI\b/.test(x)));const bad=s.replace(/\bI\b/g,"i");const bad2=bad.charAt(0).toLowerCase()+bad.slice(1);
    return mcQ("Which sentence is correct?",s,[bad,bad2],"The word <b>I</b> is always a capital letter.","Find the word I in each sentence.")},
  endMark:(tell,ask,excl)=>()=>{const t=R(["tell","ask","excl"]);const s=R(t==="tell"?tell:t==="ask"?ask:excl);const m=s.slice(-1);
    return mcQ(`Which mark goes at the end?<br><b>${s.slice(0,-1)}___</b>`,m,[".","?","!"].filter(x=>x!==m),
      m==="."?"It tells something, so it ends with a full stop.":m==="?"?"It asks something, so it ends with a question mark.":"It shows a strong feeling, so it ends with an exclamation mark.","Is it telling, asking, or showing a strong feeling?")},
  kind:(tell,ask,excl)=>()=>{const t=R(["telling","asking","exclaiming"]);const s=R(t==="telling"?tell:t==="asking"?ask:excl);
    return mcQ(`What kind of sentence is this?<br><b>${s}</b>`,t,["telling","asking","exclaiming"].filter(x=>x!==t),
      t==="telling"?"It tells us something and ends with a full stop.":t==="asking"?"It asks a question and ends with ?":"It shows strong feeling and ends with !","Look at the mark at the end.")}
};
