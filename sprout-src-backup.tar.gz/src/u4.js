/* ===================== GRADE 3 · UNIT 4 · WEATHER AND SEASONS (original content, plus one public-domain poem) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"weather", num:4, emoji:"🌦️❄️☀️", title:"Weather and Seasons", badge:"🌈 Weather Watcher",

stories:[
/* ---------- 1. STORY ---------- */
{title:"The Snow Day", e:"❄️", kind:"Story", pages:[
 {pic:"🌨️🪟", text:"Mia woke up and pulled back the curtains. Everything outside was white! Thick, fluffy snow covered the cars, the trees and the street. The radio said, \"All schools in Toronto are closed today because of the snowstorm.\" Mia ran to Leo's room. \"Leo! Wake up! It's a snow day!\"",
  qs:[f("Why were the schools closed?","Because of the snowstorm",["Because it was a holiday","Because the teachers were sick"],"The radio said schools were closed because of the snowstorm."),
      t("How did Mia feel when she saw the snow?","Excited",["Bored","Angry"],"She ran to wake Leo and shouted, \"It's a snow day!\"")]},
 {pic:"🧤🧣", text:"\"Not so fast,\" said Mom. \"It is minus fifteen degrees outside. That is freezing cold!\" Mia and Leo put on their warmest clothes: thick socks, snow pants, puffy coats, woolly hats, scarves and mittens. \"Cover your ears and fingers,\" Mom said. \"In this cold, skin can get frostbite.\"",
  qs:[f("What was the temperature outside?","Minus fifteen degrees",["Fifteen degrees","Thirty degrees"],"Mom said it was minus fifteen degrees outside."),
      t("Why did Mom tell them to cover their ears and fingers?","To protect their skin from frostbite",["To look nice","To keep the snow clean"],"Very cold air can hurt bare skin. This is called frostbite.")]},
 {pic:"⛄🥕", text:"Outside, the snow crunched under their boots. The air was so cold that their breath made little clouds. They rolled three snowballs: a big one, a bigger one and the biggest one of all. They stacked them up to make a snowman. Leo gave it a carrot nose, and Mia used pebbles for its eyes.",
  qs:[f("What did Leo use for the snowman's nose?","A carrot",["A pebble","A stick"],"Leo gave it a carrot nose."),
      t("Which snowball went at the BOTTOM of the snowman?","The biggest one",["The big one","The smallest one"],"The biggest, heaviest snowball goes at the bottom so the snowman does not fall.")]},
 {pic:"📏❄️", text:"Grandmother brought out a ruler. \"Let's be weather scientists,\" she said. Mia pushed the ruler straight down into the snow. \"Thirty centimetres!\" she read. \"That is the deepest snow I have ever seen!\" Grandmother laughed. \"When I first came to Canada, I had never seen snow at all.\"",
  qs:[f("How deep was the snow?","Thirty centimetres",["Three centimetres","Three metres"],"Mia read \"Thirty centimetres!\" on the ruler."),
      t("Why had Grandmother never seen snow before she came to Canada?","She came from a warm place where it did not snow",["She did not like going outside","She was always asleep in winter"],"Some countries are warm all year and never get snow.")]},
 {pic:"🛷🏔️", text:"After lunch, the children took their sled to the big hill in the park. They zoomed down, faster and faster, and landed in a soft pile of snow. Their cheeks turned pink, and their noses felt icy. \"One more time!\" shouted Leo, again and again, until the sun began to set.",
  qs:[f("Where did they go sledding?","The big hill in the park",["The school roof","The kitchen"],"They took their sled to the big hill in the park."),
      f("What happened to their cheeks?","They turned pink",["They turned blue","They turned green"],"Their cheeks turned pink in the cold.")]},
 {pic:"☕🔥", text:"Back inside, Mom made hot chocolate with tiny marshmallows. The children wrapped themselves in cosy blankets and watched the snowflakes falling past the window. \"Winter is the best season,\" said Leo. \"No,\" said Mia, \"summer is!\" Grandmother smiled. \"Every season has something special.\"",
  qs:[f("What did Mom make when they came inside?","Hot chocolate",["Ice cream","Lemonade"],"Mom made hot chocolate with tiny marshmallows."),
      t("\"Winter is the best season\" is a…","Opinion",["Fact"],"Leo and Mia feel differently. A sentence about what is \"best\" is an opinion.")]}
], turn:{q:"What do you like to do on a cold or rainy day? Write two sentences.",model:"On a rainy day, I like to read books under a blanket. Sometimes I also bake cookies with my dad."}},

/* ---------- 2. STORY ---------- */
{title:"Waiting for the Monsoon", e:"🌧️", kind:"Story", pages:[
 {pic:"☀️🥵", text:"In Dev's village in India, the summer was scorching hot. For weeks, the sun burned in a clear sky. The fields were dry and cracked, and the pond had almost disappeared. Every evening, Dev's grandfather looked at the sky. \"Soon,\" he said. \"The monsoon will come soon.\"",
  qs:[f("What were the fields like?","Dry and cracked",["Green and wet","Covered in snow"],"The fields were dry and cracked."),
      t("What is a monsoon?","A season of very heavy rain",["A kind of tree","A hot, dry wind with no rain"],"In India and other places, the monsoon brings months of heavy rain after the hot summer.")]},
 {pic:"🧑‍🌾🌾", text:"Dev's grandfather was a farmer. He grew rice, and rice needs a lot of water. \"Without the monsoon rain, my rice cannot grow,\" he explained. \"And if the rice does not grow, many families will not have enough food.\" Dev looked up at the empty sky and hoped very hard.",
  qs:[f("What does Dev's grandfather grow?","Rice",["Apples","Cotton"],"He grew rice, and rice needs a lot of water."),
      t("Why is the monsoon so important to farmers?","Their crops need the rain to grow",["They like getting wet","It makes the days longer"],"Without rain, the rice cannot grow, and families may not have enough food.")]},
 {pic:"☁️🌬️", text:"One afternoon, the air felt heavy and humid. A cool wind began to blow. Dark, gloomy clouds rolled across the sky like giant grey elephants. Birds flew low, and the cows mooed. Then Dev heard a deep rumble of thunder far away. \"It's coming!\" Grandfather shouted.",
  qs:[f("What were the clouds compared to?","Giant grey elephants",["Fluffy white sheep","Tall green trees"],"Dark clouds rolled across the sky like giant grey elephants."),
      t("What clues told them the rain was coming?","Heavy air, cool wind, dark clouds and thunder",["Bright sunshine and a clear sky","The pond getting smaller"],"The weather changed in many ways just before the storm.")]},
 {pic:"🌧️💃", text:"Big, warm raindrops began to fall: plop, plop, plop! Then the rain poured down like a waterfall. Dev ran outside with his sister and danced in the rain. The dry earth gave off a wonderful, fresh smell. Grandfather stood in the field with his arms wide open, laughing.",
  qs:[f("What did Dev and his sister do when the rain started?","They danced in the rain",["They hid under the bed","They went to sleep"],"Dev ran outside with his sister and danced in the rain."),
      t("Why was Grandfather laughing?","He was happy because his rice could now grow",["He slipped in the mud","Someone told him a joke"],"The rain meant his crops would grow.")]},
 {pic:"⛵💧", text:"For the next weeks, it rained almost every day. The pond filled up, the fields turned green, and frogs croaked all night. Dev and his friends made paper boats and raced them in the puddles. But Grandfather warned them, \"Never play near the river now. When it floods, the water is fast and dangerous.\"",
  qs:[f("What did Dev and his friends race in the puddles?","Paper boats",["Toy cars","Snowballs"],"They made paper boats and raced them in the puddles."),
      t("Why did Grandfather warn them about the river?","Flood water is fast and dangerous",["The river was too cold","There were sharks in the river"],"Heavy rain can make rivers flood. Flood water can sweep people away.")]},
 {pic:"🌾🌈", text:"By autumn, Grandfather's fields were full of tall, golden rice. Dev helped him with the harvest. \"The monsoon gives us life,\" Grandfather said, \"but we must respect its power.\" That evening, a bright rainbow stretched across the sky, and Dev thought it was the most beautiful sight in the world.",
  qs:[f("What colour was the rice by autumn?","Golden",["Blue","White"],"The fields were full of tall, golden rice."),
      t("What did Grandfather mean by \"we must respect its power\"?","The rain is helpful, but it can also be dangerous",["The rain is always gentle","They should be scared of rainbows"],"The monsoon brings water for crops, but floods can be dangerous.")]}
], turn:{q:"Describe the weather where you live today. Write two sentences.",model:"Today it is cloudy and chilly in Toronto. A cold wind is blowing the leaves off the trees."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"Why Do We Have Seasons?", e:"🌍", kind:"Fact text", pages:[
 {pic:"🌸☀️🍂❄️", text:"Many places on Earth have four <b>seasons</b>: spring, summer, autumn (also called fall) and winter. In summer, days are long and warm. In winter, days are short and cold. But why do the seasons change? The answer is all about how the Earth moves.",
  qs:[f("What are the four seasons?","Spring, summer, autumn and winter",["Morning, noon, evening and night","Sun, rain, wind and snow"],"Spring, summer, autumn (fall) and winter."),
      f("What is another name for autumn?","Fall",["Spring","Frost"],"Autumn is also called fall.")]},
 {pic:"🌍🔄☀️", text:"The Earth travels around the Sun in a big path called an <b>orbit</b>. One trip all the way around takes about 365 days, which is one year. At the same time, the Earth spins like a top. One spin takes 24 hours, which gives us day and night.",
  qs:[f("How long does the Earth take to travel once around the Sun?","About 365 days (one year)",["24 hours","One week"],"One trip around the Sun takes about 365 days."),
      t("What makes day and night?","The Earth spinning",["The Sun turning off","Clouds covering the Sun"],"One spin of the Earth takes 24 hours, which gives us day and night.")]},
 {pic:"🌐📐", text:"Here is the secret: the Earth is <b>tilted</b>. It leans a little to one side as it travels around the Sun. For part of the year, the top half of the Earth leans towards the Sun. The sunlight hits it more directly, and the days are longer. That half has summer.",
  qs:[f("What does \"tilted\" mean?","Leaning to one side",["Spinning fast","Very hot"],"The Earth is tilted: it leans a little to one side."),
      t("When the top half of the Earth leans towards the Sun, what season does it have?","Summer",["Winter","Autumn"],"More direct sunlight and longer days make summer.")]},
 {pic:"🌏❄️☀️", text:"Six months later, the Earth is on the other side of the Sun. Now the top half leans away from the Sun. The sunlight is weaker, and the days are shorter. That half has winter. Many people think winter happens because the Earth is farther from the Sun, but that is not true. It is because of the tilt!",
  qs:[f("Why does winter happen?","The Earth's half leans away from the Sun",["The Earth is farther from the Sun","The Sun gets smaller"],"The text says winter is caused by the tilt, not by distance."),
      t("Which sentence is a mistake that many people believe?","Winter happens because the Earth is farther from the Sun",["The Earth is tilted","Days are shorter in winter"],"The text tells us this common idea is not true.")]},
 {pic:"🇨🇦🇦🇺", text:"When it is winter in the top half of the Earth, it is summer in the bottom half. So when children in Canada are building snowmen in December, children in Australia are swimming at the beach! Their seasons are the opposite of ours.",
  qs:[f("What season is it in Australia in December?","Summer",["Winter","Autumn"],"When Canada has winter, Australia has summer."),
      t("Why are the seasons opposite in Canada and Australia?","They are on different halves of the tilted Earth",["Australia is closer to the Moon","Canada has more trees"],"When one half leans towards the Sun, the other half leans away.")]},
 {pic:"🌴☀️", text:"Places near the middle of the Earth, close to a line called the <b>equator</b>, get strong sunlight all year. They are warm all year and do not have a cold winter. Instead, many of them have a wet season and a dry season. The monsoon in India is part of a wet season.",
  qs:[f("What is the imaginary line around the middle of the Earth called?","The equator",["The orbit","The tilt"],"A line called the equator."),
      t("Why don't places near the equator have a cold winter?","They get strong sunlight all year",["They have no clouds","They are always at night"],"Places near the equator get strong sunlight all year, so they stay warm.")]}
], turn:{q:"Which season do you like best? Write two sentences explaining why.",model:"I like autumn best. The leaves turn red and gold, and the air feels cool and fresh."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"The Amazing Water Cycle", e:"💧", kind:"Fact text", pages:[
 {pic:"💧🔄", text:"The water you drink today may once have been drunk by a dinosaur! That is because the Earth keeps using the same water again and again. Water moves from the ground to the sky and back down in a never-ending journey called the <b>water cycle</b>.",
  qs:[f("What is the water's never-ending journey called?","The water cycle",["The life cycle","The food chain"],"It is called the water cycle."),
      t("Why might your water once have been drunk by a dinosaur?","The Earth uses the same water again and again",["Dinosaurs are still alive","Water comes from dinosaur bones"],"The same water keeps going around the water cycle for millions of years.")]},
 {pic:"☀️🌊⬆️", text:"<b>Step 1: Evaporation.</b> The Sun warms the water in oceans, lakes and puddles. The warm water slowly turns into an invisible gas called <b>water vapour</b> and rises into the air. That is why puddles disappear on a sunny day.",
  qs:[f("What does the Sun's heat turn water into?","Water vapour",["Ice","Sand"],"The warm water turns into an invisible gas called water vapour."),
      t("Why do puddles disappear on a sunny day?","The water evaporates into the air",["Animals drink them","They sink into the clouds"],"The Sun warms the puddle, and the water rises as vapour.")]},
 {pic:"☁️❄️", text:"<b>Step 2: Condensation.</b> High in the sky, the air is cold. The water vapour cools down and turns back into tiny droplets of water. Millions of these droplets join together to make <b>clouds</b>. You can see condensation at home too: look at the drops on the outside of a cold glass of juice.",
  qs:[f("What are clouds made of?","Millions of tiny droplets of water",["Cotton","Smoke"],"Millions of droplets join together to make clouds."),
      f("Where can you see condensation at home?","On the outside of a cold glass",["Inside a hot oven","On a dry towel"],"Look at the drops on the outside of a cold glass of juice.")]},
 {pic:"🌧️🌨️", text:"<b>Step 3: Precipitation.</b> The droplets in a cloud bump into each other and grow bigger and heavier. When they are too heavy to float, they fall back to the ground. This is called <b>precipitation</b>. It can be rain, snow, sleet or hail, depending on how cold the air is.",
  qs:[f("Name a kind of precipitation.","Snow",["Wind","Sunshine"],"Precipitation can be rain, snow, sleet or hail."),
      t("Why does precipitation sometimes fall as snow instead of rain?","The air is cold enough to freeze the water",["The cloud is angry","There is no wind"],"It depends on how cold the air is.")]},
 {pic:"🏞️🌊", text:"<b>Step 4: Collection.</b> The water that falls collects in oceans, rivers, lakes and the ground. Plants drink it through their roots, animals drink it, and people use it. Then the Sun warms it again, and the whole cycle starts over.",
  qs:[f("Where does the water collect?","In oceans, rivers, lakes and the ground",["Only in clouds","In the Sun"],"The water collects in oceans, rivers, lakes and the ground."),
      t("What happens after collection?","The Sun warms the water and it evaporates again",["The water disappears forever","The water turns into rocks"],"It is a cycle, so it starts over with evaporation.")]},
 {pic:"🚰🌍", text:"Only a very small part of all the water on Earth is fresh water that people can drink. Most water is salty ocean water, and a lot of fresh water is frozen in ice. That is why it is important not to waste water. Turning off the tap while you brush your teeth helps!",
  qs:[f("Where is most of the Earth's water?","In the salty oceans",["In rivers","In bottles"],"Most water is salty ocean water."),
      t("Why should we not waste water?","Only a small part of Earth's water is fresh water we can drink",["Water is too heavy","Taps are expensive"],"Fresh drinking water is precious.")]}
], turn:{q:"Write two ways you could save water at home or at school.",model:"I can turn off the tap while I brush my teeth. I can take a shorter shower."}},

/* ---------- 5. FABLE ---------- */
{title:"Nimbus the Little Cloud (a fable)", e:"☁️", kind:"Fable", pages:[
 {pic:"☁️😊", text:"High above a valley floated a little cloud named Nimbus. He was soft, white and very proud of himself. All day long, he drifted in the sunshine and admired his reflection in the lake below. \"I am the fluffiest cloud in the whole sky,\" he said.",
  qs:[f("What did Nimbus look at in the lake?","His reflection",["The fish","The boats"],"He admired his reflection in the lake below."),
      t("Which word best describes Nimbus at the start?","Proud",["Shy","Kind"],"He thought he was the fluffiest cloud in the whole sky.")]},
 {pic:"🌧️☁️", text:"As the days went by, Nimbus grew bigger and heavier with water. The other clouds began to rain on the valley, but Nimbus refused. \"If I rain, I will become small and thin,\" he said. \"I want to stay big and beautiful forever.\" So he held on to every drop.",
  qs:[f("Why did Nimbus refuse to rain?","He was afraid he would become small and thin",["He had no water","The wind told him not to"],"\"If I rain, I will become small and thin.\""),
      t("Was Nimbus thinking about others or only about himself?","Only about himself",["About others"],"He only cared about staying big and beautiful.")]},
 {pic:"🥀🐑", text:"Below Nimbus, there was a small farm. The farmer's garden began to wilt. The grass turned brown, and the sheep had little to eat. A thirsty sunflower looked up and called, \"Please, Nimbus, we need your rain!\" But Nimbus turned away.",
  qs:[f("What happened to the farmer's garden?","It began to wilt",["It grew huge","It was covered in snow"],"The farmer's garden began to wilt."),
      t("Why did the farm need Nimbus's rain?","The plants and animals needed water",["The farmer wanted to swim","The sheep were too hot"],"Without rain, the garden wilted and the sheep had little to eat.")]},
 {pic:"🌧️🌻", text:"That night, Nimbus watched the sad, droopy sunflower in the moonlight, and his heart felt heavy too. At last, he let go. Gentle rain fell softly onto the farm all night. In the morning, Nimbus was small and thin, but the garden sparkled, and the sunflower lifted its face. \"Thank you, Nimbus!\"",
  qs:[f("What happened to Nimbus after he rained?","He became small and thin",["He grew bigger","He turned into the Sun"],"In the morning, Nimbus was small and thin."),
      t("Why did Nimbus finally decide to rain?","He felt sorry for the plants and animals",["He was tired","The farmer paid him"],"His heart felt heavy when he saw the droopy sunflower.")]},
 {pic:"☀️☁️💛", text:"Then something wonderful happened. The warm sun shone on the wet fields and the lake, and tiny drops of water rose into the sky. They gathered around Nimbus, and soon he was round and fluffy again. \"When you give, you are filled up again,\" whispered the wind. <b>Lesson: Sharing what you have makes the world, and you, richer.</b>",
  qs:[t("How did Nimbus become fluffy again?","Water evaporated and rose back up to him",["He ate some cotton","The wind blew him"],"This is the water cycle! The water evaporated and condensed into his cloud again."),
      t("What is the lesson of this fable?","Sharing makes the world, and you, richer",["Clouds should never rain","Always stay the same size"],"Nimbus gave his rain, and he was filled up again.")]}
], turn:{q:"Write about a time you shared something or helped someone. How did it make you feel?",model:"I shared my lunch with a new boy who forgot his. It made me feel warm and happy inside."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A weather forecast and storm safety", e:"📺", kind:"Real-world text", pages:[
 {pic:"📺🌤️", text:"This is the 5-day forecast for Toronto in October.<table class=\"realtbl\"><tr><th>Day</th><th>Weather</th><th>High</th><th>Low</th><th>Chance of rain</th></tr><tr><td>Monday</td><td>☀️ Sunny</td><td>18 °C</td><td>9 °C</td><td>0%</td></tr><tr><td>Tuesday</td><td>⛅ Partly cloudy</td><td>16 °C</td><td>8 °C</td><td>20%</td></tr><tr><td>Wednesday</td><td>🌧️ Rain</td><td>12 °C</td><td>7 °C</td><td>90%</td></tr><tr><td>Thursday</td><td>🌬️ Windy</td><td>10 °C</td><td>3 °C</td><td>30%</td></tr><tr><td>Friday</td><td>🌥️ Cloudy, frost overnight</td><td>7 °C</td><td>−1 °C</td><td>10%</td></tr></table>",
  qs:[f("What is the weather on Wednesday?","Rain",["Sunny","Windy"],"Wednesday: 🌧️ Rain, 90% chance."),
      f("Which day has the highest temperature?","Monday",["Wednesday","Friday"],"Monday's high is 18 °C, the warmest of the week."),
      t("On which day should you take an umbrella?","Wednesday",["Monday","Friday"],"Wednesday has a 90% chance of rain."),
      t("What is the pattern in the temperatures this week?","They get colder each day",["They get warmer each day","They stay the same"],"The highs go 18, 16, 12, 10, 7. It is getting colder: autumn is turning towards winter."),
      t("Why is the low on Friday written as −1 °C?","It is below zero, so there will be frost",["It is a typing mistake","It means very hot"],"Temperatures below 0 °C are freezing, so water turns to ice (frost).")]},
 {pic:"⛈️🏠", text:"Read this safety card about thunderstorms.<div class=\"realdoc\" style=\"text-align:left\"><b>⚡ When Thunder Roars, Go Indoors! ⚡</b><br>1. As soon as you hear thunder, go inside a building or a car.<br>2. Stay away from tall trees, metal fences and water.<br>3. Do not use the bath or shower during a storm.<br>4. Wait 30 minutes after the last thunder before going outside again.<br><br>💡 <b>Did you know?</b> Count the seconds between a lightning flash and the thunder. Every 3 seconds means the storm is about 1 kilometre away.</div>",
  qs:[f("What should you do as soon as you hear thunder?","Go inside a building or a car",["Stand under a tall tree","Go swimming"],"Rule 1: As soon as you hear thunder, go inside."),
      f("How long should you wait after the last thunder?","30 minutes",["30 seconds","3 days"],"Rule 4: Wait 30 minutes after the last thunder."),
      t("Why should you stay away from tall trees in a storm?","Lightning often strikes tall things",["Trees might fall asleep","Leaves are slippery"],"Lightning usually hits the tallest objects nearby."),
      t("You count 6 seconds between the flash and the thunder. How far away is the storm?","About 2 kilometres",["About 6 kilometres","About 1 kilometre"],"Every 3 seconds is about 1 km, so 6 seconds is about 2 km.")]}
], turn:{q:"Write two sentences telling a younger child what to do if they hear thunder while playing outside.",model:"If you hear thunder, go inside straight away. Do not stand under a tree."}}
],

poems:[
 {title:"Who Has Seen the Wind? (by Christina Rossetti, 1872)",
  lines:["Who has seen the wind?","Neither I nor you:","But when the leaves hang trembling,","The wind is passing through.","","Who has seen the wind?","Neither you nor I:","But when the trees bow down their heads,","The wind is passing by."],
  qs:[f("Can we see the wind, according to the poem?","No, but we can see what it does",["Yes, it is blue","Yes, but only at night"],"\"Who has seen the wind? Neither I nor you.\" We see the leaves trembling and the trees bowing."),
      t("What does \"the trees bow down their heads\" really mean?","The wind bends the tops of the trees",["The trees are being polite","The trees are sleeping"],"The poet describes trees like people bowing. This is called personification."),
      f("This poem was written in 1872. About how old is it?","More than 150 years old",["About 10 years old","About 1,000 years old"],"From 1872 to today is more than 150 years. It is a classic poem that children have loved for a very long time.")]},
 {title:"Puddle Jumping",
  lines:["Pitter-patter on the pane,","Hooray, hooray, it's rain again!","Boots on, coat on, out the door,","Splash! Splash! Splash! I jump some more.","The puddles are my favourite things,","I splash until the doorbell rings.","And when the sun comes out to play,","A rainbow paints the sky today."],
  qs:[f("Which words in the poem sound like the rain?","Pitter-patter",["Boots on","Grey and grand"],"Pitter-patter copies the sound of rain. These are sound words (onomatopoeia)."),
      f("Which word rhymes with 'things'?","rings",["splash","door"],"Things and rings end with the same sound: -ings."),
      t("How does the child in the poem feel about rain?","Happy and excited",["Scared","Bored"],"\"Hooray, hooray, it's rain again!\"")]}
],

words:[
 {w:"weather",e:"🌦️",m:"what the air outside is like: hot, cold, wet, dry, windy or calm",ex:"The weather today is sunny and warm.",fill:"Let's check the ___ before we go to the beach."},
 {w:"temperature",e:"🌡️",m:"how hot or cold something is",ex:"The temperature outside is 20 degrees.",fill:"The ___ dropped below zero last night."},
 {w:"forecast",e:"📺",m:"a report that tells what the weather will probably be like",ex:"The forecast says it will rain tomorrow.",fill:"The weather ___ says it will snow on Friday."},
 {w:"thermometer",e:"🌡️",m:"a tool that measures temperature",ex:"The thermometer shows 25 degrees.",fill:"Look at the ___ to see how cold it is."},
 {w:"breeze",e:"🍃",m:"a gentle, light wind",ex:"A cool breeze blew across the beach.",fill:"A gentle ___ moved the leaves."},
 {w:"drizzle",e:"🌦️",m:"very light rain with tiny drops",ex:"It was only a drizzle, so we didn't need umbrellas.",fill:"It is not pouring, just a light ___."},
 {w:"thunder",e:"⛈️",m:"the loud rumbling sound that comes after lightning",ex:"Dev heard a deep rumble of thunder.",fill:"The dog hid under the bed when it heard the ___."},
 {w:"lightning",e:"⚡",m:"a bright flash of electricity in the sky during a storm",ex:"A flash of lightning lit up the sky.",fill:"A flash of ___ lit up the dark sky."},
 {w:"fog",e:"🌫️",m:"a cloud close to the ground that makes it hard to see",ex:"The fog was so thick we couldn't see the bridge.",fill:"Drive slowly in the thick ___."},
 {w:"frost",e:"🧊",m:"thin white ice that forms on cold nights",ex:"There was frost on the car this morning.",fill:"In the morning, the grass was white with ___."},

 {w:"season",e:"🍂",m:"one of the four parts of the year: spring, summer, autumn or winter",ex:"Winter is the coldest season.",fill:"Spring is the ___ when flowers start to bloom."},
 {w:"autumn",e:"🍁",m:"the season between summer and winter, also called fall",ex:"Leaves turn red and gold in autumn.",fill:"In ___, the leaves fall from the trees.",alt:["fall"]},
 {w:"monsoon",e:"🌧️",m:"a season of very heavy rain in some parts of the world",ex:"The monsoon brings rain to India's farms.",fill:"During the ___, it rains almost every day in India."},
 {w:"equator",e:"🌐",m:"an imaginary line around the middle of the Earth",ex:"Countries near the equator are warm all year.",fill:"It is hot all year in places near the ___."},
 {w:"orbit",e:"🔄",m:"the path one object takes as it travels around another",ex:"The Earth's orbit around the Sun takes one year.",fill:"The Moon travels in an ___ around the Earth."},
 {w:"tilt",e:"📐",m:"to lean to one side",ex:"The Earth's tilt causes the seasons.",fill:"If you ___ the glass, the water will spill."},
 {w:"daylight",e:"🌅",m:"the natural light of the day",ex:"In summer, there are many hours of daylight.",fill:"In winter, we have fewer hours of ___."},
 {w:"shiver",e:"🥶",m:"to shake because you are cold or afraid",ex:"Pip began to shiver in the Arctic.",fill:"Without a coat, you will ___ in the cold wind."},
 {w:"sunrise",e:"🌄",m:"the time in the morning when the sun comes up",ex:"Grandfather wakes up before sunrise.",fill:"The farmer wakes up at ___, when the sun appears."},
 {w:"sunset",e:"🌇",m:"the time in the evening when the sun goes down",ex:"The sky turned pink at sunset.",fill:"We went home at ___, when the sky turned orange."},

 {w:"evaporate",e:"♨️",m:"(of water) to change into a gas and rise into the air",ex:"The puddle will evaporate in the sun.",fill:"The sun makes the water in puddles ___."},
 {w:"condense",e:"🥛",m:"(of a gas) to cool down and turn into liquid drops",ex:"Water vapour condenses to make clouds.",fill:"Water vapour will ___ into drops on a cold glass."},
 {w:"precipitation",e:"🌨️",m:"water that falls from clouds: rain, snow, sleet or hail",ex:"Snow is a kind of precipitation.",fill:"Rain and snow are kinds of ___."},
 {w:"vapour",e:"💨",m:"water in the form of an invisible gas in the air",ex:"Steam from the kettle is water vapour.",fill:"When water evaporates, it turns into water ___.",alt:["vapor"]},
 {w:"droplet",e:"💧",m:"a very small drop of liquid",ex:"Clouds are made of tiny droplets.",fill:"A tiny ___ of water hung on the leaf."},
 {w:"puddle",e:"🟦",m:"a small pool of water on the ground, often after rain",ex:"Leo jumped into the puddle.",fill:"After the rain, there was a big ___ on the path."},
 {w:"flood",e:"🌊",m:"a lot of water covering land that is usually dry",ex:"Heavy rain caused a flood near the river.",fill:"The river rose over its banks and caused a ___."},
 {w:"drought",e:"🏜️",m:"a long time with little or no rain",ex:"The crops died during the drought.",fill:"There was no rain for months, so there was a ___."},
 {w:"humid",e:"🥵",m:"(of air) warm and wet, so it feels heavy and sticky",ex:"The air felt humid before the storm.",fill:"On a ___ day, the air feels sticky and wet."},
 {w:"collect",e:"🪣",m:"to gather things together in one place",ex:"Rain collects in lakes and rivers.",fill:"We put out a bucket to ___ rainwater."},

 {w:"freezing",e:"❄️",m:"extremely cold",ex:"It was freezing on the snow day.",fill:"Put on your mittens. It's ___ outside!"},
 {w:"chilly",e:"🧥",m:"a little bit cold",ex:"Bring a sweater; the evening is chilly.",fill:"It's a bit ___, so wear a jacket."},
 {w:"mild",e:"🌤️",m:"not too hot and not too cold",ex:"Spring days are often mild.",fill:"Today is ___: not too hot and not too cold."},
 {w:"scorching",e:"🔥",m:"very, very hot",ex:"The summer in Dev's village was scorching.",fill:"It was a ___ day, so we stayed in the shade."},
 {w:"gloomy",e:"🌥️",m:"dark and grey, often making people feel sad",ex:"The sky was grey and gloomy.",fill:"The sky looked ___ and dark before the storm."},
 {w:"stormy",e:"🌩️",m:"with strong winds, heavy rain and often thunder",ex:"It was a stormy night.",fill:"The sea was rough on the ___ night."},
 {w:"gusty",e:"🌬️",m:"with sudden strong bursts of wind",ex:"The gusty wind blew my hat away.",fill:"The ___ wind blew my umbrella inside out."},
 {w:"sparkling",e:"✨",m:"shining with little flashes of light",ex:"The snow was sparkling in the sun.",fill:"The ___ snow glittered in the sunshine."},
 {w:"cosy",e:"🛋️",m:"warm, comfortable and safe",ex:"We were cosy under our blankets.",fill:"The little room by the fire was warm and ___.",alt:["cozy"]},
 {w:"damp",e:"🧦",m:"a little bit wet",ex:"My socks were damp after the walk.",fill:"The towel is still ___ from my shower."}
],

spelling:[
 {w:"rain",s:"The rain fell all night.",tip:"'ai' says long a: r-ai-n."},
 {w:"snow",s:"The snow is white and soft.",tip:"'ow' as in grow."},
 {w:"cloud",s:"A dark cloud covered the sun.",tip:"'ou' as in out: cl-ou-d."},
 {w:"windy",s:"It is a windy day."},
 {w:"sunny",s:"It is sunny and warm.",tip:"Double n: su-nn-y."},
 {w:"storm",s:"The storm was very loud."},
 {w:"cold",s:"Winter is cold."},
 {w:"warm",s:"Summer is warm.",tip:"'ar' sounds like 'or' after w: w-ar-m."},
 {w:"summer",s:"We swim in summer.",tip:"Double m: su-mm-er."},
 {w:"winter",s:"It snows in winter."},
 {w:"spring",s:"Flowers bloom in spring."},
 {w:"weather",s:"The weather is lovely today.",tip:"w-ea-th-er. Don't mix it up with whether!"},
 {w:"thunder",s:"We heard thunder in the night."},
 {w:"rainbow",s:"A rainbow appeared after the rain.",tip:"rain + bow."},
 {w:"autumn",s:"Leaves fall in autumn.",tip:"The 'n' at the end is silent: autum-n."}
],

facts:[
 {e:"⚡",c:"Lightning is hotter than the surface of the Sun.",t:true,x:"True! A bolt of lightning can heat the air to about five times hotter than the surface of the Sun."},
 {e:"💧",c:"Falling raindrops are shaped like tears.",t:false,x:"Not true! Small raindrops are round, and bigger ones are flattened, a bit like a burger bun."},
 {e:"🌈",c:"To see a rainbow, the sun must be behind you.",t:true,x:"True! Sunlight shines from behind you into the raindrops in front of you, and they split it into colours."},
 {e:"🏜️",c:"Antarctica is a desert.",t:true,x:"True! A desert is a place with very little precipitation, and Antarctica gets very little snow or rain each year."},
 {e:"⛈️",c:"Lightning never strikes the same place twice.",t:false,x:"Not true! Tall buildings like Toronto's CN Tower are struck by lightning many times every year."},
 {e:"🌫️",c:"Fog is really a cloud on the ground.",t:true,x:"True! Fog is made of the same tiny water droplets as a cloud. It just forms near the ground."},
 {e:"🇮🇳",c:"One of the wettest places on Earth is in India.",t:true,x:"True! Mawsynram in north-east India gets more rain than almost anywhere else in the world."},
 {e:"🥶",c:"A place in Canada once got as cold as −63 °C.",t:true,x:"True! In 1947, a village called Snag in the Yukon reached −63 °C, the coldest temperature ever recorded in North America."},
 {e:"🧊",c:"Hailstones can be as big as a grapefruit.",t:true,x:"True! Most hail is small, but some hailstones have been bigger than a grapefruit."},
 {e:"☁️",c:"Clouds are so light that they weigh almost nothing.",t:false,x:"Not true! An ordinary fluffy cloud can hold as much water as the weight of about 100 elephants. The droplets are just spread out very thinly."},
 {e:"🌍",c:"Winter happens because the Earth moves farther away from the Sun.",t:false,x:"Not true! Winter happens because your half of the Earth is tilted away from the Sun."},
 {e:"❄️",c:"Most snowflakes have six sides or six points.",t:true,x:"True! Because of the way water freezes, snowflakes usually form with six sides or six arms."}
],

writing:[
 {e:"📺",t:"Be a weather reporter",level:"Step 1 · Sentences",
  prompt:"Pretend you are on TV. Write a weather report for today in at least 4 sentences. Say what the sky looks like, the temperature, and what people should wear or bring. Use at least 2 weather words from the word bank.",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["Good morning! Here is the weather for ","Today will be ","The temperature is ","Don't forget your ","Tomorrow, the forecast says "],
  model:"Good morning! Here is the weather for Toronto. Today will be chilly and gloomy, with a light drizzle in the afternoon. The temperature is 9 degrees. Don't forget your umbrella and a warm jacket! Tomorrow, the forecast says it will be sunny and mild."},
 {e:"🍁",t:"My favourite season",level:"Step 2 · Paragraph",
  prompt:"Write a paragraph of at least 6 sentences about your favourite season. Describe what you can see, hear, feel, smell or taste. Say what you like to do. Use at least 3 describing words (adjectives) and a list with commas, like \"red, orange and yellow leaves\".",
  minS:6,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],
      ["\\w+, \\w+(, \\w+)* (and|or) \\w+","I wrote a list with commas (red, orange and yellow)"]],
  starters:["My favourite season is ","In this season, I can see ","I can hear ","The air smells ","I love to ","This season is special because "],
  model:"My favourite season is autumn. In autumn, I can see red, orange and yellow leaves falling from the trees. I can hear the leaves crunching under my boots. The air is chilly and smells of rain and woodsmoke. I love to jump into big piles of leaves with my brother. Autumn is special because we eat warm pumpkin soup and the days feel cosy."},
 {e:"⚖️",t:"Compare two seasons",level:"Step 3 · Compare",
  prompt:"Choose two seasons. Write at least 6 sentences comparing them. How are they the same? How are they different? Use comparing words like warmer, colder, longer, shorter, the hottest or the coldest. Use \"but\" to show a difference, and finish by saying which one you like better and why.",
  minS:6,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],
      ["\\b\\w+(er|est)\\b[\\s\\S]*\\b\\w+(er|est)\\b|\\b(better|best|worse|worst|more|most)\\b","I used comparing words (warmer, coldest, better…)"],
      ["\\bbut\\b","I used but to show a difference"],["\\b([Bb]oth|[Ss]ame|[Aa]like|[Aa]lso)\\b","I said how they are the same (both, also…)"]],
  starters:["Summer and winter are ","Both seasons ","Summer is warmer than ","but ","Winter has the shortest ","I like ___ better because "],
  model:"Summer and winter are very different seasons. Both seasons are fun for children, and both have school holidays. Summer is much warmer than winter, but freezing winter has beautiful, sparkling snow. The days in summer are longer, and winter has the shortest days of the year. In summer we swim, but in winter we go sledding. I like winter better because building a snowman is the most fun thing I know."}
]
});
})();
