/* ===================== GRADE 3 · UNIT 9 · FRIENDS AND FEELINGS (original content, plus one public-domain poem) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
const p=(q,a,o,why)=>({lv:"predict",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"friends", num:9, emoji:"🤝😊💛", title:"Friends and Feelings", badge:"💛 Kind Friend",

stories:[
/* ---------- 1. ORIGINAL FABLE ---------- */
{title:"Pip the Prickly Hedgehog (a fable)", e:"🦔", kind:"Fable", pages:[
 {pic:"🦔🌳", text:"At the edge of a quiet meadow lived a little hedgehog named Pip. Pip was cheerful and funny, and he loved his friends: Rosa the rabbit, Bramble the badger and Tilly the mouse. But Pip had a problem. Whenever his friends hugged him, his sharp spines poked them. \"Ouch!\" they would cry, and they quickly jumped back.",
  qs:[f("What kind of animal was Pip?","A hedgehog",["A rabbit","A mouse"],"…a little hedgehog named Pip."),
      f("What was Pip's problem?","His sharp spines poked his friends when they hugged him",["He had no friends","He was always angry"],"Whenever his friends hugged him, his sharp spines poked them."),
      t("How do you think Pip felt when his friends jumped back?","Sad and lonely",["Proud","Bored"],"He loved his friends, but they jumped away from him.")]},
 {pic:"🦔😢", text:"One evening, Pip sat alone under an oak tree. \"Nobody wants to be close to me,\" he whispered sadly. \"I'm too prickly.\" He decided to stay away from his friends so he would never hurt them again. The next day, when Rosa called, \"Pip, come and play!\" he hid inside a hollow log and didn't answer.",
  qs:[f("Where did Pip hide?","Inside a hollow log",["In a tree","Under the water"],"He hid inside a hollow log."),
      t("Why did Pip decide to stay away from his friends?","He didn't want to hurt them",["He was angry with them","He wanted to sleep"],"…so he would never hurt them again."),
      p("What do you think his friends will do?","Look for him because they miss him",["Forget about him","Be happy he is gone"],"Good friends notice when someone is missing.")]},
 {pic:"🐰🦡🐭", text:"His friends noticed at once. \"Where's Pip?\" asked Tilly worriedly. \"He hasn't played with us for three days,\" said Bramble. They searched the meadow carefully until Rosa saw a small nose poking out of the log. \"Pip! Why are you hiding?\" Pip slowly told them everything. \"I keep poking you. I'm not a good friend.\"",
  qs:[f("Who found Pip?","Rosa the rabbit",["Tilly the mouse","An owl"],"Rosa saw a small nose poking out of the log."),
      f("How long had Pip not played with them?","Three days",["Three weeks","One hour"],"\"He hasn't played with us for three days.\""),
      t("What does 'worriedly' tell us about Tilly?","She was worried about Pip",["She was laughing","She was sleepy"],"Worriedly is an adverb. It tells how Tilly asked.")]},
 {pic:"🧣🤗", text:"Bramble thought for a moment. Then he smiled. \"Your spines aren't a problem, Pip. They keep you safe from foxes! We just need a new way to hug.\" Tilly ran home and came back with a soft, woolly scarf. She gently wrapped it around Pip's back. One by one, each friend gave him a warm, careful hug, and nobody said ouch.",
  qs:[f("What did Tilly bring?","A soft, woolly scarf",["A pillow","A pair of scissors"],"She came back with a soft, woolly scarf."),
      f("What did Bramble say Pip's spines were good for?","Keeping him safe from foxes",["Digging","Swimming"],"\"They keep you safe from foxes!\""),
      t("What does this page show about Pip's friends?","They found a kind way to include him",["They wanted him to change","They were angry with him"],"Instead of asking Pip to be different, they found a new way to hug.")]},
 {pic:"🦔💛", text:"From that day on, Pip never hid again. Sometimes his friends hugged him with the scarf, and sometimes they gave him a high-five with a leaf. Pip learned that being different was not a problem, and his friends learned that kindness can always find a way. <b>Lesson: True friends don't ask you to change who you are. They find a way to be close.</b>",
  qs:[t("What is the lesson of this fable?","True friends don't ask you to change who you are",["Hedgehogs should live alone","Never hug anyone"],"His friends accepted his spines and found a new way to be close."),
      f("What else did the friends do instead of hugging?","A high-five with a leaf",["A dance","A race"],"…they gave him a high-five with a leaf."),
      t("How did Pip change from the beginning to the end?","He stopped hiding and felt accepted",["He lost his spines","He moved away"],"At first he hid because he felt different. At the end, he felt loved for who he was.")]}
], turn:{q:"What makes you different from your friends? How do your friends show they like you just as you are? Write two sentences.",model:"I am the only one in my class who speaks three languages. My friends ask me to teach them words in Bengali."}},

/* ---------- 2. STORY ---------- */
{title:"The New Girl", e:"🎒", kind:"Story", pages:[
 {pic:"🏫🎒", text:"On Monday morning, Ms. Chen walked into the Grade 3 classroom with a new student. \"Everyone, this is Yuki,\" she said. \"She has just moved to Toronto from Japan.\" Yuki held her backpack tightly and looked at the floor. She knew only a few words of English. Her cheeks turned pink when everyone stared at her.",
  qs:[f("Where did Yuki move from?","Japan",["India","Mexico"],"She has just moved to Toronto from Japan."),
      f("How much English did Yuki know?","Only a few words",["A lot","None at all"],"She knew only a few words of English."),
      t("How was Yuki feeling?","Nervous and shy",["Angry","Silly"],"She held her backpack tightly, looked at the floor, and her cheeks turned pink.")]},
 {pic:"🍙😟", text:"At lunchtime, Yuki sat alone at the end of the table. She opened a box of rice balls wrapped in seaweed. A boy named Leo wrinkled his nose. \"Ew, what's that?\" he said loudly. A few children giggled. Yuki quietly closed her lunch box. Mia saw a tear roll down Yuki's cheek.",
  qs:[f("What was in Yuki's lunch box?","Rice balls wrapped in seaweed",["A sandwich","Pizza"],"She opened a box of rice balls wrapped in seaweed."),
      t("How do you think Yuki felt when Leo said 'Ew'?","Hurt and embarrassed",["Proud","Excited"],"She quietly closed her lunch box, and a tear rolled down her cheek."),
      p("What do you think Mia will do?","Go and sit with Yuki",["Laugh with the others","Eat Yuki's lunch"],"Mia noticed Yuki's tear. That is a clue she cares.")]},
 {pic:"👧🏽👧🏻", text:"Mia picked up her tray and sat down next to Yuki. \"Hi,\" she said gently. \"I'm Mia.\" She pointed to her own lunch. \"Roti and dal. My grandma makes it.\" Yuki looked up, surprised. Mia pointed to the rice ball and asked, \"What's it called?\" \"Onigiri,\" said Yuki softly. \"It's my favourite.\" Mia smiled. \"Can I try one? I'll share my roti.\"",
  qs:[f("What did Mia have for lunch?","Roti and dal",["Onigiri","Pasta"],"\"Roti and dal. My grandma makes it.\""),
      f("What are Yuki's rice balls called?","Onigiri",["Sushi","Roti"],"\"Onigiri,\" said Yuki softly."),
      t("Why did Mia talk about her own lunch?","To show that everyone's food is different and special",["To show off","Because she was hungry"],"Mia showed Yuki that bringing food from your family is normal and nice.")]},
 {pic:"🦢📄", text:"The next day, Yuki brought a stack of square paper. In art class, she folded one quickly and carefully. In a minute, she was holding a paper crane! Everyone gathered around, even Leo. \"How did you do that?\" he asked. Yuki showed him slowly, fold by fold. Leo's crane was a bit crooked, but he was proud of it. \"Sorry I said 'Ew' yesterday,\" he mumbled. \"That was unkind.\"",
  qs:[f("What did Yuki make from paper?","A crane",["A boat","A hat"],"…she was holding a paper crane!"),
      f("What did Leo say to Yuki?","\"Sorry I said 'Ew' yesterday\"",["\"Go away\"","\"I don't like cranes\""],"\"Sorry I said 'Ew' yesterday,\" he mumbled."),
      t("Why do you think Leo said sorry?","He realized his words had hurt Yuki",["Ms. Chen made him","He wanted a crane"],"He said, \"That was unkind.\" He understood his mistake.")]},
 {pic:"🤝🌸", text:"Yuki smiled. \"It's okay,\" she said. Over the next weeks, Yuki learned new English words every day, and her friends learned some Japanese. <i>Arigato</i> means thank you, and <i>tomodachi</i> means friend. By spring, the whole class had made one thousand paper cranes to hang in the hallway. In Japan, people say a thousand cranes bring good luck and hope.",
  qs:[f("What does 'tomodachi' mean?","Friend",["Thank you","Hello"],"…tomodachi means friend."),
      f("How many paper cranes did the class make?","One thousand",["Ten","One hundred"],"…the whole class had made one thousand paper cranes."),
      t("What is the most important message of this story?","Kindness helps new people feel welcome",["Japanese food is the best","Paper cranes are hard to make"],"Mia's kindness changed everything for Yuki, and even Leo learned."),
      t("How did Yuki change from the first page to the last?","From nervous and alone to happy with friends",["From happy to sad","She did not change"],"At first she sat alone. At the end, she was teaching the whole class.")]}
], turn:{q:"Imagine a new student joins your class. Write three things you could do to help them feel welcome.",model:"I would say hello and tell them my name. I would sit with them at lunch. I would show them where the library is."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"What Are Feelings?", e:"🎭", kind:"Fact text", pages:[
 {pic:"😊😢😠😨", text:"Everyone has feelings, also called emotions. We can feel happy, sad, angry, scared, surprised, excited and many more. Feelings are not good or bad. They are messages from inside us. They tell us what we need. For example, feeling scared tells us to be careful, and feeling lonely tells us we need a friend.",
  qs:[f("What is another word for feelings?","Emotions",["Thoughts","Muscles"],"Everyone has feelings, also called emotions."),
      f("What does feeling scared tell us?","To be careful",["To go to sleep","To eat something"],"Feeling scared tells us to be careful."),
      t("Are feelings good or bad?","Neither: they are messages that tell us what we need",["Only happy feelings are good","All feelings are bad"],"Feelings are not good or bad. They are messages from inside us.")]},
 {pic:"💓🫁", text:"Our bodies show our feelings too. When you are nervous, your heart may beat fast and your tummy may feel funny, like butterflies. When you are angry, your face may feel hot and your hands may make fists. When you are happy, you might smile, laugh or want to jump. Noticing these signals helps you understand what you are feeling.",
  qs:[f("What might your tummy feel like when you are nervous?","Like butterflies",["Like ice cream","Like a rock"],"…your tummy may feel funny, like butterflies."),
      f("What may your hands do when you are angry?","Make fists",["Wave","Clap"],"…your hands may make fists."),
      t("Why is it helpful to notice your body's signals?","They help you understand your feelings",["They make you taller","They stop you from feeling anything"],"Noticing these signals helps you understand what you are feeling.")]},
 {pic:"🌬️🔢", text:"Big feelings can be hard to handle. But there are ways to calm down. You can take slow, deep breaths: breathe in while you count to four, then breathe out slowly. You can count to ten, get a drink of water, squeeze a soft toy, or go to a quiet place for a few minutes. Moving your body, like walking or stretching, can help too.",
  qs:[f("How long should you breathe in?","While you count to four",["For one hour","Not at all"],"Breathe in while you count to four."),
      f("Which of these is a way to calm down?","Squeeze a soft toy",["Shout at a friend","Throw your books"],"You can… squeeze a soft toy."),
      t("Why might moving your body help when you are upset?","It helps your body let go of the big feeling",["It makes you hungry","It makes the feeling bigger"],"Moving your body, like walking or stretching, can help too.")]},
 {pic:"🗣️❤️", text:"One of the best ways to handle a feeling is to talk about it. You can say, \"I feel sad because my friend moved away,\" or \"I feel frustrated because this puzzle is hard.\" Talking to a parent, a teacher or a friend you trust can make a heavy feeling feel lighter. Nobody has to handle big feelings alone.",
  qs:[f("Which sentence names a feeling and a reason?","\"I feel frustrated because this puzzle is hard.\"",["\"Puzzles exist.\"","\"Go away!\""],"\"I feel frustrated because this puzzle is hard.\""),
      f("Who can you talk to about your feelings?","A parent, a teacher or a friend you trust",["Nobody","Only a stranger online"],"Talking to a parent, a teacher or a friend you trust…"),
      t("What does 'a heavy feeling feel lighter' mean?","The feeling becomes easier to carry",["You lose weight","The feeling becomes a balloon"],"It is a way of saying talking helps you feel better.")]},
 {pic:"👀🤝", text:"We can also notice other people's feelings. Look at their face, listen to their voice and watch their body. If a friend looks sad, you can ask, \"Are you okay?\" Understanding how someone else feels is called <b>empathy</b>. Empathy helps us be kind, make friends and solve problems together.",
  qs:[f("What is empathy?","Understanding how someone else feels",["Being very strong","Running fast"],"Understanding how someone else feels is called empathy."),
      f("What can you ask a friend who looks sad?","\"Are you okay?\"",["\"Why are you so silly?\"","\"Go away!\""],"You can ask, \"Are you okay?\""),
      t("What is the main idea of this whole text?","Feelings are normal, and we can understand and handle them",["Never show your feelings","Only grown-ups have feelings"],"Each page teaches how to understand, handle or notice feelings.")]}
], turn:{q:"Write about a time you felt a big feeling. What was the feeling? What helped you feel better?",model:"I felt nervous before my piano concert. Taking deep breaths and seeing my mom smile helped me feel calm."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"How to Be a Good Friend", e:"🤝", kind:"Fact text", pages:[
 {pic:"👂💬", text:"Good friends <b>listen</b>. When your friend is talking, look at them, nod, and don't interrupt. Ask questions like, \"What happened next?\" or \"How did you feel?\" When people feel listened to, they feel cared for. Listening is one of the kindest things you can do.",
  qs:[f("What should you do when your friend is talking?","Look at them, nod and don't interrupt",["Talk at the same time","Look at your phone"],"Look at them, nod, and don't interrupt."),
      t("Why is listening important in a friendship?","It makes people feel cared for",["It makes you sleepy","It is a rule at school only"],"When people feel listened to, they feel cared for.")]},
 {pic:"🎲🔄", text:"Good friends <b>share and take turns</b>. Games are more fun when everyone gets a chance. If you both want the same toy, you can take turns, play together, or find another toy. Saying \"You go first\" is a small act of kindness that makes a big difference.",
  qs:[f("What can you do if you both want the same toy?","Take turns or play together",["Grab it","Hide it"],"You can take turns, play together, or find another toy."),
      t("Why are games more fun when everyone gets a chance?","Everyone feels included and happy",["Games last forever","Nobody wins"],"Taking turns is fair, and everyone enjoys it.")]},
 {pic:"🙏💛", text:"Good friends <b>say sorry</b> and <b>forgive</b>. Everyone makes mistakes. A good apology says what you did, says sorry, and says how you will fix it: \"I'm sorry I broke your pencil. I'll give you one of mine.\" When a friend says sorry to you, try to forgive them. Forgiving helps friendships grow stronger.",
  qs:[f("What three things does a good apology include?","What you did, sorry, and how you'll fix it",["Only the word sorry","An excuse and a joke"],"A good apology says what you did, says sorry, and says how you will fix it."),
      t("Why is forgiving important?","It helps friendships grow stronger",["It means the mistake never happened","It makes you the winner"],"Forgiving helps friendships grow stronger.")]},
 {pic:"🧒🏿🧒🏼🧒🏽", text:"Good friends <b>include others</b>. Look around the playground. Is someone playing alone? You could say, \"Do you want to join us?\" Some schools have a <b>buddy bench</b>. If someone sits on it, it means they would like someone to play with. Including others makes everyone feel like they belong.",
  qs:[f("What does it mean if someone sits on a buddy bench?","They would like someone to play with",["They are being punished","They are tired"],"…it means they would like someone to play with."),
      t("What could you say to someone playing alone?","\"Do you want to join us?\"",["\"Go away.\"","\"You can't play.\""],"You could say, \"Do you want to join us?\"")]},
 {pic:"🛡️🧑‍🏫", text:"Good friends <b>stand up for each other</b>. If someone is being teased or bullied, don't join in. You can say, \"Stop, that's not kind,\" stay with the person who is being hurt, and tell a trusted adult. Telling an adult is not tattling when someone is being hurt. It is being brave. A good friend is honest, loyal and kind, and you can learn to be one every day.",
  qs:[f("What should you do if someone is being bullied?","Say stop, stay with them and tell a trusted adult",["Join in","Walk away and say nothing"],"You can say, \"Stop, that's not kind,\" stay with the person… and tell a trusted adult."),
      f("Telling an adult when someone is hurt is…","Being brave",["Tattling","Being mean"],"Telling an adult is not tattling when someone is being hurt. It is being brave."),
      t("Which words describe a good friend, according to the text?","Honest, loyal and kind",["Bossy and rude","Selfish and careless"],"A good friend is honest, loyal and kind.")]}
], turn:{q:"Which of these friend skills are you best at? Which one do you want to practise more? Write two sentences.",model:"I am good at taking turns. I want to practise listening without interrupting."}},

/* ---------- 5. STORY ---------- */
{title:"The Broken Bridge", e:"🌉", kind:"Story", pages:[
 {pic:"🌉🧱", text:"Dev and Sam had been best friends since kindergarten. For the school science fair, they spent two whole weeks building a bridge out of craft sticks and glue. It was strong enough to hold ten heavy books! On the morning of the fair, Sam carried the bridge carefully down the hallway. Then a boy ran past, bumped Sam's elbow, and the bridge crashed to the floor.",
  qs:[f("What did Dev and Sam build?","A bridge out of craft sticks",["A robot","A volcano"],"…building a bridge out of craft sticks and glue."),
      f("How many books could the bridge hold?","Ten",["Two","One hundred"],"It was strong enough to hold ten heavy books!"),
      t("Whose fault was the crash?","Nobody meant it: a boy bumped Sam by accident",["Dev broke it on purpose","Sam threw it"],"A boy ran past and bumped Sam's elbow.")]},
 {pic:"😠💔", text:"Dev stared at the broken pieces. His face felt hot. \"You dropped it!\" he shouted angrily. \"You ruined everything!\" Sam's eyes filled with tears. \"It wasn't my fault!\" he shouted back. \"Someone bumped me!\" Dev turned and stomped away. For the rest of the morning, the two friends didn't speak to each other.",
  qs:[f("What did Dev shout?","\"You dropped it! You ruined everything!\"",["\"It's okay!\"","\"Let's fix it!\""],"\"You dropped it!\" he shouted angrily."),
      t("How was Dev feeling?","Angry and upset",["Calm and happy","Bored"],"His face felt hot, he shouted angrily, and he stomped away."),
      t("Was it fair for Dev to blame Sam?","No, because someone bumped Sam by accident",["Yes, Sam did it on purpose","Yes, Sam is clumsy"],"Sam didn't drop it on purpose.")]},
 {pic:"🧑‍🏫💭", text:"At lunch, their teacher, Mr. Ali, sat down next to Dev. \"You look upset,\" he said gently. Dev took a deep breath. \"I'm sad because our bridge broke, and I'm angry because I worked so hard.\" Mr. Ali nodded. \"Those feelings make sense. But how do you think Sam is feeling?\" Dev thought about Sam's tears. \"Sad,\" he said quietly. \"And probably upset that I blamed him.\"",
  qs:[f("Who talked to Dev at lunch?","Mr. Ali, his teacher",["Sam's mom","The principal"],"Their teacher, Mr. Ali, sat down next to Dev."),
      f("How did Dev describe his feelings?","\"I'm sad because our bridge broke, and I'm angry because I worked so hard.\"",["\"I'm fine.\"","\"I'm happy.\""],"Dev named his feelings and the reasons."),
      t("Why did Mr. Ali ask how Sam was feeling?","To help Dev think about Sam's feelings (empathy)",["To blame Sam","To change the subject"],"Thinking about how others feel is called empathy."),
      p("What do you think Dev will do next?","Say sorry to Sam",["Shout at Sam again","Go home"],"Dev now understands that Sam is sad too.")]},
 {pic:"🙏🤝", text:"Dev found Sam sitting on the buddy bench. \"Sam,\" he said, \"I'm sorry I shouted at you and blamed you. It wasn't your fault. I was upset, but that's not an excuse.\" Sam wiped his eyes. \"I'm sorry too. I shouldn't have shouted back.\" Then Sam had an idea. \"The fair doesn't start until two o'clock. Do you think we could fix it?\"",
  qs:[f("Where was Sam sitting?","On the buddy bench",["In the library","On the bus"],"Dev found Sam sitting on the buddy bench."),
      f("What did Dev say he was sorry for?","Shouting at Sam and blaming him",["Being late","Losing the glue"],"\"I'm sorry I shouted at you and blamed you.\""),
      t("What made Dev's apology a good one?","He said what he did wrong and didn't make excuses",["He said sorry very loudly","He gave Sam money"],"\"I was upset, but that's not an excuse.\"")]},
 {pic:"🌉🏅", text:"The two friends raced to the art room and worked quickly together. They glued the pieces back and added extra sticks to make the bridge even stronger. At the fair, it held fifteen books, five more than before! The judges gave them a ribbon for \"Best Teamwork\". Dev grinned at Sam. \"Our bridge broke,\" he said, \"but our friendship didn't.\"",
  qs:[f("How many books did the fixed bridge hold?","Fifteen",["Ten","Five"],"At the fair, it held fifteen books, five more than before!"),
      f("What ribbon did they win?","Best Teamwork",["Best Painting","Fastest Bridge"],"The judges gave them a ribbon for \"Best Teamwork\"."),
      t("What does Dev mean by \"our friendship didn't\" break?","They solved their argument and are still friends",["Friendship is made of sticks","They aren't friends anymore"],"Even after a fight, they forgave each other and worked together."),
      t("What is the lesson of this story?","Saying sorry and working together can fix problems",["Never build bridges","Always blame others"],"The apology helped them fix both the bridge and their friendship.")]}
], turn:{q:"Write about a time you had a disagreement with a friend. How did you solve it?",model:"My sister and I both wanted the swing. We decided to take turns and count to fifty each."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A friendly letter and a feelings chart", e:"✉️", kind:"Real-world text", pages:[
 {pic:"✉️🦢", text:"Yuki wrote a letter to her friend Hana in Japan. Look at the five parts of a friendly letter.<div class=\"realdoc\" style=\"text-align:left\"><span style=\"color:var(--muted)\">① date →</span> <b>May 3, 2027</b><br><br><span style=\"color:var(--muted)\">② greeting →</span> <b>Dear Hana,</b><br><br><span style=\"color:var(--muted)\">③ body →</span> How are you? I miss you so much! At first, my new school in Toronto was scary because I didn't know anyone. Now I have a best friend named Mia. She's really kind, and she always helps me with English. Last week, I taught my whole class how to fold paper cranes. We made one thousand! Do you still go to the park after school? Please write back soon.<br><br><span style=\"color:var(--muted)\">④ closing →</span> <b>Your friend,</b><br><span style=\"color:var(--muted)\">⑤ signature →</span> <b>Yuki</b></div>",
  qs:[f("Who is the letter to?","Hana",["Mia","Ms. Chen"],"Dear Hana,"),
      f("What is the closing of the letter?","Your friend,",["Dear Hana,","May 3, 2027"],"④ closing → Your friend,"),
      f("Why was the new school scary at first?","Yuki didn't know anyone",["The building was dark","There was no lunch"],"…was scary because I didn't know anyone."),
      t("Why does Yuki ask Hana questions in the letter?","To show she cares and to help Hana write back",["Because she forgot","To test Hana"],"Friendly letters often ask questions so the friend can answer."),
      f("Which word is a contraction in the letter?","didn't",["scary","friend"],"didn't = did not.")]},
 {pic:"🌡️😀", text:"This chart hangs on the wall in Ms. Chen's classroom.<table class=\"realtbl\"><tr><th>If I feel…</th><th>I can…</th></tr><tr><td>😠 Angry</td><td>Take 5 deep breaths. Walk away and cool down.</td></tr><tr><td>😢 Sad</td><td>Talk to a friend or a teacher. Hug a soft toy.</td></tr><tr><td>😟 Worried</td><td>Tell a grown-up what is worrying me.</td></tr><tr><td>😤 Frustrated</td><td>Take a break, then try again. Ask for help.</td></tr><tr><td>😔 Lonely</td><td>Sit on the buddy bench. Ask someone to play.</td></tr><tr><td>😁 Happy</td><td>Share it! Say something kind to someone.</td></tr></table>",
  qs:[f("What can you do if you feel frustrated?","Take a break, then try again, and ask for help",["Sit on the buddy bench","Hug a soft toy"],"😤 Frustrated: Take a break, then try again. Ask for help."),
      f("How many deep breaths does the chart suggest when you are angry?","5",["10","1"],"Take 5 deep breaths."),
      t("Sam has nobody to play with at recess. Which row should he read?","Lonely",["Angry","Happy"],"Feeling alone is feeling lonely."),
      t("Why is it useful to have this chart in a classroom?","It helps children choose a good way to handle feelings",["It is a maths lesson","It shows the lunch menu"],"It gives ideas for each feeling.")]}
], turn:{q:"Write the greeting and the first two sentences of a friendly letter to someone you miss.",model:"Dear Grandma,\nI miss you so much. I can't wait to visit you in the summer."}}
],

poems:[
 {title:"A Good Play (by Robert Louis Stevenson, 1885)",
  lines:["We built a ship upon the stairs","All made of the back-bedroom chairs,","And filled it full of sofa pillows","To go a-sailing on the billows.","","We took a saw and several nails,","And water in the nursery pails;","And Tom said, \"Let us also take","An apple and a slice of cake;\"","Which was enough for Tom and me","To go a-sailing on, till tea.","","We sailed along for days and days,","And had the very best of plays;","But Tom fell out and hurt his knee,","So there was no one left but me."],
  qs:[f("What did the children use to build their ship?","Chairs from the back bedroom",["Real wood and sails","Cardboard boxes"],"\"All made of the back-bedroom chairs.\""),
      f("What did Tom want to take?","An apple and a slice of cake",["A dog","A map"],"\"Let us also take an apple and a slice of cake.\""),
      t("Is the ship real or pretend?","Pretend: they are using their imagination",["Real: they sailed on the ocean","Real: it was a big boat"],"The 'ship' is made of chairs on the stairs, and the 'billows' are pillows."),
      t("How do you think the speaker feels at the end?","Lonely, because the game ended",["Proud","Angry at Tom"],"\"So there was no one left but me.\" Playing is more fun with a friend."),
      f("Which word rhymes with 'pillows'?","billows",["stairs","nails"],"Pillows and billows end with the same sound.")]},
 {title:"Feelings Are Like Weather",
  lines:["Some days I'm sunny, warm and bright,","I laugh and play from morning light.","Some days I'm cloudy, grey and slow,","And where my smile went, I don't know.","Sometimes I'm stormy, loud and red,","With thunder rumbling in my head.","But weather changes, rain or shine,","And every feeling passes. That's fine!"],
  qs:[f("What does the poet do on sunny days?","Laughs and plays",["Cries","Hides"],"\"I laugh and play from morning light.\""),
      t("What feeling is 'stormy, loud and red' most like?","Angry",["Calm","Sleepy"],"Thunder and red are often used to describe anger."),
      t("What is the message of the last two lines?","Feelings change and pass, like the weather",["It always rains","Never feel angry"],"\"But weather changes… And every feeling passes.\""),
      f("Which word rhymes with 'red'?","head",["slow","fine"],"Red and head end with the same sound.")]}
],

words:[
 /* feelings */
 {w:"cheerful",e:"😄",m:"happy and full of good spirits",ex:"Pip was cheerful and funny.",fill:"She is always ___ and smiling in the morning."},
 {w:"nervous",e:"😬",m:"a little scared or worried about something that will happen",ex:"Yuki felt nervous on her first day.",fill:"I feel ___ before a test."},
 {w:"lonely",e:"😔",m:"sad because you are alone or have no friends with you",ex:"Pip felt lonely inside the log.",fill:"The new boy felt ___ at recess."},
 {w:"jealous",e:"😒",m:"unhappy because someone has something you want",ex:"Sam felt jealous of his sister's new bike.",fill:"Don't be ___; you will get a turn too."},
 {w:"grateful",e:"🙏",m:"thankful for something someone did or gave",ex:"I am grateful for my friends.",fill:"She was ___ for the help."},
 {w:"frustrated",e:"😤",m:"annoyed because you cannot do something",ex:"I felt frustrated because the puzzle was hard.",fill:"He felt ___ when his model kept falling down."},
 {w:"embarrassed",e:"😳",m:"feeling shy and uncomfortable because people are looking at you",ex:"Yuki felt embarrassed when everyone stared.",fill:"I was ___ when I tripped on the stage."},
 {w:"excited",e:"🤩",m:"very happy about something good that is going to happen",ex:"We were excited about the science fair.",fill:"I'm so ___ about my birthday party!"},
 {w:"worried",e:"😟",m:"thinking a lot about something bad that might happen",ex:"Tilly was worried about Pip.",fill:"Mom was ___ because I was late."},
 {w:"calm",e:"😌",m:"quiet and peaceful; not upset",ex:"Deep breaths helped Dev feel calm.",fill:"Take a deep breath and stay ___."},
 /* friendship */
 {w:"friendship",e:"🤝",m:"the special bond between friends",ex:"Their friendship grew stronger after the argument.",fill:"Our ___ started in kindergarten."},
 {w:"kindness",e:"💛",m:"being friendly, caring and helpful",ex:"Mia's kindness made Yuki feel welcome.",fill:"Small acts of ___ make a big difference."},
 {w:"trust",e:"🔐",m:"to believe that someone is honest and will not hurt you",ex:"I trust my best friend with my secrets.",fill:"You can ___ a good friend."},
 {w:"honest",e:"🗣️",m:"telling the truth",ex:"A good friend is honest.",fill:"Be ___ and tell the truth."},
 {w:"loyal",e:"🐕",m:"always on your side and ready to help",ex:"A loyal friend stands up for you.",fill:"My dog is very ___; he follows me everywhere."},
 {w:"include",e:"➕",m:"to let someone join in",ex:"Always include others in your games.",fill:"Let's ___ the new girl in our game."},
 {w:"apologize",e:"🙇",m:"to say sorry",ex:"Leo apologized to Yuki.",fill:"You should ___ when you hurt someone's feelings.",alt:["apologise"]},
 {w:"forgive",e:"🕊️",m:"to stop being angry with someone who said sorry",ex:"Sam decided to forgive Dev.",fill:"Please ___ me; I'm really sorry."},
 {w:"respect",e:"🙌",m:"to treat someone and their feelings as important",ex:"We respect each other's ideas.",fill:"Show ___ by listening when others talk."},
 {w:"compliment",e:"🌟",m:"something nice you say about someone",ex:"Mia gave Yuki a compliment on her crane.",fill:"I gave my friend a ___: \"Your drawing is amazing!\""},
 /* adverbs */
 {w:"quickly",e:"⚡",m:"in a fast way",ex:"The friends worked quickly to fix the bridge.",fill:"The rabbit ran ___ across the field."},
 {w:"slowly",e:"🐢",m:"in a slow way",ex:"Yuki showed Leo slowly, fold by fold.",fill:"The turtle walked ___."},
 {w:"gently",e:"🪶",m:"in a soft, careful way",ex:"Tilly gently wrapped the scarf around Pip.",fill:"Hold the baby bird ___."},
 {w:"quietly",e:"🤫",m:"without making much noise",ex:"Yuki quietly closed her lunch box.",fill:"Please talk ___ in the library."},
 {w:"loudly",e:"📢",m:"with a lot of noise",ex:"Leo said \"Ew\" loudly.",fill:"The crowd cheered ___."},
 {w:"carefully",e:"🔍",m:"with care, so nothing goes wrong",ex:"Sam carried the bridge carefully.",fill:"Cross the road ___."},
 {w:"happily",e:"😊",m:"in a happy way",ex:"The children played happily together.",fill:"The dog wagged its tail ___."},
 {w:"sadly",e:"😢",m:"in a sad way",ex:"\"Nobody wants me,\" Pip whispered sadly.",fill:"She waved goodbye ___."},
 {w:"politely",e:"🎩",m:"in a polite, good-mannered way",ex:"He asked politely, \"May I play too?\"",fill:"Ask ___ and say please."},
 {w:"bravely",e:"🦁",m:"in a brave way",ex:"She bravely told the teacher about the bullying.",fill:"The firefighter ___ ran into the building."},
 /* -ful and -less */
 {w:"helpful",e:"🤲",m:"full of help; giving help",ex:"Mia is helpful in class.",fill:"Thank you for being so ___!"},
 {w:"thoughtful",e:"💭",m:"thinking about what other people need",ex:"It was thoughtful of Tilly to bring a scarf.",fill:"What a ___ present!"},
 {w:"hopeful",e:"🌈",m:"full of hope that something good will happen",ex:"Yuki felt hopeful about her new school.",fill:"We are ___ that it will be sunny tomorrow."},
 {w:"peaceful",e:"🕊️",m:"calm and quiet",ex:"The meadow was peaceful in the evening.",fill:"The lake was still and ___."},
 {w:"playful",e:"🐶",m:"full of fun; liking to play",ex:"The playful puppy chased its tail.",fill:"Kittens are very ___."},
 {w:"careless",e:"🫗",m:"without care; not careful",ex:"It was careless to leave the glue open.",fill:"Don't be ___ with your new tablet."},
 {w:"fearless",e:"🦸",m:"without fear; very brave",ex:"The fearless girl climbed to the top.",fill:"The ___ explorer walked into the dark cave."},
 {w:"helpless",e:"🐣",m:"not able to look after yourself",ex:"A newborn kitten is helpless.",fill:"Baby birds are ___ without their parents."},
 {w:"hopeless",e:"😞",m:"without hope; feeling nothing will get better",ex:"At first, fixing the bridge seemed hopeless.",fill:"Don't feel ___; we can try again."},
 {w:"harmless",e:"🐞",m:"not able to hurt anyone",ex:"Ladybugs are harmless.",fill:"The little snake was ___."}
],

spelling:[
 {w:"friend",s:"Mia is my friend.",tip:"'i before e': fr-ie-nd."},
 {w:"kind",s:"Be kind to others."},
 {w:"happy",s:"I feel happy today.",tip:"Double p, ends with y."},
 {w:"angry",s:"Dev was angry."},
 {w:"sorry",s:"I am sorry.",tip:"Double r, ends with y."},
 {w:"share",s:"Let's share the toys.",tip:"'are' as in care."},
 {w:"smile",s:"She has a big smile.",tip:"Magic e: sm-i-le."},
 {w:"laugh",s:"The joke made me laugh.",tip:"'augh' sounds like 'af'."},
 {w:"feel",s:"How do you feel?",tip:"Double e."},
 {w:"heart",s:"My heart is beating fast.",tip:"It has 'ear' inside: h-ear-t."},
 {w:"brave",s:"Be brave and tell the truth.",tip:"Magic e: br-a-ve."},
 {w:"calm",s:"Take a breath and stay calm.",tip:"The 'l' is silent."},
 {w:"hug",s:"Give me a hug!"},
 {w:"tears",s:"Tears rolled down her cheeks.",tip:"'ea' says long e here."},
 {w:"nervous",s:"I feel nervous.",tip:"ner-vous. Ends with -ous."}
],

facts:[
 {e:"😂",c:"Laughter is contagious: when you hear someone laugh, you are more likely to laugh too.",t:true,x:"True! Our brains are wired to copy the laughter of people around us."},
 {e:"🐘",c:"Elephants comfort friends who are upset.",t:true,x:"True! Scientists have seen Asian elephants gently touch and make soft sounds to calm a worried friend."},
 {e:"🐶",c:"Dogs can tell the difference between happy and angry human faces.",t:true,x:"True! Studies show dogs can recognize human facial expressions."},
 {e:"😢",c:"It is wrong to feel sad.",t:false,x:"Not true! Every feeling is normal. Sadness tells us we care about something."},
 {e:"🦦",c:"Sea otters sometimes hold hands while they sleep.",t:true,x:"True! They do this so they don't drift apart in the water."},
 {e:"🐧",c:"Some penguins give pebbles as presents.",t:true,x:"True! Gentoo penguins give pebbles to their partners to help build nests."},
 {e:"🌬️",c:"Slow, deep breaths can help you calm down.",t:true,x:"True! Breathing slowly tells your body that you are safe."},
 {e:"👫",c:"You can have only one friend at a time.",t:false,x:"Not true! You can have many friends, and they can all be special in different ways."},
 {e:"👶",c:"Newborn babies like to look at faces more than at other shapes.",t:true,x:"True! Babies are born ready to connect with people."},
 {e:"🐀",c:"Some rats help free other rats that are trapped.",t:true,x:"True! In a famous experiment, rats worked hard to open a cage to free a trapped friend."},
 {e:"🤗",c:"Hugging someone you love can help you feel calmer.",t:true,x:"True! A hug can help your body relax and feel safe."},
 {e:"😠",c:"Only bad people feel angry.",t:false,x:"Not true! Everyone feels angry sometimes. What matters is what we do with the feeling."}
],

writing:[
 {e:"🎭",t:"How I feel when…",level:"Step 1 · Sentences",
  prompt:"Write at least 4 sentences about your feelings. Use the pattern \"I feel ___ when ___\" or \"I feel ___ because ___\". Use at least 3 different feeling words from the word bank.",
  minS:4,minWords:3,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["(\\bI feel\\b[\\s\\S]*){3}","I used 'I feel' at least 3 times"],["\\b(when|because)\\b","I used when or because"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["I feel excited when ","I feel nervous when ","I feel grateful because ","I feel calm when "],
  model:"I feel excited when my cousins come to visit. I feel nervous when I have to speak in front of the class. I feel frustrated when my little brother breaks my things. I feel calm when I read in my room. I feel grateful because my family loves me."},
 {e:"🤝",t:"What makes a good friend",level:"Step 2 · Paragraph",
  prompt:"Write a paragraph of at least 5 sentences about what makes a good friend. Use at least 2 adverbs (like gently, kindly, quickly) and at least 2 contractions (like don't, it's, I'm). Use at least 2 words from the word bank.",
  minS:5,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["(\\b\\w{3,}ly\\b[\\s\\S]*){2}","I used at least 2 adverbs ending in -ly"],["(\\b\\w+'(t|s|m|re|ll|ve|d)\\b[\\s\\S]*){2}","I used at least 2 contractions"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["A good friend is ","They listen carefully ","They don't ","When I'm sad, ","That's why "],
  model:"A good friend is kind, honest and loyal. They listen carefully when you talk, and they don't interrupt. When I'm sad, my best friend Ava sits with me quietly until I feel better. She's always ready to include new people in our games. That's why I think kindness is the most important thing in a friendship."},
 {e:"✉️",t:"A friendly letter",level:"Step 3 · Friendly letter",
  prompt:"Write a friendly letter to a friend or family member. Include all five parts: the date, a greeting (Dear …,), the body (at least 5 sentences), a closing (Your friend, / Love,) and your name. In the body, share some news, tell how you feel, and ask at least one question.",
  minS:5,minWords:2,
  rx:[["\\b(January|February|March|April|May|June|July|August|September|October|November|December)\\s+\\d{1,2}","I wrote the date"],["\\bDear\\s+[A-Z]\\w*,","I wrote a greeting (Dear …,)"],["\\?","I asked at least one question"],["\\bI (feel|felt|am|was)\\b|\\b(happy|sad|excited|nervous|grateful|lonely|proud|calm)\\b","I told how I feel"],["(Your friend|Love|Your cousin|Your grandson|Your granddaughter|From|Best wishes),\\s*\\n\\s*[A-Z]\\w*","I wrote a closing and my name"],["\\b\\w+'(t|s|m|re|ll|ve|d)\\b","I used a contraction"]],
  starters:["October 4, 2026\n\n","Dear ,\n","How are you? ","I'm writing to tell you ","I feel ","Do you ","Your friend,\n"],
  model:"October 4, 2026\n\nDear Hana,\nHow are you? I'm writing to tell you about my new school. At first, I felt nervous because I didn't know anyone. Now I have a kind friend named Mia, and she always helps me happily. Last week, we made one thousand paper cranes with our class! I miss you very much. Do you still play in the park after school? Please write back soon.\n\nYour friend,\nYuki"}
]
});
})();
