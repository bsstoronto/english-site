/* ===================== GRADE 1 · UNIT 4 · YUMMY FOOD ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:1,id:"g1_food",num:4,emoji:"🍲🥕🍌",title:"Yummy Food",short:"short o, action words, food and colours",badge:"🍲 Little Chef",
stories:[
/* 1 PROBLEM AND HAPPY ENDING */
{title:"Dot and the Hot Pot",e:"🍲",kind:"Story",pages:[
 {pic:"👧🏻👴🏻🍲",text:"This is Dot. Dot lives in Toronto. Dot likes to cook with Grandpa. Today they will make soup. Grandpa gets a big pot. Dot gets the carrots and peas. \"Yum!\" said Dot.",
  qs:[f("Who does Dot cook with?","Grandpa",["Mom","Her dog"],"Dot likes to cook with Grandpa."),
      f("What will they make?","Soup 🍲",["Cake 🎂","Noodles 🍜"],"Today they will make soup.")]},
 {pic:"🔥🍲😟",text:"Grandpa puts the pot on the stove. The soup gets hot. Dot wants to stir it. But the pot is too hot! Dot cannot hold it. Dot is sad. \"I want to help,\" she said.",
  qs:[f("What is the problem?","The pot is too hot",["The pot is lost","Dot is sick"],"But the pot is too hot!"),
      p("What do you think Grandpa will do?","Find a safe way for Dot to help",["Send Dot to bed","Throw the soup away"],"Grandpa wants Dot to help, so he will find a safe job.")]},
 {pic:"🧤🥄😊",text:"Grandpa has a plan. He gives Dot a long spoon. He gives her a big oven mitt. Grandpa holds the pot. Dot can stir the soup! Stir, stir, stir. Dot is not sad now.",
  qs:[f("What does Grandpa give Dot?","A long spoon and a mitt",["A cup and a hat","A box and a rock"],"He gives Dot a long spoon. He gives her a big oven mitt."),
      t("How does Dot feel now?","Happy 😊",["Sad 😢","Angry 😠"],"Dot is not sad now. She can help!")]},
 {pic:"🥣🥣😋",text:"The soup is ready. Dot and Grandpa sit down. They have soup in red bowls. \"This is the best soup!\" said Grandpa. \"We made it together,\" said Dot. They have a hot, yummy dinner.",
  qs:[f("What colour are the bowls?","Red 🔴",["Blue 🔵","Green 🟢"],"They have soup in red bowls."),
      t("Why is the soup special?","They made it together",["It was cold","It came from a shop"],"\"We made it together,\" said Dot.")]}
],turn:{q:"Who do you like to cook or eat with? Write one sentence.",model:"I like to cook with my mom."}},
/* 2 NON-FICTION */
{title:"Fruits and Vegetables",e:"🥦",kind:"Non-fiction",pages:[
 {pic:"🍎🥭🍇",text:"Fruits grow on plants. Some fruits grow on trees. Apples and mangoes grow on trees. Grapes grow on vines. Most fruits have seeds inside. Many fruits taste sweet.",
  qs:[f("Where do mangoes grow?","On trees 🌳",["Under the ground","In the sea"],"Apples and mangoes grow on trees."),
      f("What do most fruits have inside?","Seeds",["Rocks","Socks"],"Most fruits have seeds inside.")]},
 {pic:"🥕🥔🫛",text:"Vegetables grow on plants too. Carrots grow under the ground. We eat the root. Potatoes grow under the ground too. Lettuce is a leaf. Peas grow in pods.",
  qs:[f("Where do carrots grow?","Under the ground",["On trees","In pods"],"Carrots grow under the ground."),
      f("What grows in pods?","Peas 🫛",["Potatoes 🥔","Lettuce 🥬"],"Peas grow in pods.")]},
 {pic:"🍓🍌🥦",text:"Fruits and vegetables come in many colours. Strawberries are red. Bananas are yellow. Broccoli is green. Blueberries are blue. Try to eat many colours every day!",
  qs:[f("What colour is broccoli?","Green 🟢",["Red 🔴","Yellow 🟡"],"Broccoli is green."),
      p("What do you think the next page is about?","How these foods help us",["How to fly a kite","A big storm"],"The pages are all about fruits and vegetables.")]},
 {pic:"💪🏃🧒🏾",text:"Fruits and vegetables help your body. They help you grow. They help you run and play. You can have them for a snack. What fruit do you like?",
  qs:[f("What do fruits and vegetables help you do?","Grow, run and play",["Sleep all day","Fly like a bird"],"They help you grow. They help you run and play."),
      t("Which one is a good snack?","A pear 🍐",["A rock 🪨","A shoe 👟"],"A pear is a fruit, so it is a good snack.")]}
],turn:{q:"Name a fruit or vegetable you like. What colour is it?",model:"I like mangoes. They are orange and yellow."}},
/* 3 PATTERNED TEXT */
{title:"What Is in the Box?",e:"📦",kind:"Patterned text",pages:[
 {pic:"👦🏽📦❓",text:"Tom has a big box. \"What is in the box?\" said Ana. \"Is it a fox?\" \"No, it is not a fox.\" \"Is it a frog?\" \"No, it is not a frog.\"",
  qs:[f("What does Tom have?","A big box 📦",["A big pot 🍲","A big dog 🐶"],"Tom has a big box."),
      p("What do you think is in the box?","Something to eat",["A real fox","A big car"],"This unit is about food. Look for clues!")]},
 {pic:"🧦🪨❓",text:"\"Is it a sock?\" \"No, it is not a sock.\" \"Is it a rock?\" \"No, it is not a rock.\" \"Is it a mop?\" \"No, it is not a mop.\" Ana laughs. \"Then what is it?\"",
  qs:[f("What does Ana guess first on this page?","A sock 🧦",["A dog 🐶","A cake 🎂"],"\"Is it a sock?\""),
      t("Why does Ana laugh?","Tom keeps saying no",["She is sad","She fell down"],"Every guess gets a no. That is funny!")]},
 {pic:"🍿🎉👧🏻👦🏽",text:"Tom opens the box. Pop, pop, pop! It is popcorn! The popcorn is hot. It is a snack for Tom and Ana. \"Yum!\" said Ana. \"Can we share it?\" \"Yes, we can!\"",
  qs:[f("What is in the box?","Popcorn 🍿",["A fox 🦊","A frog 🐸"],"It is popcorn!"),
      t("What sound does the popcorn make?","Pop, pop, pop",["Tick, tock","Ring, ring"],"Pop, pop, pop! It is popcorn!")]}
],turn:{q:"What snack would you like to find in a box? Write: I want ___ in the box.",model:"I want a red apple in the box."}},
/* 4 HOW-TO */
{title:"How to Make a Fruit Cup",e:"🥣",kind:"How-to text",pages:[
 {pic:"🍌🍇🍐🥄",text:"You need a banana, grapes, a pear, a cup and a spoon. Ask a grown-up to help you. First, wash your hands. Then wash the fruit with water.",
  qs:[f("What do you do first?","Wash your hands 🧼",["Eat the fruit","Cut the pear"],"First, wash your hands."),
      f("Who should help you?","A grown-up",["A cat","Nobody"],"Ask a grown-up to help you.")]},
 {pic:"🍌🔪🍐",text:"Next, peel the banana. A grown-up cuts the pear. Cut the fruit into small bits. Small bits fit in the cup. Do not use a sharp knife by yourself.",
  qs:[f("Who cuts the pear?","A grown-up",["The dog","The baby"],"A grown-up cuts the pear."),
      t("Why do we cut the fruit into small bits?","So it fits in the cup",["So it turns blue","So it gets hot"],"Small bits fit in the cup.")]},
 {pic:"🥣🧃🥄",text:"Then, put the fruit in the cup. Pour a little orange juice on top. Mix it with a spoon. Mix it slowly so it stays in the cup. Mix, mix, mix!",
  qs:[f("What do you pour on top?","Orange juice 🧃",["Hot soup","Sand"],"Pour a little orange juice on top."),
      p("What do you think you do last?","Eat the fruit cup",["Throw it away","Put it in the bath"],"After you make food, you eat it!")]},
 {pic:"😋🎉🥣",text:"Last, eat your fruit cup. It is sweet and juicy. Share some with a friend. Then wash the cup and the spoon. Yum! You made a snack!",
  qs:[f("How does the fruit cup taste?","Sweet and juicy",["Sour and hot","Salty"],"It is sweet and juicy."),
      t("Which word tells the last step?","Last",["First","Next"],"Last, eat your fruit cup.")]}
],turn:{q:"What fruit would you put in your fruit cup? Write one sentence.",model:"I would put mango and grapes in my cup."}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Lunch Around the World",e:"🌍",kind:"Around the world",pages:[
 {pic:"🇮🇳🫓👧🏾",text:"Hi! I am Priya. I live in India. I eat roti for lunch. Roti is a flat, round bread. My mom makes it in a pan. I eat it with dal.",
  qs:[f("Where does Priya live?","India 🇮🇳",["Mexico 🇲🇽","Japan 🇯🇵"],"I live in India."),
      f("What is roti?","A flat, round bread",["A fruit","A drink"],"Roti is a flat, round bread.")]},
 {pic:"🇲🇽🌮👦🏽",text:"Hola! I am Diego. I live in Mexico. I eat tortillas. Tortillas are flat and round too. Some are made from corn. I fill my tortilla with beans.",
  qs:[f("What does Diego put in his tortilla?","Beans 🫘",["Ice cream 🍦","Grapes 🍇"],"I fill my tortilla with beans."),
      p("Who do you think we will meet next?","A child from another country",["A dragon","Diego's cat"],"The title is Lunch Around the World.")]},
 {pic:"🇨🇳🍜🥢🇪🇹🫓",text:"Ni hao! I am Mei. I live in China. I eat noodles. I use chopsticks. Selam! I am Abebe. I live in Ethiopia. I eat injera. It is soft and flat. I eat it with my hands.",
  qs:[f("What does Mei use to eat?","Chopsticks 🥢",["A shovel","Her feet"],"I use chopsticks."),
      f("What does Abebe eat?","Injera",["Noodles","Tortillas"],"I eat injera.")]},
 {pic:"🇯🇵🍙🌍",text:"Konnichiwa! I am Ken. I live in Japan. I eat rice. What do you eat? Kids eat many foods. But we all like a yummy lunch!",
  qs:[f("What does Ken eat?","Rice 🍚",["Roti","Injera"],"I eat rice."),
      t("What do all the kids like?","A yummy lunch",["Cold rain","Big boxes"],"But we all like a yummy lunch!")]}
],turn:{q:"What do you eat for lunch? Write one sentence.",model:"I eat rice and beans for lunch."}},
/* 6 REAL-WORLD */
{title:"Real-world reading: A lunch menu and a snack sign",e:"📋",kind:"Real-world text",pages:[
 {pic:"🏫🍽️",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🍽️ OAK HILL SCHOOL · Lunch Menu</b><table class=\"realtbl\"><tr><th>Day</th><th>Lunch</th></tr><tr><td>Monday</td><td>🍜 noodles and peas</td></tr><tr><td>Tuesday</td><td>🌮 tortillas and beans</td></tr><tr><td>Wednesday</td><td>🍲 soup and roti</td></tr><tr><td>Thursday</td><td>🍚 rice and broccoli</td></tr><tr><td>Friday</td><td>🥔 potatoes and carrots</td></tr></table><i>🍎 Fruit every day!</i></div>",
  qs:[f("What is for lunch on Tuesday?","Tortillas and beans",["Soup and roti","Rice and broccoli"],"Tuesday: 🌮 tortillas and beans."),
      t("Sam loves rice. Which day is best for Sam?","Thursday",["Monday","Friday"],"Thursday: 🍚 rice and broccoli.")]},
 {pic:"🍌🍐🧼",text:"<div class=\"realdoc\"><b>🍌 SNACK TABLE 🍐</b><br>🍎 Take one fruit.<br>🧼 Wash your hands first!<br>🗑️ Put peels in the green bin.<br>💧 Water is free.</div>",
  qs:[f("What must you do first?","Wash your hands",["Eat fast","Run around"],"🧼 Wash your hands first!"),
      f("Where do the peels go?","In the green bin",["On the floor","In your bag"],"🗑️ Put peels in the green bin.")]},
 {pic:"🕐📋",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🕐 OUR LUNCH TIME</b><br>11:30 🧼 Wash hands<br>11:35 🍽️ Eat lunch<br>12:00 🧹 Clean up<br>12:05 ⚽ Play outside</div>",
  qs:[f("What do the kids do at 12:00?","Clean up 🧹",["Eat lunch 🍽️","Wash hands 🧼"],"12:00 🧹 Clean up."),
      p("What do you think kids do after they play outside?","Go back to class",["Go to bed","Eat dinner"],"Lunch time ends, so it is time to learn again.")]}
],turn:{q:"Make a lunch menu for one day. Write: On Monday we have ___.",model:"On Monday we have soup and roti."}}
],
poems:[
 {title:"Pease Porridge Hot (a traditional nursery rhyme, first printed more than 200 years ago)",
  lines:["Pease porridge hot,","Pease porridge cold,","Pease porridge in the pot,","Nine days old.","","Some like it hot,","Some like it cold,","Some like it in the pot,","Nine days old."],
  qs:[f("Where is the porridge?","In the pot 🍲",["In a box 📦","On a log 🪵"],"\"Pease porridge in the pot\""),
      f("Which word rhymes with hot?","pot",["cold","days"],"Hot and pot end with the same sound: -ot."),
      t("Some like it hot. Some like it ___.","cold",["blue","fast"],"\"Some like it hot, some like it cold.\" Hot and cold are opposites.")]},
 {title:"Colours on My Plate",
  lines:["Red tomato, round and bright,","Yellow banana, a sunny bite,","Green peas rolling, one, two, three,","Purple grapes for you and me.","Orange carrot, crunch, crunch, crunch,","A rainbow plate for my lunch!"],
  qs:[f("What colour are the grapes?","Purple 🟣",["Red 🔴","Green 🟢"],"\"Purple grapes for you and me.\""),
      f("Which word rhymes with crunch?","lunch",["plate","three"],"Crunch and lunch end with the same sound: -unch."),
      t("Why is it a rainbow plate?","It has many colours 🌈",["It is wet","It is very big"],"The plate has red, yellow, green, purple and orange food.")]}
],
words:[
 {w:"banana",e:"🍌",m:"a long yellow fruit that you peel",ex:"I have a banana for my snack.",fill:"A monkey eats a yellow ___."},
 {w:"grapes",e:"🍇",m:"small round fruits that grow in bunches",ex:"Grapes grow in a bunch.",fill:"I eat a bunch of purple ___."},
 {w:"pear",e:"🍐",m:"a green fruit that is round at the bottom",ex:"The pear is sweet and juicy.",fill:"A grown-up cuts the green ___."},
 {w:"mango",e:"🥭",m:"a sweet fruit with a big seed inside",ex:"Mango is my best fruit.",fill:"The ___ has one big seed inside."},
 {w:"lemon",e:"🍋",m:"a yellow fruit that tastes very sour",ex:"A lemon is very sour.",fill:"The yellow ___ makes my face pucker."},
 {w:"cherry",e:"🍒",m:"a small red fruit with a stone inside",ex:"I ate a red cherry.",fill:"A ___ is small, round and red."},
 {w:"potato",e:"🥔",m:"a brown vegetable that grows under the ground",ex:"Dad bakes a potato.",fill:"A ___ grows under the ground."},
 {w:"tomato",e:"🍅",m:"a soft, round, red food for salads",ex:"I cut a red tomato.",fill:"We put a red ___ in the salad."},
 {w:"peas",e:"🫛",m:"little round green seeds in a pod",ex:"Peas grow in a pod.",fill:"Little green ___ grow in a pod."},
 {w:"broccoli",e:"🥦",m:"a green vegetable that looks like a tiny tree",ex:"Broccoli looks like a tiny tree.",fill:"Green ___ looks like a little tree."},
 {w:"breakfast",e:"🥞",m:"the meal we eat in the morning",ex:"I eat breakfast at seven.",fill:"In the morning, I eat ___."},
 {w:"dinner",e:"🍽️",m:"the meal we eat in the evening",ex:"We eat dinner at night.",fill:"At night, my family eats ___."},
 {w:"snack",e:"🍿",m:"a little bit of food between meals",ex:"A pear is a good snack.",fill:"After school, I have a small ___."},
 {w:"rice",e:"🍚",m:"small white grains we cook in water",ex:"Ken eats rice for lunch.",fill:"We cook ___ in a pot of water."},
 {w:"roti",e:"🫓",m:"a flat, round bread from India",ex:"Priya eats roti with dal.",fill:"Priya's mom makes ___ in a pan."},
 {w:"noodles",e:"🍜",m:"long, thin strings of food we cook",ex:"Mei eats noodles in a bowl.",fill:"Mei slurps her long ___."},
 {w:"tortilla",e:"🌮",m:"a flat, round bread from Mexico",ex:"Diego fills a tortilla with beans.",fill:"Diego puts beans in a ___."},
 {w:"injera",e:"🇪🇹",m:"a soft, flat bread from Ethiopia",ex:"Abebe eats injera with his hands.",fill:"In Ethiopia, Abebe eats soft ___."},
 {w:"soup",e:"🍲",m:"a hot, wet food you eat with a spoon",ex:"Dot stirs the soup.",fill:"I eat hot ___ from a bowl."},
 {w:"chopsticks",e:"🥢",m:"two thin sticks we use to eat",ex:"Mei uses chopsticks.",fill:"Mei eats her noodles with ___."},
 {w:"eat",e:"😋",m:"to put food in your mouth and chew",ex:"We eat lunch at noon.",fill:"I ___ a banana for my snack."},
 {w:"cut",e:"🔪",m:"to make food smaller with a knife",ex:"A grown-up can cut the pear.",fill:"Dad will ___ the bread with a knife."},
 {w:"mix",e:"🥣",m:"to put things together in a bowl",ex:"I mix the fruit in a bowl.",fill:"___ the fruit with a spoon."},
 {w:"pour",e:"🫗",m:"to make a drink flow out of a jug",ex:"I pour the juice.",fill:"Please ___ the water into my cup."},
 {w:"wash",e:"🧼",m:"to make clean with soap and water",ex:"I wash my hands with soap.",fill:"___ your hands before you eat."},
 {w:"bake",e:"🧁",m:"to cook food in a hot oven",ex:"We bake bread in the oven.",fill:"Gran will ___ a cake in the oven."},
 {w:"stir",e:"🥄",m:"to move a spoon round and round",ex:"Dot can stir the soup.",fill:"___ the soup with a big spoon."},
 {w:"peel",e:"🍊",m:"to take the skin off a fruit",ex:"I peel an orange.",fill:"I ___ my banana before I eat it."},
 {w:"chop",e:"🥬",m:"to cut again and again into little bits",ex:"Mom will chop the lettuce.",fill:"A grown-up will ___ the carrots into bits."},
 {w:"cook",e:"🧑‍🍳",m:"to make food hot and ready to eat",ex:"Grandpa likes to cook.",fill:"Mom and I ___ dinner together."},
 {w:"red",e:"🔴",m:"the colour of a ripe cherry",ex:"A tomato is red.",fill:"A ripe cherry is ___."},
 {w:"yellow",e:"🟡",m:"the colour of a banana",ex:"A lemon is yellow.",fill:"A banana is ___."},
 {w:"green",e:"🟢",m:"the colour of peas and broccoli",ex:"Broccoli is green.",fill:"Peas are ___."},
 {w:"orange",e:"🟠",m:"the colour of a carrot",ex:"A carrot is orange.",fill:"A pumpkin is ___."},
 {w:"purple",e:"🟣",m:"the colour you get from red and blue",ex:"The grapes are purple.",fill:"Red and blue make ___."},
 {w:"brown",e:"🟤",m:"the colour of chocolate",ex:"Chocolate is brown.",fill:"The skin of a potato is ___."},
 {w:"sweet",e:"🍯",m:"tasting like sugar or honey",ex:"A mango is sweet.",fill:"Honey tastes very ___."},
 {w:"sour",e:"😖",m:"tasting sharp, like a lemon",ex:"Lemons taste sour.",fill:"A lemon makes my mouth feel ___."},
 {w:"crunchy",e:"🥕",m:"making a loud sound when you bite it",ex:"A carrot is crunchy.",fill:"Popcorn is ___ when I bite it."},
 {w:"juicy",e:"🍉",m:"full of juice",ex:"The watermelon is juicy.",fill:"A watermelon is very ___."}
],
spelling:[],
facts:[
 {e:"🥕",c:"Carrots grow under the ground.",t:true,x:"True! We eat the root of the carrot plant."},
 {e:"🍚",c:"Rice grows on tall trees.",t:false,x:"Not true! Rice grows on a grass plant, often in wet fields."},
 {e:"🍎",c:"Apples grow on trees.",t:true,x:"True! Apples grow on apple trees."},
 {e:"🥔",c:"Potatoes grow on trees.",t:false,x:"Not true! Potatoes grow under the ground."},
 {e:"🍓",c:"Strawberries have their seeds on the outside.",t:true,x:"True! Look closely. You can see tiny seeds on a strawberry."},
 {e:"🍋",c:"Lemons taste sweet.",t:false,x:"Not true! Lemons taste sour."},
 {e:"🫛",c:"Peas grow in pods.",t:true,x:"True! A pod is like a little green case for the peas."},
 {e:"🫓",c:"Injera is a soft, flat bread from Ethiopia.",t:true,x:"True! People in Ethiopia often eat injera with their hands."},
 {e:"🥢",c:"Many people in China and Japan eat with chopsticks.",t:true,x:"True! Chopsticks are two thin sticks."},
 {e:"🧼",c:"We should wash our hands before we eat.",t:true,x:"True! Washing with soap takes the germs away."},
 {e:"🥞",c:"Breakfast is the meal we eat at night.",t:false,x:"Not true! Breakfast is the meal we eat in the morning."},
 {e:"🍌",c:"Bananas grow under the ground.",t:false,x:"Not true! Bananas grow in bunches on big banana plants."}
],
writing:[
 {e:"😋",t:"My favourite food",level:"Step 1 · 2 sentences",
  prompt:"Write 2 sentences about a food you like. Say what it is and what colour it is.",
  minS:2,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b(like|love|likes|loves)\\b","I said what I like"]],
  starters:["I like ","It is "],
  model:"I like mango. It is yellow and sweet."},
 {e:"🥞",t:"My breakfast",level:"Step 2 · 3 sentences",
  prompt:"Write 3 sentences about your breakfast. What do you eat? What colour is it? Who eats with you?",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Ee]at|[Ee]ats|[Hh]ave|[Hh]as)\\b","I said what I eat"]],
  starters:["For breakfast, I eat ","It is ","I eat with "],
  model:"For breakfast, I eat rice and a banana. The banana is yellow. I eat with my sister."},
 {e:"🥣",t:"How to make a snack",level:"Step 3 · How-to (4 sentences)",
  prompt:"Write 4 sentences that tell how to make a snack. Start with First, Next, Then and Last. Use action words like wash, cut, mix, pour or eat.",
  minS:4,minWords:1,
  rx:[["\\bFirst\\b","I used First"],["\\bNext\\b","I used Next"],["\\bThen\\b","I used Then"],["\\bLast\\b","I used Last"],["\\b([Ww]ash|[Cc]ut|[Mm]ix|[Pp]our|[Pp]eel|[Ss]tir|[Ee]at|[Cc]hop|[Pp]ut|[Ss]pread|[Bb]ake|[Aa]dd)\\b","I used an action word"],["[.!?]\\s*$","I ended with a full stop"]],
  starters:["First, ","Next, ","Then, ","Last, "],
  model:"First, I wash a red apple. Next, my dad helps me cut it. Then, I put the bits on a plate. Last, I eat my yummy snack."}
]};
UNITS.push(u);

/* ================= PHONICS: SHORT O ================= */
const OW=["pot","hot","dog","top","mop","box","fox","log","hop","dot","fog","jog","frog","stop","shop","chop","drop","sock","rock","lock","pop","not","lot","job","doll","spot","clock","block","on","got"];
const NO=["cat","map","bag","hat","pig","sit","big","pin","bed","hen","web","ten","sun","bus","cup","mud","bug","jam","fan","lid","net","rug","fish","jet","tub","van"];
const sayOpts=q=>Object.assign(q,{say:q.q.replace(/<[^>]+>/g," ")+" "+q.o.join(", ")});
const shortoQ=()=>{if(Math.random()<.6){const a=R(OW.filter(x=>x!=="pot"));return sayOpts(mcQ(`Which word has the <b>short o</b> sound, like 🍲 <b>pot</b>?`,a,SAMPLE(NO,2),`<b>${a}</b> has the short o sound, like pot.`,"Say each word. Listen for the o in pot."))}
  const a=R(NO);return sayOpts(mcQ(`Which word does <b>NOT</b> have the short o sound?`,a,SAMPLE(OW,2),`<b>${a}</b> has no short o. The other words do.`,"Say each word. Which one has no o sound like pot?"))};
const PICS=[["🦊","fox"],["📦","box"],["🪵","log"],["🐸","frog"],["🧦","sock"],["🪨","rock"],["🔒","lock"],["🕰️","clock"],["🛑","stop"],["💧","drop"],["🐶","dog"],["🍲","pot"],["🔥","hot"],["🐙","octopus"],["🦦","otter"],["🌫️","fog"],["🍭","lollipop"],["🌭","hotdog"],["🍿","popcorn"],["🥦","broccoli"],["🪆","doll"],["🦞","lobster"],["🫒","olive"],["🔵","dot"]];
const swapO=w=>SAMPLE(["a","e","i","u"],2).map(v=>w.replace("o",v));
const picQ=()=>{const x=R(PICS);if(Math.random()<.5)return mcQ(`<span style="font-size:56px">${x[0]}</span><br>Which word matches the picture?`,x[1],swapO(x[1]),`${x[0]} = <b>${x[1]}</b>. It has the short o sound.`,"Say the picture's name. Listen for o, like in pot.");
  const others=SAMPLE(PICS.filter(y=>y!==x),2).map(y=>y[0]);return mcQ(`Which picture shows <b>${x[1]}</b>?`,x[0],others,`${x[0]} = <b>${x[1]}</b>.`,"Read the word slowly. Then find its picture.",{say:x[1]})};
const MK=[["pot","🍲","We cook soup in it."],["hot","🔥","Fire is very hot."],["dog","🐶","It says woof."],["top","⬆️","It is the highest part."],["mop","🪣","We clean the floor with it."],["box","📦","We put toys in it."],["fox","🦊","An orange animal with a big tail."],["log","🪵","A big piece of a tree."],["hop","🐇","Bunnies do this."],["dot","🔵","A small round spot."],["fog","🌫️","A grey cloud near the ground."],["jog","🏃","To run slowly."],["sock","🧦","You wear it on your foot."],["rock","🪨","A big hard stone."],["lock","🔒","You open it with a key."],["frog","🐸","A green animal that hops."],["stop","🛑","The red sign says this."],["drop","💧","A little bit of water."],["shop","🏪","A place to buy things."],["chop","🔪","To cut into little bits."],["doll","🪆","A toy that looks like a person."],["pop","🎈","A balloon can go pop!"],["clock","🕰️","It tells the time."]];
const frame=w=>w.split("").map(c=>c==="o"?"_":c).join(" ");
const makeQ=()=>{const x=R(MK);const fr=`<span style="font-size:44px">${x[1]}</span><br><b style="letter-spacing:4px;font-size:26px">${frame(x[0])}</b><br><span style="color:var(--muted)">${x[2].replace(new RegExp("\\b"+x[0]+"\\b","i"),"___")}</span>`;
  if(Math.random()<.5)return mcQ(`${fr}<br>Which letter is missing?`,"o",SAMPLE(["a","e","i","u"],2),`<b>${x[0]}</b>: ${x[0].split("").join("-")}. The missing letter is <b>o</b>.`,"Say the word slowly. What sound is in the middle?");
  return {type:"type",q:`${fr}<br>Make the word. Type the whole word.`,a:[x[0]],why:`${x[1]} <b>${x[0]}</b>: ${x[0].split("").join("-")}`,hint:"The missing letter is o, like in pot."}};
const FAM={"-op":["hop","top","mop","pop","stop","shop","drop","chop","crop","flop"],"-ot":["hot","pot","dot","cot","got","lot","not","rot","spot","plot"],"-og":["dog","log","fog","jog","frog"]};
const NORHYME=["cat","pig","sun","bed","hat","bus","pin","cup","fan","web","net","mud"];
const rhymeQ=()=>{const ks=Object.keys(FAM),k=R(ks),x=R(FAM[k]);
  if(Math.random()<.65){const a=R(FAM[k].filter(y=>y!==x)),o=R(FAM[R(ks.filter(z=>z!==k))]);
    return sayOpts(mcQ(`Which word <b>rhymes</b> with <b>${x}</b>?`,a,[o,R(NORHYME)],`<b>${x}</b> and <b>${a}</b> rhyme. They both end in <b>${k}</b>.`,`Rhyming words sound the same at the end. Listen for ${k}.`))}
  return sayOpts(mcQ(`<b>${x}</b> is in which word family?`,k,ks.filter(z=>z!==k),`<b>${x}</b> ends in <b>${k}</b>, like ${FAM[k].filter(y=>y!==x).slice(0,2).join(" and ")}.`,"Look at the last two letters."))};
const OSP=G4.sp([["pot","Soup is in the pot.","p-o-t"],["hot","The soup is hot.","h-o-t"],["dog","My dog can run.","d-o-g"],["top","Put the lid on top.","t-o-p"],["mop","Dad gets the mop.","m-o-p"],["box","The snack is in the box.","b-o-x"],["fox","The fox has a big tail.","f-o-x"],["log","A frog sits on a log.","l-o-g"],["hop","I can hop on one foot.","h-o-p"],["dot","Put a red dot here.","d-o-t"],["fog","The fog is grey.","f-o-g"],["jog","We jog in the park.","j-o-g"],["frog","The frog is green.","f-r-o-g"],["stop","Stop at the red sign.","s-t-o-p"],["shop","We go to the shop.","sh-o-p"],["chop","Mom will chop the broccoli.","ch-o-p"],["drop","Do not drop the cup.","d-r-o-p"],["sock","I have a red sock.","s-o-ck"],["rock","I sit on a big rock.","r-o-ck"],["lock","I lock the door.","l-o-ck"],["pop","The corn will pop.","p-o-p"],["spot","The dog has a spot.","sp-o-t"],["clock","The clock says six.","cl-o-ck"],["doll","My doll has a hat.","d-o-ll"]]);

/* ================= GRAMMAR: ACTION WORDS (VERBS) ================= */
const VERBS=["eat","cut","mix","pour","wash","bake","stir","peel","chop","cook","drink","taste","run","jump","sit","sing","swim","read","clap","kick","hop","sleep","fry","boil","share","sip","bite","chew"];
const NONV=["pear","mango","lemon","rice","soup","kitchen","banana","bread","tomato","potato","chopsticks","noodles","roti","grapes","red","yellow","green","sweet","sour","happy","big","little","Grandpa","Mei"];
const verbQ=()=>{if(Math.random()<.6){const a=R(VERBS);return sayOpts(mcQ(`Which word is an <b>action word</b>?`,a,SAMPLE(NONV,2),`<b>${a}</b> is an action word. It is something you can do.`,"Which one can you DO? Try: I can ___."))}
  const a=R(NONV);return sayOpts(mcQ(`Which word is <b>NOT</b> an action word?`,a,SAMPLE(VERBS,2),`<b>${a}</b> is not an action. You cannot say "I can ${a}."`,"Try each word: I can ___. Which one does not work?"))};
const VP=[["🧼🙌","I ___ my hands.","wash",["sing","bake"]],["🔪🍐","We ___ the pear.","cut",["drink","sleep"]],["🥣🥄","I ___ the fruit in a bowl.","mix",["kick","read"]],["🧃🥤","I ___ the juice into a cup.","pour",["peel","jump"]],["🧁🔥","We ___ cupcakes in the oven.","bake",["wash","swim"]],["😋🍌","I ___ a banana.","eat",["pour","sit"]],["🍊✋","I ___ the orange.","peel",["drink","sing"]],["🥄🍲","I ___ the soup.","stir",["kick","sleep"]],["🥤😊","I ___ water.","drink",["cut","bake"]],["🧑‍🍳🍲","We ___ soup on the stove.","cook",["sing","read"]],["🔪🥬","I ___ the lettuce into bits.","chop",["drink","sing"]],["🏃💨","I ___ fast.","run",["peel","stir"]],["🦘","I can ___ up high.","jump",["pour","cut"]],["🐟🌊","Fish ___ in the sea.","swim",["bake","peel"]],["😴🛏️","I ___ in my bed.","sleep",["cut","pour"]],["📖","I ___ a book.","read",["stir","drink"]],["🎤🎶","We ___ a song.","sing",["chop","wash"]],["👏🎉","We ___ our hands.","clap",["peel","pour"]],["⚽🦶","I ___ the ball.","kick",["peel","stir"]],["🪑","I ___ on a chair.","sit",["chop","pour"]],["🍪🦷","I ___ the cookie.","bite",["pour","swim"]],["🍞🧈","I ___ butter on the bread.","spread",["drink","jump"]],["🫖☕","Gran will ___ the tea.","pour",["jump","read"]],["🍽️🧽","We ___ the plates.","wash",["eat","sing"]],["🥔💧🔥","We ___ the potatoes in water.","boil",["kick","read"]]];
const vpicQ=()=>{const x=R(VP);return mcQ(`<span style="font-size:48px">${x[0]}</span><br>Pick the action for the picture:<br><b>${x[1]}</b>`,x[2],x[3],`${x[0]} <b>${x[1].replace("___",x[2])}</b>`,"Look at the picture. What is happening?",{say:x[1].replace("___","blank")})};
const VS=[["Mia eats a pear.","eats",["Mia","pear"]],["We wash the grapes.","wash",["We","grapes"]],["Dad cuts the bread.","cuts",["Dad","bread"]],["I mix the rice.","mix",["I","rice"]],["Ken pours the water.","pours",["Ken","water"]],["Gran bakes a cake.","bakes",["Gran","cake"]],["Dot stirs the soup.","stirs",["Dot","soup"]],["Priya peels a mango.","peels",["Priya","mango"]],["Tom chops the broccoli.","chops",["Tom","broccoli"]],["Mom cooks the noodles.","cooks",["Mom","noodles"]],["Abebe eats injera.","eats",["Abebe","injera"]],["The kids drink juice.","drink",["kids","juice"]],["Diego fills a tortilla.","fills",["Diego","tortilla"]],["Mei holds her chopsticks.","holds",["Mei","chopsticks"]],["Ana tastes the lemon.","tastes",["Ana","lemon"]],["We share the popcorn.","share",["We","popcorn"]],["Sam spreads the jam.","spreads",["Sam","jam"]],["Lily washes the plums.","washes",["Lily","plums"]],["I boil the peas.","boil",["I","peas"]],["Omar picks a cherry.","picks",["Omar","cherry"]],["The frog hops on a log.","hops",["frog","log"]],["The fox runs to the box.","runs",["fox","box"]],["Grandpa fries the potato.","fries",["Grandpa","potato"]],["Ben sips the soup.","sips",["Ben","soup"]],["Zoe pours the tea.","pours",["Zoe","tea"]]];
const vfindQ=()=>{const x=R(VS);if(Math.random()<.6)return mcQ(`${G4.box("Read",x[0])}Which word is the <b>action word</b> (verb)?`,x[1],x[2],`<b>${x[1]}</b> is the action. It tells what someone does.`,"Who is it about? What do they DO?",{say:x[0]});
  return {type:"type",q:`${G4.box("Read",x[0])}Type the <b>action word</b> (verb).`,a:[x[1]],why:`<b>${x[1]}</b> is the action in: ${x[0]}`,hint:"Find the word that tells what someone does.",say:x[0]}};

/* ================= WORD SKILLS: FOOD, COLOURS, SIGHT WORDS ================= */
const COL=[["🍌","a banana","yellow"],["🍋","a lemon","yellow"],["🌽","corn","yellow"],["🧈","butter","yellow"],["🍓","a strawberry","red"],["🍅","a tomato","red"],["🍒","a cherry","red"],["🥕","a carrot","orange"],["🍊","an orange","orange"],["🥦","broccoli","green"],["🥒","a cucumber","green"],["🫛","a pea pod","green"],["🥬","lettuce","green"],["🥑","an avocado","green"],["🫐","a blueberry","blue"],["🍫","chocolate","brown"],["🥔","a potato","brown"],["🥜","a peanut","brown"],["🥥","a coconut","brown"],["🍚","rice","white"],["🧂","salt","white"],["🍇","these grapes","purple"]];
const colQ=()=>{const x=R(COL);if(Math.random()<.55){const cs=uniq(COL.map(y=>y[2])).filter(c=>c!==x[2]);const v=/^these /.test(x[1])?"are":"is";return mcQ(`<span style="font-size:52px">${x[0]}</span><br>What colour ${v} ${x[1]}?`,x[2],SAMPLE(cs,2),`${x[0]} ${cap(x[1])} ${v} <b>${x[2]}</b>.`,"Look at the picture. What colour do you see?")}
  const others=SAMPLE(COL.filter(y=>y[2]!==x[2]),2).map(y=>y[0]+" "+y[1].replace(/^(a|an|these) /,""));const ans=x[0]+" "+x[1].replace(/^(a|an|these) /,"");
  return mcQ(`Which food is <b>${x[2]}</b>?`,ans,others,`${ans} is <b>${x[2]}</b>.`,"Look at the colours of the pictures.")};
const SIGHT=[["Sam ___ a red apple.","has",["of","are"]],["Mia ___ a big pot.","has",["are","of"]],["Dad ___ a green pear.","has",["of","are"]],["The cake ___ a cherry on top.","has",["are","of"]],["Ken ___ rice in his bowl.","has",["are","for"]],["We ___ rice for lunch.","have",["of","has"]],["I ___ two plums.","have",["has","of"]],["They ___ hot soup.","have",["has","of"]],["You ___ a yellow banana.","have",["has","of"]],["The grapes ___ purple.","are",["has","of"]],["The peas ___ green.","are",["has","of"]],["Lemons ___ sour.","are",["has","of"]],["The noodles ___ long.","are",["has","of"]],["This snack is ___ you.","for",["are","has"]],["We have soup ___ dinner.","for",["are","has"]],["I made a card ___ Gran.","for",["are","has"]],["Thank you ___ the noodles.","for",["are","has"]],["I want a cup ___ juice.","of",["are","has"]],["I ate a lot ___ grapes.","of",["are","has"]],["She ate a bowl ___ rice.","of",["are","said"]],["Give me a piece ___ roti.","of",["are","said"]],["\"Yum!\" ___ Dot.","said",["of","are"]],["\"I like rice,\" ___ Ken.","said",["for","are"]],["\"Wash your hands,\" ___ Mom.","said",["of","has"]],["\"Let's cook!\" ___ Grandpa.","said",["for","are"]],["\"This is hot,\" ___ Priya.","said",["of","are"]]];
const sightQ=()=>{const x=R(SIGHT);return sayOpts(mcQ(`Which word fits?<br><b>${x[0]}</b>`,x[1],x[2],`<b>${x[0].replace("___",x[1])}</b>`,"Read the sentence with each word. Which one sounds right?"))};
const FRUIT=[["🍌","banana"],["🍐","pear"],["🍇","grapes"],["🥭","mango"],["🍒","cherry"],["🍓","strawberry"],["🍋","lemon"],["🍑","peach"],["🍍","pineapple"],["🍉","watermelon"],["🫐","blueberry"],["🥝","kiwi"],["🍊","orange"],["🍎","apple"]];
const VEG=[["🥕","carrot"],["🥔","potato"],["🥦","broccoli"],["🥬","lettuce"],["🫛","peas"],["🧅","onion"],["🧄","garlic"],["🍠","sweet potato"],["🫘","beans"]];
const fvQ=()=>{const r=Math.random();if(r<.5){const fr=Math.random()<.6,x=R(fr?FRUIT:VEG);return mcQ(`<span style="font-size:52px">${x[0]}</span><br>Is <b>${x[1]}</b> a fruit or a vegetable?`,fr?"fruit":"vegetable",[fr?"vegetable":"fruit"],fr?`${x[0]} ${cap(x[1])} is a <b>fruit</b>.`:`${x[0]} ${cap(x[1])} is a <b>vegetable</b>.`,"Fruits are often sweet and have seeds. Vegetables can be roots, leaves or pods.")}
  const fr=r<.75,x=R(fr?FRUIT:VEG),o=SAMPLE(fr?VEG:FRUIT,2);return mcQ(`Which one is a <b>${fr?"fruit":"vegetable"}</b>?`,x[0]+" "+x[1],o.map(y=>y[0]+" "+y[1]),`${x[0]} ${x[1]} is a ${fr?"fruit":"vegetable"}.`,fr?"Fruits are often sweet and have seeds.":"Vegetables can be roots, leaves or pods.")};

/* ================= READING: MENUS AND LABELS ================= */
const RD=(h)=>`<div class="realdoc">${h}</div>`;
const MENUS=[
 [RD("<b>🍽️ LUNCH MENU</b><br>🍜 Noodles<br>🍚 Rice<br>🥗 Salad"),[["How many foods are on the menu?","3",["2","5"]],["Which food is on the menu?","Rice 🍚",["Pizza 🍕","Cake 🎂"]],["Which food is long and thin?","Noodles 🍜",["Rice 🍚","Salad 🥗"]]]],
 [RD("<b>🍎 FRUIT STAND</b><br>🍌 Bananas: 3 for 1 dollar<br>🍐 Pears: 2 for 1 dollar<br>🍒 Cherries: 1 cup for 2 dollars"),[["What is the first fruit?","Bananas 🍌",["Pears 🍐","Cherries 🍒"]],["How many pears for 1 dollar?","2",["3","1"]],["How do you get cherries?","By the cup",["By the box","One by one"]]]],
 [RD("<b>🧃 JUICE BOX</b><br>Orange juice 🍊<br>Keep cold ❄️<br>Shake before you drink!"),[["What kind of juice is it?","Orange juice",["Lemon juice","Grape juice"]],["How should you keep it?","Cold ❄️",["Hot 🔥","In the sun ☀️"]],["What do you do before you drink?","Shake it",["Freeze it","Cook it"]]]],
 [RD("<b>🍪 BAKE SALE</b><br>Friday at 2:00<br>Cookies and muffins<br>All money helps our school library 📚"),[["What day is the bake sale?","Friday",["Monday","Sunday"]],["What can you get?","Cookies and muffins",["Soup and rice","Noodles"]],["What does the money help?","The school library",["A shop","A zoo"]]]],
 [RD("<b>🥣 RECIPE CARD: Banana Toast</b><br>1. Toast the bread 🍞<br>2. Peel a banana 🍌<br>3. Cut the banana 🔪<br>4. Put it on the toast 😋"),[["What is step 2?","Peel a banana",["Toast the bread","Cut the banana"]],["What do you need?","Bread and a banana",["Rice and peas","Soup and roti"]],["What is the last step?","Put it on the toast",["Peel a banana","Toast the bread"]]]],
 [RD("<b>🍲 SOUP OF THE DAY</b><br>Monday: 🥕 carrot soup<br>Tuesday: 🍅 tomato soup<br>Wednesday: 🫛 pea soup"),[["What soup is on Tuesday?","Tomato soup",["Carrot soup","Pea soup"]],["What soup is green?","Pea soup",["Tomato soup","Carrot soup"]],["What soup is on Monday?","Carrot soup",["Pea soup","Tomato soup"]]]],
 [RD("<b>⚠️ KITCHEN RULES</b><br>🧼 Wash your hands<br>🔪 Only grown-ups use knives<br>🔥 Do not touch the hot stove<br>🧽 Clean up when you are done"),[["Who can use knives?","Only grown-ups",["Kids","Pets"]],["What must you not touch?","The hot stove",["The soap","The spoon"]],["What do you do when you are done?","Clean up",["Run away","Go to sleep"]]]],
 [RD("<b>🌍 FOOD FAIR</b><br>🇮🇳 Roti table<br>🇲🇽 Tortilla table<br>🇨🇳 Noodle table<br>🇪🇹 Injera table<br>Saturday, 11:00 to 2:00"),[["Which table is from Mexico?","Tortilla table",["Roti table","Noodle table"]],["What day is the food fair?","Saturday",["Friday","Tuesday"]],["How many tables are there?","4",["2","6"]]]]
];
const menuQ=()=>{const m=R(MENUS),x=R(m[1]);return mcQ(`${m[0]}${x[0]}`,x[1],x[2],`Look at the sign again: the answer is there.`,"Read the sign. Find the words.",{say:m[0].replace(/<[^>]+>/g," ")+" "+x[0]})};

/* ================= THINKING: FOOD SENSE ================= */
const FOODT=[
 {q:"🌅 Which meal do we eat in the morning?",o:["Breakfast","Dinner","Lunch"],a:"Breakfast",why:"Breakfast is the first meal of the day."},
 {q:"🌙 Which meal do we eat in the evening?",o:["Dinner","Breakfast","Lunch"],a:"Dinner",why:"Dinner is the meal we eat at night."},
 {q:"🧼 What should you do before you eat?",o:["Wash your hands","Jump in mud","Go to sleep"],a:"Wash your hands",why:"Clean hands keep germs away from your food."},
 {q:"🔪 Who should use a sharp knife?",o:["A grown-up","A baby","A puppy"],a:"A grown-up",why:"Knives are sharp, so grown-ups use them."},
 {q:"🔥 The pot is very hot. What should you do?",o:["Ask a grown-up for help","Touch it","Hug it"],a:"Ask a grown-up for help",why:"Hot pots can burn you. A grown-up can help."},
 {q:"💧 You are thirsty. What is a good drink?",o:["Water","Sand","Paint"],a:"Water",why:"Water helps your body."},
 {q:"🥢 What does Mei use to eat noodles?",o:["Chopsticks","A shovel","A comb"],a:"Chopsticks",why:"Mei uses chopsticks."},
 {q:"🇪🇹 Which food is from Ethiopia?",o:["Injera","Tortillas","Roti"],a:"Injera",why:"Injera is a soft, flat bread from Ethiopia."},
 {q:"🇲🇽 Which food is from Mexico?",o:["Tortillas","Injera","Roti"],a:"Tortillas",why:"Tortillas are flat, round bread from Mexico."},
 {q:"🇮🇳 Priya eats a flat, round bread in India. What is it?",o:["Roti","Noodles","Soup"],a:"Roti",why:"Roti is a flat, round bread from India."},
 {q:"🍋 A lemon is sour. Which food is sweet?",o:["A mango","A lemon","Salt"],a:"A mango",why:"Mangoes taste sweet."},
 {q:"🍦 Ice cream melts in the sun. Why?",o:["The sun is hot","The sun is cold","Ice cream is a rock"],a:"The sun is hot",why:"Heat makes ice cream melt."},
 {q:"🌈 Your plate has red, green and yellow food. What kind of plate is it?",o:["A colourful plate","An empty plate","A blue plate"],a:"A colourful plate",why:"Many colours make a colourful plate."},
 {q:"🍌 What do you do before you eat a banana?",o:["Peel it","Bake it","Pour it"],a:"Peel it",why:"We take the skin off a banana."},
 {q:"🍲 Your soup is too hot. What can you do?",o:["Wait and blow on it","Eat it very fast","Pour it on the floor"],a:"Wait and blow on it",why:"Waiting helps the soup cool down."},
 {q:"🥕 Where does a carrot grow?",o:["Under the ground","On a tree","In the sea"],a:"Under the ground",why:"We eat the carrot's root."},
 {q:"🍎 Where do apples grow?",o:["On trees","Under the ground","In a box"],a:"On trees",why:"Apples grow on apple trees."},
 {q:"🫛 Where do peas grow?",o:["In pods","On rocks","In the clouds"],a:"In pods",why:"Peas grow in green pods."},
 {q:"🗑️ Where can banana peels go?",o:["In the green bin","On the floor","Under the bed"],a:"In the green bin",why:"Peels go in the green bin, not on the floor."},
 {q:"🤝 Your friend has no snack. What can you do?",o:["Share your snack","Laugh at your friend","Hide your snack"],a:"Share your snack",why:"Sharing is kind."},
 {q:"🧮 You have 3 cherries. You get 2 more. How many now?",o:["5","4","6"],a:"5",why:"3 + 2 = 5."},
 {q:"🧮 There are 5 bananas. You eat 1. How many are left?",o:["4","6","5"],a:"4",why:"5 − 1 = 4."},
 {q:"🧮 2 kids each have 2 grapes. How many grapes in all?",o:["4","2","3"],a:"4",why:"2 + 2 = 4."},
 {q:"🧮 Gran bakes 10 cookies. We eat 3. How many are left?",o:["7","13","6"],a:"7",why:"10 − 3 = 7."},
 {q:"🧁 Which food do we bake in an oven?",o:["A cake","A salad","Juice"],a:"A cake",why:"We bake cakes in a hot oven."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["banana","I peel a banana.","ba-na-na: three a's."],["grapes","Grapes grow in a bunch.","gr-a-pes: the e at the end is silent."],["lemon","A lemon is sour.","lem-on."],["mango","I like a sweet mango.","man-go."],["potato","Dad cooks a potato.","po-ta-to."],["tomato","The tomato is red.","to-ma-to."],["rice","We cook rice in a pot.","r-i-ce: c says s here."],["soup","The soup is hot.","s-ou-p: ou says oo."],["noodles","Mei eats noodles.","n-oo-dles: double o."],["snack","I have a snack.","sn-a-ck: ck at the end."],["dinner","We eat dinner at six.","din-ner: double n."],["breakfast","I eat breakfast in the morning.","break + fast."],["yellow","A lemon is yellow.","yel-low: double l."],["green","Peas are green.","gr-ee-n: double e."],["purple","The grapes are purple.","pur-ple."],["orange","A carrot is orange.","or-ange."],["sweet","The mango is sweet.","sw-ee-t: double e."],["juicy","The pear is juicy.","jui-cy: ends with y."],["wash","I wash my hands.","w-a-sh: sh at the end."],["cook","Grandpa can cook.","c-oo-k: double o."]]),
 CHOOSE:null,
 DETAIL:[
  ["Bananas","Bananas grow in big bunches. They are green at first. They turn yellow when they are ripe.",[["How do bananas grow?","In big bunches",["One by one","Under the ground"]],["What colour are bananas at first?","Green",["Red","Blue"]],["When do bananas turn yellow?","When they are ripe",["When they are cold","At night"]]]],
  ["Rice","Rice is a kind of grass seed. It grows in wet fields. People all over the world eat rice.",[["What is rice?","A grass seed",["A fruit","A fish"]],["Where does rice grow?","In wet fields",["On trees","In the snow"]],["Who eats rice?","People all over the world",["Only cats","Nobody"]]]],
  ["Injera","Injera is a soft, flat bread. It comes from Ethiopia. People tear it and scoop up food with it.",[["What is injera?","A soft, flat bread",["A drink","A fruit"]],["Where does injera come from?","Ethiopia",["Japan","Canada"]],["How do people use injera?","To scoop up food",["To wash dishes","To play ball"]]]],
  ["Tortillas","Tortillas are flat and round. Many are made from corn. People in Mexico eat them every day.",[["What shape are tortillas?","Flat and round",["Square","Long and thin"]],["What are many tortillas made from?","Corn",["Grapes","Rocks"]],["Where do people eat them every day?","Mexico",["The moon","The sea"]]]],
  ["Carrots","Carrots grow under the ground. Most carrots are orange. They are crunchy to eat.",[["Where do carrots grow?","Under the ground",["On trees","In the sky"]],["What colour are most carrots?","Orange",["Blue","Black"]],["How do carrots feel when you bite them?","Crunchy",["Soft like soup","Wet like water"]]]],
  ["Chopsticks","Chopsticks are two thin sticks. People use them to pick up food. Many people in China, Japan and Korea use chopsticks.",[["How many sticks are there?","Two",["One","Ten"]],["What do people pick up with them?","Food",["Rocks","Shoes"]],["Which country is named?","Japan",["Mexico","Canada"]]]],
  ["Lemons","Lemons are yellow. They taste very sour. People put lemon juice on fish and in drinks.",[["What colour are lemons?","Yellow",["Purple","Blue"]],["How do lemons taste?","Sour",["Sweet","Salty"]],["Where do people put lemon juice?","On fish and in drinks",["On shoes","In the bath"]]]],
  ["Soup","Soup is a hot food. You eat it with a spoon. Some soup has carrots, peas and noodles.",[["Is soup hot or cold?","Hot",["Cold","Frozen"]],["What do you eat soup with?","A spoon",["A fork","A comb"]],["What can be in soup?","Carrots, peas and noodles",["Sand and rocks","Socks"]]]],
  ["Roti","Roti is a flat, round bread from India. It is cooked in a hot pan. People eat it with dal or curry.",[["Where is roti from?","India",["Mexico","Ethiopia"]],["Where is roti cooked?","In a hot pan",["In the fridge","In the sea"]],["What do people eat with roti?","Dal or curry",["Ice cream","Juice"]]]],
  ["Strawberries","Strawberries are red. Their seeds are on the outside. They grow on small plants near the ground.",[["What colour are strawberries?","Red",["Blue","Brown"]],["Where are the seeds?","On the outside",["In a pod","In a box"]],["Where do strawberries grow?","On small plants",["On tall trees","Under the ground"]]]],
  ["Breakfast","Breakfast is the first meal of the day. Some kids eat porridge. Some kids eat rice or roti.",[["What is breakfast?","The first meal of the day",["The last meal","A drink"]],["What do some kids eat?","Porridge",["Rocks","Soap"]],["Which other foods are named?","Rice or roti",["Cake or candy","Fish or soup"]]]],
  ["Popcorn","Popcorn comes from corn seeds. When the seeds get hot, they pop! Popcorn is a crunchy snack.",[["What does popcorn come from?","Corn seeds",["Apple seeds","Rice"]],["What happens when the seeds get hot?","They pop",["They melt","They grow"]],["What kind of snack is popcorn?","Crunchy",["Juicy","Sour"]]]]
 ],
 MAIN:[
  ["Mangoes are sweet. Bananas are sweet. Grapes are sweet too.","Many fruits are sweet.",["Grapes are green.","Bananas are long."]],
  ["Dot gets a pot. She adds water and peas. She stirs the soup.","Dot makes soup.",["Dot has a pot.","Peas are green."]],
  ["Priya eats roti. Diego eats tortillas. Mei eats noodles.","Kids eat different foods.",["Mei likes noodles.","Roti is round."]],
  ["Wash your hands. Wash the fruit. Wash the cup when you are done.","We wash many things in the kitchen.",["Cups are round.","Fruit is sweet."]],
  ["Carrots are orange. Peas are green. Tomatoes are red.","Foods come in many colours.",["Carrots are crunchy.","Peas are small."]],
  ["We eat breakfast in the morning. We eat lunch at noon. We eat dinner at night.","We eat meals at different times.",["Dinner is at night.","Noon is lunch time."]],
  ["A grown-up cuts the bread. A grown-up holds the hot pot. A grown-up uses the stove.","Grown-ups help with sharp and hot things.",["Bread is soft.","The stove is big."]],
  ["Carrots grow under the ground. Potatoes grow under the ground. Onions grow under the ground too.","Some foods grow under the ground.",["Onions are round.","Carrots are orange."]],
  ["Apples grow on trees. Mangoes grow on trees. Cherries grow on trees too.","Some fruits grow on trees.",["Mangoes are big.","Cherries are red."]],
  ["Popcorn is crunchy. Carrots are crunchy. Crackers are crunchy too.","Some snacks are crunchy.",["Popcorn is hot.","Crackers are flat."]],
  ["Mei uses chopsticks. Abebe uses his hands. Ken uses a spoon.","People eat in different ways.",["Ken has a spoon.","Chopsticks are thin."]],
  ["Water helps you grow. Water helps you play. Water is good when you are thirsty.","Water is good for you.",["Water is wet.","Play is fun."]],
  ["Gran bakes bread. Gran bakes cookies. Gran bakes a big cake.","Gran bakes many things.",["Cookies are sweet.","The cake is big."]],
  ["Lemons are sour. Limes are sour. Some green apples are sour too.","Some fruits taste sour.",["Lemons are yellow.","Limes are green."]],
  ["Tom shares his popcorn. Ana shares her grapes. They share their juice too.","Tom and Ana share their snacks.",["Grapes are round.","Juice is wet."]],
  ["Peel the banana. Cut the banana. Put it in a cup.","How to get a banana ready.",["Bananas are yellow.","Cups are small."]],
  ["Soup is hot. Tea is hot. Toast is hot too.","Some foods and drinks are hot.",["Tea is a drink.","Toast is brown."]],
  ["Ice cream is cold. Juice from the fridge is cold. Ice is cold too.","Some foods are cold.",["Juice is orange.","Ice is hard."]],
  ["In Japan, kids eat rice. In India, kids eat rice. In Mexico, kids eat rice too.","Kids in many countries eat rice.",["Japan is far away.","India is big."]],
  ["Mix the fruit. Pour the juice. Eat the fruit cup.","How to finish a fruit cup.",["Juice is sweet.","Fruit is red."]],
  ["Grapes grow in bunches. Bananas grow in bunches. Cherries can grow in bunches too.","Some fruits grow in bunches.",["Grapes are purple.","Bananas are long."]],
  ["Strawberries are red. Cherries are red. Tomatoes are red too.","Some foods are red.",["Cherries are small.","Tomatoes are round."]],
  ["Ken sets the table. Mom cooks the rice. Dad pours the water.","The family gets dinner ready.",["Dad likes water.","Rice is white."]],
  ["Peas are green. Broccoli is green. Lettuce is green too.","Some vegetables are green.",["Peas are round.","Lettuce is a leaf."]]
 ],
 FACTS:["Bananas are yellow when they are ripe.","Carrots grow under the ground.","Lemons taste sour.","Peas grow in pods.","Apples grow on trees.","Rice grows in wet fields.","Roti is a bread from India.","Tortillas are flat and round.","Injera comes from Ethiopia.","Chopsticks are two thin sticks.","We eat breakfast in the morning.","We can eat soup with a spoon.","Broccoli is green.","Strawberries are red.","An oven gets hot.","Ice cream melts in the sun.","Popcorn comes from corn.","Honey is sweet.","Potatoes grow under the ground.","A ripe tomato is red.","Grapes grow in bunches.","Water is a drink.","A mango has a big seed.","A carrot is orange.","Blueberries are small."],
 OPIN:["Mangoes are the best fruit.","Soup is yummy.","Broccoli tastes great.","Pizza is better than rice.","Lemons are too sour.","Breakfast is the best meal.","Grapes are more fun than pears.","Popcorn is the best snack.","Red is the prettiest colour.","Noodles are more fun than rice.","Cooking is fun.","Carrots are yummy.","Everyone should love peas.","Tortillas are tastier than bread.","Chopsticks are cool.","Baking is easy.","Purple is a nice colour.","Fruit cups are the best treat.","Dinner is boring.","Juice tastes better than water.","Potatoes are delicious.","Bananas are the yummiest fruit.","Cherries are cute.","Sweet food is the best.","Washing dishes is fun."],
 SEQ:[["Wash your hands","Wash the fruit","Cut the fruit","Eat the fruit"],["Get a pot","Put in water","Add the noodles","Eat the noodles"],["Peel the banana","Cut the banana","Put it on toast","Eat the toast"],["Wake up","Eat breakfast","Go to school","Eat lunch"],["Eat lunch","Go home","Eat dinner","Go to bed"],["Mix the batter","Pour it in a pan","Bake the cake","Eat the cake"],["Get a cup","Pour the juice","Drink the juice","Wash the cup"],["Put corn seeds in a pot","Heat the pot","Pop, pop, pop!","Eat the popcorn"],["Make the roti dough","Roll it flat","Cook it in a pan","Eat the roti"],["Set the table","Sit down","Eat dinner","Clean up"],["Go to the shop","Buy some fruit","Take it home","Wash the fruit"]],
 CE:[["The soup was hot, so Dot waited.","the soup was hot","Dot waited"],["Tom dropped his cup, so the juice spilled.","Tom dropped his cup","the juice spilled"],["The ice cream sat in the sun, so it melted.","the ice cream sat in the sun","it melted"],["Ana was hungry, so she ate a pear.","Ana was hungry","she ate a pear"],["Ken was thirsty, so he drank water.","Ken was thirsty","he drank water"],["The corn got hot, so it popped.","the corn got hot","it popped"],["Mia ate a lemon, so she made a sour face.","Mia ate a lemon","she made a sour face"],["Dad left the toast in too long, so it got burnt.","Dad left the toast in too long","it got burnt"],["Sam did not wash the plate, so it was dirty.","Sam did not wash the plate","it was dirty"],["The banana was old, so it was brown.","the banana was old","it was brown"],["Gran baked cookies, so the house smelled sweet.","Gran baked cookies","the house smelled sweet"],["Lily shared her grapes, so her friend smiled.","Lily shared her grapes","her friend smiled"],["The pot was too hot, so Grandpa used a mitt.","the pot was too hot","Grandpa used a mitt"],["It was morning, so we ate breakfast.","it was morning","we ate breakfast"],["The rice cooked too long, so it got sticky.","the rice cooked too long","it got sticky"],["Diego was cold, so he had hot soup.","Diego was cold","he had hot soup"],["The peach was ripe, so it was soft.","the peach was ripe","it was soft"],["Omar spilled the juice, so he got a cloth.","Omar spilled the juice","he got a cloth"],["The cake was big, so we shared it.","the cake was big","we shared it"],["The kids had dirty hands, so they washed them.","the kids had dirty hands","they washed them"],["The bowl fell, so it broke.","the bowl fell","it broke"]],
 CMP:[
  ["Roti and tortillas are both flat bread. Roti is from India. Tortillas are from Mexico.","Both are flat bread","Roti is from India, but tortillas are from Mexico",["Both are drinks","Tortillas are from India"]],
  ["Lemons and bananas are both yellow. Lemons are sour. Bananas are sweet.","Both are yellow","Lemons are sour, but bananas are sweet",["Both are sour","Bananas are sour"]],
  ["Carrots and potatoes both grow under the ground. Carrots are orange. Potatoes are brown.","Both grow under the ground","Carrots are orange, but potatoes are brown",["Both grow on trees","Carrots are brown"]],
  ["Soup and ice cream are both foods. Soup is hot. Ice cream is cold.","Both are foods","Soup is hot, but ice cream is cold",["Both are hot","Ice cream is hot"]],
  ["Mei and Ken both eat rice. Mei lives in China. Ken lives in Japan.","Both eat rice","Mei lives in China, but Ken lives in Japan",["Both live in Mexico","Ken lives in China"]],
  ["Cherries and strawberries are both red. Cherries grow on trees. Strawberries grow on small plants.","Both are red","Cherries grow on trees, but strawberries grow on small plants",["Both are blue","Strawberries grow on trees"]],
  ["Breakfast and dinner are both meals. Breakfast is in the morning. Dinner is at night.","Both are meals","Breakfast is in the morning, but dinner is at night",["Both are at night","Dinner is in the morning"]],
  ["Peas and broccoli are both green. Peas are small and round. Broccoli looks like a tree.","Both are green","Peas are round, but broccoli looks like a tree",["Both are red","Peas look like a tree"]],
  ["Juice and water are both drinks. Juice is sweet. Water has no taste.","Both are drinks","Juice is sweet, but water has no taste",["Both are sweet","Water is sweet"]],
  ["A spoon and a fork both help us eat. A spoon is good for soup. A fork is good for noodles.","Both help us eat","A spoon is for soup, but a fork is for noodles",["Both are for cutting","A fork is for soup"]],
  ["Popcorn and carrots are both crunchy. Popcorn comes from corn. Carrots are vegetables.","Both are crunchy","Popcorn comes from corn, but carrots are vegetables",["Both are soft","Carrots come from corn"]],
  ["Grapes and blueberries are both small fruits. Grapes grow on vines. Blueberries grow on bushes.","Both are small fruits","Grapes grow on vines, but blueberries grow on bushes",["Both are big","Blueberries grow on vines"]]
 ],
 GRP:{"fruits":["banana","pear","mango","grapes","cherry"],"vegetables":["potato","peas","carrot","lettuce","onion"],"colours":["red","yellow","green","purple","brown"],"meals":["breakfast","lunch","dinner"],"kitchen things":["pan","spoon","fork","bowl","cup"],"action words":["cut","mix","pour","wash","bake"],"drinks":["juice","tea","cocoa","lemonade"],"short o words":["fox","dog","log","frog","sock"]},
 ANA:[["Banana is to yellow as broccoli is to ___.","green",["red","blue"]],["Cherry is to red as carrot is to ___.","orange",["purple","blue"]],["Morning is to breakfast as night is to ___.","dinner",["lunch","breakfast"]],["Soup is to spoon as noodles are to ___.","chopsticks",["a cup","a straw"]],["Roti is to India as injera is to ___.","Ethiopia",["Mexico","Japan"]],["Tortilla is to Mexico as roti is to ___.","India",["China","Ethiopia"]],["Hot is to cold as sweet is to ___.","sour",["sugar","yummy"]],["Cut is to knife as stir is to ___.","spoon",["plate","cup"]],["Juice is to cup as soup is to ___.","bowl",["fork","box"]],["Lemon is to sour as honey is to ___.","sweet",["salty","cold"]],["Apple is to tree as carrot is to ___.","ground",["sky","sea"]],["Peas are to pod as grapes are to ___.","bunch",["rock","sock"]],["Bake is to oven as boil is to ___.","pot",["fridge","table"]],["Eat is to food as drink is to ___.","juice",["bread","rice"]],["Fox is to box as dog is to ___.","log",["cat","pig"]],["Hop is to top as hot is to ___.","pot",["hat","pit"]],["Ice cream is to cold as soup is to ___.","hot",["blue","sour"]],["Mouth is to eat as nose is to ___.","smell",["run","hear"]],["Wash is to soap as cut is to ___.","knife",["sock","cup"]],["Breakfast is to morning as lunch is to ___.","noon",["night","bedtime"]],["Grapes are to purple as peas are to ___.","green",["red","brown"]],["Pot is to soup as cup is to ___.","juice",["rice","bread"]],["Fork is to eat as cup is to ___.","drink",["sleep","run"]],["Sour is to lemon as crunchy is to ___.","carrot",["soup","juice"]]],
 SENT:["Dot lives in Toronto.","Priya eats roti in India.","Diego lives in Mexico.","Mei eats noodles in China.","Abebe lives in Ethiopia.","Ken eats rice in Japan.","I like soup with Grandpa.","Tom and Ana share popcorn.","I eat lunch with Sam.","Mom and I bake bread.","Lily has a green pear.","Omar likes red cherries.","I see a big pot.","On Monday we have noodles.","Ben and I cook rice.","Zoe pours juice for me.","My friend Mia likes mangoes.","I eat injera with Abebe.","Gran makes soup in Canada.","Can I have a banana?"],
 ORDER:["We eat red apples.","The soup is hot.","Dad cuts the pear.","We wash our hands.","The grapes are purple.","Mom cooks the rice.","The lemon is sour.","Kids like popcorn.","The pot is big.","Gran bakes a cake.","Mei eats noodles.","Tom has a snack.","Pour the juice slowly.","Peas are green.","We mix the fruit.","The banana is yellow.","Ken drinks water.","Stir the soup.","Ana peels an orange.","Diego likes beans."],
 WP:[
  {q:"Write a sentence about a fruit you like.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I like red cherries."},
  {q:"Write a sentence about your breakfast.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Bb]reakfast|[Ee]at|[Ee]ats|[Hh]ave)\\b","Tells about breakfast"]],model:"I eat rice for breakfast."},
  {q:"Write a sentence with an action word: <b>eat, cut, mix, pour, wash</b> or <b>bake</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ee]at|[Cc]ut|[Mm]ix|[Pp]our|[Ww]ash|[Bb]ake)","Uses an action word"]],model:"We bake bread at home."},
  {q:"Write a sentence about a red food.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Rr]ed\\b","Uses the word red"]],model:"A tomato is red."},
  {q:"Write a sentence about a green food.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Gg]reen\\b","Uses the word green"]],model:"Peas are green."},
  {q:"Write a sentence with the word <b>has</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\bhas\\b","Uses has"]],model:"My mom has a big pot."},
  {q:"Write a sentence with the word <b>have</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Hh]ave\\b","Uses have"]],model:"We have soup for dinner."},
  {q:"Write a sentence with the word <b>are</b>.",checks:[CHK.cap,CHK.end,CHK.w3,["\\bare\\b","Uses are"]],model:"The grapes are purple."},
  {q:"Write a sentence with the word <b>said</b>.",checks:[CHK.cap,CHK.end,CHK.w3,["\\bsaid\\b","Uses said"]],model:"\"Yum!\" said Dot."},
  {q:"Write a sentence about a snack you share.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ss]hare|[Ss]hares|[Gg]ive|[Gg]ives)\\b","Tells about sharing"]],model:"I share my popcorn with Tom."},
  {q:"Write a sentence about what you drink.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Dd]rink|[Dd]rinks|[Ww]ater|[Jj]uice|[Tt]ea)\\b","Tells about a drink"]],model:"I drink water at lunch."},
  {q:"Write a sentence about dinner at your home.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Dd]inner\\b","Uses dinner"]],model:"We eat dinner at six."},
  {q:"Write a sentence with a short o word like <b>pot, hot, box</b> or <b>fox</b>.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b([Pp]ot|[Hh]ot|[Bb]ox|[Ff]ox|[Dd]og|[Ll]og|[Tt]op|[Mm]op|[Hh]op|[Ss]top|[Ff]rog|[Ss]ock|[Rr]ock|[Pp]op)\\b","Uses a short o word"]],model:"The soup is hot."},
  {q:"Ask a question about food. End with a question mark.",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"Can I have a pear?"},
  {q:"Write a sentence about a food from another country. Use a capital letter for the country.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.name],model:"Abebe eats injera in Ethiopia."},
  {q:"Write a sentence about a sweet food.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Ss]weet\\b","Uses sweet"]],model:"Mangoes are sweet."},
  {q:"Write a sentence about a sour food.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Ss]our\\b","Uses sour"]],model:"A lemon is sour."},
  {q:"Write a sentence about how you help in the kitchen.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Hh]elp|[Hh]elps)\\b","Uses help"]],model:"I help my dad wash the cups."},
  {q:"Write a sentence that starts with <b>First</b>.",checks:[["^\\s*First\\b","Starts with First"],CHK.end,CHK.w3,CHK.I],model:"First, I wash my hands."},
  {q:"Write a sentence about a crunchy food.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Cc]runchy\\b","Uses crunchy"]],model:"Carrots are crunchy."}
 ],
 SYN:[["yummy","tasty"],["big","large"],["small","little"],["glad","happy"],["start","begin"],["fast","quick"],["chop","cut"],["mix","stir"],["look","see"],["shut","close"],["sick","ill"],["gift","present"],["hop","jump"],["shout","yell"],["grin","smile"],["rock","stone"],["pal","friend"],["dish","plate"],["sleepy","tired"],["loud","noisy"]],
 OPP:[["hot","cold"],["sweet","sour"],["full","empty"],["wet","dry"],["big","small"],["open","shut"],["up","down"],["in","out"],["fast","slow"],["clean","dirty"],["soft","hard"],["day","night"],["happy","sad"],["yes","no"],["on","off"],["top","bottom"],["first","last"],["give","take"],["long","short"],["new","old"]],
 COMP:[["pop","corn"],["pan","cake"],["cup","cake"],["straw","berry"],["blue","berry"],["water","melon"],["pine","apple"],["lunch","box"],["tea","pot"],["hot","dog"],["oat","meal"],["break","fast"],["tea","spoon"],["cook","book"],["home","made"],["sea","food"],["butter","fly"],["sun","flower"],["rain","bow"],["sand","box"]]
};
B.CHOOSE=G4.ch([["banana","bananna","banan"],["grapes","graps","grapse"],["lemon","lemmon","lemin"],["mango","mangow","mengo"],["potato","patato","potatoe"],["tomato","tomatto","tamato"],["rice","ryce","rics"],["soup","soop","supe"],["noodles","nudles","noodels"],["snack","snak","snackk"],["dinner","dinnar","dinur"],["breakfast","brekfast","breakfist"],["yellow","yelow","yello"],["green","gren","grean"],["purple","purpel","perple"],["orange","orang","oranje"],["sweet","swete","sweete"],["juicy","jucy","juicey"],["wash","wosh","wahs"],["cook","cuk","coock"]],B.SP);

const L={
 shorto:"Short <b>o</b> says /o/, like in <b>pot</b>, <b>hot</b> and <b>fox</b>. Say the word slowly and listen for it.",
 pic:"Say the name of the picture. Listen for short o: 🦊 <b>f-o-x</b>.",
 make:"Say the word slowly: <b>p-o-t</b>. The middle sound is short o, so the missing letter is <b>o</b>.",
 rhyme:"Rhyming words sound the same at the end. <b>hop, top, mop</b> end in -op. <b>hot, pot</b> end in -ot. <b>dog, log</b> end in -og.",
 listen:"Listen to the word. Say each sound: <b>d-o-g</b>. Write a letter for each sound.",
 verb:"An <b>action word</b> (verb) is something you can do. <b>eat, cut, mix, pour, wash, bake</b>. Try: <i>I can ___.</i>",
 vpic:"Look at the picture. What is someone doing? That is the action word. 🔪🍐 We <b>cut</b> the pear.",
 vfind:"Every sentence has an action word. It tells what someone does. <i>Mia <b>eats</b> a pear.</i>",
 colour:"Foods come in many colours. 🍌 A banana is <b>yellow</b>. 🥦 Broccoli is <b>green</b>.",
 fv:"Fruits are often sweet and have seeds, like 🍎 apples. Vegetables can be roots, leaves or pods, like 🥕 carrots.",
 sight:"Sight words are words we see a lot. Learn them by heart: <b>has, have, are, for, of, said</b>. <i>Sam <b>has</b> a pear.</i>",
 menu:"Signs, menus and labels give us facts. Read every line. The answer is there.",
 food:"Think it through. Ask: What makes sense? What is safe? What is kind?",
 mixed:"Use what you learned: short o, action words, colours and sight words."
};
u.review=G4.MIX(verbQ,vpicQ,vfindQ,shortoQ,picQ,rhymeQ,colQ,sightQ,F.vocab(u.words));
u.cats=G4.std(u,{sets:["Fruits and vegetables","Meals and food around the world","Cooking action words","Colours and taste words"],B,
 reading:[{id:"r_menu",t:"Read menus, signs and labels",learn:L.menu,gen:menuQ}],
 vocab:[{id:"v_colour",t:"Colours of food",learn:L.colour,gen:colQ},{id:"v_fruitveg",t:"Fruit or vegetable?",learn:L.fv,gen:fvQ},{id:"v_sight",t:"Sight words: has, have, are, for, of, said",learn:L.sight,gen:sightQ}],
 grammar:[{id:"g_verb",t:"Which word is an action?",learn:L.verb,gen:verbQ},{id:"g_vpic",t:"Pick the action for the picture",learn:L.vpic,gen:vpicQ},{id:"g_vfind",t:"Find the verb in the sentence",learn:L.vfind,gen:vfindQ},{id:"g_mixed",t:"Mixed review",learn:L.mixed,gen:u.review}],
 spelling:[{id:"p_shorto",t:"Short o: which word has it?",learn:L.shorto,gen:shortoQ},{id:"p_pic",t:"Short o: picture to word",learn:L.pic,gen:picQ},{id:"p_make",t:"Make the word (p _ t)",learn:L.make,gen:makeQ},{id:"p_rhyme",t:"Rhyming words: -op, -ot, -og",learn:L.rhyme,gen:rhymeQ},{id:"p_listen",t:"Short o words: listen and write",learn:L.listen,gen:F.listen(OSP)}],
 thinking:[{id:"t_food",t:"Food sense: think it through",learn:L.food,gen:F.bank(FOODT)}]});
})();
