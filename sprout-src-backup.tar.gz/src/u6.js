/* ===================== GRADE 3 · UNIT 6 · LIFE IN THE OCEAN (original content, plus one public-domain poem) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
const p=(q,a,o,why)=>({lv:"predict",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"ocean", num:6, emoji:"🌊🐠🐚", title:"Life in the Ocean", badge:"🐚 Ocean Guardian",

stories:[
/* ---------- 1. STORY (with predictions) ---------- */
{title:"The Message in the Bottle", e:"🍾", kind:"Story (predict)", pages:[
 {pic:"🏖️🍾", text:"In the summer holidays, Mia and Leo visited their aunt in Nova Scotia, on the east coast of Canada. One foggy morning, they walked along the rocky beach near the old lighthouse. Leo kicked at a pile of seaweed and stopped. Something green and shiny was tangled inside. It was a glass bottle, and there was a rolled-up piece of paper in it!",
  qs:[f("Where were Mia and Leo?","On a beach in Nova Scotia",["In a city park","At school"],"They visited their aunt in Nova Scotia, on the east coast of Canada."),
      p("What do you think they will do next?","Open the bottle and read the paper",["Throw the bottle back into the sea without looking","Go home and forget about it"],"Most curious children would want to read the message. Good readers use clues to predict what will happen.")]},
 {pic:"📜🐟", text:"Mia carefully pulled out the cork. The paper was a little damp, but the writing was clear. <i>\"Hello! My name is Sofia. I am nine years old and I live in Portugal. I threw this bottle into the ocean from my grandfather's fishing boat. If you find it, please write to me!\"</i> At the bottom was an email address and a drawing of a smiling fish.",
  qs:[f("Where does Sofia live?","Portugal",["Nova Scotia","India"],"\"I live in Portugal.\""),
      t("How did the bottle get from Portugal to Canada?","Ocean currents carried it across the sea",["A bird carried it","Sofia posted it"],"Ocean currents are like giant rivers in the sea that can carry things very far.")]},
 {pic:"🗺️🌊", text:"Back at the house, Aunt Jo spread out a big map. \"Portugal is in Europe, way over here,\" she said, pointing across the Atlantic Ocean. \"Your bottle travelled more than four thousand kilometres!\" Leo's eyes went wide. \"How long did it take?\" Aunt Jo shook her head. \"Let's ask Sofia.\"",
  qs:[f("Which ocean did the bottle cross?","The Atlantic Ocean",["The Pacific Ocean","The Indian Ocean"],"She pointed across the Atlantic Ocean."),
      p("What do you think the children will do next?","Write an email to Sofia",["Throw the map away","Go fishing"],"Aunt Jo said, \"Let's ask Sofia.\" That is a strong clue!")]},
 {pic:"💻✉️", text:"Mia and Leo wrote an email together. They told Sofia about the lighthouse, the fog and the seaweed. The next morning, there was a reply! <i>\"I can't believe it! I threw that bottle into the sea two years ago. My grandfather said it would sink. I'm so happy it reached a friend!\"</i> Sofia also sent a photo of herself on her grandfather's boat.",
  qs:[f("How long ago did Sofia throw the bottle?","Two years ago",["Two days ago","Ten years ago"],"\"I threw that bottle into the sea two years ago.\""),
      t("How did Sofia feel when she got the email?","Very happy and surprised",["Angry","Bored"],"\"I can't believe it! … I'm so happy.\"")]},
 {pic:"🐢🧴", text:"Then Sofia wrote something that made the children think. <i>\"My grandfather says we should not throw bottles in the sea anymore. Too much rubbish ends up in the ocean, and it hurts the animals. Next time, let's just send emails!\"</i> Mia looked at the beach. Among the seaweed, she could see plastic bags, a rope and a bottle cap.",
  qs:[f("What did Sofia's grandfather say?","We should not throw bottles in the sea anymore",["Throw more bottles","Fishing is boring"],"\"We should not throw bottles in the sea anymore.\""),
      p("What do you think Mia and Leo will decide to do?","Clean up the rubbish on the beach",["Throw more rubbish into the sea","Stop talking to Sofia"],"Mia noticed the rubbish just after reading about how it hurts animals.")]},
 {pic:"🧺🤝", text:"That afternoon, Mia, Leo and Aunt Jo cleaned the beach. They filled three big bags with rubbish. They kept the glass bottle on the shelf, with Sofia's letter inside, to remember their new friend. Now, every month, they send Sofia an email, and Sofia sends back photos of the sea from the other side of the ocean.",
  qs:[f("How many bags of rubbish did they fill?","Three",["One","Ten"],"They filled three big bags with rubbish."),
      t("Was your prediction on the last page correct? What really happened?","They cleaned the beach",["They went swimming","They threw the bottle away"],"Good readers check their predictions as they read.")]}
], turn:{q:"If you found a message in a bottle, what would you hope it said? Write two sentences.",model:"I would hope it was a letter from a child in another country. I would write back and become their pen pal."}},

/* ---------- 2. STORY ---------- */
{title:"Asha and the Mangrove Forest", e:"🌳", kind:"Story", pages:[
 {pic:"🛶🌳", text:"Asha lives in a village at the edge of the Sundarbans, a huge mangrove forest where the rivers of India and Bangladesh meet the sea. Mangrove trees are special. They can grow in salty water, and their tangled roots stand up out of the mud like hundreds of wooden legs.",
  qs:[f("What is special about mangrove trees?","They can grow in salty water",["They grow in deserts","They have no roots"],"Mangrove trees can grow in salty water."),
      f("What do the roots look like?","Hundreds of wooden legs",["Long ropes","Green leaves"],"Their tangled roots stand up out of the mud like hundreds of wooden legs.")]},
 {pic:"🐅👣", text:"One morning, Asha and her father paddled their small boat along the river. Fish jumped, crabs scuttled across the mud, and a kingfisher flashed blue. Then her father pointed to the muddy bank. \"Look, Asha. Tiger footprints!\" The Sundarbans is home to Bengal tigers, which can even swim across rivers.",
  qs:[f("What did Asha's father point to?","Tiger footprints",["A crocodile","A boat"],"\"Look, Asha. Tiger footprints!\""),
      t("Why might the tigers here need to swim?","The forest is full of rivers and water",["They are chasing boats","They are too hot"],"The Sundarbans is made of many islands and rivers, so tigers swim between them.")]},
 {pic:"🌀🌊", text:"\"Why do you love the mangroves so much, Baba?\" Asha asked. Her father was quiet for a moment. \"When I was a boy, a terrible cyclone came from the sea,\" he said. \"Huge waves crashed towards the land. But the mangrove forest stood in their way. The roots slowed the water down, and our village was saved.\"",
  qs:[f("What came from the sea when Asha's father was a boy?","A terrible cyclone",["A whale","A big ship"],"\"A terrible cyclone came from the sea.\""),
      t("How did the mangroves save the village?","Their roots slowed down the huge waves",["They scared the cyclone away","They floated on the water"],"The thick roots act like a wall that slows the water.")]},
 {pic:"🪓😟", text:"But in some places, people had cut down mangroves to build farms and fish ponds. Asha's teacher said that without the mangroves, villages are in more danger from storms. Fish and crabs also lose the places where their babies grow. Asha frowned. \"Can we plant new mangroves?\" she asked.",
  qs:[f("Why had people cut down some mangroves?","To build farms and fish ponds",["To make paper boats","Because tigers asked them to"],"People had cut down mangroves to build farms and fish ponds."),
      t("Why is cutting down mangroves a problem?","Villages are in more danger and young fish lose their homes",["It makes the trees grow faster","There is nothing wrong with it"],"Mangroves protect villages and are nurseries for young sea animals.")]},
 {pic:"🌱🤝", text:"That year, Asha's whole school joined a mangrove-planting project. The children collected seedlings and pushed them into the soft mud at low tide. It was messy work! Their feet sank deep, and Asha fell over twice. But by the end of the day, they had planted five hundred little trees.",
  qs:[f("How many trees did they plant?","Five hundred",["Fifty","Five"],"They had planted five hundred little trees."),
      t("Why did they plant at low tide?","The water was low, so they could reach the mud",["The fish were asleep","It was dark"],"At low tide, the sea goes out and the muddy ground is uncovered.")]},
 {pic:"🌳🦀", text:"Three years later, Asha paddled past the planting place with her little brother. The seedlings had grown taller than her! Tiny crabs climbed the roots, and baby fish darted between them. \"We planted these,\" Asha told him proudly. \"One day, they will protect our village, just like the old forest protected Baba.\"",
  qs:[f("Who was with Asha three years later?","Her little brother",["Her teacher","Sofia"],"Asha paddled past the planting place with her little brother."),
      t("What is the message of this story?","Protecting nature also protects people",["Tigers are dangerous","Mud is messy"],"The mangroves help animals AND keep the village safe.")]}
], turn:{q:"What is one thing children can do to help protect nature where you live? Write two sentences.",model:"Children can plant trees in their neighbourhood. They can also pick up rubbish at the park."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"Coral Reefs: Cities Under the Sea", e:"🪸", kind:"Fact text", pages:[
 {pic:"🪸🐠", text:"A coral reef looks like a colourful underwater garden. But the coral is not a plant. It is made of millions of tiny animals called <b>polyps</b>. Each polyp builds a hard, stony skeleton around itself. Over hundreds of years, these skeletons pile up to make a reef.",
  qs:[f("Is coral a plant or an animal?","An animal",["A plant","A rock"],"Coral is made of millions of tiny animals called polyps."),
      f("How is a reef made?","Polyp skeletons pile up over hundreds of years",["People build it with bricks","Waves push sand together"],"Over hundreds of years, these skeletons pile up to make a reef.")]},
 {pic:"🏙️🐟", text:"Coral reefs are sometimes called the cities of the sea. They cover only a tiny part of the ocean floor, but about one-quarter of all ocean creatures live on or near them. Fish, turtles, crabs, sea stars and octopuses all find food and shelter among the coral.",
  qs:[f("About how many ocean creatures live on or near reefs?","About one-quarter",["Almost none","All of them"],"About one-quarter of all ocean creatures live on or near them."),
      t("Why are reefs called the cities of the sea?","So many creatures live close together there",["They have traffic lights","People live under the water"],"Like a busy city, a reef is crowded with life.")]},
 {pic:"🐠🌸", text:"On a reef, animals often help each other. The clownfish lives among the stinging arms of a sea anemone. The clownfish has a special slimy coat, so the stings don't hurt it. The anemone protects the clownfish from bigger fish, and the clownfish keeps the anemone clean.",
  qs:[f("Why don't the anemone's stings hurt the clownfish?","It has a special slimy coat",["It is too fast","It has no skin"],"The clownfish has a special slimy coat."),
      t("How do the clownfish and the anemone help each other?","The anemone protects the clownfish, and the clownfish keeps it clean",["They fight every day","They never meet"],"Each one gives the other something it needs.")]},
 {pic:"🇦🇺🛰️", text:"The biggest reef in the world is the Great Barrier Reef, off the coast of Australia. It is more than 2,000 kilometres long. It is so big that astronauts can see it from space! It is the largest structure on Earth built by living things.",
  qs:[f("Where is the Great Barrier Reef?","Off the coast of Australia",["Off the coast of Canada","In a lake"],"Off the coast of Australia."),
      f("Who can see the reef from space?","Astronauts",["Fish","Nobody"],"Astronauts can see it from space.")]},
 {pic:"🌡️🤍", text:"Coral reefs are in danger. When the ocean gets too warm, coral becomes stressed and turns white. This is called <b>coral bleaching</b>. If the water stays too warm for too long, the coral can die. Pollution and careless fishing also harm reefs.",
  qs:[f("What is it called when coral turns white?","Coral bleaching",["Coral painting","Coral sleeping"],"This is called coral bleaching."),
      t("What causes coral bleaching?","Water that is too warm",["Too many fish","Cold winters"],"When the ocean gets too warm, coral becomes stressed and turns white.")]},
 {pic:"🤿💙", text:"Scientists and divers around the world are working to protect reefs. Some grow baby corals in underwater nurseries and plant them back on damaged reefs. Visitors can help too, by never touching or standing on coral and by using sunscreen that is safe for reefs.",
  qs:[f("Where do some scientists grow baby corals?","In underwater nurseries",["In the desert","In kitchens"],"Some grow baby corals in underwater nurseries."),
      t("Why should divers never stand on coral?","It can damage or kill the tiny animals",["The coral will bite them","It is too slippery"],"Coral is alive and fragile.")]}
], turn:{q:"Would you like to dive on a coral reef? Write two sentences saying what you would hope to see.",model:"Yes, I would love to dive on a reef. I would hope to see a clownfish hiding in an anemone."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"A Journey to the Deep", e:"🤿", kind:"Fact text", pages:[
 {pic:"🌊☀️", text:"The ocean is so deep that scientists divide it into layers, called <b>zones</b>. The top layer is the <b>sunlight zone</b>. It is bright and warm, and most ocean plants and animals live here, because plants need sunlight to make food.",
  qs:[f("What is the top layer of the ocean called?","The sunlight zone",["The midnight zone","The sand zone"],"The top layer is the sunlight zone."),
      t("Why do most ocean plants live in the sunlight zone?","Plants need sunlight to make food",["It is the coldest zone","There are no fish there"],"Plants need sunlight to make their food.")]},
 {pic:"🌗🦑", text:"Below that is the <b>twilight zone</b>. Only a little sunlight reaches it, so it is dim and blue, like the sky just after sunset. Many animals here swim up to the sunlight zone at night to feed, then sink back down in the day to hide from predators.",
  qs:[f("Why is it called the twilight zone?","It is dim and blue, like the sky just after sunset",["It only exists at night","Twilight is the name of a fish"],"Twilight is the dim time just after sunset."),
      t("Why do the animals swim back down in the day?","To hide from predators",["To sleep in beds","To find sunlight"],"In the dark, it is harder for predators to see them.")]},
 {pic:"🌑🐟", text:"Deeper still is the <b>midnight zone</b>. No sunlight reaches it at all. It is pitch black and very cold. But it is not completely dark! Many creatures here make their own light. The anglerfish has a glowing lure on its head, like a fishing rod, to attract smaller fish to its huge mouth.",
  qs:[f("What does the anglerfish have on its head?","A glowing lure, like a fishing rod",["A crown","A shell"],"The anglerfish has a glowing lure on its head."),
      t("Why does the anglerfish have a glowing lure?","To attract smaller fish to eat",["To read in the dark","To scare away divers"],"Little fish swim towards the light and get eaten.")]},
 {pic:"🏔️⬇️", text:"The deepest place in the ocean is the <b>Mariana Trench</b> in the Pacific Ocean. It is about 11 kilometres deep. If you put Mount Everest, the tallest mountain on Earth, at the bottom, its top would still be more than 2 kilometres under the water!",
  qs:[f("Where is the Mariana Trench?","In the Pacific Ocean",["In the Atlantic Ocean","In a lake in Canada"],"The Mariana Trench is in the Pacific Ocean."),
      t("What does the Mount Everest comparison show?","The trench is deeper than the tallest mountain is tall",["Everest is underwater","Mountains can swim"],"Even the tallest mountain would fit inside the trench.")]},
 {pic:"🫧🚢", text:"Deep down, the water presses on everything with enormous force. This is called <b>water pressure</b>. A human diver would be crushed, so scientists explore the deep in special submarines with thick, strong walls. They also send robots with cameras.",
  qs:[f("How do scientists explore the deep ocean?","In special submarines and with robots",["By swimming in a swimsuit","On a sailboat"],"Scientists explore in special submarines and send robots with cameras."),
      t("Why do submarines need thick, strong walls?","To stand up to the enormous water pressure",["To keep fish out","To look nice"],"The deeper you go, the harder the water presses.")]},
 {pic:"🔦❓", text:"Scientists say we have explored only a small part of the deep ocean. Every year, they discover new creatures, like see-through fish and glowing jellyfish. Some people say we know more about the surface of the Moon than about the bottom of our own ocean!",
  qs:[f("How much of the deep ocean has been explored?","Only a small part",["All of it","Exactly half"],"We have explored only a small part of the deep ocean."),
      t("Why might we know more about the Moon's surface than the deep ocean?","The deep ocean is dark, cold and hard to reach",["The Moon is closer","Fish hide the maps"],"Deep water is dark and has crushing pressure, which makes it very hard to explore.")]}
], turn:{q:"Imagine you discovered a brand-new creature in the deep ocean. Describe it in two sentences.",model:"My creature is a purple fish with glowing blue spots. It uses its light to talk to its friends in the dark."}},

/* ---------- 5. FABLE ---------- */
{title:"Shelly the Hermit Crab (a fable)", e:"🐚", kind:"Fable", pages:[
 {pic:"🦀🐚", text:"Shelly was a little hermit crab. Hermit crabs don't grow their own shells. Instead, they live in empty shells that they find. Shelly loved her shell. It was spiral, pink and just the right size. \"This is the best shell in the whole ocean,\" she said, \"and I will keep it forever.\"",
  qs:[f("Where do hermit crabs live?","In empty shells they find",["In shells they grow","In holes in the sand only"],"Hermit crabs live in empty shells that they find."),
      p("What do you think will happen as Shelly grows?","Her shell will become too small",["Her shell will grow with her","She will shrink"],"Shells don't grow, but crabs do. That is a strong clue!")]},
 {pic:"😣🐚", text:"But Shelly grew, and her shell did not. Soon it pinched her legs. She couldn't pull herself all the way inside when a seagull flew over. \"You need a bigger shell,\" said her friend Pearl, an old sea turtle. \"Never!\" said Shelly. \"I'm scared to leave. What if I never find a shell as good as this one?\"",
  qs:[f("What happened when Shelly grew?","Her shell pinched her and was too small",["Her shell grew too","She could fly"],"Soon it pinched her legs."),
      t("Why didn't Shelly want to leave her shell?","She was scared she wouldn't find a better one",["She was lazy","Pearl told her to stay"],"\"I'm scared to leave. What if I never find a shell as good as this one?\"")]},
 {pic:"🦀🦀🦀", text:"One day, Shelly saw something amazing on the sand. A row of hermit crabs was lined up from smallest to biggest beside a large, empty shell. The biggest crab climbed into the new shell. The next crab took the shell it left behind, and the next took that one, until every crab had a bigger home!",
  qs:[f("How were the crabs lined up?","From smallest to biggest",["By colour","In a circle"],"A row of hermit crabs was lined up from smallest to biggest."),
      t("Why did the crabs line up?","So each crab could move into a bigger shell",["To race each other","To hide from the sun"],"When one crab moves to a bigger shell, it leaves its old shell for the next crab.")]},
 {pic:"🐚✨", text:"At the end of the line, there was one shell left over: a little bigger than Shelly's, smooth and white with brown stripes. Shelly's heart thumped. She stepped out of her pink shell, felt the cool water on her soft body, and quickly climbed into the new one. It fit perfectly. She had room to grow!",
  qs:[f("What did the new shell look like?","Smooth and white with brown stripes",["Pink and spiral","Black and spiky"],"Smooth and white with brown stripes."),
      t("How do you think Shelly felt when she stepped out of her old shell?","Scared but brave",["Bored","Angry"],"Her heart thumped, but she did it anyway. That is bravery.")]},
 {pic:"🦀💛", text:"Shelly left her old pink shell on the sand, and a tiny crab happily moved in. \"Thank you!\" it squeaked. Shelly smiled. She had been afraid of change, but change had given her room to grow, and her old home had become a gift for someone else. <b>Lesson: Growing up means being brave enough to change.</b>",
  qs:[t("What is the lesson of this fable?","Growing up means being brave enough to change",["Never leave your home","Pink shells are best"],"Shelly learned that change helps us grow."),
      f("What happened to Shelly's old shell?","A tiny crab moved into it",["It broke","Shelly took it with her"],"A tiny crab happily moved in.")]}
], turn:{q:"Write about a change in your life, like a new school, a new home or a new baby in the family. How did you feel?",model:"When I moved to a new school, I felt nervous. After a week, I made two new friends and felt happy."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A tide table and a beach safety sign", e:"🏖️", kind:"Real-world text", pages:[
 {pic:"🌊📋", text:"The Bay of Fundy, between New Brunswick and Nova Scotia in Canada, has the highest tides in the world. The water can rise and fall more than 15 metres, as tall as a five-storey building! Here is a tide table for one day.<table class=\"realtbl\"><tr><th>Tide</th><th>Time</th><th>What you will see</th></tr><tr><td>🔽 Low tide</td><td>6:10 a.m.</td><td>Walk on the ocean floor!</td></tr><tr><td>🔼 High tide</td><td>12:25 p.m.</td><td>Water covers the beach</td></tr><tr><td>🔽 Low tide</td><td>6:35 p.m.</td><td>Walk on the ocean floor!</td></tr><tr><td>🔼 High tide</td><td>12:50 a.m. (next night)</td><td>Water covers the beach</td></tr></table>",
  qs:[f("Where are the highest tides in the world?","The Bay of Fundy, in Canada",["The Sahara","The Great Barrier Reef"],"The Bay of Fundy has the highest tides in the world."),
      f("What time is the first low tide?","6:10 a.m.",["12:25 p.m.","6:35 p.m."],"Low tide: 6:10 a.m."),
      t("How many high tides happen in about one day?","Two",["One","Six"],"The table shows high tide at 12:25 p.m. and again at 12:50 a.m., so there are two."),
      t("When should you walk on the ocean floor?","At low tide",["At high tide","Never check the time"],"At low tide, the water goes out and you can walk where the sea was."),
      t("About how long is it from the first low tide to the high tide?","About 6 hours",["About 1 hour","About 12 days"],"From 6:10 a.m. to 12:25 p.m. is a little more than 6 hours.")]},
 {pic:"🚩🏊", text:"Read this beach safety sign.<div class=\"realdoc\" style=\"text-align:left\"><b>🏖️ BEACH SAFETY 🏖️</b><br>🟢 Green flag: Calm water<br>🟡 Yellow flag: Swim with care<br>🔴 Red flag: <b>No swimming!</b><br><br>🌊 <b>Caught in a rip current?</b> (a strong current that pulls you away from the shore)<br>1. Stay calm. Don't fight the current.<br>2. Swim <b>sideways</b>, along the shore, until you are out of it.<br>3. If you can't, float and wave for help.<br><br>👀 Always swim near a lifeguard and with a grown-up.<br>⏰ Check the tide times. Don't get stuck on rocks when the tide comes in!</div>",
  qs:[f("What does a red flag mean?","No swimming",["Calm water","Swim with care"],"🔴 Red flag: No swimming!"),
      f("If you are caught in a rip current, which way should you swim?","Sideways, along the shore",["Straight back to the shore against the current","Further out to sea"],"Swim sideways, along the shore, until you are out of it."),
      t("Why shouldn't you fight a rip current?","It is stronger than you, and you will get tired",["It is warm","It helps you swim faster"],"Rip currents are very strong. Fighting them makes swimmers exhausted."),
      t("Why should you check the tide times?","The tide could come in and trap you on the rocks",["To know when lunch is","Because fish are hungry at high tide"],"At places like the Bay of Fundy, the water rises fast and high.")]}
], turn:{q:"Write two safety rules for children at the beach. Explain why one is important.",model:"Always swim near a lifeguard. Never swim when the red flag is up, because the water is dangerous."}}
],

poems:[
 {title:"At the Sea-Side (by Robert Louis Stevenson, 1885)",
  lines:["When I was down beside the sea","A wooden spade they gave to me","To dig the sandy shore.","","My holes were empty like a cup,","In every hole the sea came up,","Till it could come no more."],
  qs:[f("What did the child use to dig?","A wooden spade",["A metal bucket","His hands only"],"\"A wooden spade they gave to me.\""),
      t("Why did the sea come up into the holes?","The water from the sea soaked through the sand",["Someone poured water in","It rained"],"Near the sea, the sand is full of water, so holes fill up."),
      f("Which word rhymes with 'sea'?","me",["sand","cup"],"Sea and me end with the same sound.")]},
 {title:"Down in the Deep",
  lines:["Down in the deep where the sunlight fades,","The anglerfish glows in the dark blue shades.","Up on the reef, where the waters are warm,","The clownfish hides from the shark and the storm.","Out on the waves, the gulls dip and fly,","Under the clouds and the wide grey sky.","Ocean, oh ocean, so big and so old,","Full of more secrets than ever been told."],
  qs:[f("Where does the clownfish hide?","On the reef, where the waters are warm",["In the deep, dark zone","Up in the sky"],"\"Up on the reef, where the waters are warm, the clownfish hides.\""),
      f("Which word rhymes with 'warm'?","storm",["reef","shark"],"Warm and storm end with the same sound."),
      t("What does \"Full of more secrets than ever been told\" mean?","There is still a lot we don't know about the ocean",["The ocean tells stories","Fish keep diaries"],"Scientists have explored only a small part of the ocean.")]}
],

words:[
 {w:"reef",e:"🪸",m:"a long line of rock or coral near the surface of the sea",ex:"Colourful fish swim around the coral reef.",fill:"The divers explored a coral ___ full of fish."},
 {w:"tide",e:"🌊",m:"the rising and falling of the sea, usually twice a day",ex:"At low tide, we can walk on the sand.",fill:"When the ___ comes in, the beach is covered with water."},
 {w:"shore",e:"🏖️",m:"the land along the edge of the sea or a lake",ex:"We collected shells along the shore.",fill:"The waves crashed on the rocky ___."},
 {w:"current",e:"➰",m:"water (or air) moving strongly in one direction",ex:"The current carried the bottle across the ocean.",fill:"A strong ___ carried the boat out to sea."},
 {w:"coast",e:"🗺️",m:"the land next to the sea",ex:"Nova Scotia is on the east coast of Canada.",fill:"The lighthouse stands on the ___."},
 {w:"bay",e:"⛵",m:"a part of the sea that curves into the land",ex:"The Bay of Fundy has very high tides.",fill:"The boats sheltered in the calm ___."},
 {w:"island",e:"🏝️",m:"land with water all around it",ex:"The coconut floated to a new island.",fill:"We took a boat to the little ___ in the middle of the lake."},
 {w:"lagoon",e:"🏝️",m:"a calm area of salt water separated from the sea",ex:"We swam in the warm, calm lagoon.",fill:"The water in the ___ was calm and clear."},
 {w:"trench",e:"🕳️",m:"a long, deep, narrow hole, like a ditch",ex:"The Mariana Trench is the deepest place in the ocean.",fill:"The deepest part of the ocean is a ___."},
 {w:"mangrove",e:"🌳",m:"a tree that grows in salty water along tropical coasts",ex:"Mangrove roots protect the village from big waves.",fill:"A ___ tree can grow in salty water."},

 {w:"coral",e:"🪸",m:"a hard material made by tiny sea animals, which forms reefs",ex:"Coral is made by tiny animals called polyps.",fill:"Tiny animals build ___ reefs."},
 {w:"plankton",e:"🦠",m:"tiny plants and animals that drift in the sea",ex:"Whales eat tiny plankton.",fill:"Many sea animals eat tiny floating ___."},
 {w:"anemone",e:"🌸",m:"a soft sea animal with stinging arms that looks like a flower",ex:"The clownfish lives in a sea anemone.",fill:"The clownfish hides in the arms of a sea ___."},
 {w:"jellyfish",e:"🪼",m:"a soft, see-through sea animal that can sting",ex:"Don't touch a jellyfish; it may sting.",fill:"A ___ is soft, see-through and can sting."},
 {w:"seahorse",e:"🐴",m:"a small fish with a head shaped like a horse's",ex:"The seahorse wrapped its tail around the seaweed.",fill:"A ___ has a head shaped like a horse."},
 {w:"crab",e:"🦀",m:"a sea animal with a hard shell, ten legs and two big claws",ex:"A crab scuttled across the mud.",fill:"The ___ walked sideways across the sand."},
 {w:"eel",e:"🐍",m:"a long, thin fish that looks like a snake",ex:"An eel hid in a crack in the rocks.",fill:"The long, thin ___ looked like a snake."},
 {w:"stingray",e:"🐟",m:"a flat fish with wide fins and a long tail",ex:"The stingray glided over the sand.",fill:"The flat ___ glided across the sea floor."},
 {w:"salmon",e:"🐟",m:"a large fish that swims from the sea back up the river where it hatched",ex:"Salmon swim up rivers in British Columbia.",fill:"Every autumn, ___ swim back up the river where they hatched."},
 {w:"shell",e:"🐚",m:"the hard outer covering of some sea animals",ex:"Shelly lived in an empty shell.",fill:"I held the ___ to my ear and heard the sea."},

 {w:"submarine",e:"🚢",m:"a ship that can travel under the water",ex:"Scientists explore the deep sea in a submarine.",fill:"The ___ dived deep under the waves."},
 {w:"diver",e:"🤿",m:"a person who swims under the water, often with special equipment",ex:"The diver saw a turtle on the reef.",fill:"The ___ wore a mask and flippers."},
 {w:"lighthouse",e:"🗼",m:"a tower with a bright light that warns ships of danger",ex:"The lighthouse flashed in the fog.",fill:"The ___ shone its light to warn the ships."},
 {w:"anchor",e:"⚓",m:"a heavy metal object dropped from a boat to keep it in one place",ex:"The sailors dropped the anchor.",fill:"Drop the ___ so the boat does not drift away."},
 {w:"harbour",e:"⛴️",m:"a safe place where boats can stay near the land",ex:"The fishing boats returned to the harbour.",fill:"The boats were safe in the ___ during the storm.",alt:["harbor"]},
 {w:"voyage",e:"🧭",m:"a long journey, especially by sea",ex:"The bottle made a long voyage across the ocean.",fill:"The sailors went on a long ___ across the ocean."},
 {w:"sailor",e:"🧑‍✈️",m:"a person who works on a ship or sails a boat",ex:"The sailor followed the North Star.",fill:"The ___ tied the ropes on the ship."},
 {w:"pressure",e:"🫧",m:"the force of something pressing on something else",ex:"Water pressure is very strong in the deep ocean.",fill:"Deep in the sea, the water ___ is enormous."},
 {w:"pollution",e:"🗑️",m:"dirt, rubbish or chemicals that harm the air, land or water",ex:"Plastic pollution hurts sea animals.",fill:"Plastic bags in the sea are a kind of ___."},
 {w:"recycle",e:"♻️",m:"to make something new out of old things instead of throwing them away",ex:"We recycle bottles and cans.",fill:"Please ___ your plastic bottles."},

 {w:"shallow",e:"🦶",m:"not deep",ex:"Little children play in the shallow water.",fill:"The water is ___, so it only comes up to my knees."},
 {w:"murky",e:"🌫️",m:"dark and dirty, so it is hard to see through",ex:"We couldn't see the fish in the murky water.",fill:"The pond was so ___ we couldn't see the bottom."},
 {w:"salty",e:"🧂",m:"tasting of salt",ex:"Sea water is salty.",fill:"Don't drink sea water; it is too ___."},
 {w:"slippery",e:"🧼",m:"smooth or wet, so it is easy to slide or fall",ex:"The wet rocks were slippery.",fill:"Be careful on the wet, ___ rocks."},
 {w:"transparent",e:"🪟",m:"clear, so you can see through it",ex:"Some jellyfish are transparent.",fill:"The jellyfish was ___, like glass."},
 {w:"colourful",e:"🌈",m:"having many bright colours",ex:"The reef is full of colourful fish.",fill:"The coral reef was bright and ___.",alt:["colorful"]},
 {w:"graceful",e:"🩰",m:"moving in a smooth, beautiful way",ex:"The stingray is graceful.",fill:"The ___ dolphin leapt smoothly over the waves."},
 {w:"unusual",e:"🦄",m:"not usual; strange or rare",ex:"The anglerfish is an unusual fish.",fill:"A fish that glows in the dark is very ___."},
 {w:"unsafe",e:"⚠️",m:"not safe; dangerous",ex:"It is unsafe to swim when the red flag is up.",fill:"It is ___ to swim alone in the sea."},
 {w:"unknown",e:"❓",m:"not known",ex:"Many deep-sea creatures are still unknown.",fill:"Many creatures in the deep ocean are still ___."}
],

spelling:[
 {w:"ocean",s:"The ocean is very deep.",tip:"o-c-e-a-n. The 'c' sounds like 'sh'."},
 {w:"wave",s:"A big wave crashed on the shore.",tip:"Magic e: w-a-ve."},
 {w:"shell",s:"I found a shell on the beach.",tip:"Double l at the end."},
 {w:"beach",s:"We walked along the beach.",tip:"'ea' says long e: b-ea-ch."},
 {w:"sand",s:"The sand is warm."},
 {w:"fish",s:"A fish swam past."},
 {w:"crab",s:"The crab has big claws."},
 {w:"boat",s:"The boat sailed away.",tip:"'oa' says long o: b-oa-t."},
 {w:"whale",s:"A whale swam by.",tip:"'wh' at the start, magic e at the end."},
 {w:"coral",s:"The coral is colourful."},
 {w:"island",s:"We sailed to an island.",tip:"The 's' is silent: i-s-land."},
 {w:"shore",s:"The waves hit the shore."},
 {w:"salty",s:"The sea is salty."},
 {w:"deep",s:"The ocean is very deep.",tip:"Double e: d-ee-p."},
 {w:"swim",s:"Dolphins swim fast."}
],

facts:[
 {e:"🐴",c:"Seahorse dads carry the babies before they are born.",t:true,x:"True! The father seahorse keeps the eggs in a pouch on his belly until the babies are ready to swim out."},
 {e:"🪸",c:"Coral is a kind of plant.",t:false,x:"Not true! Coral is made of tiny animals called polyps."},
 {e:"🫁",c:"About half of the oxygen we breathe comes from the ocean.",t:true,x:"True! Tiny ocean plants called phytoplankton make a huge amount of the world's oxygen."},
 {e:"🏔️",c:"The deepest part of the ocean is deeper than Mount Everest is tall.",t:true,x:"True! The Mariana Trench is about 11 km deep, and Everest is less than 9 km tall."},
 {e:"🪼",c:"Jellyfish have no brain.",t:true,x:"True! Jellyfish have no brain, no heart and no bones, but they have lived in the ocean for millions of years."},
 {e:"✨",c:"Some deep-sea animals make their own light.",t:true,x:"True! In the dark midnight zone, many fish, squid and jellyfish glow."},
 {e:"🦈",c:"Sharks have lived on Earth longer than trees.",t:true,x:"True! Sharks were swimming in the oceans millions of years before the first trees grew."},
 {e:"⭐",c:"A sea star can grow back an arm if it loses one.",t:true,x:"True! Many sea stars can regrow lost arms."},
 {e:"🌊",c:"The Bay of Fundy in Canada has the highest tides in the world.",t:true,x:"True! The water there can rise more than 15 metres."},
 {e:"🥤",c:"If you are very thirsty at sea, it is safe to drink sea water.",t:false,x:"Not true! Sea water is too salty. Drinking it makes your body lose even more water."},
 {e:"🗺️",c:"Scientists have explored almost all of the deep ocean.",t:false,x:"Not true! Most of the deep ocean has never been explored."},
 {e:"🐟",c:"Salmon find their way back to the river where they hatched.",t:true,x:"True! Salmon travel the ocean for years and then swim back to the very river where they were born, partly by smell."}
],

writing:[
 {e:"🏖️",t:"Describe a beach using your senses",level:"Step 1 · Sentences",
  prompt:"Imagine you are at the beach. Write at least 4 sentences about what you see, hear, smell, feel and taste. Use at least 2 describing words from the word bank.",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["I can see ","I can hear ","The air smells ","The sand feels ","The water tastes "],
  model:"I can see colourful sailboats and a tall lighthouse on the shore. I can hear the waves crashing and the seagulls calling. The air smells salty and fresh. The wet rocks feel slippery under my feet. When a wave splashes me, the water tastes salty."},
 {e:"✉️",t:"A letter to keep our beaches clean",level:"Step 2 · Opinion letter",
  prompt:"Write a letter to the people of your town. Give your opinion: why should everyone keep beaches, rivers and oceans clean? Give at least 2 reasons using \"because\". Use words like \"should\" or \"must\". Start with \"Dear\" and finish with \"From,\" and your first name. Write at least 6 sentences.",
  minS:6,minWords:2,
  rx:[["^\\s*Dear\\s+\\w","I started with Dear"],["\\b(should|must)\\b","I used should or must"],["(\\bbecause\\b[\\s\\S]*){2}","I gave at least 2 reasons with because"],["(From|Your friend|Sincerely|Love),?\\s*\\n*\\s*[A-Z][a-z]+[.!]?\\s*$","I ended with From, and my name"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["Dear people of ","I think we should ","This is important because ","Another reason is that ","Please ","From,\n"],
  model:"Dear people of Toronto,\nI think we should all keep our beaches and the lake clean. This is important because plastic pollution hurts fish, birds and turtles. Another reason is that clean water is safer for children to swim in, because rubbish can carry germs. We must recycle our bottles and never leave rubbish on the sand. Please join our beach clean-up next Saturday! Together, we can protect the animals that live in the water.\nFrom,\nMia"},
 {e:"📖",t:"An ocean adventure story",level:"Step 3 · Story",
  prompt:"Write a story of at least 8 sentences about an adventure in or near the ocean. Your story needs a BEGINNING (who and where), a MIDDLE (a problem) and an END (how the problem is solved). Write in the past tense. Use time words like One day, Suddenly, Then and Finally.",
  minS:8,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],
      ["\\b(One day|Once upon a time|Long ago|Last summer)\\b","My beginning uses a time phrase (One day…)"],
      ["\\b(Suddenly|But|Then|Next)\\b","My middle uses Suddenly, But or Then"],
      ["\\b(Finally|In the end|At last)\\b","My ending uses Finally, In the end or At last"],
      ["(\\b(\\w+ed|saw|went|was|were|had|felt|swam|ran|came|found|took|made|got|told|thought|began|knew|caught|dove|dived)\\b[\\s\\S]*){3}","I used at least 3 past-tense verbs"]],
  starters:["One day, ","was swimming near ","Suddenly, ","Then, ","Finally, ","In the end, "],
  model:"One day, a young dolphin named Splash was playing near a coral reef. Suddenly, she heard a cry for help. A baby sea turtle was tangled in an old fishing net! Splash tried to pull the net with her teeth, but it was too strong. Then she swam to the surface and clicked loudly for her friends. Three dolphins came and pulled the net together. Finally, the net came loose, and the little turtle swam free. In the end, the turtle thanked Splash, and they became best friends."}
]
});
})();
