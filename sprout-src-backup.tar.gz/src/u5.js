/* ===================== GRADE 3 · UNIT 5 · SPACE AND THE PLANETS (original content, plus one public-domain poem) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"space", num:5, emoji:"🚀🪐🌙", title:"Space and the Planets", badge:"🚀 Space Explorer",

stories:[
/* ---------- 1. STORY (diary) ---------- */
{title:"Leo's Space Camp Diary", e:"📔", kind:"Story (diary)", pages:[
 {pic:"📔🚀", text:"<b>Monday</b><br>Dear Diary,<br>Today I arrived at Space Camp! I will be here for five whole days. My room has a bunk bed and a window that looks at the stars. Our camp leader is named Captain Rosa. She says that by Friday, we will build and launch our own rocket. I am so excited that I can't sleep!",
  qs:[f("How long will Leo stay at Space Camp?","Five days",["One day","Two weeks"],"\"I will be here for five whole days.\""),
      t("What kind of writing is this?","A diary, where someone writes about their own day",["A recipe","A newspaper"],"A diary starts with \"Dear Diary\" and tells about the writer's day, using I and me.")]},
 {pic:"🌍🪐", text:"<b>Tuesday</b><br>Dear Diary,<br>Today we learned about the planets. Captain Rosa taught us a trick to remember their order from the Sun: <i>My Very Excellent Mother Just Served Us Noodles.</i> That means Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus and Neptune! Jupiter is so big that more than a thousand Earths could fit inside it.",
  qs:[f("Which planet is closest to the Sun?","Mercury",["Neptune","Earth"],"The first word of the trick is \"My\", for Mercury."),
      t("Why did Captain Rosa teach a sentence like \"My Very Excellent Mother…\"?","The first letters help you remember the planets in order",["Because mothers make noodles","To learn about cooking"],"Each word starts with the same letter as a planet. This kind of memory trick is called a mnemonic.")]},
 {pic:"🧑‍🚀🎈", text:"<b>Wednesday</b><br>Dear Diary,<br>Today was the best day! We tried on real spacesuits. They were heavy and hot! Then we went into a special pool to practise moving like astronauts in space. Captain Rosa told us that astronauts on the International Space Station float because they are falling around the Earth all the time. My brain is still spinning!",
  qs:[f("Where did they practise moving like astronauts?","In a special pool",["On a trampoline","In the kitchen"],"\"We went into a special pool to practise.\""),
      f("How did the spacesuits feel?","Heavy and hot",["Light and cold","Soft and fluffy"],"\"They were heavy and hot!\"")]},
 {pic:"🔭⭐", text:"<b>Thursday</b><br>Dear Diary,<br>Tonight we looked through a big telescope. I saw the craters on the Moon and four tiny dots near Jupiter. Captain Rosa said those dots are Jupiter's biggest moons! We also found the Big Dipper, a group of stars shaped like a giant spoon. Tomorrow is launch day. I hope our rocket flies high!",
  qs:[f("What did Leo see near Jupiter?","Four tiny dots, which were Jupiter's biggest moons",["A rocket","A comet"],"The tiny dots were Jupiter's biggest moons."),
      t("What shape is the Big Dipper?","A giant spoon",["A circle","A star"],"A dipper is a big spoon for scooping water.")]},
 {pic:"🚀💨", text:"<b>Friday</b><br>Dear Diary,<br>Launch day! Our team built a rocket from a plastic bottle, cardboard fins and a paper nose cone. We filled it with a little water and pumped in air. Everyone counted down: \"Five, four, three, two, one… LIFT-OFF!\" Whoosh! Our rocket shot up higher than the trees. Our team cheered so loudly that birds flew away.",
  qs:[f("What was the rocket made from?","A plastic bottle, cardboard fins and a paper nose cone",["Metal and glass","Wood and nails"],"They used a plastic bottle, cardboard fins and a paper nose cone."),
      t("Why did the birds fly away?","The team cheered very loudly",["The rocket hit them","It started to rain"],"\"Our team cheered so loudly that birds flew away.\"")]},
 {pic:"🏠🌟", text:"<b>Saturday</b><br>Dear Diary,<br>Today I came home. I told Mia and Grandmother everything. Grandmother laughed and said that when she was a girl, nobody had walked on the Moon yet. Now I know what I am going to be when I grow up: an astronaut! First, I will study hard in science and maths. One day, I will float among the stars.",
  qs:[f("What does Leo want to be?","An astronaut",["A baker","A pilot"],"\"Now I know what I am going to be when I grow up: an astronaut!\""),
      t("Which sentence talks about the FUTURE?","One day, I will float among the stars.",["Today I came home.","I told Mia everything."],"The word \"will\" shows something that has not happened yet.")]}
], turn:{q:"Write a short diary entry about something you did today. Start with \"Dear Diary,\".",model:"Dear Diary, today I went to the library with my dad. I found a great book about planets."}},

/* ---------- 2. STORY ---------- */
{title:"The Night of the Full Moon", e:"🌕", kind:"Story", pages:[
 {pic:"🌕👵", text:"On a clear autumn night, Grandmother woke Mia and Leo. \"Put on your warm jackets,\" she whispered. \"Tonight there will be a lunar eclipse.\" The children followed her into the back garden. The full Moon hung above the roofs like a giant silver coin.",
  qs:[f("What did Grandmother say would happen tonight?","A lunar eclipse",["A snowstorm","A rocket launch"],"\"Tonight there will be a lunar eclipse.\""),
      f("What was the Moon compared to?","A giant silver coin",["A banana","A ball of fire"],"The full Moon hung above the roofs like a giant silver coin.")]},
 {pic:"🌍🌑", text:"\"What is an eclipse?\" asked Leo. Grandmother held up an orange, a tennis ball and a torch. \"The torch is the Sun, the orange is the Earth, and the ball is the Moon,\" she said. \"Sometimes the Earth moves exactly between the Sun and the Moon. Then the Earth's shadow falls on the Moon. That is a lunar eclipse.\"",
  qs:[f("In Grandmother's model, what was the torch?","The Sun",["The Moon","The Earth"],"\"The torch is the Sun.\""),
      t("What causes a lunar eclipse?","The Earth's shadow falls on the Moon",["The Moon falls asleep","Clouds cover the Moon"],"When the Earth moves between the Sun and the Moon, its shadow covers the Moon.")]},
 {pic:"🌘🔴", text:"Slowly, a dark shadow crept across the Moon. Bit by bit, the bright Moon disappeared. Then something amazing happened. The Moon did not turn black. It glowed a deep, coppery red! \"A blood moon,\" whispered Grandmother. \"In my village, people used to bang pots to scare away the giant they thought was eating the Moon.\"",
  qs:[f("What colour did the Moon turn?","Deep, coppery red",["Black","Bright green"],"It glowed a deep, coppery red!"),
      t("Why did people in Grandmother's village bang pots long ago?","They did not know about the Earth's shadow and thought a giant was eating the Moon",["To make music for dancing","To call their cows"],"Long ago, people made up stories to explain things they did not understand yet.")]},
 {pic:"🔭👀", text:"Leo looked through Grandmother's small telescope. \"I can see craters!\" he said. \"Those were made by space rocks crashing into the Moon long ago,\" Grandmother explained. \"The Moon has no air and no wind, so the craters stay there for millions of years. Even the astronauts' footprints are still there!\"",
  qs:[f("What made the craters on the Moon?","Space rocks crashing into it",["Volcanoes of ice","Astronauts digging"],"Space rocks crashed into the Moon long ago."),
      t("Why are the astronauts' footprints still on the Moon?","There is no wind or rain to wipe them away",["Someone guards them","They are painted on"],"The Moon has no air and no wind, so nothing moves the dust.")]},
 {pic:"🌗🌒", text:"\"Does the Moon really change shape every night?\" asked Mia. \"No,\" said Grandmother. \"The Moon is always round. It has no light of its own. It reflects light from the Sun. As the Moon travels around the Earth, we see different amounts of its sunny side. Those are called the phases of the Moon.\"",
  qs:[f("Does the Moon make its own light?","No, it reflects light from the Sun",["Yes, it glows by itself","Only on Fridays"],"\"It has no light of its own. It reflects light from the Sun.\""),
      t("Why does the Moon seem to change shape?","We see different amounts of its sunny side as it moves around the Earth",["The Moon gets bitten","The Moon shrinks every night"],"These changing shapes are called the phases of the Moon.")]},
 {pic:"🌕💛", text:"After an hour, the shadow moved away and the Moon shone silver again. Mia yawned. \"I will never forget tonight,\" she said. Grandmother hugged them both. \"People all over the world have watched the same Moon for thousands of years,\" she said. \"Tonight, you joined them.\"",
  qs:[f("What happened after about an hour?","The shadow moved away and the Moon shone silver again",["The Moon disappeared forever","It started to snow"],"After an hour, the shadow moved away."),
      t("What did Grandmother mean by \"Tonight, you joined them\"?","Mia and Leo shared the same experience as people throughout history",["They joined a club","They flew to the Moon"],"Everyone on Earth, now and long ago, has watched the same Moon.")]}
], turn:{q:"What do you see when you look at the night sky? Write two sentences.",model:"I can see the Moon and a few bright stars. Sometimes I see a plane blinking as it flies past."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"Our Solar System", e:"🪐", kind:"Fact text", pages:[
 {pic:"☀️🪐", text:"Our <b>solar system</b> is the Sun and everything that travels around it: eight planets, their moons, and millions of rocks and balls of ice. The Sun is right in the middle. It is a <b>star</b>, a giant ball of hot, glowing gas. Its light takes about eight minutes to reach the Earth.",
  qs:[f("What is in the middle of our solar system?","The Sun",["The Earth","The Moon"],"The Sun is right in the middle."),
      f("What is the Sun?","A star",["A planet","A moon"],"The Sun is a star, a giant ball of hot, glowing gas.")]},
 {pic:"☿️♀️🌍♂️", text:"The four planets closest to the Sun are <b>Mercury, Venus, Earth and Mars</b>. They are called the rocky planets because they have hard, rocky surfaces. Mercury is the smallest planet. Venus is the hottest, because its thick clouds trap heat. Mars looks red because its dust contains rust.",
  qs:[f("Which planet is the hottest?","Venus",["Mercury","Mars"],"Venus is the hottest, because its thick clouds trap heat."),
      t("Venus is farther from the Sun than Mercury, but it is hotter. Why?","Its thick clouds trap the heat",["It is made of fire","It is closer to the Sun"],"Thick clouds work like a blanket, keeping the heat in.")]},
 {pic:"🌍💙", text:"<b>Earth</b> is the third planet from the Sun. It is the only planet we know of with liquid water on its surface and living things. It is not too hot and not too cold. Scientists sometimes call it the \"Goldilocks planet\", because its temperature is just right for life.",
  qs:[f("Which planet is Earth from the Sun?","The third",["The first","The eighth"],"Earth is the third planet from the Sun."),
      t("Why is Earth called the \"Goldilocks planet\"?","Its temperature is just right for life",["It has golden rocks","A girl named Goldilocks lives there"],"Like the porridge in the story, Earth is not too hot and not too cold.")]},
 {pic:"🪐🌀", text:"The next four planets are <b>Jupiter, Saturn, Uranus and Neptune</b>. They are called the giant planets. Jupiter is the biggest planet of all, and it has a storm bigger than the whole Earth. Saturn is famous for its huge, bright rings, made of ice and rock. You could never land on these planets, because they have no solid ground.",
  qs:[f("Which is the biggest planet?","Jupiter",["Saturn","Earth"],"Jupiter is the biggest planet of all."),
      f("What are Saturn's rings made of?","Ice and rock",["Gold","Clouds of fire"],"Saturn's rings are made of ice and rock.")]},
 {pic:"🥶🔵", text:"Uranus and Neptune are so far from the Sun that they are freezing cold. Uranus spins on its side, as if it were rolling around the Sun. Neptune, the farthest planet, has the fastest winds in the solar system. A year on Neptune lasts about 165 Earth years!",
  qs:[f("Which planet is the farthest from the Sun?","Neptune",["Uranus","Mars"],"Neptune is the farthest planet."),
      t("Why is a year on Neptune so long?","It is so far away that its trip around the Sun is very long",["It spins very slowly","It has no Sun"],"A year is one trip around the Sun. The farther out a planet is, the longer its path.")]},
 {pic:"🧊⚫", text:"Pluto used to be called the ninth planet. But in 2006, scientists decided it was too small, and now it is called a <b>dwarf planet</b>. Beyond the planets are millions of icy objects. Every year, scientists discover new things about our solar system, and maybe one day you will too!",
  qs:[f("What is Pluto called now?","A dwarf planet",["The ninth planet","A star"],"Now Pluto is called a dwarf planet."),
      f("In which year did scientists change Pluto's name?","2006",["1906","2026"],"In 2006, scientists decided it was too small.")]}
], turn:{q:"If you could visit one planet, which would you choose? Write two sentences saying why.",model:"I would visit Saturn. I want to see its huge, bright rings up close."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"Footprints on the Moon", e:"👣", kind:"Fact text", pages:[
 {pic:"🌙🌍", text:"The Moon is the Earth's closest neighbour in space. It travels around the Earth about once every month. It is about 384,000 kilometres away. That is so far that if you could drive a car there, it would take about six months without stopping!",
  qs:[f("How often does the Moon travel around the Earth?","About once a month",["Once a day","Once a year"],"It travels around the Earth about once every month."),
      t("Why would it take six months to drive to the Moon?","It is very, very far away",["Cars are slow on the Moon","The road is bumpy"],"The Moon is about 384,000 kilometres away.")]},
 {pic:"🚀🇺🇸", text:"On July 20, 1969, the Apollo 11 spacecraft landed on the Moon. Neil Armstrong climbed down the ladder and became the first person ever to walk on the Moon. He said, \"That's one small step for man, one giant leap for mankind.\" Buzz Aldrin joined him soon after.",
  qs:[f("Who was the first person to walk on the Moon?","Neil Armstrong",["Buzz Aldrin","Captain Rosa"],"Neil Armstrong became the first person ever to walk on the Moon."),
      f("In which year did Apollo 11 land on the Moon?","1969",["2006","1906"],"On July 20, 1969.")]},
 {pic:"🏃🌙", text:"The Moon's <b>gravity</b> is much weaker than the Earth's. Things weigh only about one-sixth as much there. The astronauts could bounce and leap like kangaroos! There is also no air on the Moon, so astronauts must wear spacesuits that give them oxygen to breathe.",
  qs:[f("Why must astronauts wear spacesuits on the Moon?","There is no air to breathe",["To look smart","Because it is raining"],"There is no air on the Moon, so spacesuits give them oxygen."),
      t("A child weighs 30 kg on Earth. On the Moon, the child would feel…","much lighter",["much heavier","exactly the same"],"The Moon's gravity is weaker, so things weigh only about one-sixth as much.")]},
 {pic:"🌡️🌙", text:"The Moon has no air to act like a blanket. So in the daytime, it can be hotter than boiling water. At night, it gets colder than anywhere on Earth. There is no wind and no rain, so the astronauts' footprints may stay in the Moon dust for millions of years.",
  qs:[f("What is the daytime temperature on the Moon like?","Hotter than boiling water",["Cool and pleasant","Always freezing"],"In the daytime, it can be hotter than boiling water."),
      t("Why does the Moon get so hot AND so cold?","It has no air to act like a blanket",["It is close to the Sun","It spins very fast"],"Air helps keep a planet's temperature steady. The Moon has none.")]},
 {pic:"🇮🇳🛰️", text:"Many countries have sent spacecraft to the Moon. In August 2023, India's Chandrayaan-3 mission landed near the Moon's south pole, the first spacecraft ever to land there. Its little rover, Pragyan, drove across the surface and studied the soil.",
  qs:[f("Which country's mission landed near the Moon's south pole in 2023?","India",["Canada","Brazil"],"India's Chandrayaan-3 mission landed near the Moon's south pole."),
      f("What was the name of the rover?","Pragyan",["Apollo","Rosa"],"Its little rover, Pragyan, drove across the surface.")]},
 {pic:"🧑‍🚀🔮", text:"Scientists are now planning for people to return to the Moon and maybe one day live there in special bases. From the Moon, astronauts may even travel on to Mars. The children reading this today could be the scientists and astronauts of tomorrow!",
  qs:[t("Where might astronauts travel to after the Moon?","Mars",["The Sun","Inside the Earth"],"From the Moon, astronauts may travel on to Mars."),
      t("What is the author saying in the last sentence?","Today's children could become future space explorers",["Children cannot be scientists","Space travel has ended"],"The author encourages readers to dream about the future.")]}
], turn:{q:"If you could ask Neil Armstrong one question, what would it be? Write your question and say why you would ask it.",model:"I would ask him, \"Were you scared when you stepped on the Moon?\" I want to know how brave astronauts feel."}},

/* ---------- 5. FABLE ---------- */
{title:"Stella, the Little Star (a fable)", e:"⭐", kind:"Fable", pages:[
 {pic:"⭐🌕", text:"High in the night sky lived a little star named Stella. She was not big, and she was not very bright. Every night she looked at the Moon and sighed. \"Everyone on Earth looks at the Moon,\" she said. \"Nobody ever notices me.\"",
  qs:[f("Who did Stella look at every night?","The Moon",["The Sun","A comet"],"Every night she looked at the Moon and sighed."),
      t("How did Stella feel?","Unimportant and jealous",["Proud and happy","Angry at the Sun"],"She felt that nobody noticed her because she was small.")]},
 {pic:"☄️✨", text:"One night, a bright comet zoomed past with a long, glowing tail. \"Look at me!\" it shouted. \"I am the most dazzling thing in the sky!\" All the children on Earth pointed at the comet. Stella felt even smaller. \"If only I could zoom and sparkle like that,\" she whispered.",
  qs:[f("What did the comet have?","A long, glowing tail",["Wings","A red ring"],"A bright comet zoomed past with a long, glowing tail."),
      t("Why did Stella feel even smaller?","Everyone noticed the comet, but not her",["The comet bumped into her","She was getting colder"],"She compared herself to the comet and felt less important.")]},
 {pic:"⛵🌊", text:"Far below, on a dark sea, a little fishing boat was lost. The storm had passed, but the sailor could not find her way home. The Moon had set, and the comet was gone. The sailor looked up at the sky, searching. Then her eyes stopped on one small star that never moved: Stella.",
  qs:[f("Why was the sailor lost?","She could not find her way home after the storm",["Her boat had no sail","She was asleep"],"The sailor could not find her way home."),
      t("Why couldn't the Moon or the comet help the sailor?","The Moon had set and the comet was gone",["They were too bright","They were angry"],"Neither of them was in the sky anymore.")]},
 {pic:"⭐🧭", text:"\"There you are!\" said the sailor. \"The star that always points north. My grandfather taught me to follow you home.\" Stella stayed in her place all night, shining as steadily as she could. By morning, the little boat had reached the harbour, where the sailor's family was waiting.",
  qs:[f("What did the sailor's grandfather teach her?","To follow the star that points north",["To swim fast","To catch big fish"],"\"My grandfather taught me to follow you home.\""),
      t("What was special about Stella?","She always stayed in the same place, so sailors could find their way",["She was the brightest star","She had a long tail"],"Stella never moved, so she was a guide for travellers.")]},
 {pic:"⭐💛", text:"The next night, the Moon said to Stella, \"I shine brightly for only part of the month. The comet passes by once in many years. But you are there every night for those who need you.\" Stella glowed with happiness. She never wished to be someone else again. <b>Lesson: You don't have to be the biggest or the brightest to be important.</b>",
  qs:[t("What is the lesson of this fable?","You don't have to be the biggest or the brightest to be important",["Comets are better than stars","Never go sailing"],"Stella helped the sailor because of who she was."),
      t("Which real star is Stella like?","The North Star, which sailors used to find north",["The Sun","A shooting star"],"For hundreds of years, travellers in the northern half of the Earth have used the North Star to find their way.")]}
], turn:{q:"Write about a time you helped someone, even in a small way. How did it feel?",model:"I helped my little cousin tie her shoes. It felt good to be useful."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A stargazing poster and a planet chart", e:"🔭", kind:"Real-world text", pages:[
 {pic:"🔭🌌", text:"Read this poster from the library.<div class=\"realdoc\"><b>🌌 Family Stargazing Night! 🌌</b><br>📅 <b>Saturday, November 14</b><br>🕖 <b>7:00 p.m. to 9:00 p.m.</b><br>📍 Maple Park, by the big field<br><br>🔭 Look through real telescopes!<br>🪐 See Saturn's rings and the Moon's craters<br>☕ Free hot chocolate<br><br>👕 Dress warmly. Bring a blanket.<br>🔦 Please use only red flashlights, so everyone's eyes stay used to the dark.<br>☁️ If it is cloudy, the event will move to Sunday.</div>",
  qs:[f("What time does the stargazing start?","7:00 p.m.",["9:00 p.m.","7:00 a.m."],"7:00 p.m. to 9:00 p.m."),
      f("What will happen if it is cloudy?","The event will move to Sunday",["It will be cancelled forever","Everyone will go home early"],"If it is cloudy, the event will move to Sunday."),
      t("Why will the event move if it is cloudy?","Clouds would hide the stars and planets",["Clouds are cold","The park closes"],"You cannot see the sky through thick clouds."),
      t("Why are only red flashlights allowed?","Red light does not spoil your eyes' night vision",["Red is a pretty colour","Red flashlights are free"],"Bright white light makes it harder for your eyes to see faint stars.")]},
 {pic:"🪐📊", text:"This chart compares some planets.<table class=\"realtbl\"><tr><th>Planet</th><th>Order from the Sun</th><th>Type</th><th>Fun fact</th></tr><tr><td>Mercury</td><td>1st</td><td>Rocky</td><td>Smallest planet</td></tr><tr><td>Venus</td><td>2nd</td><td>Rocky</td><td>Hottest planet</td></tr><tr><td>Earth</td><td>3rd</td><td>Rocky</td><td>Has living things</td></tr><tr><td>Mars</td><td>4th</td><td>Rocky</td><td>Red dust</td></tr><tr><td>Jupiter</td><td>5th</td><td>Giant</td><td>Biggest planet</td></tr><tr><td>Saturn</td><td>6th</td><td>Giant</td><td>Bright rings</td></tr></table>",
  qs:[f("Which planet is 4th from the Sun?","Mars",["Jupiter","Earth"],"Mars: 4th."),
      f("What type of planet is Jupiter?","Giant",["Rocky","Icy moon"],"Jupiter: Giant."),
      t("How many ROCKY planets are in the chart?","4",["2","6"],"Mercury, Venus, Earth and Mars are rocky."),
      t("Which planet comes right after Earth?","Mars",["Venus","Saturn"],"Earth is 3rd, so the 4th, Mars, comes right after.")]}
], turn:{q:"Write two rules for a stargazing night. Explain why one of them is important.",model:"Bring a warm blanket. Use only a red flashlight, because bright light makes it harder to see the stars."}}
],

poems:[
 {title:"The Star (by Jane Taylor, 1806)",
  lines:["Twinkle, twinkle, little star,","How I wonder what you are!","Up above the world so high,","Like a diamond in the sky.","","When the blazing sun is gone,","When he nothing shines upon,","Then you show your little light,","Twinkle, twinkle, all the night."],
  qs:[f("What does the poet compare the star to?","A diamond in the sky",["A ball","A flower"],"\"Like a diamond in the sky.\""),
      t("When does the star show its light, according to the poem?","At night, when the sun is gone",["At noon","Only in summer"],"\"When the blazing sun is gone… Then you show your little light.\""),
      f("This poem was written in 1806. Is it a new poem or an old poem?","An old poem, more than 200 years old",["A brand-new poem"],"It was written more than 200 years ago and is famous all over the world as a song.")]},
 {title:"Rocket Ride",
  lines:["Ten, nine, eight, the engines roar,","Seven, six, the sky I'll soar!","Five, four, three, I hold on tight,","Two, one, zero, into the night!","Past the Moon and planets bright,","Stars are sparkling, what a sight!","One day soon, I'll fly up high,","And wave hello across the sky."],
  qs:[f("Which word rhymes with 'roar'?","soar",["seven","engine"],"Roar and soar end with the same sound."),
      t("Why does the poem start with numbers going down?","It is a countdown before a rocket launch",["The poet is learning to count","The numbers are a phone number"],"Rockets launch after a countdown: 10, 9, 8…"),
      t("Which line talks about the future?","One day soon, I'll fly up high",["Stars are sparkling, what a sight!","Past the Moon and planets bright"],"\"I'll\" means \"I will\", which shows the future.")]}
],

words:[
 {w:"planet",e:"🪐",m:"a very large, round object that travels around a star",ex:"Mars is a red planet.",fill:"Earth is the ___ we live on."},
 {w:"star",e:"⭐",m:"a huge ball of hot, glowing gas in space",ex:"The Sun is a star.",fill:"At night, I saw a bright ___ twinkling."},
 {w:"comet",e:"☄️",m:"a ball of ice and dust in space with a long glowing tail",ex:"A comet zoomed past with a glowing tail.",fill:"The ___ had a long, glowing tail."},
 {w:"asteroid",e:"🪨",m:"a rock that travels around the Sun",ex:"An asteroid is a big space rock.",fill:"A big space rock that travels around the Sun is an ___."},
 {w:"galaxy",e:"🌌",m:"a huge group of billions of stars",ex:"Our galaxy is called the Milky Way.",fill:"The Milky Way is our ___."},
 {w:"constellation",e:"✨",m:"a group of stars that makes a shape or picture",ex:"The Big Dipper is a famous constellation.",fill:"A group of stars that makes a picture is a ___."},
 {w:"crater",e:"🌑",m:"a large round hole made when something crashes into the ground",ex:"The Moon is covered in craters.",fill:"A space rock made a big ___ on the Moon."},
 {w:"meteor",e:"🌠",m:"a space rock that burns up in our sky, making a streak of light",ex:"We saw a meteor flash across the sky.",fill:"People call a ___ a shooting star."},
 {w:"satellite",e:"🛰️",m:"an object that travels around a planet",ex:"The Moon is Earth's natural satellite.",fill:"A ___ in space helps send TV signals."},
 {w:"universe",e:"🌌",m:"everything that exists: all of space, stars and planets",ex:"The universe is bigger than we can imagine.",fill:"All the galaxies together make up the ___."},

 {w:"astronaut",e:"🧑‍🚀",m:"a person who travels into space",ex:"The astronaut floated in the space station.",fill:"An ___ trains for years before going to space."},
 {w:"rocket",e:"🚀",m:"a vehicle with powerful engines that flies into space",ex:"The rocket shot up into the sky.",fill:"The ___ blasted off into space."},
 {w:"launch",e:"🔥",m:"to send a rocket or spacecraft up into the air",ex:"They will launch the rocket on Friday.",fill:"Scientists will ___ the rocket tomorrow morning."},
 {w:"spacesuit",e:"👨‍🚀",m:"special clothing that keeps astronauts safe and gives them air",ex:"Leo tried on a heavy spacesuit.",fill:"An astronaut wears a ___ to breathe in space."},
 {w:"telescope",e:"🔭",m:"a tool that makes faraway things look bigger and closer",ex:"We looked at the Moon through a telescope.",fill:"Through the ___, I could see Saturn's rings."},
 {w:"gravity",e:"🍎",m:"the force that pulls things towards each other, like towards the ground",ex:"Gravity makes an apple fall from a tree.",fill:"___ keeps our feet on the ground."},
 {w:"mission",e:"🎯",m:"an important job or journey with a special goal",ex:"The mission to the Moon was a success.",fill:"The astronauts' ___ was to study Mars."},
 {w:"countdown",e:"🔟",m:"counting backwards to zero before something starts",ex:"The countdown went five, four, three, two, one!",fill:"Everyone shouted the ___: three, two, one, lift-off!"},
 {w:"float",e:"🎈",m:"to stay up in the air or on water without sinking",ex:"Astronauts float inside the space station.",fill:"In space, astronauts ___ around the cabin."},
 {w:"orbit",e:"🔄",m:"the curved path of something travelling around a planet or star",ex:"The Moon is in orbit around the Earth.",fill:"The space station is in ___ around the Earth."},

 {w:"rotate",e:"🌀",m:"to turn or spin around in a circle",ex:"The Earth rotates once every day.",fill:"The Earth will ___ once every 24 hours."},
 {w:"phase",e:"🌓",m:"one of the shapes the Moon seems to have as it changes",ex:"The full Moon is one phase of the Moon.",fill:"The half Moon is one ___ of the Moon."},
 {w:"eclipse",e:"🌘",m:"when one object in space blocks the light of another",ex:"During the eclipse, the Moon turned red.",fill:"During a lunar ___, the Earth's shadow covers the Moon."},
 {w:"horizon",e:"🌅",m:"the line where the land or sea seems to meet the sky",ex:"The Sun sank below the horizon.",fill:"The Moon rose slowly over the ___."},
 {w:"dawn",e:"🌄",m:"the early morning, when the sky first gets light",ex:"The birds sing at dawn.",fill:"We woke up at ___, when the sky was just getting light."},
 {w:"dusk",e:"🌆",m:"the evening, when the sky is getting dark",ex:"The first stars appear at dusk.",fill:"At ___, the sky turns dark and the stars come out."},
 {w:"shadow",e:"👤",m:"a dark shape made when something blocks the light",ex:"The Earth's shadow covered the Moon.",fill:"My ___ was very long in the evening sun."},
 {w:"reflect",e:"🪞",m:"to bounce light back",ex:"The Moon reflects light from the Sun.",fill:"A mirror can ___ light."},
 {w:"twinkle",e:"✨",m:"to shine with a light that seems to flicker",ex:"The stars twinkle at night.",fill:"Look at the stars ___ in the dark sky."},
 {w:"distance",e:"📏",m:"how far it is from one place to another",ex:"The distance to the Moon is huge.",fill:"The ___ from the Earth to the Sun is very great."},

 {w:"vast",e:"🌌",m:"extremely large",ex:"Space is vast.",fill:"The ocean looked ___ and endless."},
 {w:"distant",e:"🔭",m:"far away",ex:"We saw a distant planet through the telescope.",fill:"The ___ stars looked like tiny dots."},
 {w:"gigantic",e:"🪐",m:"extremely big",ex:"Jupiter is a gigantic planet.",fill:"Jupiter is a ___ planet."},
 {w:"rocky",e:"🪨",m:"made of rock or full of rocks",ex:"Mars is a rocky planet.",fill:"Mercury has a hard, ___ surface."},
 {w:"dazzling",e:"🌟",m:"so bright that it is hard to look at",ex:"The comet was dazzling.",fill:"The fireworks were ___ in the night sky."},
 {w:"mysterious",e:"❓",m:"strange and hard to understand or explain",ex:"Space is full of mysterious things.",fill:"The ___ light in the sky puzzled everyone."},
 {w:"ancient",e:"🏛️",m:"very, very old",ex:"Ancient people watched the stars too.",fill:"The ___ castle was a thousand years old."},
 {w:"weightless",e:"🎈",m:"seeming to have no weight, so you float",ex:"Astronauts feel weightless in space.",fill:"In the space station, the astronauts felt ___."},
 {w:"glowing",e:"💡",m:"giving out a soft, steady light",ex:"The glowing Moon lit up the garden.",fill:"The ___ lantern lit up the path."},
 {w:"fiery",e:"🔥",m:"very hot, or looking like fire",ex:"The rocket left a fiery trail.",fill:"The Sun is a ___ ball of gas."}
],

spelling:[
 {w:"moon",s:"The moon is bright tonight.",tip:"Double o: m-oo-n."},
 {w:"star",s:"I wished on a star.",tip:"'ar' as in car."},
 {w:"space",s:"Astronauts travel into space.",tip:"Ends with a magic e: sp-a-ce."},
 {w:"planet",s:"Earth is a planet."},
 {w:"rocket",s:"The rocket flew up.",tip:"'ck' after a short vowel: ro-ck-et."},
 {w:"earth",s:"We live on the Earth.",tip:"'ear' sounds like 'er': ear-th."},
 {w:"night",s:"Stars shine at night.",tip:"'igh' says long i."},
 {w:"light",s:"The Moon reflects light.",tip:"'igh' says long i."},
 {w:"world",s:"The world is round."},
 {w:"bright",s:"The comet was very bright.",tip:"'igh' says long i."},
 {w:"orbit",s:"The Moon is in orbit."},
 {w:"comet",s:"We saw a comet."},
 {w:"astronaut",s:"The astronaut waved.",tip:"astro-naut: 'au' sounds like 'aw'."},
 {w:"gravity",s:"Gravity pulls us down."},
 {w:"shadow",s:"The Earth's shadow covered the Moon.",tip:"Ends with 'ow' as in snow."}
],

facts:[
 {e:"☀️",c:"The Sun is a star.",t:true,x:"True! The Sun is a star. It looks much bigger and brighter than other stars because it is so much closer to us."},
 {e:"🌍",c:"About one million Earths could fit inside the Sun.",t:true,x:"True! The Sun is so big that more than a million Earths could fit inside it."},
 {e:"🔴",c:"Mars looks red because of rust in its dust.",t:true,x:"True! The dust on Mars contains iron that has rusted, just like an old bicycle."},
 {e:"🔇",c:"You can hear loud explosions in space.",t:false,x:"Not true! Sound needs air to travel, and space has no air. Space is completely silent."},
 {e:"🌙",c:"The Moon makes its own light.",t:false,x:"Not true! The Moon reflects light from the Sun, like a mirror."},
 {e:"🪐",c:"Saturn is so light for its size that it could float in a giant bathtub.",t:true,x:"True! Saturn is mostly made of light gases, so it is less dense than water."},
 {e:"🧑‍🚀",c:"Astronauts grow a little taller while they live in space.",t:true,x:"True! Without gravity squeezing their spine, astronauts can grow a few centimetres taller. They shrink back on Earth."},
 {e:"✨",c:"Stars twinkle because they switch on and off.",t:false,x:"Not true! Stars shine steadily. They seem to twinkle because moving air in our sky bends their light."},
 {e:"🧊",c:"Pluto is still called the ninth planet.",t:false,x:"Not true! Since 2006, Pluto has been called a dwarf planet."},
 {e:"🌠",c:"A shooting star is a star falling from the sky.",t:false,x:"Not true! A shooting star is a meteor: a small space rock burning up in our sky."},
 {e:"🌀",c:"Jupiter has a storm that is bigger than the whole Earth.",t:true,x:"True! It is called the Great Red Spot, and it has been swirling for hundreds of years."},
 {e:"🌅",c:"Astronauts on the space station can see about 16 sunrises every day.",t:true,x:"True! The space station goes around the Earth about every 90 minutes, so astronauts see many sunrises and sunsets."}
],

writing:[
 {e:"🌌",t:"Describe the night sky",level:"Step 1 · Sentences",
  prompt:"Imagine you are lying on a blanket on a clear night. Write at least 4 sentences describing what you see, hear and feel. Use at least 2 describing words from the word bank.",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["The sky is ","I can see ","The Moon looks ","I can hear ","I feel "],
  model:"The sky is dark and vast. I can see thousands of tiny stars that twinkle like diamonds. The glowing Moon is round and silver. I can hear crickets in the grass. I feel small and amazed under the distant stars."},
 {e:"📔",t:"Diary: A day on the Moon",level:"Step 2 · Diary",
  prompt:"Imagine you spent one day on the Moon. Write a diary entry of at least 6 sentences. Start with \"Dear Diary,\". Tell what you did, what you saw and how you felt. Write in the past tense, because it already happened.",
  minS:6,minWords:2,
  rx:[["^\\s*Dear Diary","I started with Dear Diary"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],
      ["(\\b(\\w+ed|saw|went|was|were|had|felt|ate|drank|took|made|found|flew|ran|came|thought|wore|slept|told|got|could)\\b[\\s\\S]*){3}","I used at least 3 past-tense verbs"]],
  starters:["Dear Diary,\nToday I ","First, I ","I saw ","Then I ","I felt ","Tomorrow I will "],
  model:"Dear Diary,\nToday I landed on the Moon! First, I put on my heavy spacesuit and climbed down the ladder. The ground was grey, dusty and full of craters. I bounced high because gravity is weak here, and I felt weightless. When I looked up, I saw the Earth glowing blue in the black sky. I felt tiny but very proud."},
 {e:"🔮",t:"My future",level:"Step 3 · The future",
  prompt:"What will you do when you grow up? What will the world be like? Write at least 6 sentences about the future. Use \"will\" or \"going to\" at least 3 times. Finish by saying how you will reach your dream.",
  minS:6,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],
      ["(\\b(will|'ll|going to)\\b[\\s\\S]*){3}","I used will or going to at least 3 times"]],
  starters:["When I grow up, I will ","I am going to ","In the future, people will ","One day, ","To reach my dream, I will "],
  model:"When I grow up, I will be a scientist who studies planets. I am going to work with a giant telescope. In the future, people will live in bases on the Moon. Maybe I will even visit Mars on a mission. My family will watch my rocket launch on TV. To reach my dream, I will study hard in science and maths."}
]
});
})();
