/* ===================== UNIT 8 · SKILL BANKS AND SKILL LIST (original content) ===================== */
(function(){
const u=UNITS.find(x=>x.id==="inventions");
const set=k=>u.words.slice(k*10,k*10+10);
const MIX=(...g)=>()=>R(g)();
const box=(t,txt)=>`<div class="qbox" style="margin:0 0 12px;font-size:18px;line-height:1.6;font-weight:400"><b>${t}</b><br>${txt}</div>`;
const rint=(a,b)=>a+Math.floor(Math.random()*(b-a+1));

/* ================= GRAMMAR: WAS AND WERE ================= */
const PS1=["Alexander","William","Margaret","My grandfather","The inventor","He","She","I","Thomas Watson","The teacher","Grandma","Mr. Lopez"],PP1=["We","You","They","The Wright brothers","Bell and Watson","The villagers","My friends","The children","The scientists","My parents"];
const PC=["very curious as a child","at the library yesterday","happy with the result","in the workshop last night","tired after the long day","excited about the invention fair","late for the experiment","proud of the new machine","busy all afternoon","surprised by the light"];
const TS1=["The first telephone","The machine","The windmill","The old engine","The first airplane","The light bulb","The paper cup","The model"],TP1=["The first wheels","The old machines","The pebbles","The gears","The batteries","The paper bags","The first bicycles","The kites"];
const TC=["very simple","very heavy","made of wood","in the museum","broken last week","too small","bright and shiny","on the table"];
const wsub=()=>{const k=R(["ps","pp","ts","tp"]);if(k==="ps")return {s:R(PS1),pl:false,c:R(PC)};if(k==="pp")return {s:R(PP1),pl:true,c:R(PC)};if(k==="ts")return {s:R(TS1),pl:false,c:R(TC)};return {s:R(TP1),pl:true,c:R(TC)}};
const vOf=x=>x.pl||x.s==="You"?"were":"was";
const WN="I was · he / she / it was · one person or thing was<br>we / you / they were · more than one were";
const wasWere=()=>{const x=wsub(),v=vOf(x);
  if(Math.random()<.3)return {type:"type",q:`Type <b>was</b> or <b>were</b>:<br><b>${x.s} ___ ${x.c}.</b>`,a:[v],why:`<b>${x.s} ${v} ${x.c}.</b><br>${WN}`,hint:"One person or thing (and I) → was. More than one, or you → were."};
  return mcQ(`Choose <b>was</b> or <b>were</b>:<br><b>${x.s} ___ ${x.c}.</b>`,v,[v==="was"?"were":"was"],`<b>${x.s} ${v} ${x.c}.</b><br>${WN}`,"One person or thing (and I) → was. More than one, or you → were.")};
const wasNeg=()=>{const x=wsub(),v=vOf(x)==="was"?"wasn't":"weren't";
  return mcQ(`Choose <b>wasn't</b> or <b>weren't</b>:<br><b>${x.s} ___ ${x.c}.</b>`,v,[v==="wasn't"?"weren't":"wasn't"],`<b>${x.s} ${v} ${x.c}.</b> wasn't = was not · weren't = were not.`,"wasn't = was not (one) · weren't = were not (more than one, or you)")};
const lcS=t=>/^(I\b|Alexander|William|Margaret|Thomas|Grandma|Mr\.|Bell)/.test(t)?t:t.charAt(0).toLowerCase()+t.slice(1);
const wasQ=()=>{const x=wsub(),v=vOf(x);const s=lcS(x.s);
  return mcQ(`Choose <b>Was</b> or <b>Were</b> to make a question:<br><b>___ ${s} ${x.c}?</b>`,cap(v),[v==="was"?"Were":"Was"],`<b>${cap(v)} ${s} ${x.c}?</b> In a question, was/were comes first, but the rule is the same.`,"One person or thing → Was…? More than one, or you → Were…?")};
const PRES=[["The machine is very loud.","The machine was very loud."],["The bulbs are bright.","The bulbs were bright."],["I am at the library.","I was at the library."],["We are excited.","We were excited."],["The crow is thirsty.","The crow was thirsty."],["They are in the workshop.","They were in the workshop."],["The experiment is successful.","The experiment was successful."],["You are very clever.","You were very clever."],["William is determined.","William was determined."],["The gears are broken.","The gears were broken."],["My idea is simple.","My idea was simple."],["The inventors are famous.","The inventors were famous."],["The telephone is new.","The telephone was new."],["The streets are dark.","The streets were dark."],["I am very curious.","I was very curious."],["The brothers are in the bicycle shop.","The brothers were in the bicycle shop."],["The windmill is tall.","The windmill was tall."],["You are at the fair.","You were at the fair."],["The pebbles are small.","The pebbles were small."],["Grandma is proud of me.","Grandma was proud of me."],["We are in the library.","We were in the library."],["The design is clever.","The design was clever."],["The robots are busy.","The robots were busy."],["My model is ready.","My model was ready."]];
const toPast=()=>{const x=R(PRES);const v=x[1].match(/\b(was|were)\b/)[0];return {type:"type",q:`Change the sentence to the <b>past</b>. Type only the new verb:<br><b>${x[0]}</b>`,a:[v],why:`<b>${x[1]}</b> am/is → was · are → were.`,hint:"am and is → was · are → were"}};
const wasFix=()=>{const x=wsub(),v=vOf(x),w=v==="was"?"were":"was";return {type:"type",q:`Find the mistake and type the correct word:<br><b>${x.s} ${w} ${x.c}.</b>`,a:[v],why:`<b>${x.s} ${v} ${x.c}.</b>`,hint:"Is the subject one thing (was) or more than one / you (were)?"}};

/* ================= GRAMMAR: JOINING WORDS ================= */
const J=[
 ["The crow was thirsty","she looked for water","so","but","because"],["The crow was thirsty","the water was too low","but","so","because"],["The crow dropped pebbles in","she wanted the water to rise","because","but","so"],
 ["William had no money","he used old scrap","so","because","but"],["William's family were farmers","they grew maize","and","because","but"],["William wanted to build a windmill","some people laughed at him","but","so","because"],
 ["The windmill worked","the family had light at night","so","but","because"],["William left school","his family could not pay the fees","because","so","and"],["Bell was born in Scotland","he later moved to Canada","but","because","so"],
 ["Bell loved sound","his mother was deaf","because","but","so"],["The first experiments failed","Bell and Watson kept trying","but","so","because"],["Bell spoke into the machine","Watson heard him","and","because","but"],
 ["It was cold in winter","Naismith invented an indoor game","so","but","because"],["The Wright brothers owned a bicycle shop","they knew a lot about machines","so","but","because"],["The first flight was short","it changed the world","but","so","because"],
 ["Books were copied by hand","they were very expensive","so","but","because"],["Gutenberg built a printing press","books became cheaper","and","but","because"],["People used candles at night","electric light was not invented yet","because","but","so"],
 ["The battery was empty","the robot stopped","so","but","because"],["The robot stopped","the battery was empty","because","so","but"],["I wanted to make a cup telephone","I needed a long string","so","because","but"],
 ["The string was loose","we couldn't hear anything","so","but","because"],["We pulled the string tight","we could hear each other","and","because","but"],["My invention was simple","it was very useful","but","so","because"],
 ["I like inventing","it is fun to solve problems","because","so","but"],["Mia drew a design","Leo built the model","and","because","so"],["The model broke","we fixed it with tape","so","because","but"],
 ["We fixed the model with tape","it broke","because","so","but"],["Paper is light","it is cheap","and","but","because"],["The machine is complicated","it is easy to use","but","so","because"],
 ["The engine was very powerful","the car went fast","so","but","because"],["The car went fast","the engine was very powerful","because","so","but"],["Margaret saw an accident in the factory","she invented a safety device","so","but","because"],
 ["Insulin is important","it saves lives","because","but","so"],["Banting could have been rich","he sold the rights for one dollar","but","so","because"],["Chess started in India","it travelled to Persia","and","because","but"],
 ["The bulb was broken","we bought a new one","so","because","but"],["We bought a new bulb","the old one was broken","because","so","but"],["Snow was deep","Bombardier built a snow vehicle","so","because","but"],
 ["The lamplighter carried a ladder","he climbed up to light the lamps","and","because","but"],["I wanted to win the fair","my invention did not work","but","so","because"],["The fair was free","many families came","so","but","because"]
];
const JN="<b>and</b> adds another idea · <b>but</b> shows something different or surprising · <b>because</b> gives the reason (why) · <b>so</b> gives the result (what happened next)";
const joinQ=()=>{const x=R(J);return mcQ(`Choose the best joining word:<br><b>${x[0]} ___ ${x[1]}.</b>`,x[2],[x[3],x[4]],`<b>${x[0]}${x[2]==="because"?" ":", "}${x[2]} ${x[1]}.</b><br>${JN}`,"Does the second part add an idea (and), show a surprise (but), give a reason (because) or a result (so)?")};
const joinType=()=>{const x=R(J);const full=`${x[0]}${x[2]==="because"?" ":", "}${x[2]} ${x[1]}`;
  return {type:"type",q:`Join the two sentences with <b>${x[2]}</b>. Type the whole new sentence:<br><b>${x[0]}. ${cap(x[1])}.</b>`,a:[full,full.replace(", "+x[2]," "+x[2]),full.replace(" "+x[2],", "+x[2])],why:`<b>${full}.</b> ${x[2]==="because"?"No comma is needed before because.":"We usually put a comma before "+x[2]+"."}`,hint:`Take away the first full stop, add ${x[2]}, and make the next word small.`}};
const becauseSo=()=>{const x=R(J.filter(y=>y[2]==="because"||y[2]==="so"));const right=`${x[0]}${x[2]==="because"?" ":", "}${x[2]} ${x[1]}.`;const wrong=`${x[0]}${x[2]==="because"?", so":" because"} ${x[1]}.`;
  return mcQ("Which sentence makes sense?",right,[wrong],`<b>${right}</b> <b>because</b> comes before the <b>reason</b>. <b>so</b> comes before the <b>result</b>.`,"Ask: which part is the reason (why) and which part is the result?")};

/* ================= WORD SKILL: -TION ================= */
const TION=[["invent","invention"],["act","action"],["collect","collection"],["protect","protection"],["direct","direction"],["connect","connection"],["add","addition"],["subtract","subtraction"],["attend","attention"],["educate","education"],["celebrate","celebration"],["create","creation"],["decorate","decoration"],["pollute","pollution"],["locate","location"],["inform","information"],["invite","invitation"],["imagine","imagination"],["explore","exploration"],["prepare","preparation"],["compete","competition"],["solve","solution"],["construct","construction"],["predict","prediction"],["instruct","instruction"]];
const TS={invention:"The telephone is a famous invention.",action:"The film was full of action.",collection:"Mia has a shell collection.",protection:"A helmet gives your head protection.",direction:"Which direction is north?",connection:"The wire makes a connection.",addition:"We practised addition in maths.",subtraction:"Ten minus four is a subtraction.",attention:"Please pay attention.",education:"Every child deserves an education.",celebration:"We had a big celebration for Diwali.",creation:"The robot was her own creation.",decoration:"We hung a decoration on the door.",pollution:"Pollution makes the air dirty.",location:"The map shows the location of the school.",information:"The library has lots of information.",invitation:"I got an invitation to the party.",imagination:"Use your imagination to invent something.",exploration:"Space exploration is exciting.",preparation:"Good preparation helps you do well.",competition:"She won the drawing competition.",solution:"The crow found a solution.",construction:"The new bridge is under construction.",prediction:"My prediction was correct!",instruction:"Read each instruction carefully.",station:"The train left the station.",nation:"Canada is a nation in North America.",question:"Can I ask a question?",fiction:"I like reading fiction.",motion:"The machine is in motion."};
const tionJoin=()=>{const x=R(TION);const easy=x[1]===x[0]+"ion";
  if(Math.random()<.5)return {type:"type",q:`Make a <b>-tion</b> word (a naming word) from the verb:<br><b>${x[0]} → ?</b>`,a:[x[1]],why:`<b>${x[0]} → ${x[1]}</b>. ${easy?"Just add -ion.":x[0].endsWith("e")?"Drop the e, then add the ending.":"The ending changes a little."}<br>Example: ${TS[x[1]]}`,hint:`It starts with "${x[1].slice(0,3)}" and ends with -tion.`};
  const fake1=x[0]+"tion",fake2=x[0].replace(/e$/,"")+"shun";return mcQ(`Which is the correct <b>-tion</b> word for <b>${x[0]}</b>?`,x[1],uniq([fake1,fake2,x[0]+"sion"].filter(z=>z!==x[1])).slice(0,2),`<b>${x[0]} → ${x[1]}</b>. ${TS[x[1]]}`,"The -tion ending sounds like 'shun'.")};
const tionUse=()=>{const k=R(Object.keys(TS));const ex=TS[k];const others=SAMPLE(Object.keys(TS).filter(z=>z!==k),2);
  return mcQ(`Choose the missing word:<br><b>${ex.replace(new RegExp("\\b"+k+"\\b","i"),"___")}</b>`,k,others,`<b>${ex}</b>`,"Which -tion word makes sense in the sentence?")};
const TLIST=Object.keys(TS).map(w=>({w,s:TS[w],tip:"It ends with -tion, which sounds like 'shun'."}));

/* ================= INVENTIONS: WHO, WHEN, BEFORE AND AFTER ================= */
const IV=[["the telephone","Alexander Graham Bell",1876],["a long-lasting light bulb","Thomas Edison and his team",1879],["the first powered airplane","the Wright brothers",1903],["the printing press","Johannes Gutenberg",1440],["basketball","James Naismith",1891],["the World Wide Web","Tim Berners-Lee",1989],["Braille, a reading system for blind people","Louis Braille",1824],["windshield wipers","Mary Anderson",1903],["a machine that makes flat-bottomed paper bags","Margaret Knight",1868],["a windmill from scrap in Malawi","William Kamkwamba",2002],["the snowmobile","Joseph-Armand Bombardier's company",1959],["insulin as a medicine","Frederick Banting and Charles Best",1921]];
const whatQ=()=>{const x=R(IV);return mcQ(`🧑‍🔬 What did <b>${x[1]}</b> invent?`,cap(x[0]),SAMPLE(IV.filter(y=>y!==x&&y[1]!==x[1]).map(y=>cap(y[0])),2),`<b>${cap(x[1])}</b> invented ${x[0]} (${x[2]}).`,"Think about the stories and fact pages in this unit.")};
const whoQ=()=>{const x=R(IV);return mcQ(`🧑‍🔬 Who invented <b>${x[0]}</b>?`,x[1],SAMPLE(IV.filter(y=>y!==x&&y[1]!==x[1]).map(y=>y[1]),2),`<b>${cap(x[1])}</b> invented ${x[0]} (${x[2]}).`,"Think about the stories and fact pages in this unit.")};
const whenQ=()=>{const [a,b]=SAMPLE(IV.filter(y=>y[2]),2);if(a[2]===b[2])return whenQ();const first=a[2]<b[2]?a:b;
  return mcQ(`📅 Which came <b>first</b>?<br>${cap(a[0])} (${a[2]}) or ${b[0]} (${b[2]})?`,cap(first[0]),[cap((first===a?b:a)[0])],`${first[2]} comes before ${(first===a?b:a)[2]}, so <b>${first[0]}</b> came first.`,"The smaller year number is earlier.")};
const BA=[
 {q:"Before electric lights, what did people use to see at night?",a:"Candles and oil lamps",o:["Phones","Computers"],why:"Light bulbs replaced candles and lamps."},
 {q:"Before the telephone, how did people send messages far away?",a:"They wrote letters",o:["They sent emails","They used video calls"],why:"Letters could take days or weeks."},
 {q:"Before the printing press, how were books made?",a:"Copied by hand",o:["Printed by computers","Typed on phones"],why:"Monks and scribes copied books by hand."},
 {q:"Before cars, how did people travel on land?",a:"On foot, on horses and in carts",o:["In airplanes","In rockets"],why:"Horses and carts were common."},
 {q:"Before fridges, how did people keep food cold?",a:"With ice and cool cellars",o:["In ovens","In the sun"],why:"Ice houses and cellars kept food cool."},
 {q:"Before washing machines, how were clothes washed?",a:"By hand, with a washboard",o:["With robots","In the dishwasher"],why:"Washing by hand took many hours."},
 {q:"Before paper, what did people write on?",a:"Clay, stone, bamboo and silk",o:["Plastic","Glass screens"],why:"Paper made writing cheaper and lighter."},
 {q:"Before clocks, how did people tell the time?",a:"With sundials and the Sun's shadow",o:["With phones","With calculators"],why:"Unit 7 taught us about sundials."},
 {q:"Before money, what did people do to get things?",a:"They traded (bartered)",o:["They used credit cards","They printed coins at home"],why:"People swapped goods."},
 {q:"Before airplanes, how did people cross the ocean?",a:"By ship",o:["By car","By bicycle"],why:"Long sea voyages took weeks."},
 {q:"Before calculators, what did people use to count and add?",a:"Their fingers, pebbles and the abacus",o:["Computers","Phones"],why:"The abacus is a very old counting tool."},
 {q:"Before the World Wide Web, where did people find information?",a:"In books and libraries",o:["On websites","On social media"],why:"Libraries were full of information."},
 {q:"What replaced candles in most homes?",a:"Electric light bulbs",o:["Telephones","Wheels"],why:"Electric light is safer and brighter."},
 {q:"What replaced horses and carts on most roads?",a:"Cars and buses",o:["Kites","Robots"],why:"Engines made travel faster."},
 {q:"What made copying books much faster?",a:"The printing press",o:["The wheel","The telephone"],why:"Gutenberg's press printed pages quickly."},
 {q:"What lets us talk to someone far away right now?",a:"The telephone",o:["The printing press","The wheel"],why:"Bell's invention carried voices along a wire."},
 {q:"Which invention made heavy loads easier to move?",a:"The wheel",o:["Paper","Chess"],why:"Carts with wheels carried heavy loads."},
 {q:"Which invention helps blind people read?",a:"Braille",o:["Insulin","Basketball"],why:"Braille uses raised dots you can feel."},
 {q:"Which invention cleans car windows in the rain?",a:"Windshield wipers",o:["Snowmobiles","Light bulbs"],why:"Mary Anderson invented them in 1903."},
 {q:"Which invention helps people travel across deep snow?",a:"The snowmobile",o:["The bicycle","The submarine"],why:"Bombardier's snow vehicles helped people in the North."}
];
const PSOL=[
 {q:"Problem: It is dark at night and candles are dangerous. Which invention helps?",a:"The electric light bulb",o:["The wheel","Basketball"],why:"Electric lights are bright and safer than flames."},
 {q:"Problem: You want to talk to your grandmother in another country. Which invention helps?",a:"The telephone",o:["The printing press","The snowmobile"],why:"Telephones carry voices far away."},
 {q:"Problem: Students need a game to play indoors in winter. Which invention solved this?",a:"Basketball",o:["Chess pieces made of stone","Insulin"],why:"Naismith invented basketball for an indoor gym."},
 {q:"Problem: The water is too low for the crow to drink. What was her solution?",a:"Dropping pebbles in to raise the water",o:["Tipping the pitcher over","Waiting for rain"],why:"The pebbles pushed the water up."},
 {q:"Problem: William's village had no electricity. What was his solution?",a:"A windmill made from scrap",o:["A telephone","A printing press"],why:"The wind turned the blades and made electricity."},
 {q:"Problem: Rain makes it hard to see through a car window. Which invention helps?",a:"Windshield wipers",o:["Light bulbs","Batteries"],why:"Wipers push the rain away."},
 {q:"Problem: Blind people could not read printed books. Which invention helped?",a:"Braille",o:["The telephone","The wheel"],why:"Braille uses raised dots that fingers can read."},
 {q:"Problem: Copying books by hand took months. Which invention helped?",a:"The printing press",o:["The airplane","The bicycle"],why:"It printed many pages quickly."},
 {q:"Problem: People with diabetes became very ill. What helped them?",a:"Insulin made into a medicine",o:["Basketball","The snowmobile"],why:"Banting and Best's work saved millions of lives."},
 {q:"Problem: People in the North need to travel over deep snow. Which invention helps?",a:"The snowmobile",o:["The submarine","The printing press"],why:"Snowmobiles glide over snow."},
 {q:"Problem: Carrying heavy rocks by hand is very hard. Which invention helps?",a:"A cart with wheels",o:["A light bulb","A telephone"],why:"Wheels roll heavy loads."},
 {q:"Problem: A toy needs power but has no plug. What can help?",a:"A battery",o:["A wheel","A gear"],why:"Batteries store electricity."},
 {q:"Problem: You want to keep milk cold. Which invention helps?",a:"A fridge",o:["An oven","A fan heater"],why:"Fridges keep food cold and fresh."},
 {q:"Problem: You want to share information with people all over the world. Which invention helps?",a:"The World Wide Web",o:["A sundial","A wheel"],why:"The web shares pages of information."},
 {q:"Problem: A paper bag with a pointed bottom can't stand up. What was Margaret Knight's solution?",a:"A machine that makes flat-bottomed bags",o:["Plastic bags","Bigger bags"],why:"Flat-bottomed bags stand up and hold more."},
 {q:"Problem: You need to fix a loose screw. Which tool helps?",a:"A screwdriver",o:["A paintbrush","A spoon"],why:"Use the right tool for the job."},
 {q:"Problem: People needed to fly across oceans quickly. Which invention helped?",a:"The airplane",o:["The bicycle","The snowmobile"],why:"Planes cross oceans in hours instead of weeks."},
 {q:"Problem: Your grandma can't reach the top shelf. Which is the safest idea?",a:"A step stool with a handle",o:["Standing on a wobbly chair","Jumping"],why:"A good invention is safe."},
 {q:"Problem: Plastic bottles are filling the bins. Which idea helps most?",a:"Reuse or recycle them into something new",o:["Throw them in the river","Buy more bottles"],why:"Reusing and recycling reduce rubbish."},
 {q:"Problem: You forget to water your plants. Which invention could help?",a:"A plant waterer with a timer",o:["A louder doorbell","A bigger pot of soil only"],why:"A timer could water the plants for you."}
];

/* ================= OTHER VOCABULARY ================= */
const SYN=[["invent","create"],["clever","smart"],["useful","helpful"],["famous","well-known"],["ancient","very old"],["modern","new"],["simple","easy"],["complicated","difficult"],["brilliant","excellent"],["determined","not giving up"],["discover","find"],["build","construct"],["fix","repair"],["join","connect"],["test","try"],["problem","difficulty"],["idea","thought"],["quick","fast"],["machine","device"],["begin","start"]];
const OPP=[["ancient","modern"],["simple","complicated"],["success","failure"],["useful","useless"],["build","destroy"],["connect","disconnect"],["powerful","weak"],["famous","unknown"],["past","future"],["invent","copy"],["first","last"],["light","dark"],["push","pull"],["on","off"],["start","stop"],["fast","slow"],["loud","quiet"],["remember","forget"],["ordinary","special"],["tight","loose"]];
const COMP=[["air","plane"],["type","writer"],["head","phones"],["wind","mill"],["sun","glasses"],["tooth","brush"],["rail","way"],["motor","bike"],["skate","board"],["key","board"],["lap","top"],["door","bell"],["flash","light"],["wheel","chair"],["web","site"],["up","load"],["fire","works"],["basket","ball"],["foot","ball"],["paper","clip"],["light","house"],["snow","mobile"],["note","book"],["work","shop"]];

/* ================= SPELLING ================= */
const SP=u.spelling.concat([{w:"inventor",s:"The inventor tested her idea.",tip:"invent + or."},{w:"telephone",s:"The telephone rang.",tip:"tele + phone. 'ph' sounds like f."},{w:"computer",s:"I use a computer at school.",tip:"com-pu-ter."},{w:"tool",s:"A hammer is a tool.",tip:"Double o."},{w:"famous",s:"Bell is a famous inventor.",tip:"fa-mous. Ends with -ous."},{w:"clever",s:"The crow was clever."},{w:"library",s:"I went to the library.",tip:"li-brar-y. Don't forget the first r!"},{w:"factory",s:"The factory makes cars."},{w:"history",s:"I love history."},{w:"experiment",s:"We did an experiment.",tip:"ex-per-i-ment."},{w:"electricity",s:"Lamps need electricity.",tip:"e-lec-tri-ci-ty."},{w:"problem",s:"Every invention solves a problem."},{w:"wire",s:"Connect the wire.",tip:"Magic e: w-i-re."},{w:"engine",s:"The engine started.",tip:"The 'g' sounds like 'j'."},{w:"create",s:"Let's create a poster.",tip:"cre-ate."}]);
const CHOOSE=[["invention","invenshun","invension"],["machine","masheen","machien"],["electricity","electrisity","electricty"],["telephone","telefone","telephon"],["experiment","expiriment","experement"],["library","libary","librery"],["famous","famus","faymous"],["wheel","weel","wheal"],["engine","enjin","engin"],["battery","batery","battry"],["design","desine","dezign"],["build","bild","biuld"],["computer","compooter","computor"],["solution","solushun","solusion"],["question","questshun","quesion"],["station","stashun","staion"],["celebration","celebrashun","celebrasion"],["useful","usefull","yousful"],["simple","simpel","simpul"],["direction","direcshun","derection"]].map(x=>({w:x[0],bad:[x[1],x[2]],tip:(SP.find(y=>y.w===x[0])||TLIST.find(y=>y.w===x[0])||{}).tip}));

/* ================= READING ================= */
const DETAIL=[
 ["Margaret Knight","Margaret Knight was born in the United States in 1838. When she was only 12, she worked in a cotton mill. After she saw a worker hurt by a machine, she invented a safety guard to stop it from happening again. Later, she invented a machine that made paper bags with flat bottoms. A man tried to steal her idea, but she proved in court that it was hers.",[["How old was Margaret when she worked in the cotton mill?","12",["20","5"]],["Why did she invent a safety guard?","She saw a worker hurt by a machine",["She wanted money","Her teacher asked her"]],["What did her later machine make?","Paper bags with flat bottoms",["Shoes","Cars"]],["What happened when a man tried to steal her idea?","She proved in court that it was hers",["She gave up","She moved away"]]]],
 ["Louis Braille","Louis Braille was born in France in 1809. He became blind after an accident when he was three. At school, books for blind students were huge and hard to read. When he was about 15, Louis invented a system of raised dots that people can read with their fingers. Today, blind people all over the world read Braille.",[["Where was Louis Braille born?","France",["Canada","India"]],["How old was he when he invented Braille?","About 15",["About 50","Three"]],["How do people read Braille?","With their fingers",["With their ears","With a telescope"]]]],
 ["Mary Anderson","In 1902, Mary Anderson rode a streetcar in New York City on a snowy day. She noticed the driver had to open the window again and again to clear the snow. She invented a handle inside the car that moved a rubber blade across the glass. She got a patent for her windshield wiper in 1903.",[["Where was Mary Anderson when she had her idea?","On a streetcar in New York City",["On a plane","At home in bed"]],["What problem did the driver have?","He had to open the window to clear the snow",["He was hungry","The streetcar had no wheels"]],["When did she get her patent?","1903",["1876","2003"]]]],
 ["The Bicycle","Early bicycles had no pedals at all. Riders pushed along the ground with their feet! Later bicycles had a giant front wheel and a tiny back wheel, and riders often fell off. In the 1880s, the safety bicycle was invented, with two wheels of the same size and a chain. It looks a lot like the bikes we ride today.",[["How did riders move the first bicycles?","They pushed along the ground with their feet",["With pedals","With an engine"]],["What was a problem with the giant-front-wheel bicycle?","Riders often fell off",["It was too slow","It could fly"]],["What did the safety bicycle have?","Two wheels of the same size and a chain",["Three wheels","No wheels"]]]],
 ["Velcro","In 1941, a Swiss engineer named George de Mestral went for a walk with his dog. When he came home, burrs (spiky seeds) were stuck to his trousers and to his dog's fur. He looked at them under a microscope and saw tiny hooks. This gave him the idea for Velcro: one side has tiny hooks, and the other side has tiny loops.",[["What was stuck to his dog's fur?","Burrs (spiky seeds)",["Mud","Snow"]],["What did he see under the microscope?","Tiny hooks",["Tiny eyes","Tiny wheels"]],["How does Velcro work?","Tiny hooks catch on tiny loops",["It uses glue","It uses magnets"]]]],
 ["The Abacus","The abacus is one of the oldest counting tools in the world. It is a frame with rows of beads that slide along wires or rods. People in China, Japan, Russia and many other places have used the abacus for hundreds of years. Some people can add and subtract on an abacus faster than on a calculator!",[["What does an abacus have?","Rows of beads on wires or rods",["A screen","Buttons"]],["What is an abacus used for?","Counting and doing maths",["Cooking","Telling the time"]],["Where have people used the abacus?","China, Japan, Russia and many other places",["Only in Canada","Nowhere"]]]],
 ["Thomas Edison","Thomas Edison was an American inventor who lived from 1847 to 1931. He was born in the same year as Alexander Graham Bell! Edison and his team worked in a lab in New Jersey. They invented or improved more than one thousand things, including a machine that recorded sound and a long-lasting light bulb.",[["In which year was Edison born?","1847",["1876","1931"]],["Who was born in the same year?","Alexander Graham Bell",["William Kamkwamba","Mary Anderson"]],["About how many things did Edison's team invent or improve?","More than one thousand",["Two","Ten"]]]],
 ["The Wheelchair","Wheelchairs help people who cannot walk easily to move around. Early wheelchairs were heavy and made of wood. Modern wheelchairs are light and strong. Some are powered by batteries and can be steered with a small stick. Wheelchair athletes even race and play basketball at the Paralympic Games.",[["What were early wheelchairs made of?","Wood",["Plastic","Glass"]],["How are some modern wheelchairs powered?","By batteries",["By horses","By the wind"]],["Where do wheelchair athletes compete?","At the Paralympic Games",["Only in schools","On the Moon"]]]],
 ["The Zipper","Before zippers, people fastened their clothes and boots with buttons and hooks, which took a long time. In 1913, an engineer named Gideon Sundback, who lived in the United States and later in Canada, designed a zipper with rows of small metal teeth that lock together. Today, zippers are on jackets, bags, tents and boots.",[["What did people use before zippers?","Buttons and hooks",["Velcro only","Glue"]],["Who designed the modern zipper?","Gideon Sundback",["Thomas Edison","James Naismith"]],["What does a zipper have?","Rows of small metal teeth that lock together",["Magnets","Buttons"]]]],
 ["The Light Bulb and Lewis Latimer","Lewis Latimer was an American inventor and the son of people who had escaped from slavery. He taught himself to draw plans for machines. In 1882, he invented a better way to make the thin thread inside light bulbs, called the filament, so bulbs lasted longer and cost less. He also helped Alexander Graham Bell draw the plans for the telephone.",[["What did Lewis Latimer teach himself?","To draw plans for machines",["To fly planes","To play chess"]],["What did he improve in 1882?","The filament inside light bulbs",["The wheel","The bicycle chain"]],["Which other inventor did he help?","Alexander Graham Bell",["William Kamkwamba","Louis Braille"]]]],
 ["Solar Panels","Solar panels turn sunlight into electricity. They are made of special materials that create a tiny electric current when light shines on them. Solar panels are on houses, schools, calculators and even on the International Space Station. They help make clean energy that does not pollute the air.",[["What do solar panels turn sunlight into?","Electricity",["Water","Wind"]],["Where can you find solar panels?","On houses, schools and the space station",["Only on boats","Only underground"]],["Why is solar energy good for the planet?","It does not pollute the air",["It is noisy","It needs coal"]]]],
 ["Inventions by Children","Some famous inventions were made by children. Louis Braille invented Braille at about 15. Frank Epperson was 11 when he left a cup of juice with a stick outside on a cold night, and it froze into an ice pop. Today, children all over the world enter invention fairs with ideas to help their families and communities.",[["How old was Frank Epperson when he made the first ice pop?","11",["40","5"]],["How did the ice pop happen?","He left juice with a stick outside on a cold night",["He bought it in a shop","He put it in an oven"]],["Who else invented something as a teenager?","Louis Braille",["Thomas Edison","Mary Anderson"]]]]
];
const detail=()=>{const p=R(DETAIL),x=R(p[2]);return mcQ(`${box(p[0],p[1])}${x[0]}`,x[1],x[2],`Look back at the text: the answer is there.`,"Read the text again and find the words.",{say:p[1]+" "+x[0]})};
const MAIN=[
 ["Inventors never give up. Bell's first experiments failed. The Wright brothers crashed many times. William built his windmill even when people laughed.","Inventors never give up.",["Windmills are tall.","Planes can crash."]],
 ["The wheel is used everywhere. Cars and bikes have wheels. Clocks have tiny wheels called gears. Even suitcases and office chairs have wheels.","The wheel is used everywhere.",["Chairs are comfortable.","Suitcases are heavy."]],
 ["Electric light changed people's lives. People could read at night. Streets became safer. Factories could work after dark.","Electric light changed people's lives.",["Streets are long.","Factories are big."]],
 ["Many inventions come from nature. Velcro was inspired by burrs. Airplane wings copy the shape of bird wings. Some swimsuits copy the skin of sharks.","Many inventions come from nature.",["Sharks are fast.","Birds have feathers."]],
 ["Good inventors ask questions. They ask: What is the problem? How could it be better? What if we tried something new?","Good inventors ask questions.",["Problems are hard.","New things are fun."]],
 ["Inventions can help people with disabilities. Braille helps blind people read. Wheelchairs help people move around. Hearing aids help people hear.","Inventions can help people with disabilities.",["Wheelchairs have wheels.","Ears hear sounds."]],
 ["Recycled materials can become new inventions. William used old bicycle parts. Children make toys from boxes. Artists make sculptures from bottle caps.","Recycled materials can become new inventions.",["Bottles are plastic.","Toys are fun."]],
 ["The telephone has changed a lot. The first phones were big and attached to a wall. Later, phones had no wires. Today, phones are small computers in our pockets.","The telephone has changed a lot.",["Pockets are small.","Walls are tall."]],
 ["Teamwork helps inventors. Bell worked with Watson. Edison had a big team. The Wright brothers worked together.","Teamwork helps inventors.",["Brothers are family.","Teams play games."]],
 ["Some inventions happen by accident. The ice pop was made when juice froze. Velcro was invented after a walk with a dog. Some medicines were found by surprise.","Some inventions happen by accident.",["Dogs like walks.","Juice is sweet."]],
 ["Before writing an invention report, inventors plan. They draw a design. They list the parts. They think about how to test it.","Inventors plan before they build.",["Designs are pictures.","Parts are small."]],
 ["Canadians have invented many useful things. Basketball, the snowmobile and the paint roller were invented by Canadians. Insulin was made into a medicine in Toronto.","Canadians have invented many useful things.",["Toronto is a city.","Snow is cold."]],
 ["Ancient India gave the world many ideas. Zero as a number came from India. An early form of chess was played there. The word shampoo comes from Hindi.","Ancient India gave the world many ideas.",["Chess is a game.","Shampoo is for hair."]],
 ["Solar and wind power make clean energy. Solar panels use sunlight. Windmills use the wind. Neither of them pollutes the air.","Solar and wind power make clean energy.",["The wind blows.","The Sun is hot."]],
 ["Paper changed how people share ideas. It was cheaper than silk. It was lighter than clay or stone. Later, books and newspapers were printed on paper.","Paper changed how people share ideas.",["Silk is soft.","Stone is heavy."]],
 ["Robots do many jobs today. They build cars in factories. They explore Mars. Some even vacuum floors in our homes.","Robots do many jobs today.",["Mars is red.","Floors get dirty."]],
 ["Some inventions keep us safe. Seat belts protect us in cars. Smoke alarms warn us about fire. Helmets protect our heads.","Some inventions keep us safe.",["Cars are fast.","Fire is hot."]],
 ["The printing press spread knowledge. Books became cheaper. More people learned to read. New ideas travelled quickly from city to city.","The printing press spread knowledge.",["Cities are busy.","Books have pages."]],
 ["Inventions often improve old ideas. The safety bicycle improved earlier bikes. Electric lights improved candles. Phones improved letters.","Inventions often improve old ideas.",["Candles are old.","Letters have stamps."]],
 ["Children can be inventors too. Louis Braille was a teenager. Frank Epperson was 11. Many children win prizes at invention fairs.","Children can be inventors too.",["Prizes are shiny.","Fairs are fun."]],
 ["Testing is an important part of inventing. Inventors test their ideas many times. They learn from what goes wrong. Then they improve the design.","Testing is an important part of inventing.",["Designs are drawings.","Things go wrong."]],
 ["Some inventions help us talk to each other. Letters, telephones and the internet all carry messages. Today, we can talk to people anywhere in the world in seconds.","Some inventions help us talk to each other.",["Letters have stamps.","Seconds are short."]],
 ["Patents protect inventors. A patent says the idea belongs to the inventor. Others cannot copy it for some years. Margaret Knight fought to keep her patent.","Patents protect inventors' ideas.",["Margaret was brave.","Years are long."]],
 ["Women have invented many important things. Mary Anderson invented windshield wipers. Margaret Knight invented a paper bag machine. Many women scientists work on new inventions today.","Women have invented many important things.",["Bags carry things.","Windows are glass."]]
];
const mainIdea=()=>{const m=R(MAIN);return mcQ(`${box("Read",m[0])}What is the <b>main idea</b>? (What is it mostly about?)`,m[1],m[2],`The main idea is what the whole text is about: <b>${m[1]}</b>`,"Which answer fits ALL the sentences, not just one?",{say:m[0]})};
const FACTS=["Alexander Graham Bell made the first telephone call in 1876.","The Wright brothers flew in 1903.","Basketball was invented by James Naismith.","The wheel is more than 5,000 years old.","Braille is read with the fingers.","Gutenberg built a printing press.","Insulin was made into a medicine in Toronto.","Tim Berners-Lee invented the World Wide Web.","William Kamkwamba built a windmill in Malawi.","Mary Anderson invented windshield wipers.","Bell was born in Scotland.","A battery stores electricity.","Solar panels turn sunlight into electricity.","Velcro has hooks and loops.","Chess began in India as chaturanga.","Paper-making was improved in China.","The first flight lasted 12 seconds.","Edison's team made a long-lasting light bulb.","The word shampoo comes from Hindi.","A patent protects an inventor's idea.","Margaret Knight invented a paper bag machine.","Robots work in car factories.","Bell lived in Brantford, Ontario.","Louis Braille was blind.","Some crows can drop pebbles to raise water."];
const OPIN=["The telephone is the best invention ever.","Basketball is more fun than chess.","Robots are scary.","Inventing is the most exciting job.","Velcro shoes are better than shoes with laces.","Old telephones look funny.","Everyone should build a windmill.","The printing press is more important than the wheel.","Bicycles are the best way to travel.","Computers are boring.","Edison was a better inventor than Bell.","Solar panels are beautiful.","The crow was the smartest bird ever.","Science fairs are better than art fairs.","Ice pops taste best in summer.","Snowmobiles are too noisy.","Braille is the cleverest invention.","Playing chess is relaxing.","Robots should do all our chores.","The Wright brothers were the bravest inventors.","Phones are more useful than books.","Inventions from nature are the coolest.","Paper planes are the most fun to make.","Windmills look prettier than solar panels.","My invention idea is the best in the class."];
const factOp=()=>{const f=Math.random()<.5;const s=f?R(FACTS):R(OPIN);return mcQ(`Is this a <b>fact</b> or an <b>opinion</b>?<br><b>${s}</b>`,f?"Fact":"Opinion",[f?"Opinion":"Fact"],f?"A <b>fact</b> can be checked in a book or by an expert.":"An <b>opinion</b> is what someone thinks or feels. Others may disagree.","Could you check it? Or is it a feeling?")};
const SEQ=[["Bell is born in Scotland","The family moves to Canada","Bell teaches deaf students in Boston","Bell makes the first telephone call"],["There is a drought in Malawi","William leaves school","William reads about windmills","William builds a windmill"],["Find a problem","Think of an idea","Draw a design","Build and test it"],["The crow is thirsty","She finds a pitcher","She drops in pebbles","She drinks the water"],["Make holes in two cups","Push the string through","Tie the string to paper clips","Pull the string tight and talk"],["Copying books by hand","The printing press (1440)","The telephone (1876)","The World Wide Web (1989)"],["Candles","Oil lamps","Electric light bulbs","Modern LED lights"],["Bicycles with no pedals","Bicycles with a giant front wheel","The safety bicycle","Modern bicycles"],["Basketball invented (1891)","First airplane flight (1903)","Insulin made into a medicine (1921)","The snowmobile (1959)"],["George walks his dog","Burrs stick to his trousers","He looks at them under a microscope","He invents Velcro"],["Juice is left outside with a stick","The night is very cold","The juice freezes","Frank has the first ice pop"],["Test the invention","Find what went wrong","Improve the design","Test it again"]];
const order=()=>{const s=R(SEQ),t=R(["first","last","next"]);
  if(t==="first")return mcQ(`What comes <b>FIRST</b>?`,s[0],SAMPLE(s.slice(1),2),`Order: ${s.join(" → ")}`,"What must come before everything else?");
  if(t==="last")return mcQ(`What comes <b>LAST</b>?`,s[s.length-1],SAMPLE(s.slice(0,-1),2),`Order: ${s.join(" → ")}`,"What comes at the very end?");
  const k=Math.floor(Math.random()*(s.length-1));return mcQ(`What comes right <b>AFTER</b> this?<br><b>${s[k]}</b>`,s[k+1],SAMPLE(s.filter((_,i)=>i!==k&&i!==k+1),2),`Order: ${s.join(" → ")}`,"What is the very next step?")};
const CE=J.filter(x=>x[2]==="because"||x[2]==="so").map(x=>x[2]==="so"?[`${x[0]}, so ${x[1]}.`,x[0].charAt(0).toLowerCase()+x[0].slice(1),x[1]]:[`${x[0]} because ${x[1]}.`,x[1],x[0].charAt(0).toLowerCase()+x[0].slice(1)]).map(c=>[c[0],c[1].replace(/^i\b/,"I"),c[2].replace(/^i\b/,"I")]).map(c=>[c[0],c[1].replace(/^(bell|william|margaret|banting|naismith|bombardier|gutenberg|watson|mia|leo|insulin|chess)\b/i,m=>cap(m)),c[2].replace(/^(bell|william|margaret|banting|naismith|bombardier|gutenberg|watson|mia|leo|insulin|chess)\b/i,m=>cap(m))]);
const cause=()=>{const c=R(CE),other=R(CE.filter(x=>x!==c));const askCause=Math.random()<.5;
  return mcQ(`${box("Read",c[0])}What is the <b>${askCause?"cause":"effect"}</b>? <span style="color:var(--muted);font-size:15px">(${askCause?"WHY it happened":"WHAT happened"})</span>`,askCause?c[1]:c[2],[askCause?c[2]:c[1],askCause?other[1]:other[2]].filter(z=>z!==(askCause?c[1]:c[2])),`Cause (why): <b>${c[1]}</b>. Effect (what happened): <b>${c[2]}</b>.`,"Look for because and so.",{say:c[0]})};
const CMP=[
 ["Alexander Graham Bell and Thomas Edison were both inventors born in 1847. Bell is famous for the telephone. Edison is famous for the light bulb.","Both were inventors born in 1847","Bell is famous for the telephone, but Edison for the light bulb",["Both invented the airplane","Edison invented the telephone"]],
 ["Candles and light bulbs both give light. Candles use a flame. Light bulbs use electricity and are safer.","Both give light","Candles use a flame, but light bulbs use electricity",["Both use a flame","Light bulbs use fire"]],
 ["Letters and telephones both carry messages. A letter can take days to arrive. A telephone call is instant.","Both carry messages","Letters take days, but phone calls are instant",["Both take weeks","Phone calls take days"]],
 ["Windmills and solar panels both make clean electricity. Windmills use the wind. Solar panels use sunlight.","Both make clean electricity","Windmills use wind, but solar panels use sunlight",["Both use coal","Solar panels use wind"]],
 ["William Kamkwamba and the crow both solved a problem in a clever way. William built a windmill from scrap. The crow dropped pebbles into a pitcher.","Both solved a problem in a clever way","William built a windmill, but the crow used pebbles",["Both built windmills","The crow built a windmill"]],
 ["Basketball and chess are both games. Basketball is played by running and throwing a ball. Chess is played by moving pieces on a board.","Both are games","Basketball uses a ball, but chess uses pieces on a board",["Both use a ball","Chess uses running"]],
 ["Velcro and zippers both fasten clothes and bags. Velcro uses hooks and loops. Zippers use rows of metal or plastic teeth.","Both fasten clothes and bags","Velcro uses hooks and loops, but zippers use teeth",["Both use buttons","Zippers use hooks and loops"]],
 ["Early bicycles and modern bicycles both have two wheels. Some early bicycles had no pedals. Modern bicycles have pedals and a chain.","Both have two wheels","Early bikes had no pedals, but modern bikes have pedals and a chain",["Both have no pedals","Modern bikes have no chain"]],
 ["Margaret Knight and Mary Anderson were both women inventors. Margaret invented a paper bag machine. Mary invented windshield wipers.","Both were women inventors","Margaret invented a bag machine, but Mary invented wipers",["Both invented wipers","Mary invented the bag machine"]],
 ["Paper and the printing press both helped people share ideas. Paper was improved in China. The printing press was built in Germany.","Both helped people share ideas","Paper was improved in China, but the press was built in Germany",["Both came from Canada","The press came from China"]],
 ["Robots and people can both build cars. Robots can work all day without getting tired. People can think of new ideas and solve surprising problems.","Both can build cars","Robots don't get tired, but people think of new ideas",["Both get tired","Robots think of all the new ideas"]],
 ["Braille and printed books both let people read. Printed books are read with the eyes. Braille is read with the fingers.","Both let people read","Printed books are read with the eyes, but Braille with the fingers",["Both are read with the ears","Braille is read with the eyes"]]
];
const compare=()=>{const c=R(CMP);const same=Math.random()<.5;
  return mcQ(`${box("Read",c[0])}${same?"How are they the <b>same</b>?":"What is one <b>difference</b>?"}`,same?c[1]:c[2],[same?c[2]:c[1],R(c[3])],same?`Same: <b>${c[1]}</b>.`:`Different: <b>${c[2]}</b>.`,same?"Look for the word both.":"Look for the word but.",{say:c[0]})};

/* ================= THINKING ================= */
const PUZ=[
 {q:"🧩 Riddle: I have teeth but I never bite. I hold your jacket closed tight. What am I?",o:["A zipper","A comb","A dog"],a:"A zipper",why:"Zippers have rows of teeth."},
 {q:"🧩 Riddle: I ring and ring, but I am not a bell. You talk into me. What am I?",o:["A telephone","A clock","A doorbell"],a:"A telephone",why:"You talk into a telephone."},
 {q:"🧩 Riddle: I am round and I roll. Without me, cars could not go. What am I?",o:["A wheel","A ball","A coin"],a:"A wheel",why:"Wheels help vehicles move."},
 {q:"🧩 Riddle: I glow when you switch me on, but I'm not the Sun. What am I?",o:["A light bulb","A star","A candle"],a:"A light bulb",why:"Electric light bulbs glow when switched on."},
 {q:"🧩 Riddle: I have keys but open no doors. What am I?",o:["A keyboard","A lock","A car"],a:"A keyboard",why:"A computer keyboard has keys."},
 {q:"🧩 Riddle: I have hooks and loops, and I go 'rrrip!' What am I?",o:["Velcro","A zipper","A button"],a:"Velcro",why:"Velcro's hooks catch on loops."},
 {q:"🧩 Riddle: I have arms that turn in the wind, and I can make electricity. What am I?",o:["A windmill","A tree","A kite"],a:"A windmill",why:"The wind turns its blades."},
 {q:"🧩 Riddle: I store power for your toys and flashlights. What am I?",o:["A battery","A gear","A wire"],a:"A battery",why:"Batteries store electricity."},
 {q:"⚠️ What should you do before using a tool like scissors or a sharp pencil to make holes?",o:["Ask a grown-up for help","Use it with your eyes closed","Run with it"],a:"Ask a grown-up for help",why:"Sharp tools can hurt you."},
 {q:"⚠️ Is it safe to put metal objects into an electric socket?",o:["No, never","Yes, it's fine","Only with a spoon"],a:"No, never",why:"Electricity can badly hurt you."},
 {q:"⚠️ An electrical cord is broken and the wires show. What should you do?",o:["Don't touch it and tell a grown-up","Use it anyway","Fix it with tape yourself"],a:"Don't touch it and tell a grown-up",why:"Broken cords are dangerous."},
 {q:"🧪 Your invention doesn't work the first time. What should you do?",o:["Find out what went wrong and try again","Give up forever","Throw it away and cry"],a:"Find out what went wrong and try again",why:"Inventors learn from mistakes."},
 {q:"🧪 You want to know which paper plane flies farthest. What is the fairest test?",o:["Throw each plane the same way from the same spot","Throw one plane outside and one inside","Throw one hard and one softly"],a:"Throw each plane the same way from the same spot",why:"A fair test changes only one thing."},
 {q:"🧪 Why do inventors draw a design first?",o:["To plan how it will look and work","Because drawing is required by law","To waste paper"],a:"To plan how it will look and work",why:"A plan saves time and mistakes."},
 {q:"🪨 The crow dropped 10 pebbles. Then she dropped 8 more. How many pebbles altogether?",o:["18","2","80"],a:"18",why:"10 + 8 = 18."},
 {q:"☎️ The telephone was invented in 1876. The airplane flew in 1903. Which came first?",o:["The telephone","The airplane","They came at the same time"],a:"The telephone",why:"1876 is before 1903."},
 {q:"🛞 A bicycle has 2 wheels. How many wheels do 4 bicycles have?",o:["8","6","4"],a:"8",why:"2 × 4 = 8."},
 {q:"🔋 A toy needs 3 batteries. How many batteries do 3 toys need?",o:["9","6","3"],a:"9",why:"3 × 3 = 9."},
 {q:"🔌 Which uses electricity?",o:["A fridge","A pencil","A spoon"],a:"A fridge",why:"Fridges plug into the wall."},
 {q:"🌍 Which energy source is clean and never runs out?",o:["Sunlight","Coal","Gasoline"],a:"Sunlight",why:"The Sun shines every day."},
 {q:"♻️ What could you invent with an old shoebox?",o:["A pencil holder or a toy car garage","A real car","A rocket to the Moon"],a:"A pencil holder or a toy car garage",why:"Ordinary things can become useful inventions."},
 {q:"🤖 Which job would a robot do best?",o:["Doing the same task again and again","Comforting a sad friend","Choosing a birthday present for Grandma"],a:"Doing the same task again and again",why:"Robots are good at repeating tasks; people are good at feelings and choices."},
 {q:"💡 Which is the best first step to invent something?",o:["Find a problem to solve","Buy expensive parts","Give it a cool name"],a:"Find a problem to solve",why:"Every good invention solves a problem."},
 {q:"🐦‍⬛ Why did dropping pebbles make the water rise?",o:["The pebbles took up space at the bottom","The pebbles melted","The crow sang to the water"],a:"The pebbles took up space at the bottom",why:"Things you put in water push the water up."},
 {q:"📞 Why does a cup telephone not work if the string is loose?",o:["The vibrations can't travel along a loose string","The cups get angry","Loose string is too heavy"],a:"The vibrations can't travel along a loose string",why:"Sound travels along a tight string."},
 {q:"🔦 Which invention helps you see in a dark tent?",o:["A flashlight","A wheel","A zipper"],a:"A flashlight",why:"A flashlight uses a battery and a bulb."},
 {q:"🧠 What do all inventors have in common?",o:["They are curious and keep trying","They are all rich","They are all grown-ups"],a:"They are curious and keep trying",why:"Even children can be inventors."},
 {q:"🧩 Which came first: the wheel or the bicycle?",o:["The wheel","The bicycle","Neither"],a:"The wheel",why:"You need wheels to make a bicycle!"}
];
const yearsQ=()=>{const x=R(IV.filter(y=>y[2]>=1800));const t=R(["bday","after","before"]);let q,ans,why;
  if(t==="bday"){const n=R([10,20,50,100]);ans=x[2]+n;q=`${cap(x[0])} was invented in ${x[2]}. What year was it ${n} years later?`;why=`${x[2]} + ${n} = ${ans}.`}
  else if(t==="after"){const n=rint(1,9);ans=x[2]+n;q=`${cap(x[0])} came in ${x[2]}. What year was ${n} years after that?`;why=`${x[2]} + ${n} = ${ans}.`}
  else{const n=rint(1,9);ans=x[2]-n;q=`${cap(x[0])} came in ${x[2]}. What year was ${n} years before that?`;why=`${x[2]} − ${n} = ${ans}.`}
  return mcQ("📅 "+q,String(ans),SAMPLE(uniq([ans+1,ans-1,ans+10,ans-10].filter(z=>z!==ans)),2).map(String),why,"Add for later, take away for earlier.")};
const GRP={"things that use electricity":["fridge","computer","light bulb","robot","television"],"tools":["hammer","screwdriver","saw","wrench","drill"],"inventors":["Bell","Edison","Braille","Naismith","Kamkwamba"],"ways to travel":["bicycle","airplane","train","snowmobile","car"],"parts of a machine":["gear","wheel","engine","battery","wire"],"fruits":["apple","banana","mango","grape"],"musical instruments":["guitar","drum","flute","violin"]};
const odd=()=>{const ks=Object.keys(GRP);const k=R(ks),k2=R(ks.filter(x=>x!==k));const three=SAMPLE(GRP[k],3),o=R(GRP[k2].filter(x=>!GRP[k].includes(x)));
  return mcQ(`🤔 Which one does NOT belong?`,o,three,`${three.join(", ")} are all ${k}. <b>${o}</b> is not.`,"Find what three of them have in common.")};
const ANA=[["Bell is to telephone as Naismith is to ___.","basketball",["chess","Braille"]],["Candle is to flame as bulb is to ___.","electricity",["wax","wind"]],["Windmill is to wind as solar panel is to ___.","sunlight",["water","coal"]],["Invent is to invention as collect is to ___.","collection",["collector","collected"]],["Act is to action as protect is to ___.","protection",["protector","protecting"]],["Was is to one as were is to ___.","more than one",["none","nothing"]],["Is is to was as are is to ___.","were",["was","be"]],["Because is to reason as so is to ___.","result",["question","name"]],["Pilot is to airplane as driver is to ___.","car",["boat","rocket"]],["Hammer is to nail as screwdriver is to ___.","screw",["glue","paper"]],["Ancient is to old as modern is to ___.","new",["broken","heavy"]],["Eyes are to reading print as fingers are to reading ___.","Braille",["music","clocks"]],["Velcro is to burrs as airplane wings are to ___.","birds' wings",["fish fins","leaves"]],["Battery is to toy as petrol is to ___.","car",["bicycle","kite"]],["Library is to books as factory is to ___.","machines",["animals","clouds"]],["Wheel is to cart as wing is to ___.","airplane",["boat","car"]],["Letter is to post as email is to ___.","internet",["horse","ship"]],["Crow is to pebbles as William is to ___.","scrap parts",["peach baskets","silk"]],["Inventor is to invents as explorer is to ___.","explores",["cooks","sleeps"]],["Simple is to easy as complicated is to ___.","difficult",["quick","small"]]];
const analogy=()=>{const x=R(ANA);return mcQ("🔗 "+x[0],x[1],x[2],`${x[0].replace("___","<b>"+x[1]+"</b>")} Think about how the first two words are linked.`,"How are the first two words linked? Use the same link.")};

/* ================= SENTENCES AND WRITING ================= */
const SENT=["Alexander Graham Bell was born in Scotland.","The Bell family moved to Canada in 1870.","William built a windmill in Malawi.","James Naismith invented basketball.","The Wright brothers flew in December 1903.","Louis Braille was from France.","Mary Anderson lived in Alabama.","Insulin was made into a medicine in Toronto.","Gutenberg built a printing press in Germany.","The first telephone call was in March 1876.","Tim Berners-Lee invented the World Wide Web.","Chess began in India.","The crow dropped pebbles into the pitcher.","The inventors were very determined.","The experiment was successful.","My invention was very simple.","The machine was loud, but it worked.","We were excited about the invention fair.","The bulb was broken, so we bought a new one.","Bell loved sound because his mother was deaf.","The robot stopped because the battery was empty.","The wheels were made of wood.","The children were proud of their models.","The windmill was tall and strong."];
const fix=()=>{const s=R(SENT);return {type:"type",strict:true,q:`Fix this sentence. Add the capital letters and the full stop:<br><b>${breakSentence(s)}</b>`,a:[s],hint:"Capital letter at the start, capitals for names, places, months and I, and a full stop at the end.",why:`Correct: <b>${s}</b>`}};
const D=[CHK.cap,CHK.end,CHK.w4,CHK.I];
const WP=[
 {q:"Write a sentence about the past using <b>was</b>.",checks:[...D,["\\bwas\\b","Uses was"]],model:"The first telephone was very big."},
 {q:"Write a sentence about the past using <b>were</b>.",checks:[...D,["\\bwere\\b","Uses were"]],model:"The Wright brothers were very brave."},
 {q:"Write a sentence using <b>wasn't</b> or <b>weren't</b>.",checks:[...D,["\\b(wasn't|weren't)\\b","Uses wasn't or weren't"]],model:"The first experiments weren't successful."},
 {q:"Write a question that starts with <b>Was</b> or <b>Were</b>.",checks:[["^\\s*(Was|Were)\\b","Starts with Was or Were"],CHK.q,CHK.w3],model:"Were you at the invention fair?"},
 {q:"Write a sentence using <b>and</b> to join two ideas.",checks:[...D,["\\band\\b","Uses and"]],model:"Mia drew the design and Leo built the model."},
 {q:"Write a sentence using <b>but</b>.",checks:[...D,["\\bbut\\b","Uses but"]],model:"The machine was noisy, but it worked well."},
 {q:"Write a sentence using <b>because</b>.",checks:[...D,["\\bbecause\\b","Uses because"]],model:"I like inventing because it is fun to solve problems."},
 {q:"Write a sentence using <b>so</b>.",checks:[...D,["\\bso\\b","Uses so"]],model:"The battery was empty, so the toy stopped."},
 {q:"Write a sentence with a word that ends in <b>-tion</b>.",checks:[...D,["\\w+tion\\b","Uses a -tion word"]],model:"The telephone is an amazing invention."},
 {q:"Write a sentence about an inventor from this unit.",checks:[...D,["\\b(Bell|William|Kamkwamba|Naismith|Edison|Braille|Anderson|Knight|Gutenberg|Wright|Banting|Berners-Lee|Bombardier)\\b","Names an inventor with a capital letter"]],model:"Louis Braille invented a way for blind people to read."},
 {q:"Write a sentence that tells what people used <b>before</b> an invention.",checks:[...D,["\\b[Bb]efore\\b","Uses before"]],model:"Before light bulbs, people used candles."},
 {q:"Write a sentence about a problem you would like to solve.",checks:[...D,["\\b(problem|solve|fix)\\b","Mentions a problem"]],model:"I would like to solve the problem of plastic in the ocean."},
 {q:"Write a sentence describing a machine using two describing words.",checks:[...D,["\\b(machine|robot|engine|computer|windmill|telephone)\\b","Names a machine"]],model:"The robot was small and clever."},
 {q:"Write a sentence that starts with <b>One day,</b> about inventing something.",checks:[["^\\s*One day,","Starts with One day,"],CHK.end,CHK.w4,CHK.I],model:"One day, I will invent a flying bicycle."},
 {q:"Write a sentence using both <b>because</b> and <b>so</b>.",checks:[...D,["\\bbecause\\b","Uses because"],["\\bso\\b","Uses so"]],model:"It was cold because it snowed, so we stayed inside."},
 {q:"Write a sentence about an invention you use at school.",checks:[...D,["\\b(computer|pencil|ruler|calculator|board|bell|light|clock|scissors|book)s?\\b","Names a school invention"]],model:"We use a computer to write stories."},
 {q:"Write a thank-you sentence to an inventor.",checks:[...D,["\\b([Tt]hank you|[Tt]hanks)\\b","Says thank you"]],model:"Thank you, Mr. Bell, for inventing the telephone."},
 {q:"Write a sentence about how the crow solved her problem.",checks:[...D,["\\b(pebbles?|stones?)\\b","Mentions the pebbles"]],model:"The crow dropped pebbles in, so the water rose."},
 {q:"Write a sentence that tells why testing an invention is important.",checks:[...D,["\\b[Tt](est|esting|ested)\\b","Mentions testing"]],model:"Testing is important because it shows what needs to be fixed."},
 {q:"Write a sentence that compares the past and today.",checks:[...D,["\\b(was|were|used)\\b","Talks about the past"],["\\b(now|today)\\b","Talks about today"]],model:"Phones were big in the past, but today they fit in our pockets."}
];

/* ================= LEARN NOTES ================= */
const L={
 detail:"Read the short text carefully. The answer is <b>in the text</b>.",
 main:"The <b>main idea</b> is what the whole text is mostly about. It fits <b>all</b> the sentences.",
 factop:"A <b>fact</b> can be checked in a book or by an expert. An <b>opinion</b> is a feeling: <i>The telephone is the best invention ever.</i>",
 order:"Life stories, instructions and history all have an <b>order</b>. What comes first, next and last?",
 cause:"The <b>cause</b> is <b>why</b>. The <b>effect</b> is <b>what happened</b>. Look for <b>because</b> and <b>so</b>.",
 compare:"<b>Same:</b> look for <b>both</b>, <b>also</b>. <b>Different:</b> look for <b>but</b>.",
 psol:"Every invention solves a <b>problem</b>. Read the problem, then choose the invention (the <b>solution</b>) that fixes it.",
 vocab:"Read the word, say it aloud, and think of a sentence that uses it.",
 who:"<b>Bell</b> telephone (1876) · <b>Edison's team</b> long-lasting light bulb (1879) · <b>Wright brothers</b> airplane (1903) · <b>Gutenberg</b> printing press (1440) · <b>Naismith</b> basketball (1891) · <b>Braille</b> reading for blind people · <b>Berners-Lee</b> World Wide Web (1989).",
 when:"The <b>smaller</b> year number came <b>first</b>. 1876 is before 1903.",
 ba:"Before an invention, people found other ways: candles before light bulbs, letters before telephones, horses before cars.",
 syn:"<b>Synonyms</b> mean almost the same: invent = create, fix = repair.",
 opp:"<b>Opposites</b>: ancient ↔ modern, simple ↔ complicated, connect ↔ disconnect.",
 comp:"<b>Compound words</b>: wind + mill = windmill, head + phones = headphones.",
 was:"Use <b>was</b> with <b>I, he, she, it</b> and one person or thing: <i>Bell <b>was</b> curious. The machine <b>was</b> loud.</i><br>Use <b>were</b> with <b>we, you, they</b> and more than one: <i>The brothers <b>were</b> brave. You <b>were</b> right.</i>",
 wasneg:"<b>wasn't</b> = was not · <b>weren't</b> = were not.<br>In questions, <b>Was</b> or <b>Were</b> comes first: <i><b>Was</b> it loud? <b>Were</b> they happy?</i>",
 topast:"Present → past: <b>am</b> → was · <b>is</b> → was · <b>are</b> → were.",
 join:"Joining words connect two ideas:<br><b>and</b> adds another idea · <b>but</b> shows something different · <b>because</b> gives the <b>reason</b> · <b>so</b> gives the <b>result</b>.<br>Put a comma before <b>and, but, so</b> when they join two sentences. No comma before <b>because</b>.",
 tion:"<b>-tion</b> sounds like \"shun\". It turns an action word into a naming word: invent → <b>invention</b>, collect → <b>collection</b>. If the word ends in <b>e</b>, drop the e: create → <b>creation</b>.",
 fix:"Check: <b>1.</b> capital letter at the start, <b>2.</b> capitals for names, places, months and I, <b>3.</b> a full stop at the end.",
 orderW:"Find the word with the capital letter: it goes first. Then think: <b>who? did what?</b>",
 write:"Plan in your head first. Then write: capital letter, complete idea, end mark.",
 spell:"Use <b>Look → Say → Cover → Write → Check</b>.",
 choose:"Say the word slowly and picture it. Remember: <b>-tion</b> (not -shun), <b>ph</b> sounds like f, <b>ch</b> in machine sounds like sh.",
 think:"Think like an inventor: find the problem, plan, test and stay safe.",
 years:"To find a later year, <b>add</b>. To find an earlier year, <b>take away</b>.",
 odd:"Three belong to the same group. Find the one that does <b>not</b> belong.",
 ana:"Find how the first two words are linked. Use the <b>same link</b> for the next pair.",
 review:"These questions come from earlier units, so you keep everything you learned fresh."
};
const RV=id=>UNITS.find(x=>x.id===id).review;
u.review=MIX(wasWere,wasNeg,wasQ,toPast,joinQ,becauseSo,tionJoin,tionUse,whoQ,F.bank(PSOL),F.vocab(u.words));

/* ================= THE SKILL LIST ================= */
u.cats=[
 {n:"Reading",e:"📖",items:[
  {id:"r_t1",t:"Life story: Alexander Graham Bell",act:"story",si:0},
  {id:"r_t2",t:"True story: The Boy Who Caught the Wind",act:"story",si:1},
  {id:"r_t3",t:"Fact text: Inventions That Changed the World",act:"story",si:2},
  {id:"r_t4",t:"Fact text: Inventions from Canada and India",act:"story",si:3},
  {id:"r_t5",t:"Fable: The Crow and the Pitcher",act:"story",si:4},
  {id:"r_t6",t:"Real-world reading: Instructions and an invention fair poster",act:"story",si:5},
  {id:"r_p1",t:"Classic poem: The Lamplighter (Robert Louis Stevenson)",act:"poem",pi:0},
  {id:"r_p2",t:"Poem: If I Could Invent",act:"poem",pi:1},
  {id:"r_psol",t:"Problem and solution",learn:L.psol,gen:F.bank(PSOL)},
  {id:"r_detail",t:"Read and find the details",learn:L.detail,gen:detail},
  {id:"r_main",t:"Find the main idea",learn:L.main,gen:mainIdea},
  {id:"r_factop",t:"Fact or opinion?",learn:L.factop,gen:factOp},
  {id:"r_order",t:"Order and sequence",learn:L.order,gen:order},
  {id:"r_cause",t:"Cause and effect",learn:L.cause,gen:cause},
  {id:"r_compare",t:"Compare and contrast",learn:L.compare,gen:compare}]},
 {n:"Vocabulary",e:"🔤",items:[
  {id:"v_s1",t:"Inventing words",learn:L.vocab,gen:F.vocab(set(0))},
  {id:"v_s2",t:"Machine and technology words",learn:L.vocab,gen:F.vocab(set(1))},
  {id:"v_s3",t:"History and people words",learn:L.vocab,gen:F.vocab(set(2))},
  {id:"v_s4",t:"Describing and doing words",learn:L.vocab,gen:F.vocab(set(3))},
  {id:"v_fill",t:"Use the right word in a sentence",learn:L.vocab,gen:F.fill(u.words)},
  {id:"v_who",t:"Who invented it?",learn:L.who,gen:MIX(whoQ,whatQ)},
  {id:"v_when",t:"Invention timeline: which came first?",learn:L.when,gen:whenQ},
  {id:"v_ba",t:"Before and after inventions",learn:L.ba,gen:F.bank(BA)},
  {id:"v_syn",t:"Synonyms",learn:L.syn,gen:F.pairs(SYN,"synonym")},
  {id:"v_opp",t:"Opposites",learn:L.opp,gen:F.pairs(OPP,"opposite")},
  {id:"v_comp",t:"Compound words",learn:L.comp,gen:MIX(F.compoundJoin(COMP),F.compoundPick(COMP))}]},
 {n:"Grammar",e:"🧩",items:[
  {id:"g_was",t:"Was or were?",learn:L.was,gen:MIX(wasWere,wasFix)},
  {id:"g_wasneg",t:"Wasn't, weren't and was/were questions",learn:L.wasneg,gen:MIX(wasNeg,wasQ)},
  {id:"g_topast",t:"Change am, is, are to the past",learn:L.topast,gen:toPast},
  {id:"g_join",t:"Joining words: and, but, because, so",learn:L.join,gen:joinQ},
  {id:"g_jointype",t:"Join two sentences",learn:L.join,gen:joinType},
  {id:"g_becso",t:"Because or so? (reason and result)",learn:L.join,gen:becauseSo},
  {id:"g_tion",t:"Make -tion words (invent → invention)",learn:L.tion,gen:tionJoin},
  {id:"g_tionuse",t:"Use -tion words in sentences",learn:L.tion,gen:tionUse},
  {id:"g_fix",t:"Fix the sentence (capitals and full stops)",learn:L.fix,gen:fix},
  {id:"g_order",t:"Put the words in order",learn:L.orderW,gen:G.order(SENT.filter(x=>(x.match(/\b[A-Z]/g)||[]).length===1&&!/,/.test(x)))},
  {id:"g_write",t:"Write your own sentences",learn:L.write,gen:F.write(WP)},
  {id:"g_mixed",t:"Mixed grammar review",learn:"Use all the was/were, joining-word and -tion rules from this unit.",gen:MIX(wasWere,wasFix,wasNeg,wasQ,toPast,joinQ,becauseSo,tionJoin,tionUse)}]},
 {n:"Spelling",e:"🎧",items:[
  {id:"s_inv",t:"Invention words: listen and write",learn:L.spell,gen:F.listen(SP)},
  {id:"s_tion",t:"-tion words: listen and write",learn:L.tion,gen:F.listen(TLIST)},
  {id:"s_choose",t:"Choose the correct spelling",learn:L.choose,gen:F.chooseSpelling(CHOOSE)},
  {id:"s_missing",t:"Missing letters",learn:L.spell,gen:F.missing(SP.concat(TLIST))}]},
 {n:"Thinking and science",e:"🧠",items:[
  {id:"t_puz",t:"Invention riddles and safety",learn:L.think,gen:F.bank(PUZ)},
  {id:"t_years",t:"Years and timelines",learn:L.years,gen:yearsQ},
  {id:"t_odd",t:"Odd one out",learn:L.odd,gen:odd},
  {id:"t_ana",t:"Word links (analogies)",learn:L.ana,gen:analogy}]},
 {n:"Review earlier units",e:"🔁",items:[
  {id:"rv_u1",t:"Review: Unit 1 (sentences, question words, nouns)",learn:L.review,gen:RV("me")},
  {id:"rv_u2",t:"Review: Unit 2 (plurals, past tense, animals)",learn:L.review,gen:RV("animals")},
  {id:"rv_u3",t:"Review: Unit 3 (present tense, plants, magic e)",learn:L.review,gen:RV("plants")},
  {id:"rv_u4",t:"Review: Unit 4 (adjectives, comparing, homophones)",learn:L.review,gen:RV("weather")},
  {id:"rv_u5",t:"Review: Unit 5 (future tense, a/an/the, space)",learn:L.review,gen:RV("space")},
  {id:"rv_u6",t:"Review: Unit 6 (prepositions, pronouns, un-/re-)",learn:L.review,gen:RV("ocean")},
  {id:"rv_u7",t:"Review: Unit 7 (has/have, question words, time, money)",learn:L.review,gen:RV("maths")}]},
 {n:"Explore and write",e:"✏️",items:[
  {id:"x_facts",t:"Did you know? Amazing invention facts",act:"facts"},
  {id:"x_w1",t:"Writing step 1: An invention I use every day",act:"write",wi:0},
  {id:"x_w2",t:"Writing step 2: Problem and solution",act:"write",wi:1},
  {id:"x_w3",t:"Writing step 3: Report: My Invention",act:"write",wi:2}]}
];
})();
