/* ===================== GRADE 2 · UNIT 1 · FRIENDS AND NEIGHBOURS ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:2,id:"g2_friends",num:1,emoji:"🧑‍🤝‍🧑🏘️👋",title:"Friends and Neighbours",short:"long a, complete sentences, describing people",badge:"🤝 Friendship Star",
stories:[
/* 1 STORY: PROBLEM AND HAPPY ENDING */
{title:"A New Friend on Maple Lane",e:"🏡",kind:"Story",pages:[
 {pic:"🚚🏡🪁",text:"A big truck stops on Maple Lane. A new family is moving in next door. Sam looks out of his window. He sees a girl with a red kite. Her name is Lena. She is seven, just like Sam. Sam wants to say hello. But Sam feels a little shy. His tummy feels funny.",
  qs:[f("What does the new girl have?","A red kite 🪁",["A blue ball ⚽","A grey cat 🐱"],"He sees a girl with a red kite."),
      f("How does Sam feel?","A little shy 🙈",["Very angry 😠","Sleepy 😴"],"Sam feels a little shy.")]},
 {pic:"👋😶",text:"The next day, Sam waves to Lena. \"Hi! Do you want to play?\" he asks. Lena smiles, but she does not say a word. She looks down at her shoes. Sam feels sad. Did he say something wrong? His mom says, \"Lena is from Ukraine. She is still learning English.\"",
  qs:[f("Where is Lena from?","Ukraine 🇺🇦",["Japan 🇯🇵","Mexico 🇲🇽"],"Lena is from Ukraine."),
      p("What will Sam do next?","Find a new way to play 💡",["Never talk to Lena again","Move away 🚚"],"Sam still wants to be Lena's friend.")]},
 {pic:"🖍️🌈",text:"Sam has an idea. He gets a box of chalk. He draws a sun and a kite on the sidewalk. Then he holds out a piece of chalk to Lena. Lena's face lights up. She draws a big rainbow. Sam claps for her. They do not need many words. They draw and laugh all day.",
  qs:[f("What does Sam get?","A box of chalk",["A big cake 🎂","A toy train 🚂"],"He gets a box of chalk."),
      t("Why don't they need many words?","Drawing helps them play together 🎨",["They are angry","They are asleep"],"They can play and laugh with pictures.")]},
 {pic:"🌧️🍰🤝",text:"Then the rain starts to fall. Oh no! The rain washes the pictures away. Lena points to her house. \"Come in,\" she says in English. Her dad gives them cake on a plate. Lena teaches Sam to say \"pryvit.\" It means hi in Ukrainian. Sam teaches Lena to say \"hello.\" Now they are friends.",
  qs:[f("What does \"pryvit\" mean?","Hi 👋",["Goodbye","Thank you"],"It means hi in Ukrainian."),
      t("How did Sam help Lena feel welcome?","He found a way to play 🖍️",["He laughed at her","He ran away"],"Sam shared his chalk so they could play.")]}
],turn:{q:"How can you help a new friend feel welcome? Write one or two sentences.",model:"I can wave and ask the new kid to play with me."}},
/* 2 NON-FICTION */
{title:"What Is a Neighbourhood?",e:"🏘️",kind:"Non-fiction",pages:[
 {pic:"🏘️🌳",text:"A neighbourhood is the place around your home. It has streets, homes and shops. The people who live near you are your neighbours. Some neighbourhoods are in big cities. Some are in small towns. On farms, neighbours may live far apart. Every neighbourhood is a little different. What is your neighbourhood like?",
  qs:[f("Who are your neighbours?","People who live near you 🏡",["People on TV 📺","People far away ✈️"],"The people who live near you are your neighbours."),
      f("What does a neighbourhood have?","Streets, homes and shops",["Only trees","Only water"],"It has streets, homes and shops.")]},
 {pic:"🥐📚🛒",text:"A neighbourhood has places we need. A bakery sells bread and cakes. A market sells fruit and vegetables. A library lends books for free. A park has trees, benches and swings. Some neighbourhoods have a pool or a community centre too. These places help make a neighbourhood a good place to live.",
  qs:[f("What does a bakery sell?","Bread and cakes 🍞",["Books 📚","Shoes 👟"],"A bakery sells bread and cakes."),
      t("Where would you go to borrow a book?","The library 📚",["The bakery 🥐","The market 🛒"],"A library lends books for free.")]},
 {pic:"📬🧑‍🚒🚌",text:"Many helpers work in a neighbourhood. A mail carrier brings letters to our homes. Firefighters keep us safe from fires. A crossing guard helps children cross the street. Bus drivers take people where they need to go. Doctors and nurses help us when we are sick. Each helper has an important job.",
  qs:[f("Who brings letters to our homes?","A mail carrier 📬",["A baker 🥐","A firefighter 🧑‍🚒"],"A mail carrier brings letters to our homes."),
      p("The next page tells how neighbours help each other. What might it say?","Neighbours share and help 🤝",["Neighbours never talk","Neighbours eat the mail"],"The page is about helping, so it will tell about sharing and helping.")]},
 {pic:"🤝🌻❄️",text:"Good neighbours help each other. They wave and say hello. They may share vegetables from a garden. They may help shovel snow in winter. They keep the street clean and safe. They share tools and toys. Some neighbours watch your pet when you go away. When neighbours are kind, everyone feels at home.",
  qs:[f("How can neighbours help in winter?","Shovel snow ❄️",["Go swimming 🏊","Pick apples 🍎"],"They may help shovel snow in winter."),
      t("Why is it good to have kind neighbours?","Everyone feels at home 🏡",["The street gets messy","No one says hello"],"When neighbours are kind, everyone feels at home.")]}
],turn:{q:"Name one place in your neighbourhood. What do you do there?",model:"I go to the library. I read books there."}},
/* 3 PATTERNED TEXT */
{title:"Can You Be My Friend?",e:"🧑‍🤝‍🧑",kind:"Pattern book",pages:[
 {pic:"🖍️⏳🛝",text:"Can you play with me today? Yes, I can! Can you share your crayons with me? Yes, I can! Can you wait for your turn? Yes, I can! A friend can play. A friend can share. A friend can wait. Can you be my friend? Yes, I can! Let us go and play!",
  qs:[t("Which words come again and again?","Yes, I can!",["No, thank you!","Good night!"],"Yes, I can! is said again and again. That is the pattern."),
      f("What can a friend share?","Crayons 🖍️",["A train 🚂","A snail 🐌"],"Can you share your crayons with me?")]},
 {pic:"🩹😂🙏",text:"Can you help me when I fall? Yes, I can! Can you make me laugh out loud? Yes, I can! Can you say sorry when you are wrong? Yes, I can! A friend can help. A friend can be funny. A friend can say sorry. Can you be my friend? Yes, I can!",
  qs:[f("What can a friend say when they are wrong?","Sorry 🙏",["Go away","Ha ha"],"Can you say sorry when you are wrong?"),
      p("What do you think the next page will ask?","More \"Can you...?\" questions ❓",["A story about a dragon 🐉","How to bake bread 🍞"],"Every page asks Can you...? questions.")]},
 {pic:"🦁💖👂",text:"Can you be brave and try new things? Yes, I can! Can you be kind to someone new? Yes, I can! Can you listen when I talk? Yes, I can! A friend is brave. A friend is kind. A friend can listen. Can you be my friend? Yes, I can!",
  qs:[f("Who can a friend be kind to?","Someone new 🧒",["Only themself","Nobody"],"Can you be kind to someone new?"),
      t("What does a good listener do?","Listens when you talk 👂",["Talks all the time","Walks away"],"Can you listen when I talk?")]},
 {pic:"🌧️🎂👋",text:"Can you play with me in the rain? Yes, I can! Can you make a cake out of clay? Yes, I can! Can you wave to me from far away? Yes, I can! Rain or sun, near or far, we can play. You are my friend, and I am yours. Hooray!",
  qs:[f("What do they make out of clay?","A cake 🎂",["A train 🚂","A plane ✈️"],"Can you make a cake out of clay?"),
      t("Which word rhymes with play?","clay",["rain","cake"],"Play and clay both end in -ay.")]}
],turn:{q:"Write your own pattern sentence: Can you ___? Yes, I can!",model:"Can you skip with me? Yes, I can!"}},
/* 4 HOW-TO */
{title:"How to Fix a Small Problem",e:"🛠️",kind:"How-to text",pages:[
 {pic:"⚽😠😠",text:"Friends do not always agree. Maya and Omar both want the red ball. Maya pulls. Omar pulls. Now they are both upset! The ball almost rips. This is a small problem. Small problems can be fixed. Friends can fix them together. You can fix them with four easy steps. Let us learn them!",
  qs:[f("What do Maya and Omar both want?","The red ball ⚽",["A cake 🎂","The swing"],"Maya and Omar both want the red ball."),
      p("What will the four steps help them do?","Fix the problem 🛠️",["Shout louder 📢","Break the ball"],"Small problems can be fixed with four easy steps.")]},
 {pic:"🛑😮‍💨🗣️",text:"Step 1: Stop. Take three slow, deep breaths. This helps your body calm down. Step 2: Talk. Use kind words to say how you feel. Maya says, \"I feel sad when you pull.\" Then listen to your friend. Omar says, \"I wanted a turn too.\" Now they both know how the other feels.",
  qs:[f("What do you do in Step 1?","Stop and take deep breaths",["Run away","Yell"],"Step 1: Stop. Take three slow, deep breaths."),
      t("Why do you take deep breaths?","To calm down 😌",["To get the ball","To fall asleep"],"This helps your body calm down.")]},
 {pic:"💡🔄⏲️",text:"Step 3: Think of a plan. Is there a fair way to share? Maya and Omar think of ideas. They could take turns. They could play catch together. They could use a timer. Step 4: Try the plan. They pick playing catch. Maya throws the ball to Omar. Omar throws it back. Now they both get to play!",
  qs:[f("Which plan do they pick?","Playing catch together",["Using a timer ⏲️","Going home 🏠"],"They pick playing catch."),
      f("What is Step 4?","Try the plan",["Stop","Talk"],"Step 4: Try the plan.")]},
 {pic:"🙂🤝🙂",text:"What if the plan does not work? You can try another plan. If the problem is too big, ask a grown-up for help. That is a smart and brave thing to do. Grown-ups like to help. Remember the steps: stop, talk, think and try. Small problems happen to everyone. Good friends work it out together!",
  qs:[f("What if the problem is too big?","Ask a grown-up for help 🧑‍🏫",["Hide 🙈","Push your friend"],"If the problem is too big, ask a grown-up for help."),
      t("What are the four steps?","Stop, talk, think, try",["Run, hide, cry, shout","Eat, sleep, play, read"],"Remember the steps: stop, talk, think and try.")]}
],turn:{q:"Write one kind thing you can say when you and a friend have a problem.",model:"I feel sad. Can we take turns?"}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Hello, Friends Around the World!",e:"🌍",kind:"Children around the world",pages:[
 {pic:"🇯🇵🙇✊✋✌️",text:"This is Aiko. She lives in Japan. When Aiko meets her teacher, she bows to say hello. Aiko and her friends like to play jan-ken-pon. It is rock, paper, scissors! Rock beats scissors. Scissors beat paper. Paper beats rock. Aiko and her friend count, \"Jan, ken, pon!\" Who will win this time?",
  qs:[f("How does Aiko say hello to her teacher?","She bows 🙇",["She claps 👏","She jumps 🦘"],"She bows to say hello."),
      t("Which one beats scissors?","Rock ✊",["Paper ✋","Scissors ✌️"],"Rock beats scissors.")]},
 {pic:"🇬🇭👏🦶",text:"This is Ama. She lives in Ghana, in Africa. Ama and her friends play a game called ampe. Two girls clap and jump at the same time. When they land, each girl puts one foot out. The feet decide who gets a point. The game is fast, and everyone laughs.",
  qs:[f("Where does Ama live?","Ghana 🇬🇭",["Japan 🇯🇵","India 🇮🇳"],"She lives in Ghana, in Africa."),
      f("What do the girls do in ampe?","Clap, jump and put a foot out",["Swim and dive","Paint and draw"],"They clap and jump, then each girl puts one foot out.")]},
 {pic:"🇮🇳🙏🪁",text:"This is Dev. He lives in India. Dev puts his hands together and says \"Namaste\" to greet people. On windy days, Dev flies kites with his friends on the roof. The sky is full of bright kites. Some kites are red, and some are green. Dev and his friends cheer and wave.",
  qs:[f("What does Dev say to greet people?","Namaste 🙏",["Ampe","Jan-ken-pon"],"Dev says \"Namaste\" to greet people."),
      p("The next child is from New Zealand. What will we learn?","How he says hello 👋",["How to bake bread","How to fly a plane"],"Each page tells how a child greets people or plays.")]},
 {pic:"🇳🇿👃🏉",text:"This is Tane. He lives in New Zealand. He is Māori. Sometimes Māori people greet with a hongi. Two people gently press their noses and foreheads together. It shows they share the breath of life. Tane also loves to play rugby with his friends. They run, pass the ball and laugh.",
  qs:[f("What touches in a hongi?","Noses and foreheads 👃",["Hands and feet","Elbows and knees"],"Two people gently press their noses and foreheads together."),
      t("How are Aiko, Ama, Dev and Tane the same?","They all have fun with friends 🤝",["They all live in Japan","They all fly kites"],"They live in different places, but they all play with friends.")]}
],turn:{q:"How do you say hello to your friends? Write one or two sentences.",model:"I wave and say hello to my friends."}},
/* 6 REAL-WORLD TEXT */
{title:"Real-world reading: Signs on Our Street",e:"🪧",kind:"Real-world text",pages:[
 {pic:"🐱📞",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🐱 LOST KITTEN! 🐱</b><br><span style=\"font-size:22px;line-height:1.8\">😺 Name: Pepper<br>🎨 Grey with white paws<br>📍 Last seen: Maple Lane, Saturday<br>📞 Please call Rosa<br>💖 Thank you for your help!</span></div>",
  qs:[f("What is the kitten's name?","Pepper",["Rosa","Maple"],"😺 Name: Pepper"),
      f("What colour are the kitten's paws?","White 🤍",["Black 🖤","Orange 🧡"],"🎨 Grey with white paws")]},
 {pic:"🎂🧁🍪",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🎂 BAKE SALE 🎂</b><br><span style=\"font-size:22px;line-height:1.8\">📅 Saturday, 10:00 to 12:00<br>📍 Maple Lane Library<br>🍪 Cookie $1<br>🧁 Cupcake $2<br>🍰 Slice of cake $3<br>🌳 The money helps our park!</span></div>",
  qs:[f("Where is the bake sale?","Maple Lane Library 📚",["The bakery 🥐","The school gym 🏀"],"📍 Maple Lane Library"),
      t("You buy a cupcake and a cookie. How much do you pay?","$3",["$2","$5"],"$2 + $1 = $3.")]},
 {pic:"🌳🪧",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🌳 MAPLE PARK RULES 🌳</b><br><span style=\"font-size:22px;line-height:1.8\">🐕 Keep dogs on a leash<br>🗑️ Put trash in the bin<br>🔄 Take turns on the swings<br>🚲 Walk your bike on the path<br>🌙 The park closes at 9:00</span></div>",
  qs:[f("What do you do on the swings?","Take turns 🔄",["Stand on them","Run away"],"🔄 Take turns on the swings"),
      p("Leo has an empty wrapper. What should he do?","Put it in the bin 🗑️",["Drop it on the grass","Give it to a dog"],"🗑️ Put trash in the bin is a park rule.")]},
 {pic:"🗺️🔑",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🗺️ MAP KEY: OUR NEIGHBOURHOOD</b><br><span style=\"font-size:22px;line-height:1.8\">🏠 Homes<br>🥐 Bakery<br>📚 Library<br>🛒 Market<br>🚸 Crosswalk<br>⛲ Fountain<br>🚏 Bus stop</span></div>",
  qs:[f("What does 🚸 show?","A crosswalk",["A bakery","A fountain"],"🚸 Crosswalk"),
      t("Which symbol shows where to wait for a bus?","🚏",["⛲","🥐"],"🚏 Bus stop")]}
],turn:{q:"Make a sign for your street. Write one rule.",model:"Please drive slowly on our street."}}
],
poems:[
 {title:"Pat-a-Cake (a traditional clapping rhyme, more than 200 years old)",
  lines:["Pat-a-cake, pat-a-cake, baker's man,","Bake me a cake as fast as you can;","Pat it and prick it, and mark it with B,","And put it in the oven for baby and me."],
  qs:[f("Who is asked to bake the cake?","The baker's man 🧑‍🍳",["The baby 👶","A cat 🐱"],"\"Pat-a-cake, pat-a-cake, baker's man, bake me a cake.\""),
      f("Which letter goes on the cake?","B",["A","C"],"\"Mark it with B.\""),
      f("Which word rhymes with man?","can",["cake","bake"],"Man and can both end in -an.")]},
 {title:"A Friend on My Street",
  lines:["I wave to Kai across the way,","He waves right back: \"Come out and play!\"","We race our scooters in the sun,","We share a snack when we are done.","If rain comes down, we stay inside","And build a fort that's big and wide.","A friend next door is fun to see,","I'm glad that Kai lives next to me!"],
  qs:[f("What do the friends race?","Scooters 🛴",["Trains 🚂","Boats ⛵"],"\"We race our scooters in the sun.\""),
      t("What do they do when it rains?","Build a fort inside 🏠",["Race outside","Go to sleep"],"\"If rain comes down, we stay inside and build a fort.\""),
      f("Which word rhymes with way?","play",["race","rain"],"Way and play both end in -ay.")]}
],
words:[
 {w:"friend",e:"🧑‍🤝‍🧑",m:"a person you like and have fun with",ex:"My friend and I play tag.",fill:"Leo is my best ___."},
 {w:"neighbour",e:"🏡",alt:["neighbor"],m:"a person who lives near you",ex:"My neighbour has a big dog.",fill:"The ___ next door waves to me."},
 {w:"greet",e:"👋",m:"to say hello when you meet someone",ex:"I greet my teacher with a smile.",fill:"Aiko bows to ___ her teacher."},
 {w:"share",e:"🤝",m:"to let others use or have some too",ex:"I share my crayons with Mia.",fill:"Please ___ the blocks with your friends."},
 {w:"gift",e:"🎁",m:"something you give to make someone happy",ex:"I made a gift for my friend.",fill:"I wrapped the ___ in pretty paper."},
 {w:"letter",e:"💌",m:"a message you write and send to someone",ex:"I wrote a letter to my cousin.",fill:"I put the ___ in the envelope."},
 {w:"envelope",e:"✉️",m:"a paper cover that you put a letter in",ex:"The envelope has a stamp on it.",fill:"Put the card in the ___ and close it."},
 {w:"mailbox",e:"📬",m:"a box where letters are put",ex:"The mail carrier puts letters in our mailbox.",fill:"Check the ___ for letters."},
 {w:"invite",e:"📨",m:"to ask someone to come",ex:"I invite my friends to my house.",fill:"Let us ___ Sam to play with us."},
 {w:"visit",e:"🚪",m:"to go and see a person or a place",ex:"We visit our neighbour on Sunday.",fill:"Can I ___ your house after school?"},
 {w:"kind",e:"💖",m:"nice and caring to others",ex:"Ana is kind to everyone.",fill:"It is ___ to help a friend who is sad."},
 {w:"funny",e:"😂",m:"makes people laugh",ex:"My friend tells funny jokes.",fill:"The clown was so ___!"},
 {w:"brave",e:"🦁",m:"not afraid to do something hard",ex:"Sam was brave at the doctor.",fill:"It was ___ to try the big slide."},
 {w:"helpful",e:"🙋",m:"likes to help other people",ex:"Kai is helpful. He carries the bags.",fill:"Thank you for being so ___!"},
 {w:"gentle",e:"🕊️",m:"soft and careful, not rough",ex:"Be gentle with the baby kitten.",fill:"Pat the puppy in a ___ way."},
 {w:"honest",e:"😇",m:"always tells the truth",ex:"Leo is honest. He tells the truth.",fill:"An ___ friend tells the truth."},
 {w:"shy",e:"🙈",m:"a little scared to talk to new people",ex:"Mia is shy on the first day.",fill:"The new boy was ___ and did not talk."},
 {w:"friendly",e:"😊",m:"nice and happy to meet people",ex:"Our new neighbour is very friendly.",fill:"The ___ girl said hi to me."},
 {w:"polite",e:"🙏",m:"uses good manners, like please and thank you",ex:"It is polite to say thank you.",fill:"Say please and thank you to be ___."},
 {w:"cheerful",e:"😄",m:"happy and smiling",ex:"Grandpa is cheerful in the morning.",fill:"Her ___ smile made me happy."},
 {w:"street",e:"🛣️",m:"a road with houses or shops on it",ex:"I live on Maple Street.",fill:"Look both ways before you cross the ___."},
 {w:"bakery",e:"🥐",m:"a shop that makes and sells bread and cakes",ex:"The bakery smells so good.",fill:"We buy fresh bread at the ___."},
 {w:"library",e:"📚",m:"a place where you borrow books",ex:"I borrow books from the library.",fill:"Please be quiet in the ___."},
 {w:"apartment",e:"🏢",m:"a home in a big building",ex:"Lin lives in an apartment.",fill:"Our ___ is on the fifth floor."},
 {w:"crosswalk",e:"🚸",m:"stripes on the road where people cross",ex:"We cross the street at the crosswalk.",fill:"Use the ___ to cross the street safely."},
 {w:"bench",e:"🪑",m:"a long seat for more than one person",ex:"We sit on a bench in the park.",fill:"Grandma rests on the park ___."},
 {w:"fountain",e:"⛲",m:"a place where water shoots up into the air",ex:"The fountain sprays water up high.",fill:"Birds splash in the ___ at the park."},
 {w:"market",e:"🛒",m:"a place where people buy and sell food",ex:"We buy apples at the market.",fill:"The ___ has fresh fruit and vegetables."},
 {w:"scooter",e:"🛴",m:"a toy with two wheels, a board and a handle",ex:"I ride my scooter to the park.",fill:"Put on a helmet before you ride your ___."},
 {w:"skate",e:"⛸️",m:"to slide on ice or roll on wheels",ex:"We skate on the pond in winter.",fill:"Can you ___ on the ice?"},
 {w:"race",e:"🏁",m:"to try to be the fastest",ex:"Let us race to the big tree!",fill:"We ___ to the fence and back."},
 {w:"train",e:"🚂",m:"a long line of cars that runs on a track",ex:"We ride the train to the city.",fill:"The ___ goes choo-choo down the track."},
 {w:"cake",e:"🎂",m:"a sweet food that you bake",ex:"We share a cake with our neighbours.",fill:"Mom baked a chocolate ___."},
 {w:"plate",e:"🍽️",m:"a flat dish that holds food",ex:"Put the cake on a plate.",fill:"Put your sandwich on the ___."},
 {w:"sandwich",e:"🥪",m:"bread with food in the middle",ex:"I eat a cheese sandwich.",fill:"I put cheese in my ___."},
 {w:"balloon",e:"🎈",m:"a soft bag you fill with air",ex:"My balloon is red and round.",fill:"Blow up the ___ and tie it."},
 {w:"language",e:"🗣️",m:"the words people use to talk",ex:"Lena speaks two languages.",fill:"Ukrainian is a ___."},
 {w:"soccer",e:"⚽",m:"a game where you kick a ball into a net",ex:"We play soccer at the park.",fill:"In ___, you kick the ball."},
 {w:"chess",e:"♟️",m:"a board game with kings and queens",ex:"Grandpa and I play chess.",fill:"In ___, the king must stay safe."},
 {w:"clap",e:"👏",m:"to hit your hands together to make a sound",ex:"We clap to the music.",fill:"___ your hands to the beat!"}
],
spelling:[],
facts:[
 {e:"🙇",c:"In Japan, many people bow to say hello.",t:true,x:"True! A bow is a polite way to greet someone in Japan."},
 {e:"🙏",c:"Namaste is a way to say hello in India.",t:true,x:"True! People put their hands together and say Namaste."},
 {e:"📬",c:"A mail carrier brings letters to homes.",t:true,x:"True! Mail carriers bring letters and small boxes."},
 {e:"🗣️",c:"All people in the world speak English.",t:false,x:"Not true! People speak thousands of different languages."},
 {e:"🧑‍🤝‍🧑",c:"Friends must always like the same things.",t:false,x:"Not true! Friends can like different things and still be friends."},
 {e:"✊",c:"Rock, paper, scissors is played in many countries.",t:true,x:"True! Children all over the world play it."},
 {e:"📚",c:"In most libraries, you can borrow books for free.",t:true,x:"True! You just need a library card."},
 {e:"🏡",c:"A neighbour is a person who lives far away from you.",t:false,x:"Not true! A neighbour lives near you."},
 {e:"👋",c:"The word hello is the same in every language.",t:false,x:"Not true! In Spanish, people say hola. In Ukrainian, they say pryvit."},
 {e:"👃",c:"Some Māori people in New Zealand greet by pressing noses.",t:true,x:"True! This greeting is called a hongi."},
 {e:"🚸",c:"A crosswalk is a safe place to cross the street.",t:true,x:"True! Cars should stop for people at a crosswalk."},
 {e:"✉️",c:"You can mail a letter without an address on it.",t:false,x:"Not true! The mail carrier needs an address to know where it goes."}
],
writing:[
 {e:"🧑‍🤝‍🧑",t:"My friend",level:"Step 1 · 3 sentences",
  prompt:"Write 3 sentences about a friend. What is your friend's name? What do you like to do together? Use a word from the word bank, like friend, kind or funny.",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b[Ff]riend","I wrote about my friend"]],
  starters:["My friend is ","We like to ","My friend is very "],
  model:"My friend is Kai. We like to race our scooters. My friend is very funny."},
 {e:"🏘️",t:"A good neighbour",level:"Step 2 · 4 sentences",
  prompt:"Write 4 sentences about a neighbour or about your neighbourhood. Who lives near you? What places are near your home? Use describing words, like kind, helpful or friendly.",
  minS:4,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Nn]eighbou?r|[Ss]treet|[Hh]ome|[Hh]ouse|[Aa]partment)","I wrote about where I live"],["\\b(kind|funny|brave|helpful|gentle|honest|shy|friendly|polite|cheerful|nice|happy)\\b","I used a describing word"]],
  starters:["My neighbour is ","Near my home, there is ","I like to ","My neighbour is very "],
  model:"My neighbour is Rosa. She is kind and helpful. Near my home, there is a bakery. I like to wave to her every day."},
 {e:"💌",t:"A friendly letter",level:"Step 3 · Dear…, 4 sentences, From…",
  prompt:"Write a friendly letter to a friend or a neighbour. Start with <b>Dear</b> and a name. Write 4 sentences. Tell some news and ask a question. End with <b>From,</b> or <b>Your friend,</b> and your name.",
  minS:4,minWords:1,
  rx:[["^\\s*Dear [A-Z]","I started with Dear and a name with a capital letter"],["^\\s*Dear [A-Za-z. ]+,","I put a comma after the name"],["\\.","I used a full stop"],["\\?","I asked a question"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b(From|Your friend|Love),?\\s*\\n?\\s*[A-Z][a-z]+\\s*$","I ended with From, and my name"]],
  starters:["Dear ___,","Thank you for ","I like to ","Can you come to ","From,"],
  model:"Dear Lena,\nThank you for the cake. It was very yummy. I like to draw with you. Can you come to my house on Saturday?\nFrom,\nSam"}
]};
UNITS.push(u);

/* ================= PHONICS: LONG A (a_e, ai, ay) ================= */
const big=e=>`<span style="font-size:44px">${e}</span>`;
/* [word, picture, spelling pattern, two wrong spellings that are not real words] */
const LA=[
 ["cake","🎂","a_e","caik","cayk"],["snake","🐍","a_e","snaik","snayk"],["plate","🍽️","a_e","playt","plaite"],["grapes","🍇","a_e","graips","grayps"],
 ["skate","⛸️","a_e","skait","skayt"],["whale","🐳","a_e","whail","whayl"],["face","😀","a_e","faice","fayce"],["plane","✈️","a_e","playn","plaine"],
 ["vase","🏺","a_e","vaise","vayse"],["race","🏁","a_e","raice","rayce"],["flame","🔥","a_e","flaim","flaym"],["frame","🖼️","a_e","fraim","fraym"],
 ["wave","👋","a_e","waiv","wayv"],["lake","🏞️","a_e","laik","layk"],["game","🎲","a_e","gaim","gaym"],["cape","🦸","a_e","caip","cayp"],["shape","🔷","a_e","shaip","shayp"],
 ["rain","🌧️","ai","rane","rayn"],["train","🚂","ai","trane","trayn"],["snail","🐌","ai","snale","snayl"],["mail","📬","ai","mayl","maile"],
 ["nail","💅","ai","nale","nayl"],["sail","⛵","ai","sayl","saile"],["paint","🎨","ai","paynt","pante"],["chain","⛓️","ai","chane","chayn"],
 ["pail","🪣","ai","payl","paile"],["rainbow","🌈","ai","ranebow","raynbow"],
 ["hay","🌾","ay","hai","haye"],["crayon","🖍️","ay","craion","craeon"],["x-ray","🩻","ay","x-rai","x-rae"],["pay","💵","ay","pai","pae"],
 ["day","🌞","ay","dai","dae"],["subway","🚇","ay","subwai","subwae"],["birthday","🥳","ay","birthdai","birthdae"],["highway","🛣️","ay","highwai","highwae"]
];
/* more long a words without pictures: [word, pattern] */
const LAW=[["gate","a_e"],["bake","a_e"],["same","a_e"],["made","a_e"],["late","a_e"],["wake","a_e"],["cane","a_e"],["tape","a_e"],["safe","a_e"],["brave","a_e"],["skate","a_e"],["grape","a_e"],["blame","a_e"],["trade","a_e"],
 ["wait","ai"],["tail","ai"],["main","ai"],["brain","ai"],["paid","ai"],["rail","ai"],["afraid","ai"],["trail","ai"],["drain","ai"],["plain","ai"],["raise","ai"],["daisy","ai"],
 ["play","ay"],["say","ay"],["stay","ay"],["way","ay"],["tray","ay"],["clay","ay"],["spray","ay"],["away","ay"],["today","ay"],["Sunday","ay"],["may","ay"],["sway","ay"],["stray","ay"],["okay","ay"]];
const PAT=["a_e","ai","ay"],PATN={"a_e":"a_e (like c<b>a</b>k<b>e</b> 🎂)","ai":"ai (like r<b>ai</b>n 🌧️)","ay":"ay (like d<b>ay</b> 🌞)"};
const showPat=(w,pt)=>pt==="ai"?w.replace("ai","<u>ai</u>"):pt==="ay"?w.replace(/ay/,"<u>ay</u>"):w;
const laWhich=()=>{const r=Math.random();
  if(r<.4){const x=R(LA);return mcQ(`${big(x[1])}<br>Which long a spelling is in <b>${x[0]}</b>?`,PATN[x[2]],PAT.filter(z=>z!==x[2]).map(z=>PATN[z]),`<b>${showPat(x[0],x[2])}</b> uses <b>${x[2]}</b> to spell the long a sound.`,"Look at the letters that say /ā/.")}
  if(r<.7){const x=R(LAW);return mcQ(`Which long a spelling is in <b>${x[0]}</b>?`,PATN[x[1]],PAT.filter(z=>z!==x[1]).map(z=>PATN[z]),`<b>${showPat(x[0],x[1])}</b> uses <b>${x[1]}</b>.`,"Find the letters that make the long a sound.")}
  const x=R(LA);return mcQ(`${big(x[1])}<br>Which is the right spelling?`,x[0],[x[3],x[4]],`${x[1]} is spelled <b>${x[0]}</b>. It uses <b>${x[2]}</b>.`,x[2]==="ay"?"Long a at the very end of a word is often spelled ay.":"Picture the word. Have you seen it in a book?",{say:x[0]})};
const laPic=()=>{const x=R(LA);
  if(Math.random()<.5)return mcQ(`What is this? ${big(x[1])}`,x[0],SAMPLE(LA.filter(y=>y!==x&&y[0][0]!==x[0][0]),2).map(y=>y[0]),`${x[1]} is <b>${x[0]}</b>.`,"Say the picture word. Then read each word.");
  return mcQ(`Which picture shows <b>${x[0]}</b>?`,x[1],SAMPLE(LA.filter(y=>y!==x),2).map(y=>y[1]),`<b>${x[0]}</b> is ${x[1]}.`,"Read the word sound by sound, then find the picture.",{say:x[0]})};
const gapW=(w,pt)=>pt==="ai"?w.replace("ai","_ _"):pt==="ay"?w.replace(/ay/,"_ _"):w.replace(/a([^aeiou]+)e/,"_$1_");
/* sentences with a long a word: [sentence with ___, word, pattern] */
const LAS=[["We ride the tr___n to the city.","train","ai"],["Put the cake on a pl___t___.","plate","a_e"],["I like to pl___ with my friends.","play","ay"],["The r___n made a big puddle.","rain","ai"],["The sn___l has a shell on its back.","snail","ai"],["Can you st___ for lunch?","stay","ay"],["We w___t at the crosswalk.","wait","ai"],["The m___l is in the mailbox.","mail","ai"],["Lena and Sam p___nt a picture.","paint","ai"],["Close the g___t___, please.","gate","a_e"],["W___v___ to your neighbour!","wave","a_e"],["The dog wags its t___l.","tail","ai"],["Let us b___k___ a cake.","bake","a_e"],["We have the s___m___ hat!","same","a_e"],["Today is a sunny d___.","day","ay"],["Put the cups on the tr___.","tray","ay"],["Do not be l___t___ for school.","late","a_e"],["The cow eats h___.","hay","ay"],["We make pots out of cl___.","clay","ay"],["We play a fun g___m___.","game","a_e"],["The boat has a big s___l.","sail","ai"],["We sk___t___ on the ice.","skate","a_e"],["The pl___n___ flies in the sky.","plane","a_e"],["I was not afr___d of the dark.","afraid","ai"]];
const laMake=()=>{if(Math.random()<.55){const x=R(LA);
  return {type:"type",q:`🧩 Complete the word. Type the <b>whole word</b>.<br>${big(x[1])}<br><b style="font-size:28px;letter-spacing:4px">${gapW(x[0],x[2])}</b>`,a:[x[0]],why:`${x[1]} is spelled <b>${showPat(x[0],x[2])}</b>, with <b>${x[2]}</b>.`,hint:x[2]==="a_e"?"Two letters are missing: a in the middle and a magic e at the end.":`The missing letters are a long a spelling: ${x[2]==="ai"?"ai or ay":"ay or ai"}.`}}
  const x=R(LAS);return {type:"type",q:`🧩 Complete the long a word. Type the <b>whole word</b>.<br><b>${x[0]}</b>`,a:[x[1]],why:`<b>${x[0].replace(/[a-z]*___[a-z_]*/i,x[1])}</b> The word <b>${x[1]}</b> uses <b>${x[2]}</b>.`,hint:x[2]==="a_e"?"It needs a and a magic e.":x[2]==="ay"?"It is at the end of the word, so try ay.":"It is in the middle of the word, so try ai."}};
/* short a / long a pairs */
const SL=[["cap","cape"],["mad","made"],["tap","tape"],["can","cane"],["man","mane"],["plan","plane"],["mat","mate"],["hat","hate"],["van","vane"],["fad","fade"],["scrap","scrape"],["rat","rate"],["pan","pain"],["ran","rain"],["bat","bait"],["pal","pail"],["lad","laid"],["snack","snake"],["back","bake"],["sack","sake"],["tack","take"],["Sam","same"],["pad","paid"],["lack","lake"]];
const SHORTX=["cat","map","bag","jam","ham","fan","sad","dad","tag","clap","flag","black","crab","grass","hand","glad","trap","last"];
const LONGX=["day","play","rain","wait","gate","cake","say","tray","snail","game","late","wave","name","paint","stay","race"];
const laShort=()=>{const r=Math.random(),pr=R(SL),L="Long a 🎂 (like cake)",S="Short a 🐱 (like cat)";
  if(r<.35){const isL=Math.random()<.5,w=isL?R(LONGX.concat(SL.map(z=>z[1]))):R(SHORTX.concat(SL.map(z=>z[0])));
    return mcQ(`Does <b>${w}</b> have a <b>long a</b> or a <b>short a</b>?`,isL?L:S,[isL?S:L],isL?`<b>${w}</b> has long a. The a says its name: /ā/.`:`<b>${w}</b> has short a, like c-a-t.`,"Say the word. Does the a say its name, /ā/?",{say:w})}
  if(r<.6)return mcQ(`Which word has the <b>long a</b> sound? 🎂`,pr[1],[pr[0],R(SHORTX)],`<b>${pr[1]}</b> has long a. <b>${pr[0]}</b> has short a.`,"Long a says its name: /ā/.");
  if(r<.8)return mcQ(`Which word has the <b>short a</b> sound? 🐱`,pr[0],[pr[1],R(LONGX)],`<b>${pr[0]}</b> has short a. <b>${pr[1]}</b> has long a.`,"Short a sounds like the a in cat.");
  const m=R(SL.filter(z=>/^[a-z]/.test(z[0])&&z[1]===z[0]+"e"));
  return {type:"type",q:`🪄 Add a <b>magic e</b> to make a long a word:<br><b style="font-size:26px">${m[0]} + e = ?</b>`,a:[m[1]],why:`${m[0]} + e = <b>${m[1]}</b>. The magic e makes the a say its name.`,hint:"Write the word, then put e at the end."}};
const LALIST=G4.sp([["cake","We eat cake at the party.","c-a-k-e: the magic e makes a say its name"],["rain","The rain is falling.","r-ai-n: ai says long a"],["play","Can you play with me?","pl-ay: ay comes at the end"],["train","The train is long.","tr-ai-n: ai in the middle"],["snail","The snail is slow.","sn-ai-l: ai in the middle"],["plate","Put it on a plate.","pl-a-t-e: magic e"],["day","Have a good day!","d-ay: ay at the end"],["wave","I wave to my friend.","w-a-v-e: magic e"],["paint","We paint a picture.","p-ai-n-t: ai says long a"],["tray","Put the cups on the tray.","tr-ay: ay at the end"],["mail","The mail came today.","m-ai-l: ai in the middle"],["skate","I can skate on ice.","sk-a-t-e: magic e"],["game","We play a fun game.","g-a-m-e: magic e"],["stay","Please stay with me.","st-ay: ay at the end"],["gate","Shut the gate.","g-a-t-e: magic e"],["way","This is the way to the park.","w-ay: ay at the end"],["sail","The boat has a white sail.","s-ai-l: ai in the middle"],["lake","We swim in the lake.","l-a-k-e: magic e"],["snake","The snake is long and green.","sn-a-k-e: magic e"],["hay","The horse eats hay.","h-ay: ay at the end"],["chain","The bike has a chain.","ch-ai-n: ai in the middle"],["race","Let us race to the tree.","r-a-c-e: magic e"],["clay","I made a pot of clay.","cl-ay: ay at the end"],["wait","Wait at the crosswalk.","w-ai-t: ai in the middle"]]);

/* ================= GRAMMAR: COMPLETE SENTENCES (WHO + WHAT THEY DO) ================= */
const WHO1=["Mia","Leo","Sam","Lena","Omar","Aiko","Kofi","Priya","Ben","Rosa","My friend","My neighbour","The new girl","The little boy","My cousin","The kind boy next door","My funny friend Kai","The girl with the red kite","Our neighbour with the big dog"];
const DO1=["waves hello","shares a snack","rides a scooter","reads a book","bakes a cake","plays soccer","draws with chalk","sings a song","helps a friend","walks to the park","jumps in a puddle","flies a kite","feeds the cat","writes a letter","laughs at the joke","claps to the music","races to the gate","paints a rainbow","skates on the pond","waits for the bus","plays chess","visits the library"];
const WHO2=["My friends","The children","Lena and Sam","We","Our neighbours","The twins","Aiko and Dev","My classmates"];
const DO2=["wave hello","share a snack","play tag","read books","bake a cake","play soccer","draw with chalk","sing a song","help each other","walk to the park","fly kites","write letters","race to the gate","skate on the pond","wait for the bus","clap and jump"];
const pickSD=()=>Math.random()<.65?[R(WHO1),R(DO1)]:[R(WHO2),R(DO2)];
const CS_OK="✅ Yes, it is complete",CS_W="❌ No, it needs a WHO",CS_D="❌ No, it needs a WHAT THEY DO";
const csIs=()=>{const [w,d]=pickSD(),r=Math.random();
  if(r<.6){const k=Math.floor(Math.random()*3);
    const s=k===0?`${w} ${d}.`:k===1?`${cap(d)}.`:`${w}.`,a=[CS_OK,CS_W,CS_D][k];
    return mcQ(`Is this a <b>complete sentence</b>?<br><b style="font-size:22px">${s}</b>`,a,[CS_OK,CS_W,CS_D].filter(z=>z!==a),
      k===0?`<b>${w}</b> is the who. <b>${d}</b> is what they do. It is complete!`:k===1?`We don't know WHO ${d}. Add a who, like <b>${w} ${d}.</b>`:`We know who, but not what they do. Add a doing part, like <b>${w} ${d}.</b>`,
      "A complete sentence tells WHO and WHAT THEY DO.")}
  return mcQ(`Which one is a <b>complete sentence</b>?`,`${w} ${d}.`,[`${cap(d)}.`,`${w}.`],`<b>${w} ${d}.</b> tells who (${w}) and what they do (${d}).`,"Find the one with a WHO and a WHAT THEY DO.")};
const NOTDO=["the red kite","my new friend","a big cake","the park bench","at the park","in the rain","on Maple Lane","after school","very happy","so funny"];
const NOTWHO=["Very happy","So kind","At the park","In the rain","After school","Plays tag","Runs fast","Under the bench"];
const csAdd=()=>{const [w,d]=pickSD();
  if(Math.random()<.5)return mcQ(`Which part finishes the sentence? It needs <b>what they do</b>.<br><b style="font-size:22px">${w} ___.</b>`,d,SAMPLE(NOTDO,2),`<b>${w} ${d}.</b> Now it tells what ${w==="We"?"we do":"they do"}.`,"Pick the part with a doing word, like runs, plays or reads.");
  return mcQ(`Which part finishes the sentence? It needs a <b>who</b>.<br><b style="font-size:22px">___ ${d}.</b>`,w,SAMPLE(NOTWHO,2),`<b>${w} ${d}.</b> Now we know who does it.`,"Pick the part that names a person or people.")};
/* who + what pairs that only fit together */
const WW=[["The baker 🧑‍🍳","bakes bread and cakes"],["The mail carrier 📬","brings letters to our homes"],["The firefighter 🧑‍🚒","puts out fires"],["The crossing guard 🚸","helps children cross the street"],["The bus driver 🚌","drives the bus"],["The librarian 📚","helps us find books"],["The doctor 🩺","helps sick people get better"],["The farmer 🧑‍🌾","grows food on a farm"],["The dentist 🦷","checks our teeth"],["The pilot 🧑‍✈️","flies the plane"],["The gardener 🌻","waters the flowers"],["The plumber 🔧","fixes the leaky pipes"],["The painter 🖌️","paints the walls"],["The bird 🐦","builds a nest"],["The dog 🐕","wags its tail"],["The frog 🐸","hops into the pond"],["The hen 🐔","lays an egg"],["The cat 🐱","says meow"],["The fish 🐟","swims in the water"],["The bee 🐝","makes honey"],["The baby 👶","drinks milk from a bottle"],["The singer 🎤","sings on the stage"],["The vet 🐶","takes care of sick pets"],["The cow 🐄","eats grass in the field"]];
const nm=x=>x.replace(/ \S+$/,"");/* strip the emoji */
const csMatch=()=>{const r=Math.random();
  if(r<.35){const x=R(WW);return mcQ(`Who does this? Match the <b>who</b> to the <b>what</b>.<br><b style="font-size:22px">___ ${x[1]}.</b>`,x[0],SAMPLE(WW.filter(y=>y!==x),2).map(y=>y[0]),`<b>${nm(x[0])} ${x[1]}.</b>`,"Which person or animal really does this?")}
  if(r<.7){const x=R(WW);return mcQ(`What does ${x[0].replace(/^The/,"the")} do?<br><b style="font-size:22px">${nm(x[0])} ___.</b>`,x[1],SAMPLE(WW.filter(y=>y!==x),2).map(y=>y[1]),`<b>${nm(x[0])} ${x[1]}.</b>`,"Think about what this person or animal does.")}
  const [w,d]=pickSD();
  if(r<.85)return mcQ(`${G4.box("Sentence",w+" "+d+".")}Which part tells <b>WHO</b>?`,w,[d,d.split(" ").slice(-1)[0]],`<b>${w}</b> tells who. <b>${d}</b> tells what they do.`,"The who part names a person or people.",{say:w+" "+d+"."});
  return mcQ(`${G4.box("Sentence",w+" "+d+".")}Which part tells <b>WHAT THEY DO</b>?`,d,[w,R(WHO1.concat(WHO2).filter(z=>z!==w))],`<b>${d}</b> tells what they do. <b>${w}</b> tells who.`,"The doing part has an action word.",{say:w+" "+d+"."})};

/* ================= WORD SKILL: DESCRIBING PEOPLE ================= */
const DESC=[["Ken carries bags for his old neighbour.","helpful",["shy","funny"]],["Zoe tells jokes, and we all laugh.","funny",["shy","gentle"]],["Raj is not scared to jump into the deep pool.","brave",["shy","polite"]],["Ana always tells the truth.","honest",["funny","shy"]],["Tom pets the kitten very softly.","gentle",["brave","funny"]],["Mei says please and thank you.","polite",["brave","shy"]],["Ali hides behind his dad when he meets new people.","shy",["brave","funny"]],["Grandma smiles and sings all morning.","cheerful",["shy","honest"]],["Lucy says hi to every new kid at the park.","friendly",["shy","honest"]],["Ben gives his sad friend a hug.","kind",["funny","brave"]],
 ["Kofi helps his dad wash the dishes.","helpful",["shy","brave"]],["Priya makes a silly face, and her baby brother giggles.","funny",["honest","shy"]],["Lena climbs to the top of the tall slide, even though she is scared.","brave",["polite","gentle"]],["Omar finds a wallet and gives it back.","honest",["funny","shy"]],["Dev holds the baby bird with care.","gentle",["funny","brave"]],["Aiko waits for her turn and says excuse me.","polite",["funny","brave"]],["Max talks very quietly on his first day.","shy",["brave","funny"]],["Rosa hums a happy song as she walks.","cheerful",["shy","honest"]],["Sam waves to all the neighbours on his street.","friendly",["shy","brave"]],["Mia shares her lunch with a friend who forgot his.","kind",["shy","funny"]],
 ["Tane picks up toys to help his teacher.","helpful",["shy","funny"]],["Ama is always smiling, even on rainy days.","cheerful",["shy","honest"]],["Jin says, \"I broke the cup. I am sorry.\"","honest",["funny","shy"]],["Nora brushes her horse slowly and softly.","gentle",["funny","brave"]]];
const DESCW=["kind","funny","brave","helpful","gentle","honest","shy","friendly","polite","cheerful","happy","clever","tall","strong"];
const NOTDESC=["bench","train","street","skate","bakery","letter","clap","scooter","plate","market","fountain","race"];
const descQ=()=>{const r=Math.random();
  if(r<.75){const x=R(DESC);return mcQ(`${G4.box("Read",x[0])}Which word <b>describes</b> this person?`,x[1],x[2],`${x[0]} This person is <b>${x[1]}</b>.`,"What kind of person does this?",{say:x[0]})}
  if(r<.9){const w=R(DESCW);return mcQ(`Which word <b>describes a person</b>? <span style="color:var(--muted);font-size:15px">(tells what someone is like)</span>`,w,SAMPLE(NOTDESC,2),`<b>${w}</b> tells what a person is like.`,"Try each word in: My friend is ___.")}
  const w=R(NOTDESC);return mcQ(`Which word does <b>NOT</b> describe a person?`,w,SAMPLE(DESCW,2),`<b>${w}</b> does not tell what a person is like. Try it: My friend is ${w}? That does not make sense.`,"Try each word in: My friend is ___.")};

/* ================= READING: A FRIENDLY LETTER ================= */
const LTO=["Lena","Kai","Aiko","Omar","Priya","Ben","Rosa","Dev","Mia","Tane"];
const LTH=[["Thank you for the cake.","the cake 🎂"],["Thank you for the birthday card.","the birthday card 💌"],["Thank you for the red balloon.","the red balloon 🎈"],["Thank you for the scooter ride.","the scooter ride 🛴"],["Thank you for the chess game.","the chess game ♟️"],["Thank you for the sandwich.","the sandwich 🥪"]];
const LNEWS=[["I saw a snail in the rain.","a snail 🐌"],["I saw a train on the bridge.","a train 🚂"],["I saw a duck at the lake.","a duck 🦆"],["I saw a rainbow in the sky.","a rainbow 🌈"],["I saw a big snake at the zoo.","a big snake 🐍"],["I saw a sailboat on the lake.","a sailboat ⛵"]];
const LDAY=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
const LCL=["From,","Your friend,","Love,"];
const letterQ=()=>{const [to,fr]=SAMPLE(LTO,2),th=R(LTH),nw=R(LNEWS),dy=R(LDAY),cl=R(LCL);
  const doc=`<div class="realdoc" style="text-align:left;font-size:20px;line-height:1.7">Dear ${to},<br>${th[0]} ${nw[0]} Can you come and play on ${dy}?<br>${cl}<br>${fr}</div>`;
  const say=`Dear ${to}. ${th[0]} ${nw[0]} Can you come and play on ${dy}? ${cl} ${fr}.`;const k=Math.floor(Math.random()*6);
  if(k===0)return mcQ(`${doc}Who <b>wrote</b> this letter?`,fr,[to,R(LTO.filter(z=>z!==to&&z!==fr))],`The name at the end tells who wrote it: <b>${fr}</b>.`,"Look at the name at the very end.",{say});
  if(k===1)return mcQ(`${doc}Who is the letter <b>for</b>?`,to,[fr,R(LTO.filter(z=>z!==to&&z!==fr))],`It starts with <b>Dear ${to}</b>, so it is for ${to}.`,"Look at the name after Dear.",{say});
  if(k===2)return mcQ(`${doc}What is ${fr} saying thank you for?`,th[1],SAMPLE(LTH.filter(z=>z!==th),2).map(z=>z[1]),`${th[0]}`,"Find the words Thank you.",{say});
  if(k===3)return mcQ(`${doc}What did ${fr} see?`,nw[1],SAMPLE(LNEWS.filter(z=>z!==nw),2).map(z=>z[1]),`${nw[0]}`,"Find the words I saw.",{say});
  if(k===4)return mcQ(`${doc}Which day does ${fr} want to play?`,dy,SAMPLE(LDAY.filter(z=>z!==dy),2),`Can you come and play on <b>${dy}</b>?`,"Find the question in the letter.",{say});
  return mcQ(`${doc}Which part is the <b>greeting</b> (the hello part)?`,`Dear ${to},`,[cl,nw[0]],`A friendly letter starts with a greeting: <b>Dear ${to},</b>`,"The greeting is at the very top.",{say})};

/* ================= THINKING: BEING A GOOD FRIEND AND NEIGHBOUR ================= */
const FRT=[
 {q:"🧒 A new child is standing alone at recess. What can you do?",o:["Ask them to play with you","Laugh at them","Walk away"],a:"Ask them to play with you",why:"Asking them to play helps them feel welcome."},
 {q:"🖍️ Your friend forgot her crayons. What can you do?",o:["Share your crayons","Hide your crayons","Tell her to go away"],a:"Share your crayons",why:"Sharing is a kind thing to do."},
 {q:"⚽ You and a friend both want the same ball. What is fair?",o:["Take turns","Grab it and run","Throw it on the roof"],a:"Take turns",why:"Taking turns is fair for everyone."},
 {q:"😢 Your friend falls and hurts her knee. What can you say?",o:["Are you OK? I will get help.","Ha ha, you fell!","Get up fast!"],a:"Are you OK? I will get help.",why:"Kind words and getting help show you care."},
 {q:"💥 You break your friend's toy by mistake. What should you do?",o:["Say sorry and tell the truth","Hide it","Say someone else did it"],a:"Say sorry and tell the truth",why:"An honest friend says sorry."},
 {q:"👵 Your old neighbour has heavy bags. What can you do?",o:["Offer to help carry them","Run past","Laugh"],a:"Offer to help carry them",why:"Helpful neighbours make the street a nice place."},
 {q:"🗣️ A new friend speaks a different language. How can you play together?",o:["Use pictures and smiles","Stop playing","Shout loudly"],a:"Use pictures and smiles",why:"You can share a game without many words, like Sam and Lena."},
 {q:"😠 You feel very angry with a friend. What is the first step?",o:["Stop and take deep breaths","Push your friend","Yell at them"],a:"Stop and take deep breaths",why:"Deep breaths help you calm down first."},
 {q:"🎁 A friend gives you a gift. What do you say?",o:["Thank you!","Is that all?","I don't want it."],a:"Thank you!",why:"Saying thank you is polite."},
 {q:"🎂 It is your neighbour's birthday. What could you make?",o:["A card","A mess","A loud noise at night"],a:"A card",why:"A card is a kind way to say happy birthday."},
 {q:"🚸 Where is the safest place to cross the street?",o:["At the crosswalk","Between parked cars","In the middle of the road"],a:"At the crosswalk",why:"Cars should stop for people at a crosswalk."},
 {q:"🐕 A neighbour's dog is lost. What can you do?",o:["Tell a grown-up and look for posters","Chase the dog","Keep it a secret"],a:"Tell a grown-up and look for posters",why:"A grown-up can help get the dog home safely."},
 {q:"🗑️ You see trash on the sidewalk. What can a good neighbour do?",o:["Put it in the bin","Kick it","Throw more trash"],a:"Put it in the bin",why:"Good neighbours keep the street clean. Wash your hands after!"},
 {q:"🙊 A friend tells you a secret that someone may get hurt. What should you do?",o:["Tell a grown-up you trust","Tell no one ever","Laugh about it"],a:"Tell a grown-up you trust",why:"If someone could get hurt, a grown-up needs to know."},
 {q:"🎲 You lose a game. What does a good friend say?",o:["Good game!","You cheated!","I quit!"],a:"Good game!",why:"Saying good game shows you are a good sport."},
 {q:"🧑‍🤝‍🧑 Two friends want to play different games. What is a good plan?",o:["Play one game, then the other","Stop being friends","Nobody plays"],a:"Play one game, then the other",why:"Taking turns with games is fair."},
 {q:"📬 Which one do you need to mail a letter?",o:["An address and a stamp","A cake and a plate","A ball and a net"],a:"An address and a stamp",why:"The address tells where the letter goes. The stamp pays for it."},
 {q:"🙇 Aiko bows to her teacher. What does this mean?",o:["Hello","Go away","I am hungry"],a:"Hello",why:"In Japan, a bow can be a polite hello."},
 {q:"😶 Your friend is quiet and sad today. What can you do?",o:["Ask, \"Do you want to talk?\"","Tease them","Ignore them all day"],a:"Ask, \"Do you want to talk?\"",why:"Asking shows you care."},
 {q:"✋ Your friend is talking. What does a good listener do?",o:["Looks at them and listens","Talks at the same time","Walks away"],a:"Looks at them and listens",why:"Good listeners let their friends finish."},
 {q:"🧮 Sam has 6 pieces of chalk. He gives 2 to Lena. How many does Sam have now?",o:["4","8","3"],a:"4",why:"6 − 2 = 4."},
 {q:"🧮 Maya has 5 stickers. Omar gives her 3 more. How many stickers does Maya have?",o:["8","7","2"],a:"8",why:"5 + 3 = 8."},
 {q:"🧮 4 friends each bring 2 apples to share. How many apples are there in all?",o:["8","6","4"],a:"8",why:"2 + 2 + 2 + 2 = 8."},
 {q:"🧮 There are 10 cupcakes at the bake sale. Neighbours buy 7. How many are left?",o:["3","17","4"],a:"3",why:"10 − 7 = 3."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["friend","My friend is fun.","fr-ie-nd: i before e"],["neighbour","My neighbour waves to me.","neigh-bour: eigh says long a"],["greet","We greet our friends.","gr-ee-t: double e"],["share","We share the toys.","sh-are"],["gift","This gift is for you.","g-i-f-t"],["letter","I write a letter.","let-ter: double t"],["kind","Be kind to others.","k-i-n-d: the i says its name"],["funny","The joke is funny.","fun-ny: double n"],["brave","The girl is brave.","br-a-v-e: magic e"],["helpful","Thank you for being helpful.","help-ful: only one l at the end"],["gentle","Be gentle with the cat.","gen-tle: g says j"],["polite","It is polite to say please.","po-lite: magic e"],["street","I live on this street.","str-ee-t: double e"],["bakery","The bakery sells bread.","bak-er-y: bake + ery"],["library","We go to the library.","li-brar-y: say the r in the middle"],["cake","We eat cake.","c-a-k-e: magic e"],["plate","Put it on a plate.","pl-a-t-e: magic e"],["train","The train is fast.","tr-ai-n: ai says long a"],["race","Let us race!","r-a-c-e: c says s"],["skate","I can skate.","sk-a-t-e: magic e"]]),
 CHOOSE:null,
 DETAIL:[
  ["The New Neighbour","A new boy moved in next door. His name is Kofi. He has a big brown dog named Max.",[["What is the new boy's name?","Kofi",["Max","Sam"]],["Where did he move?","Next door",["To the moon","To a farm"]],["What is the dog's name?","Max",["Kofi","Pepper"]]]],
  ["The Bake Sale","On Saturday, our street had a bake sale. Lena sold cupcakes. The money helped fix the park swings.",[["When was the bake sale?","On Saturday",["On Monday","At night"]],["What did Lena sell?","Cupcakes",["Books","Kites"]],["What did the money help fix?","The park swings",["The train","The library"]]]],
  ["A Letter for Aiko","Dev wrote a letter to Aiko. He put it in an envelope. Then he put a stamp on it and mailed it.",[["Who wrote the letter?","Dev",["Aiko","Lena"]],["What did he put the letter in?","An envelope",["A box","A cake"]],["What did he put on the envelope?","A stamp",["A sticker","A leaf"]]]],
  ["At the Library","Mia and Ben go to the library after school. Mia picks a book about whales. Ben picks a book about trains.",[["When do they go to the library?","After school",["Before breakfast","At midnight"]],["What is Mia's book about?","Whales",["Trains","Snails"]],["What is Ben's book about?","Trains",["Whales","Cakes"]]]],
  ["The Snow Day","It snowed a lot on Maple Lane. Omar helped his neighbour shovel snow. She gave him hot cocoa.",[["What did Omar do?","Shovel snow",["Paint a fence","Bake a cake"]],["Who did Omar help?","His neighbour",["His teacher","His dog"]],["What did she give him?","Hot cocoa",["A scooter","A kite"]]]],
  ["Rock, Paper, Scissors","Aiko and her friend play rock, paper, scissors. Aiko shows rock. Her friend shows scissors.",[["What does Aiko show?","Rock",["Paper","Scissors"]],["What does her friend show?","Scissors",["Rock","Paper"]],["Who wins?","Aiko",["Her friend","No one"]]]],
  ["The Lost Kitten","Rosa lost her kitten, Pepper. Ben found Pepper under a bench. Rosa gave Ben a big thank you.",[["What did Rosa lose?","Her kitten",["Her bike","Her hat"]],["Where was Pepper?","Under a bench",["In a tree","At the lake"]],["Who found Pepper?","Ben",["Rosa","Max"]]]],
  ["Soccer at the Park","Every Sunday, the children play soccer at the park. Tane is the goalie. Priya scores two goals.",[["When do they play soccer?","Every Sunday",["Every Monday","Never"]],["Who is the goalie?","Tane",["Priya","Leo"]],["How many goals does Priya score?","Two",["Five","None"]]]],
  ["The Fountain","There is a fountain in our town. Water shoots up high. Birds like to splash in it.",[["Where is the fountain?","In our town",["In the sea","At school"]],["What does the water do?","Shoots up high",["Stays still","Turns to ice"]],["Who likes to splash in it?","Birds",["Fish","Cows"]]]],
  ["Lena Learns English","Lena is from Ukraine. She is learning English at school. Her friend Sam helps her learn new words.",[["Where is Lena from?","Ukraine",["Japan","Ghana"]],["What is she learning?","English",["Chess","Soccer"]],["Who helps her?","Her friend Sam",["Her dog","A baker"]]]],
  ["The Market","On Friday, Dad and I go to the market. We buy apples and corn. We say hi to the farmer.",[["When do they go?","On Friday",["On Sunday","Every night"]],["What do they buy?","Apples and corn",["Toys","Shoes"]],["Who do they say hi to?","The farmer",["The pilot","The dentist"]]]],
  ["Kite Day","Dev and his friends fly kites on the roof. Dev's kite is orange. It flies higher than the rest.",[["Where do they fly kites?","On the roof",["In the kitchen","In a car"]],["What colour is Dev's kite?","Orange",["Blue","Green"]],["Whose kite flies highest?","Dev's kite",["His dad's","No one's"]]]]
 ],
 MAIN:[
  ["Friends share. Friends help. Friends play together.","Friends do many nice things together.",["Friends play.","Toys are fun."]],
  ["A bakery sells bread. A market sells fruit. A library lends books.","A neighbourhood has many useful places.",["Bread is yummy.","Books have pages."]],
  ["Sam waves to Lena. He shares his chalk. They draw together.","Sam makes friends with Lena.",["Chalk is white.","Sam waves."]],
  ["The mail carrier brings letters. The crossing guard helps us cross. The firefighter keeps us safe.","Many helpers work in our neighbourhood.",["Letters come in the mail.","Fires are hot."]],
  ["Stop and breathe. Talk and listen. Make a plan and try it.","These are steps to fix a small problem.",["Breathing is easy.","Plans are fun."]],
  ["Aiko bows. Dev says namaste. Tane gives a hongi.","Children greet people in different ways.",["Aiko lives in Japan.","Noses are small."]],
  ["Omar shovels snow for his neighbour. He carries her bags. He walks her dog.","Omar is a helpful neighbour.",["Snow is cold.","Dogs like walks."]],
  ["We sell cookies. We sell cupcakes. The money helps our park.","The bake sale raises money for the park.",["Cupcakes are sweet.","Parks have trees."]],
  ["I write Dear and a name. I write my news. I write From and my name.","These are the parts of a friendly letter.",["Names have capitals.","News is fun."]],
  ["Zoe tells jokes. She makes silly faces. Everyone laughs with her.","Zoe is a funny friend.",["Faces are round.","Jokes are short."]],
  ["Lena speaks Ukrainian. Aiko speaks Japanese. Sam speaks English.","Friends can speak different languages.",["Sam is seven.","English has letters."]],
  ["We play soccer. We play chess. We play tag.","Friends play many kinds of games.",["Chess has a king.","Tag is fast."]],
  ["Dogs must be on a leash. Trash goes in the bin. Take turns on the swings.","These are the rules for the park.",["Dogs bark.","Swings go high."]],
  ["Kofi moved in next door. He has a big dog. He is friendly.","Kofi is our new neighbour.",["Dogs are big.","Doors open."]],
  ["Ana tells the truth. She found a lost toy and gave it back. She says sorry when she is wrong.","Ana is an honest friend.",["Toys get lost.","Ana says sorry."]],
  ["Mia lives in an apartment. Her home is on the fifth floor. She can see the whole street.","Mia lives high up in an apartment.",["Streets are long.","Floors are flat."]],
  ["Cake, plate and wave have a_e. Rain and train have ai. Day and play have ay.","Long a can be spelled in different ways.",["Cake is sweet.","Trains are long."]],
  ["Ama claps. She jumps. She puts one foot out.","Ama is playing the game ampe.",["Feet are fast.","Ama has shoes."]],
  ["We wait at the crosswalk. We look both ways. Then we walk across.","This is how to cross the street safely.",["Cars are loud.","We look."]],
  ["Dev and Lena write letters. Dev lives in India. Lena lives in Canada.","Dev and Lena are friends who live far apart.",["India is big.","Letters are paper."]],
  ["Grandpa smiles a lot. He sings in the garden. He says good morning to everyone.","Grandpa is a cheerful neighbour.",["Gardens have flowers.","Mornings are early."]],
  ["Maya and Omar both wanted the ball. They talked about it. Now they play catch together.","Maya and Omar solved their problem.",["Balls are round.","Maya talked."]],
  ["The new girl is shy. Sam says hi. Soon she smiles and plays.","Sam helps a shy girl feel welcome.",["Girls smile.","Sam says hi."]],
  ["Pepper is lost. Rosa makes a poster. Neighbours help her look.","Neighbours help Rosa find her lost kitten.",["Posters have words.","Rosa makes a poster."]]
 ],
 FACTS:["A bakery sells bread.","A library has books.","A mail carrier brings letters.","Japan is a country.","Ghana is a country in Africa.","New Zealand is a country.","Canada is a country.","People in India often say namaste.","A scooter has wheels.","A plate is flat.","A train runs on a track.","Snow is cold.","A week has seven days.","The word cake has the long a sound.","Rain is water that falls from clouds.","A fountain has water.","A crosswalk has stripes.","Chess has a king and a queen.","Soccer is played with a ball.","A balloon can hold air.","An envelope can hold a letter.","Ukraine is a country.","Five plus three is eight.","Rock beats scissors in rock, paper, scissors.","A bench is a seat."],
 OPIN:["Cake is the best food.","Soccer is more fun than chess.","Rainy days are boring.","My street is the nicest street.","Red balloons are the prettiest.","Scooters are better than bikes.","The bakery smells the best.","Chess is too hard.","Saturday is the best day.","Letters are more fun than phone calls.","Funny friends are the best friends.","The library is the coolest place in town.","Sandwiches are yummy.","Trains are more exciting than buses.","Snails are cute.","Skating is the most fun.","Our park is the best park.","Cupcakes are better than cookies.","Clapping games are silly.","Big dogs are better than small dogs.","Winter is the best season.","Japanese is the most beautiful language.","Kites are the best toys.","Fountains are pretty.","Everyone should love chess."],
 SEQ:[["Write the letter","Put it in an envelope","Put on a stamp","Put it in the mailbox"],["Stop and breathe","Talk and listen","Think of a plan","Try the plan"],["The truck stops on Maple Lane","Sam sees Lena","Sam shares his chalk","Lena and Sam become friends"],["Wait at the crosswalk","Look both ways","Walk across","Get to the other side"],["Mix the cake","Bake the cake","Let it cool","Put it on a plate"],["Rosa loses Pepper","Rosa makes a poster","Ben finds Pepper","Rosa says thank you"],["Blow up the balloon","Tie the end","Add a string","Give it to a friend"],["Put on a helmet","Get on the scooter","Push with your foot","Ride to the park"],["Clap and jump","Land on the ground","Put one foot out","See who gets a point"],["Knock on the door","Say hello","Give the gift","Wave goodbye"],["Make a sandwich","Put it on a plate","Share it with a friend","Eat it together"]],
 CE:[["It was raining, so we played inside.","it was raining","we played inside"],["Sam shared his chalk, so Lena smiled.","Sam shared his chalk","Lena smiled"],["Maya pulled the ball, so Omar was upset.","Maya pulled the ball","Omar was upset"],["Rosa lost her kitten, so she made a poster.","Rosa lost her kitten","she made a poster"],["It snowed a lot, so Omar helped shovel.","it snowed a lot","Omar helped shovel"],["Zoe told a joke, so we all laughed.","Zoe told a joke","we all laughed"],["The rain fell, so the chalk pictures washed away.","the rain fell","the chalk pictures washed away"],["Ben found the kitten, so Rosa was happy.","Ben found the kitten","Rosa was happy"],["Lena is learning English, so Sam helps her.","Lena is learning English","Sam helps her"],["The light was red, so we waited.","the light was red","we waited"],["The cake was hot, so we let it cool.","the cake was hot","we let it cool"],["I forgot my lunch, so my friend shared hers.","I forgot my lunch","my friend shared hers"],["The balloon popped, so the baby cried.","the balloon popped","the baby cried"],["It was windy, so Dev flew his kite.","it was windy","Dev flew his kite"],["Kofi said sorry, so we were friends again.","Kofi said sorry","we were friends again"],["The bakery sold all its bread, so it closed early.","the bakery sold all its bread","it closed early"],["Mia was shy, so Ana asked her to play.","Mia was shy","Ana asked her to play"],["We took turns, so everyone had fun.","we took turns","everyone had fun"],["The ice was thick, so we could skate.","the ice was thick","we could skate"],["I wrote a letter, so my cousin wrote back.","I wrote a letter","my cousin wrote back"]],
 CMP:[
  ["Sam and Lena both like to draw. Sam draws suns. Lena draws rainbows.","Both like to draw","Sam draws suns, but Lena draws rainbows",["Both draw cats","Lena draws suns"]],
  ["Aiko and Dev both greet people. Aiko bows. Dev says namaste.","Both greet people","Aiko bows, but Dev says namaste",["Both play rugby","Dev bows"]],
  ["A bakery and a market both sell food. A bakery sells bread. A market sells fruit.","Both sell food","A bakery sells bread, but a market sells fruit",["Both sell books","A bakery sells fruit"]],
  ["A letter and a card can both be mailed. A letter has many words. A card often has a picture.","Both can be mailed","A letter has many words, but a card often has a picture",["Both are eaten","A letter is a cake"]],
  ["Soccer and chess are both games. Soccer is played outside. Chess is played on a board.","Both are games","Soccer is played outside, but chess is played on a board",["Both use a big ball","Chess is played with a kick"]],
  ["A scooter and a bike both have wheels. A scooter has a board. A bike has pedals.","Both have wheels","A scooter has a board, but a bike has pedals",["Both have wings","A bike has a board"]],
  ["Rain and train both have ai. Rain falls from the sky. A train runs on a track.","Both have ai","Rain falls from the sky, but a train runs on a track",["Both are animals","A train falls from the sky"]],
  ["Kofi and Ben are both kind. Kofi is shy. Ben is very chatty.","Both are kind","Kofi is shy, but Ben is chatty",["Both are mean","Ben is shy"]],
  ["A house and an apartment are both homes. A house stands alone. An apartment is in a big building.","Both are homes","A house stands alone, but an apartment is in a big building",["Both are shops","A house is in a big building"]],
  ["Ama and Tane both play with friends. Ama plays ampe. Tane plays rugby.","Both play with friends","Ama plays ampe, but Tane plays rugby",["Both play chess","Tane plays ampe"]],
  ["A bench and a chair are both seats. A bench is long. A chair is for one person.","Both are seats","A bench is long, but a chair is for one person",["Both are beds","A chair is long"]],
  ["Cake and plate both have a_e. You eat a cake. You eat from a plate.","Both have a_e","You eat a cake, but you eat from a plate",["Both have ay","You eat a plate"]]
 ],
 GRP:{"describing words":["kind","funny","brave","gentle","polite"],"foods to share":["sandwich","cookie","apple","pizza","cupcake"],"places in a neighbourhood":["bakery","library","market","park","school"],"neighbourhood helpers":["baker","mail carrier","firefighter","crossing guard","librarian"],"things you can mail":["letter","card","postcard","parcel","envelope"],"games friends play":["soccer","chess","tag","hopscotch","catch"],"ways to say hello":["hello","hi","namaste","hola","pryvit"]},
 ANA:[["Hello is to hi as goodbye is to ___.","bye",["hi","hello"]],["Rain is to wet as snow is to ___.","cold",["hot","dry"]],["Baker is to bakery as librarian is to ___.","library",["market","pool"]],["Cake is to eat as book is to ___.","read",["bake","drink"]],["Happy is to sad as brave is to ___.","scared",["kind","funny"]],["Day is to night as up is to ___.","down",["top","high"]],["Letter is to envelope as foot is to ___.","shoe",["hat","glove"]],["Hand is to clap as foot is to ___.","kick",["sing","wave"]],["Train is to track as boat is to ___.","water",["road","sky"]],["Cat is to kitten as dog is to ___.","puppy",["calf","chick"]],["Bird is to nest as bee is to ___.","hive",["den","pond"]],["Cap is to cape as tap is to ___.","tape",["tip","top"]],["Plate is to food as cup is to ___.","drink",["chair","shoe"]],["Japan is to Aiko as India is to ___.","Dev",["Ama","Tane"]],["Hot is to cold as near is to ___.","far",["close","next"]],["Clap is to hands as nod is to ___.","head",["feet","knees"]],["Snail is to slow as rabbit is to ___.","fast",["tiny","wet"]],["Mail carrier is to letters as bus driver is to ___.","people",["cakes","fires"]],["Pen is to write as scissors is to ___.","cut",["sing","sleep"]],["Cheer is to cheerful as help is to ___.","helpful",["helps","helping"]],["Sun is to day as moon is to ___.","night",["morning","lunch"]],["Ran is to rain as pan is to ___.","pain",["pin","pen"]]],
 SENT:["Sam and Lena play with chalk.","I live on Maple Lane.","Aiko lives in Japan.","Dev flies kites in India.","My friend Omar is funny.","Ama plays ampe in Ghana.","Tane lives in New Zealand.","I wrote a letter to Kai.","Can Priya come to play?","Rosa lost her kitten.","Lena speaks Ukrainian.","I play soccer with Ben.","Mia and I share a sandwich.","Is Leo your neighbour?","We visit Grandma on Sunday.","Kofi and I race to the gate.","I live in Canada.","Maya and Omar take turns.","Do you know Max?","The bake sale is on Saturday."],
 ORDER:["We share our snacks.","My friend is kind.","The baker makes bread.","We wave to our neighbour.","The train is long.","She has a red kite.","We play in the rain.","The cake is on the plate.","He rides a scooter.","We race to the gate.","My neighbour has a dog.","The snail is slow.","They play soccer together.","We sit on the bench.","The fountain is wet.","Please share the chalk.","We skate on the pond.","The mail is here.","Friends help each other.","We clap and sing."],
 WP:[
  {q:"Write a sentence about your best friend.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Ff]riend","Uses the word friend"]],model:"My best friend is Kai."},
  {q:"Write a complete sentence: tell <b>who</b> and <b>what they do</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"Mia plays soccer."},
  {q:"Write a sentence about a neighbour.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Nn]eighbou?r","Uses the word neighbour"]],model:"My neighbour has a cat."},
  {q:"Write a sentence with a long a word, like cake, rain or play.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Cc]ake|[Rr]ain|[Pp]lay|[Tt]rain|[Dd]ay|[Ww]ave|[Gg]ame|[Pp]late|[Ss]nail|[Mm]ail|[Pp]aint|[Ss]kate|[Ll]ake|[Ss]tay|[Ww]ait|[Gg]ate|[Rr]ace|[Ss]ail|[Tt]ray|[Hh]ay|[Ss]ay|[Ww]ay|[Ss]ame|[Nn]ame|[Mm]ade|[Bb]ake|[Tt]oday|[Ss]nake|[Gg]rapes?)","Uses a long a word"]],model:"We play in the rain."},
  {q:"Write a sentence that describes a friend. Use a word like <b>kind</b>, <b>funny</b> or <b>brave</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b(kind|funny|brave|helpful|gentle|honest|shy|friendly|polite|cheerful)\\b","Uses a describing word"]],model:"My friend Zoe is funny."},
  {q:"Write a sentence about a place in your neighbourhood.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Bb]akery|[Ll]ibrary|[Mm]arket|[Pp]ark|[Ss]chool|[Ss]treet|[Ss]hop|[Ss]tore|[Pp]ool|[Ff]ountain|[Bb]ench|[Cc]rosswalk)","Names a place"]],model:"The library is near my home."},
  {q:"Write a sentence about how you share with a friend.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Ss]har(e|es|ed|ing)\\b","Uses share"]],model:"I share my crayons with Ben."},
  {q:"Write a sentence that starts with <b>We</b> and tells what you do.",checks:[CHK.end,CHK.w3,CHK.I,["^\\s*We\\b","Starts with We"]],model:"We skate on the pond."},
  {q:"Write a question to ask a new friend. End it with <b>?</b>",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"Do you like to play chess?"},
  {q:"Write a sentence with your name and the word <b>I</b>.",checks:[CHK.cap,CHK.end,CHK.I,CHK.name,["\\bI\\b","Uses I"]],model:"I am Leo."},
  {q:"Write a sentence about a game you play with friends.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Pp]lay","Uses play"]],model:"We play tag at the park."},
  {q:"Write a kind thing you can say to a sad friend.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"Do you want to play with me?"},
  {q:"Write a sentence about a helper in your neighbourhood.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Bb]aker|[Mm]ail|[Ff]irefighter|[Gg]uard|[Dd]river|[Ll]ibrarian|[Dd]octor|[Nn]urse|[Tt]eacher|[Ff]armer|[Vv]et|[Dd]entist|[Pp]olice)","Names a helper"]],model:"The baker makes bread."},
  {q:"Write a sentence about the rain. Use the long a word <b>rain</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Rr]ain","Uses rain"]],model:"The rain is cold."},
  {q:"Write a sentence that uses <b>and</b> to name two friends.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\band\\b","Uses and"]],model:"Sam and Lena draw with chalk."},
  {q:"Write a sentence about a child in another country.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\s[A-Z][a-z]+","Has a name with a capital letter"]],model:"Aiko lives in Japan."},
  {q:"Write a thank-you sentence for a gift.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Tt]hank","Says thank you"]],model:"Thank you for the red balloon."},
  {q:"Write a sentence about how you say hello.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Hh]ello|[Hh]i|[Ww]ave|[Bb]ow|[Nn]amaste|[Hh]ola)","Tells a way to say hello"]],model:"I wave and say hello."},
  {q:"Write a sentence with a describing word and a who: <b>The ___ girl ___.</b>",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Gg]irl|[Bb]oy|[Ff]riend|[Nn]eighbou?r)","Has a who"]],model:"The brave girl climbs the tree."},
  {q:"Write a sentence about something you make for a friend.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Mm]a(ke|kes|de)\\b","Uses make or made"]],model:"I made a card for my friend."}
 ],
 SYN:[["big","large"],["happy","glad"],["fast","quick"],["shut","close"],["start","begin"],["talk","speak"],["kind","nice"],["yell","shout"],["gift","present"],["end","finish"],["tired","sleepy"],["stone","rock"],["laugh","giggle"],["pick","choose"],["friend","pal"],["jump","leap"],["mad","angry"],["scared","afraid"],["street","road"],["tiny","small"]],
 OPP:[["up","down"],["in","out"],["hot","cold"],["wet","dry"],["fast","slow"],["happy","sad"],["day","night"],["full","empty"],["loud","quiet"],["push","pull"],["early","late"],["open","shut"],["near","far"],["clean","dirty"],["give","take"],["brave","scared"],["kind","mean"],["old","new"],["tall","short"],["come","go"]],
 COMP:[["mail","box"],["cross","walk"],["side","walk"],["neighbour","hood"],["rain","bow"],["rain","coat"],["sun","flower"],["sun","shine"],["snow","man"],["play","ground"],["birth","day"],["home","work"],["sand","box"],["foot","ball"],["pan","cake"],["sail","boat"],["butter","fly"],["gold","fish"],["star","fish"],["hand","shake"],["tooth","brush"]]
};
B.CHOOSE=G4.ch([["friend","frend","freind"],["neighbour","naybour","neihbour"],["greet","greit","grete"],["share","shair","shere"],["gift","gifft","guift"],["letter","leter","lettur"],["kind","kynd","kinde"],["funny","funy","funnie"],["brave","brayv","braiv"],["helpful","helpfull","helpfel"],["gentle","jentle","gentel"],["polite","pollite","polyte"],["street","streat","stret"],["bakery","bakary","baikery"],["library","libary","liberry"],["cake","caik","kake"],["plate","playt","plaet"],["train","trane","trayn"],["race","rase","raice"],["skate","skait","scate"]],B.SP);

const L={
 which:"Long a says its name: /ā/. It can be spelled <b>a_e</b> (c<b>a</b>k<b>e</b>), <b>ai</b> (r<b>ai</b>n) or <b>ay</b> (d<b>ay</b>). <b>ay</b> is usually at the end of a word.",
 pic:"Look at the picture and say its name slowly: 🚂 tr-ai-n. Then find the word that matches.",
 make:"Say the word slowly. Which letters spell the long a sound? 🎂 c-a-k-e uses a_e. 🌧️ r-ai-n uses ai. 🌞 d-ay uses ay.",
 short:"Short a sounds like 🐱 c<b>a</b>t. Long a says its name, like 🎂 c<b>a</b>ke. A magic e can change short a to long a: cap → cape.",
 listen:"Listen to the word. Is the long a in the middle (ai or a_e) or at the end (ay)? Example: tr-ai-n, pl-ay.",
 is:"A <b>complete sentence</b> tells <b>who</b> and <b>what they do</b>. <i>Mia waves hello.</i> Who? Mia. What does she do? Waves hello.",
 add:"If a sentence is missing a part, add it. <i>___ reads a book.</i> needs a who: <b>Leo</b> reads a book.",
 match:"Match the <b>who</b> to the <b>what they do</b>. <i>The baker</i> + <i>bakes bread</i> = The baker bakes bread.",
 desc:"<b>Describing words</b> tell what a person is like: <i>kind, funny, brave, helpful, shy</i>. Example: My friend is <b>funny</b>.",
 letter:"A friendly letter starts with a <b>greeting</b> (Dear Lena,), then tells news, and ends with a <b>closing</b> (From,) and a name.",
 frt:"Think: what would a kind, fair and safe friend or neighbour do?"
};
u.review=G4.MIX(csIs,csAdd,csMatch,laWhich,laShort,descQ,F.vocab(u.words));
u.cats=G4.std(u,{sets:["Making friends","Describing people","My neighbourhood","Fun around the world"],B,
 reading:[{id:"r_letter",t:"Read a friendly letter",learn:L.letter,gen:letterQ}],
 vocab:[{id:"v_desc",t:"Describing people: kind, funny, brave, helpful",learn:L.desc,gen:descQ}],
 grammar:[{id:"g_csis",t:"Is it a complete sentence?",learn:L.is,gen:csIs},{id:"g_csadd",t:"Add the missing part",learn:L.add,gen:csAdd},{id:"g_csmatch",t:"Match the who to the what",learn:L.match,gen:csMatch},{id:"g_mixed",t:"Mixed review: sentences, long a and describing words",learn:"Use what you learned in this unit.",gen:u.review}],
 spelling:[{id:"s_lawhich",t:"Long a: which spelling (a_e, ai or ay)?",learn:L.which,gen:laWhich},{id:"s_lapic",t:"Long a: picture to word",learn:L.pic,gen:laPic},{id:"s_lamake",t:"Long a: complete the word",learn:L.make,gen:laMake},{id:"s_lashort",t:"Long a or short a?",learn:L.short,gen:laShort},{id:"s_lalisten",t:"Long a words: listen and write",learn:L.listen,gen:F.listen(LALIST)}],
 thinking:[{id:"t_friend",t:"Good friend, good neighbour: what should you do?",learn:L.frt,gen:F.bank(FRT)}]});
})();
