/* ===================== GRADE 3 · UNIT 10 · COUNTRIES AND CULTURES (original content, plus one public-domain poem and one retold folktale) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
const p=(q,a,o,why)=>({lv:"predict",q,o:[a].concat(o),a:[a],why});
const card=(pic,place,body,sign)=>`<div class="realdoc" style="text-align:left"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>${pic} ${place}</b><span style="border:2px dashed #b8962e;padding:2px 8px;border-radius:6px;font-size:14px">📮 stamp</span></div><br>${body}<br><br>${sign}</div>`;
UNITS.push({
id:"world", num:10, emoji:"🗺️🌍✈️", title:"Countries and Cultures", badge:"🌍 World Explorer",

stories:[
/* ---------- 1. POSTCARDS ---------- */
{title:"Postcards from Grandma Kiran", e:"📮", kind:"Postcards", pages:[
 {pic:"🧳✈️", text:"When Grandma Kiran retired, she decided to travel around the world. Before she left Toronto, she gave her grandchildren, Asha and Neel, a big world map. \"Every time I visit a new country, I'll send you a postcard,\" she promised. \"Put a pin on the map so you can follow my journey.\" A week later, the first postcard arrived.",
  qs:[f("Where does Grandma Kiran live?","Toronto",["Paris","Cairo"],"Before she left Toronto…"),
      f("What did she give her grandchildren?","A big world map",["A suitcase","A camera"],"She gave her grandchildren, Asha and Neel, a big world map."),
      t("Why did she ask them to put pins on the map?","So they could follow her journey",["To decorate their room","To practise sewing"],"\"Put a pin on the map so you can follow my journey.\"")]},
 {pic:"🦒🌍", text:card("🦒","Nairobi, Kenya","Jambo, Asha and Neel! That means hello in Swahili, one of Kenya's languages. Yesterday, our guide's jeep drove through the Maasai Mara. I saw giraffes, zebras and a lion's cub sleeping in the grass! Kenya is in East Africa, and the equator runs right through it. It's sunny and warm. Tonight, a Maasai family's village welcomed us with singing and dancing.","Love, Grandma Kiran"),
  qs:[f("What does 'Jambo' mean?","Hello",["Goodbye","Thank you"],"\"Jambo… That means hello in Swahili.\""),
      f("Which animals did Grandma see?","Giraffes, zebras and a lion's cub",["Penguins and seals","Kangaroos and koalas"],"I saw giraffes, zebras and a lion's cub."),
      f("Which part of Africa is Kenya in?","East Africa",["West Africa","South Africa"],"Kenya is in East Africa."),
      t("In 'a lion's cub', what does the 's show?","The cub belongs to the lion",["There are many lions","It is a question"],"The apostrophe s shows ownership: the lion's cub = the cub of the lion.")]},
 {pic:"🌸🏯", text:card("🌸","Kyoto, Japan","Konnichiwa! That means hello in Japanese. I'm in Kyoto, a city full of old temples and gardens. The cherry blossoms are blooming, and everything is pink! People have picnics under the trees. This custom is called hanami. I took a super-fast bullet train from Tokyo. It went almost 300 kilometres an hour! I ate noodles with chopsticks, and I only dropped a few.","Love, Grandma Kiran"),
  qs:[f("What is hanami?","Having picnics under the cherry blossoms",["A kind of noodle","A fast train"],"People have picnics under the trees. This custom is called hanami."),
      f("How did Grandma travel from Tokyo?","On a bullet train",["On a bicycle","On a camel"],"I took a super-fast bullet train from Tokyo."),
      t("Why are the cities Kyoto and Tokyo written with capital letters?","They are names of places (proper nouns)",["They are long words","They start sentences"],"Names of cities, countries and languages always start with a capital letter."),
      f("What language is 'Konnichiwa'?","Japanese",["Swahili","Spanish"],"\"Konnichiwa! That means hello in Japanese.\"")]},
 {pic:"🌮💀", text:card("🌮","Mexico City, Mexico","¡Hola! That's hello in Spanish. I arrived just in time for the Day of the Dead. It isn't scary at all! Families remember the people they love who have died. They build colourful altars with marigold flowers, candles, photos and their loved ones' favourite foods. I ate tacos with fresh salsa, and I tried hot chocolate with cinnamon. Mexico is south of the United States.","Love, Grandma Kiran"),
  qs:[f("What do families do on the Day of the Dead?","Remember loved ones who have died",["Go swimming","Have a race"],"Families remember the people they love who have died."),
      f("Which flowers are on the altars?","Marigolds",["Roses","Tulips"],"…colourful altars with marigold flowers…"),
      f("Which direction is Mexico from the United States?","South",["North","East"],"Mexico is south of the United States."),
      t("Why does Grandma say the day 'isn't scary at all'?","It is a loving celebration, not a scary one",["Because it is daytime","Because she is brave"],"It is about remembering and loving family.")]},
 {pic:"🐪🔺", text:card("🐪","Cairo, Egypt","Marhaba! That means hello in Arabic. Today I stood in front of the Great Pyramid of Giza. It's more than 4,500 years old! I rode a camel across the sand, and it was bumpy. Later, I sailed on the Nile River in a boat called a felucca. The Nile is one of the longest rivers in the world. Egypt is in the north-east corner of Africa.","Love, Grandma Kiran"),
  qs:[f("How old is the Great Pyramid?","More than 4,500 years old",["About 45 years old","Brand new"],"It's more than 4,500 years old!"),
      f("What is a felucca?","A kind of boat",["A camel","A pyramid"],"…sailed on the Nile River in a boat called a felucca."),
      f("What language is 'Marhaba'?","Arabic",["Japanese","Spanish"],"\"Marhaba! That means hello in Arabic.\""),
      t("Which continent is Egypt in?","Africa",["Asia","Europe"],"Egypt is in the north-east corner of Africa.")]},
 {pic:"🗺️📍", text:"The last postcard came from India, where Grandma Kiran was born. <i>\"Namaste! I'm in Kolkata, visiting my cousins for Durga Puja, a big festival with music, lights and beautiful statues. I'll be home next week!\"</i> Asha and Neel put the last pin on the map. Five pins now made a line around the world. When Grandma came home, she brought souvenirs: a Kenyan bracelet, Japanese chopsticks, a Mexican paper flower, an Egyptian scarf and Indian sweets. \"The world is big,\" she said, \"but people everywhere love their families, their food and a good celebration.\"",
  qs:[f("Where was Grandma Kiran born?","India",["Japan","Egypt"],"…from India, where Grandma Kiran was born."),
      f("What does 'Namaste' mean?","Hello (a respectful greeting in Hindi)",["Goodbye forever","Let's eat"],"Namaste is a greeting used in India."),
      t("How many countries did Grandma visit?","Five",["Two","Ten"],"Kenya, Japan, Mexico, Egypt and India: five pins."),
      t("What did Grandma learn about people around the world?","People everywhere love family, food and celebrations",["Everyone is exactly the same","People in other countries don't celebrate"],"\"People everywhere love their families, their food and a good celebration.\"")]}
], turn:{q:"If you could send a postcard from any country, which would you choose? Write two sentences about what you would see there.",model:"I would send a postcard from Brazil. I would see the Amazon rainforest and colourful parrots."}},

/* ---------- 2. STORY ---------- */
{title:"World Lunch Day", e:"🍲", kind:"Story", pages:[
 {pic:"🏫🍽️", text:"Ms. Chen had an exciting announcement. \"On Friday, we will have World Lunch Day. Please bring a dish that your family loves, and tell us where it comes from.\" The class buzzed with excitement. Leo frowned. \"My family is from Canada,\" he said. \"We just eat normal food.\" Ms. Chen smiled. \"Every family's food has a story, Leo. Ask your parents.\"",
  qs:[f("When is World Lunch Day?","Friday",["Monday","Sunday"],"\"On Friday, we will have World Lunch Day.\""),
      t("Why did Leo frown?","He thought his family's food wasn't special",["He was hungry","He didn't like Ms. Chen"],"\"We just eat normal food.\""),
      p("What do you think Leo will find out from his parents?","His family's food has an interesting story too",["His family doesn't eat","He has no family"],"Ms. Chen said every family's food has a story.")]},
 {pic:"🥟🥘", text:"On Friday, the tables were full. Ada brought jollof rice, a spicy tomato rice from Nigeria. Wei brought dumplings from China, folded like little purses. Yuki brought onigiri from Japan. Mia's grandma made samosas, crispy pastries filled with spiced potatoes, from India. Sofia brought pastéis de nata, small custard tarts from Portugal. The classroom smelled amazing.",
  qs:[f("What did Ada bring?","Jollof rice from Nigeria",["Dumplings from China","Samosas from India"],"Ada brought jollof rice, a spicy tomato rice from Nigeria."),
      f("What are pastéis de nata?","Small custard tarts from Portugal",["Spicy rice","Folded dumplings"],"…pastéis de nata, small custard tarts from Portugal."),
      t("In 'Mia's grandma', who does the grandma belong to?","Mia",["Leo","Ada"],"Mia's grandma = the grandma of Mia.")]},
 {pic:"🥞🍁", text:"Leo carried a big plate covered with a towel. \"I asked my dad,\" he said shyly. \"My great-great-grandparents came from Poland and Ukraine more than a hundred years ago. They brought this recipe.\" He lifted the towel. \"Pierogi! Dumplings filled with potato and cheese. And this,\" he added, pointing to a small bottle, \"is maple syrup from my uncle's farm in Quebec, for dessert pancakes.\"",
  qs:[f("Where did Leo's great-great-grandparents come from?","Poland and Ukraine",["Nigeria","Japan"],"…came from Poland and Ukraine more than a hundred years ago."),
      f("What are pierogi filled with?","Potato and cheese",["Chocolate","Rice and fish"],"Dumplings filled with potato and cheese."),
      f("Where is the maple syrup from?","His uncle's farm in Quebec",["A shop in Japan","His school"],"…maple syrup from my uncle's farm in Quebec."),
      t("What did Leo discover?","His family's food has a history too",["He doesn't like pierogi","Canada has no food"],"His family's recipe travelled from Europe a long time ago.")]},
 {pic:"🧭🌎", text:"Ms. Chen pinned a world map to the board. Each child put a sticker on the country their dish came from. Nigeria and Kenya were in Africa. China, Japan and India were in Asia. Poland, Ukraine and Portugal were in Europe. Canada was in North America. \"Look,\" said Ms. Chen. \"Our class lunch covers four continents!\"",
  qs:[f("Which continent are China, Japan and India in?","Asia",["Europe","Africa"],"China, Japan and India were in Asia."),
      f("How many continents did the lunch cover?","Four",["Two","Seven"],"\"Our class lunch covers four continents!\""),
      t("Which continent is Portugal in?","Europe",["Asia","North America"],"Poland, Ukraine and Portugal were in Europe.")]},
 {pic:"😋🤝", text:"Everyone tried a little of everything. Wei loved the samosas. Ada asked for Leo's recipe. Leo had three of Sofia's custard tarts! Then each child taught the class how to say \"thank you\" in their family's language: <i>asante</i> (Swahili), <i>xièxie</i> (Mandarin), <i>arigatō</i> (Japanese), <i>dhanyavaad</i> (Hindi), <i>obrigado</i> (Portuguese) and <i>dziękuję</i> (Polish). Leo grinned. \"I thought my food was normal. Now I know every family's food has a story, even mine.\"",
  qs:[f("What does 'obrigado' mean?","Thank you in Portuguese",["Hello in Japanese","Goodbye in Swahili"],"…obrigado (Portuguese)…"),
      f("Whose recipe did Ada ask for?","Leo's",["Wei's","Yuki's"],"Ada asked for Leo's recipe."),
      t("What is the message of this story?","Every family's food and culture has a special story",["Only some families are interesting","Lunch is boring"],"\"Every family's food has a story, even mine.\""),
      t("How did Leo's feelings change?","From unsure to proud of his family's story",["From happy to angry","He didn't change"],"At first he thought his food was 'normal'. Then he felt proud.")]}
], turn:{q:"What dish does your family love? Where does it come from? Write two or three sentences.",model:"My family loves biryani. It comes from India. My mom makes it with rice, chicken and lots of spices."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"Our World: Continents and Oceans", e:"🌍", kind:"Fact text", pages:[
 {pic:"🌍🧭", text:"Our planet has seven big areas of land called <b>continents</b>: Asia, Africa, North America, South America, Antarctica, Europe and Australia (sometimes called Oceania). <b>Asia</b> is the biggest continent, and it has the most people. <b>Australia</b> is the smallest. Each continent has many countries, except Antarctica, which has no countries at all, only scientists who visit to study the ice.",
  qs:[f("How many continents are there?","Seven",["Five","Ten"],"Our planet has seven big areas of land called continents."),
      f("Which is the biggest continent?","Asia",["Africa","Australia"],"Asia is the biggest continent."),
      t("Why does Antarctica have no countries?","Nobody lives there all the time; only scientists visit",["It is too small","It is underwater"],"…only scientists who visit to study the ice.")]},
 {pic:"🌊🐋", text:"Between the continents are five great <b>oceans</b>: the Pacific, the Atlantic, the Indian, the Arctic and the Southern Ocean. The Pacific is the biggest and deepest. The Atlantic is between the Americas and Europe and Africa. Oceans cover about seventy out of every one hundred parts of the Earth's surface. That's why the Earth looks blue from space!",
  qs:[f("How many oceans are there?","Five",["Seven","Two"],"…five great oceans."),
      f("Which ocean is between the Americas and Europe and Africa?","The Atlantic",["The Pacific","The Arctic"],"The Atlantic is between the Americas and Europe and Africa."),
      t("Why does the Earth look blue from space?","Most of its surface is ocean",["The sky paints it","The land is blue"],"Oceans cover about seventy out of every one hundred parts of the Earth's surface.")]},
 {pic:"🧭⬆️", text:"To find our way, we use four main directions: <b>north</b>, <b>south</b>, <b>east</b> and <b>west</b>. A <b>compass</b> has a needle that always points north. On most maps, north is at the top, south is at the bottom, east is on the right and west is on the left. The sun rises in the east and sets in the west. Here's a trick to remember the order clockwise: <b>N</b>ever <b>E</b>at <b>S</b>oggy <b>W</b>affles!",
  qs:[f("Where is north on most maps?","At the top",["At the bottom","On the left"],"On most maps, north is at the top."),
      f("Where does the sun rise?","In the east",["In the west","In the north"],"The sun rises in the east."),
      f("What does 'Never Eat Soggy Waffles' help you remember?","North, East, South, West",["The planets","The oceans"],"Never Eat Soggy Waffles = N, E, S, W."),
      t("On a map, if you move to the right, which direction are you going?","East",["West","South"],"East is on the right.")]},
 {pic:"🟰🌡️", text:"The <b>equator</b> is an imaginary line around the middle of the Earth. Places near the equator, like Kenya and Brazil, are hot all year. The part of the Earth above the equator is the Northern Hemisphere, and the part below is the Southern Hemisphere. Seasons are opposite! When it is summer in Canada, it is winter in Australia and Argentina.",
  qs:[f("What is the equator?","An imaginary line around the middle of the Earth",["A real fence","A river"],"The equator is an imaginary line around the middle of the Earth."),
      f("What are places near the equator like?","Hot all year",["Snowy all year","Dark all year"],"Places near the equator… are hot all year."),
      t("It is July and summer in Toronto. What season is it in Australia?","Winter",["Summer","Spring"],"Seasons are opposite in the two hemispheres.")]},
 {pic:"🏙️🚩", text:"There are about 195 countries in the world. Each country has its own <b>flag</b>, its own <b>capital city</b> and its own government. Ottawa is the capital of Canada, New Delhi is the capital of India, and Tokyo is the capital of Japan. Some countries are huge, like Russia and Canada, the two largest. Others are tiny, like Vatican City, which is smaller than many city parks!",
  qs:[f("What is the capital of Canada?","Ottawa",["Toronto","Vancouver"],"Ottawa is the capital of Canada."),
      f("What is the capital of India?","New Delhi",["Mumbai","Kolkata"],"New Delhi is the capital of India."),
      f("Which are the two largest countries?","Russia and Canada",["Japan and Egypt","Mexico and Peru"],"Some countries are huge, like Russia and Canada, the two largest."),
      t("What is the main idea of this whole text?","The world has continents, oceans and countries, and directions help us find our way",["Only Canada is important","Maps are boring"],"Each page teaches a different part of world geography.")]}
], turn:{q:"Which continent do you live on? Write two sentences about where you live using direction words.",model:"I live in North America. My city, Toronto, is north of Lake Ontario."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"Festivals Around the World", e:"🎉", kind:"Fact text", pages:[
 {pic:"🪔✨", text:"<b>Diwali</b> is the festival of lights, celebrated by Hindus, Sikhs, Jains and many others, in India and around the world. Families light small clay lamps called diyas, make colourful rangoli patterns, share sweets and wear new clothes. Diwali celebrates light winning over darkness and good winning over evil. It usually comes in October or November.",
  qs:[f("What is Diwali called?","The festival of lights",["The festival of snow","The festival of kites"],"Diwali is the festival of lights."),
      f("What are diyas?","Small clay lamps",["Sweets","New clothes"],"…small clay lamps called diyas…"),
      t("What does Diwali celebrate?","Light winning over darkness and good over evil",["The start of summer","A football match"],"Diwali celebrates light winning over darkness and good winning over evil.")]},
 {pic:"🧧🐉", text:"<b>Lunar New Year</b> is celebrated in China, Vietnam, Korea and by many families around the world. It starts on the new moon, between late January and February. People clean their homes to sweep away bad luck, give red envelopes with money for good luck, and watch dragon and lion dances. Each year is named after one of twelve animals, like the Rabbit, the Dragon or the Horse.",
  qs:[f("Why do people clean their homes?","To sweep away bad luck",["To find coins","Because guests are messy"],"People clean their homes to sweep away bad luck."),
      f("What colour are the envelopes for good luck?","Red",["Blue","Black"],"…give red envelopes with money for good luck."),
      f("How many animals are years named after?","Twelve",["Seven","Five"],"Each year is named after one of twelve animals.")]},
 {pic:"🌙🍬", text:"<b>Eid al-Fitr</b> is a happy celebration for Muslims around the world. It comes at the end of Ramadan, a month when many adults fast from sunrise to sunset. On Eid, families go to the mosque to pray, wear their best clothes, visit relatives, give gifts and share delicious food. Many families also give money or food to people in need. People greet each other by saying \"Eid Mubarak!\"",
  qs:[f("When does Eid al-Fitr come?","At the end of Ramadan",["At the start of winter","On every birthday"],"It comes at the end of Ramadan."),
      f("What do people say to greet each other on Eid?","\"Eid Mubarak!\"",["\"Happy Halloween!\"","\"Good night!\""],"People greet each other by saying \"Eid Mubarak!\""),
      t("Why do many families give food or money on Eid?","To help people in need",["To show off","Because it is the law"],"Many families also give money or food to people in need.")]},
 {pic:"🕎🎄", text:"In winter, many families celebrate festivals of light and joy. During <b>Hanukkah</b>, Jewish families light one more candle on a menorah each night for eight nights, eat foods fried in oil like potato latkes, and play a spinning-top game called dreidel. At <b>Christmas</b>, many Christian families decorate trees, sing carols, give gifts and share a big meal on December 25.",
  qs:[f("How many nights does Hanukkah last?","Eight",["Two","Twelve"],"…each night for eight nights."),
      f("What is a dreidel?","A spinning top",["A candle holder","A kind of cake"],"…a spinning-top game called dreidel."),
      f("On what date is Christmas?","December 25",["January 1","July 1"],"…on December 25.")]},
 {pic:"🎨🌈", text:"<b>Holi</b>, the festival of colours, welcomes spring in India and Nepal. People throw bright coloured powder and water at each other, laugh, dance and eat sweets. Everyone ends up covered in colour, and it doesn't matter who you are! Festivals like these remind us that people around the world celebrate family, kindness, light and new beginnings, each in their own special way.",
  qs:[f("What does Holi celebrate?","The coming of spring",["The end of school","Winter snow"],"Holi, the festival of colours, welcomes spring."),
      f("What do people throw during Holi?","Coloured powder and water",["Snowballs","Flowers only"],"People throw bright coloured powder and water at each other."),
      t("What is the main idea of this whole text?","People around the world celebrate in different but similar ways",["Only one festival matters","Festivals are only for children"],"Every page shows a festival with family, light, kindness or new beginnings.")]}
], turn:{q:"Write about a festival or celebration your family enjoys. What do you do, eat or wear?",model:"My family celebrates Eid. We wear new clothes, visit my aunt and eat sweet vermicelli."}},

/* ---------- 5. FOLKTALE ---------- */
{title:"Anansi and the Pot of Wisdom (a folktale from Ghana, retold)", e:"🕷️", kind:"Folktale", pages:[
 {pic:"🕷️🌳", text:"Long ago in West Africa, the Ashanti people told stories about Anansi, a clever spider who was sometimes too clever for his own good. One day, Anansi decided that he wanted to be the wisest creature in the world. So he went around collecting every bit of wisdom he could find and put it all into one big clay pot.",
  qs:[f("Who is Anansi?","A clever spider",["A lion","A farmer"],"…Anansi, a clever spider…"),
      f("Which people told stories about Anansi?","The Ashanti people of West Africa",["The Maasai of Kenya","The Inuit of Canada"],"…the Ashanti people told stories about Anansi."),
      f("Where did Anansi put the wisdom?","In a big clay pot",["In a box","Under his bed"],"…put it all into one big clay pot.")]},
 {pic:"🏺🔒", text:"\"Now I have all the wisdom in the world,\" Anansi said proudly, \"and I won't share it with anyone.\" He decided to hide the pot at the top of the tallest tree in the forest, where nobody could reach it. He tied the pot to his front with a vine and began to climb. But the big pot was in the way. He slipped and slid. He tried again and again, but he couldn't climb.",
  qs:[f("Where did Anansi want to hide the pot?","At the top of the tallest tree",["In a river","In a cave"],"…at the top of the tallest tree in the forest."),
      t("Why couldn't Anansi climb?","The pot on his front was in the way",["The tree was too slippery","He was too tired"],"He tied the pot to his front… But the big pot was in the way."),
      t("What does Anansi's plan show about him?","He was selfish with the wisdom",["He was generous","He was shy"],"\"I won't share it with anyone.\"")]},
 {pic:"👦🏾🕷️", text:"Anansi's young son, Ntikuma, was watching from below. \"Father,\" he called, \"why don't you tie the pot on your back? Then you can hold the tree with all your legs.\" Anansi stopped. It was such a simple idea, and he hadn't thought of it! He was so angry that someone else had wisdom he didn't have that he threw the pot down.",
  qs:[f("What was the name of Anansi's son?","Ntikuma",["Kwame","Tilly"],"Anansi's young son, Ntikuma…"),
      f("What did Ntikuma suggest?","Tying the pot on his back",["Throwing the pot away","Asking a bird to carry it"],"\"Why don't you tie the pot on your back?\""),
      p("What do you think will happen to the pot?","It will break, and the wisdom will spill out",["It will fly away","It will stay safe"],"Clay pots break when they fall.")]},
 {pic:"🏺💨", text:"The pot crashed onto a rock and broke into pieces. All the wisdom inside spilled out. Then a strong wind blew, and it carried the wisdom all over the world: across rivers, over mountains, to every village and every town. Bits of wisdom landed on every person, young and old.",
  qs:[f("What happened to the pot?","It broke on a rock",["It floated away","It got bigger"],"The pot crashed onto a rock and broke into pieces."),
      f("What carried the wisdom around the world?","A strong wind",["A river","A bird"],"…a strong wind blew, and it carried the wisdom all over the world."),
      t("Why does the story say wisdom landed on everyone?","To explain why everybody has some wisdom",["Because the wind was angry","Because the pot was magic"],"Folktales often explain how things came to be.")]},
 {pic:"🌍💡", text:"And that, the Ashanti say, is why no single person has all the wisdom in the world. Everyone has a little, and when we share what we know, we all become wiser. Even a small child can teach a grown-up something new! Stories about Anansi travelled with people to the Caribbean and the Americas, and they are still told today.",
  qs:[t("What is the lesson of this folktale?","Nobody has all the wisdom; we learn by sharing",["Spiders are bad climbers","Keep everything for yourself"],"Everyone has a little wisdom, and sharing makes us wiser."),
      f("Where did Anansi stories travel?","To the Caribbean and the Americas",["To the Moon","Only to Asia"],"Stories about Anansi travelled with people to the Caribbean and the Americas."),
      t("How does Ntikuma prove the lesson?","A small child had a wise idea his father didn't",["He climbed the tree","He was the fastest"],"\"Even a small child can teach a grown-up something new!\"")]}
], turn:{q:"Write about something you taught a grown-up, or something a younger child taught you.",model:"I taught my grandpa how to send a video message. He was very happy and called me his little teacher."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A town map and a departures board", e:"🗺️", kind:"Real-world text", pages:[
 {pic:"🗺️🧭", text:"Here is a map of Maple Town. North is at the top.<table class=\"realtbl\" style=\"text-align:center\"><tr><td>🌲 Forest</td><td>🏔️ Lookout Hill</td><td>🏰 Museum</td></tr><tr><td>🏫 School</td><td>⛲ Town Square</td><td>🏥 Hospital</td></tr><tr><td>🏊 Pool</td><td>🛒 Market</td><td>🚉 Train Station</td></tr></table><div style=\"text-align:center;font-weight:700;margin-top:6px\">⬆️ N &nbsp;·&nbsp; ➡️ E &nbsp;·&nbsp; ⬇️ S &nbsp;·&nbsp; ⬅️ W</div>",
  qs:[f("What is in the middle of the map?","The Town Square",["The Museum","The Pool"],"⛲ Town Square is in the centre."),
      t("What is directly north of the Town Square?","Lookout Hill",["The Market","The School"],"North is up. Above the Town Square is Lookout Hill."),
      t("What is directly east of the School?","The Town Square",["The Forest","The Pool"],"East is to the right. To the right of the School is the Town Square."),
      t("You are at the Market. Which direction is the Train Station?","East",["West","North"],"The Train Station is to the right (east) of the Market."),
      t("Which place is in the south-west corner?","The Pool",["The Museum","The Forest"],"South is the bottom and west is the left: the bottom-left corner is the Pool.")]},
 {pic:"✈️🕓", text:"Grandma Kiran checked the departures board at Toronto Pearson Airport.<table class=\"realtbl\"><tr><th>Time</th><th>Flight to</th><th>Country</th><th>Gate</th></tr><tr><td>14:05</td><td>Nairobi</td><td>Kenya</td><td>B12</td></tr><tr><td>14:40</td><td>Tokyo</td><td>Japan</td><td>C3</td></tr><tr><td>15:15</td><td>Mexico City</td><td>Mexico</td><td>A7</td></tr><tr><td>16:00</td><td>Cairo</td><td>Egypt</td><td>B4</td></tr><tr><td>18:30</td><td>Delhi</td><td>India</td><td>C9</td></tr></table><i>Please arrive at your gate 30 minutes before departure.</i>",
  qs:[f("Which gate is the flight to Tokyo?","C3",["B12","A7"],"14:40 · Tokyo · Japan · C3"),
      f("What time is the flight to Cairo?","16:00",["14:05","18:30"],"16:00 · Cairo · Egypt"),
      t("Which flight leaves first?","The flight to Nairobi",["The flight to Delhi","The flight to Cairo"],"14:05 is the earliest time."),
      t("The flight to Mexico City leaves at 15:15. By what time should you be at the gate?","14:45",["15:45","15:15"],"30 minutes before 15:15 is 14:45."),
      f("Which city is in Egypt?","Cairo",["Nairobi","Tokyo"],"Cairo · Egypt")]}
], turn:{q:"Write directions from your home to a place nearby (a park, a shop or your school). Use words like north, left, right and next to.",model:"Walk out of my front door and turn left. Go straight for two blocks. The park is next to the library."}}
],

poems:[
 {title:"Foreign Lands (by Robert Louis Stevenson, 1885)",
  lines:["Up into the cherry tree","Who should climb but little me?","I held the trunk with both my hands","And looked abroad on foreign lands.","","I saw the next door garden lie,","Adorned with flowers, before my eye,","And many pleasant places more","That I had never seen before.","","I saw the dimpling river pass","And be the sky's blue looking-glass;","The dusty roads go up and down","With people tramping in to town.","","If I could find a higher tree","Farther and farther I should see,","To where the grown-up river slips","Into the sea among the ships,","","To where the roads on either hand","Lead onward into fairy land,","Where all the children dine at five,","And all the playthings come alive."],
  qs:[f("What did the child climb?","A cherry tree",["A mountain","A ladder"],"\"Up into the cherry tree who should climb but little me?\""),
      t("What does 'foreign lands' mean in this poem?","Places the child had never seen before",["Only other countries","The child's bedroom"],"From the tree, the child sees \"pleasant places… that I had never seen before.\""),
      t("What does 'the sky's blue looking-glass' mean?","The river reflects the sky like a mirror",["The sky is made of glass","A blue window"],"A looking-glass is an old word for a mirror."),
      t("What does the child wish for?","A higher tree to see even farther",["To climb down","To go to sleep"],"\"If I could find a higher tree, farther and farther I should see.\""),
      f("Which word rhymes with 'tree'?","see",["ships","town"],"Tree and see end with the same sound.")]},
 {title:"Hello Around the World",
  lines:["In France they say bonjour with a smile,","In Spain it's hola, warm all the while.","In India, namaste with hands held tight,","In Japan, konnichiwa, polite and bright.","In Kenya, jambo rings out clear,","In China, nǐ hǎo, friendly and near.","So many words, but they all say the same:","\"Hello, my friend! What is your name?\""],
  qs:[f("How do people say hello in Spain?","Hola",["Bonjour","Jambo"],"\"In Spain it's hola.\""),
      f("In which country do people say 'jambo'?","Kenya",["Japan","France"],"\"In Kenya, jambo rings out clear.\""),
      t("What is the message of the last two lines?","Different words can share the same friendly meaning",["Everyone speaks French","Names are not important"],"\"So many words, but they all say the same.\""),
      f("Which word rhymes with 'tight'?","bright",["clear","same"],"Tight and bright end with the same sound.")]}
],

words:[
 /* geography */
 {w:"continent",e:"🌍",m:"one of the seven very large areas of land on Earth",ex:"Asia is the biggest continent.",fill:"Africa is a ___ with more than fifty countries."},
 {w:"country",e:"🇨🇦",m:"an area of land with its own government and flag",ex:"Canada is a very big country.",fill:"Japan is a ___ in Asia."},
 {w:"capital",e:"🏛️",m:"the city where a country's government is",ex:"Ottawa is the capital of Canada.",fill:"New Delhi is the ___ of India."},
 {w:"city",e:"🏙️",m:"a large, busy town where many people live",ex:"Tokyo is a huge city.",fill:"Toronto is the biggest ___ in Canada."},
 {w:"border",e:"🚧",m:"the line where one country ends and another begins",ex:"Canada and the United States share a long border.",fill:"We crossed the ___ into Mexico."},
 {w:"globe",e:"🌐",m:"a round model of the Earth",ex:"I spun the globe and pointed to India.",fill:"The ___ in our classroom spins around."},
 {w:"compass",e:"🧭",m:"a tool with a needle that always points north",ex:"The hikers used a compass to find their way.",fill:"The ___ needle pointed north."},
 {w:"equator",e:"🟰",m:"an imaginary line around the middle of the Earth",ex:"Kenya is on the equator.",fill:"Countries near the ___ are hot all year."},
 {w:"population",e:"👨‍👩‍👧‍👦",m:"the number of people who live in a place",ex:"India has a very large population.",fill:"The ___ of our town is ten thousand people."},
 {w:"flag",e:"🚩",m:"a piece of cloth with a design that stands for a country",ex:"The Canadian flag has a red maple leaf.",fill:"Each country has its own ___."},
 /* maps and directions */
 {w:"north",e:"⬆️",m:"the direction towards the top of most maps",ex:"The Arctic is far north of Toronto.",fill:"A compass needle always points ___."},
 {w:"south",e:"⬇️",m:"the direction opposite north",ex:"Mexico is south of the United States.",fill:"Birds fly ___ for the winter."},
 {w:"east",e:"➡️",m:"the direction where the sun rises",ex:"The sun rises in the east.",fill:"Japan is far to the ___ of India."},
 {w:"west",e:"⬅️",m:"the direction where the sun sets",ex:"The sun sets in the west.",fill:"Vancouver is in the ___ of Canada."},
 {w:"map",e:"🗺️",m:"a drawing that shows where places are",ex:"Grandma gave us a world map.",fill:"Look at the ___ to find the museum."},
 {w:"direction",e:"🧭",m:"the way something is going or pointing",ex:"Which direction is the station?",fill:"We walked in the wrong ___ and got lost."},
 {w:"route",e:"🛣️",m:"the way you take to get from one place to another",ex:"The bus took a long route through the city.",fill:"What is the quickest ___ to school?"},
 {w:"nearby",e:"📍",m:"not far away; close",ex:"There is a park nearby.",fill:"Is there a shop ___?"},
 {w:"landmark",e:"🗼",m:"a famous building or place that is easy to recognize",ex:"The CN Tower is a famous landmark in Toronto.",fill:"The pyramids are a famous ___ in Egypt."},
 {w:"symbol",e:"🔣",m:"a picture or sign that stands for something",ex:"On the map, a tree symbol shows a forest.",fill:"The maple leaf is a ___ of Canada."},
 /* culture */
 {w:"culture",e:"🎎",m:"the way of life, beliefs, arts and customs of a group of people",ex:"Food and music are part of a culture.",fill:"We learned about Japanese ___ at the museum."},
 {w:"custom",e:"🙏",m:"something people in a place usually do",ex:"Picnics under cherry trees are a Japanese custom.",fill:"It is a ___ to take off your shoes in some homes."},
 {w:"festival",e:"🎉",m:"a special time of celebration",ex:"Diwali is the festival of lights.",fill:"Holi is a colourful ___ in India."},
 {w:"language",e:"🗣️",m:"the words people use to speak and write",ex:"Swahili is a language spoken in Kenya.",fill:"How many ___s can you speak?"},
 {w:"greeting",e:"👋",m:"a word or action used to say hello",ex:"Namaste is a respectful greeting.",fill:"A handshake is a ___ in many countries."},
 {w:"costume",e:"👘",m:"special clothes worn for a festival, a show or a tradition",ex:"The dancers wore colourful costumes.",fill:"She wore a lion ___ for the dance."},
 {w:"recipe",e:"📝",m:"instructions for making a dish",ex:"Leo's family brought the pierogi recipe from Europe.",fill:"Grandma wrote down the ___ for samosas."},
 {w:"heritage",e:"🧬",m:"the traditions and history that come from your family and ancestors",ex:"Leo is proud of his Polish and Ukrainian heritage.",fill:"Learning your family's language is part of your ___."},
 {w:"community",e:"🏘️",m:"a group of people who live in the same area or share something",ex:"Our community has people from many countries.",fill:"The whole ___ came to the street festival."},
 {w:"ancestor",e:"👴",m:"a family member who lived a long time ago",ex:"My ancestors came from Ireland.",fill:"An ___ is someone in your family from long ago."},
 /* travel and describing */
 {w:"passport",e:"🛂",m:"an official book you need to travel to other countries",ex:"Grandma showed her passport at the airport.",fill:"You need a ___ to fly to another country."},
 {w:"luggage",e:"🧳",m:"the bags and suitcases you take on a trip",ex:"Our luggage was very heavy.",fill:"Put your ___ on the cart."},
 {w:"souvenir",e:"🎁",m:"something you buy or keep to remember a place",ex:"Grandma brought souvenirs from every country.",fill:"I bought a little Eiffel Tower as a ___."},
 {w:"tourist",e:"📸",m:"a person who visits a place on holiday",ex:"Many tourists visit the pyramids.",fill:"The ___ took photos of the castle."},
 {w:"foreign",e:"🌏",m:"from another country",ex:"Learning a foreign language is fun.",fill:"She speaks three ___ languages."},
 {w:"local",e:"🏡",m:"from the area where you live",ex:"We buy vegetables from local farmers.",fill:"The ___ library is open on Saturdays."},
 {w:"crowded",e:"🚇",m:"full of people",ex:"The market in Mexico City was crowded.",fill:"The train was so ___ that we had to stand."},
 {w:"traditional",e:"🪭",m:"done or made in the same way for a long time",ex:"They wore traditional clothes for the festival.",fill:"Pierogi are a ___ food in Poland."},
 {w:"delicious",e:"😋",m:"tasting very good",ex:"The samosas were delicious.",fill:"Mmm, this soup is ___!"},
 {w:"spicy",e:"🌶️",m:"having a strong, hot taste",ex:"Jollof rice can be spicy.",fill:"This curry is too ___ for me!"}
],

spelling:[
 {w:"world",s:"The world is big.",tip:"'or' sounds like 'ur': w-or-ld."},
 {w:"country",s:"Canada is a country.",tip:"'ou' sounds like 'u': c-ou-ntry."},
 {w:"city",s:"Tokyo is a big city.",tip:"c sounds like s."},
 {w:"north",s:"Go north.",tip:"'or' as in for."},
 {w:"south",s:"Birds fly south.",tip:"'ou' as in out."},
 {w:"east",s:"The sun rises in the east.",tip:"'ea' says long e."},
 {w:"west",s:"The sun sets in the west."},
 {w:"flag",s:"Wave the flag."},
 {w:"language",s:"I speak two languages.",tip:"lan-guage. The 'u' after g is easy to forget."},
 {w:"people",s:"Many people live here.",tip:"'eo' sounds like long e: p-eo-ple."},
 {w:"holiday",s:"We went on holiday.",tip:"holi + day."},
 {w:"festival",s:"Diwali is a festival.",tip:"fes-ti-val."},
 {w:"globe",s:"Spin the globe.",tip:"Magic e: gl-o-be."},
 {w:"capital",s:"Ottawa is the capital.",tip:"cap-i-tal."},
 {w:"culture",s:"Music is part of culture.",tip:"cul-ture."}
],

facts:[
 {e:"🌍",c:"There are seven continents.",t:true,x:"True! Asia, Africa, North America, South America, Antarctica, Europe and Australia."},
 {e:"🗣️",c:"There are about 7,000 languages spoken in the world.",t:true,x:"True! Some are spoken by millions of people and some by only a few hundred."},
 {e:"🍁",c:"Toronto is the capital of Canada.",t:false,x:"Not true! Ottawa is the capital of Canada. Toronto is the capital of Ontario."},
 {e:"🐧",c:"Antarctica has many countries.",t:false,x:"Not true! Antarctica has no countries. Only scientists live there for part of the year."},
 {e:"☀️",c:"When it is summer in Canada, it is winter in Australia.",t:true,x:"True! The Northern and Southern Hemispheres have opposite seasons."},
 {e:"🇨🇦",c:"Canada has two official languages, English and French.",t:true,x:"True! And many Indigenous languages are spoken there too."},
 {e:"🇮🇳",c:"India has more than 20 officially recognized languages.",t:true,x:"True! Hindi, Bengali, Tamil, Telugu, Marathi and many more."},
 {e:"🌊",c:"The Pacific is the biggest ocean.",t:true,x:"True! It is bigger than all the land on Earth put together."},
 {e:"🧭",c:"A compass needle always points south.",t:false,x:"Not true! A compass needle points north."},
 {e:"🏔️",c:"Mount Everest, the highest mountain, is in Asia.",t:true,x:"True! It is on the border of Nepal and China."},
 {e:"🦘",c:"Kangaroos live wild in Africa.",t:false,x:"Not true! Wild kangaroos live only in Australia."},
 {e:"🏞️",c:"The Nile is one of the longest rivers in the world.",t:true,x:"True! It flows through eleven countries in Africa."}
],

writing:[
 {e:"🌏",t:"A country I would love to visit",level:"Step 1 · Sentences",
  prompt:"Choose a country you would love to visit. Write at least 4 sentences: where it is (which continent), what language people speak, what you would see or eat, and why you want to go. Remember capital letters for countries, cities and languages!",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["\\b(Asia|Africa|Europe|North America|South America|Australia|Oceania|Antarctica)\\b","I named a continent with a capital letter"],["\\b(English|French|Spanish|Hindi|Bengali|Japanese|Swahili|Arabic|Portuguese|Mandarin|Chinese|Italian|German|Korean|Polish|Ukrainian|Urdu|Punjabi|Tamil|Russian|Greek|Turkish|Vietnamese|Tagalog)\\b","I named a language with a capital letter"],["\\bbecause\\b","I used because"]],
  starters:["I would love to visit ","It is in ","People there speak ","I would see ","I want to go because "],
  model:"I would love to visit Brazil. It is in South America. People there speak Portuguese. I would see the Amazon rainforest and colourful parrots, and I would taste delicious food. I want to go because I love animals and the rainforest has thousands of them."},
 {e:"🧭",t:"Giving directions",level:"Step 2 · Directions",
  prompt:"Write directions to help a visitor get from your school (or your home) to a place nearby. Write at least 5 sentences. Use direction words (north, south, east, west, left, right, straight, next to, across from) and order words (First, Then, Next, Finally).",
  minS:5,minWords:2,
  rx:[["\\b(First|Start)\\b","I used First (or Start)"],["\\b(Then|Next|After that)\\b","I used Then, Next or After that"],["\\b(Finally|At last)\\b","I used Finally"],["(\\b(north|south|east|west|left|right|straight|next to|across from|opposite|behind|between)\\b[\\s\\S]*){3}","I used at least 3 direction words"],["[.!?]\\s*$","I ended with a full stop"]],
  starters:["First, walk out of ","Then, turn left at ","Next, go straight ","The park is next to ","Finally, "],
  model:"First, walk out of the school's front door and turn left. Then, go straight along Maple Street for two blocks. Next, turn right at the big red mailbox and walk north. Cross the road carefully at the traffic lights. Finally, you will see the library on your left, next to the bakery and across from the park."},
 {e:"📮",t:"A postcard to a friend",level:"Step 3 · Postcard",
  prompt:"Imagine you are on a trip to another country. Write a postcard to a friend. Include a greeting (Dear …,), where you are, at least 4 sentences about what you have seen, eaten or learned, how you feel, and a closing with your name. Use at least one possessive (like Grandma's house or the city's market).",
  minS:4,minWords:2,
  rx:[["\\bDear\\s+[A-Z]\\w*,","I wrote a greeting (Dear …,)"],["\\b(I'm in|I am in|I'm visiting|I am visiting|Greetings from|Hello from)\\b","I said where I am"],["\\b[A-Z][a-z]+\\b[\\s\\S]*\\b[A-Z][a-z]+\\b","I used capital letters for places"],["\\b\\w+'s\\b|\\b\\w+s'\\s","I used a possessive ('s)"],["\\b(happy|excited|amazed|tired|wonderful|love|miss|fun)\\b","I told how I feel"],["(Your friend|Love|From|See you soon|Best wishes),\\s*\\n\\s*[A-Z]\\w*","I wrote a closing and my name"]],
  starters:["Dear ,\n","Greetings from ","Today I saw ","I ate ","I'm having a wonderful time! ","Your friend,\n"],
  model:"Dear Ava,\nGreetings from Rome, Italy! Today I saw the Colosseum, a huge ancient stadium. I ate the most delicious pizza in a tiny restaurant near my aunt's apartment. Tomorrow we're going to throw a coin into the Trevi Fountain because people say it means you will come back. Italians say ciao for hello and goodbye. I'm having a wonderful time, but I miss you!\n\nYour friend,\nNeel"}
]
});
})();
