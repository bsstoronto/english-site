/* ===================== GRADE 1 · UNIT 3 · ANIMALS ON THE FARM ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:1,id:"g1_farm",num:3,emoji:"🐷🐄🐔",title:"Animals on the Farm",short:"short i, plurals with -s, animal babies",badge:"🐷 Farm Friend",
stories:[
/* 1 PROBLEM AND HAPPY ENDING */
{title:"Where Is Pip?",e:"🐷",kind:"Story",pages:[
 {pic:"🐷🏡",text:"This is Pip. Pip is a little pig. He lives on a farm with Nina. Pip likes to dig in the mud. One day, Nina calls, “Pip! Pip!” But Pip does not come. Nina looks and looks. Where is Pip?",
  qs:[f("Who is Pip?","A little pig 🐷",["A big cow 🐄","A hen 🐔"],"Pip is a little pig."),
      t("How does Nina feel?","Worried 😟",["Happy 😀","Sleepy 😴"],"Pip does not come, so Nina is worried.")]},
 {pic:"🐄🐔",text:"Nina looks in the barn. She sees a big cow. “Moo!” says the cow. No Pip. Nina looks in the coop. She sees six hens. “Cluck!” say the hens. No Pip in the coop.",
  qs:[f("What does Nina see in the barn?","A big cow 🐄",["A pig 🐷","A duck 🦆"],"She sees a big cow."),
      f("How many hens are in the coop?","Six",["Two","Ten"],"She sees six hens.")]},
 {pic:"🦆👂",text:"Nina looks by the pond. She sees a duck and her ducklings. “Quack!” No Pip. Then Nina hears a little sound. “Oink, oink!” It comes from the big mud pit. Nina runs to look.",
  qs:[f("What sound does Nina hear?","Oink, oink!",["Moo!","Quack!"],"“Oink, oink!” It comes from the big mud pit."),
      p("What will Nina find in the mud?","Pip the pig 🐷",["A fish 🐟","A tractor 🚜"],"Pigs say oink, and Pip likes mud.")]},
 {pic:"🐷💛",text:"There is Pip! He is in the mud. He is wet and brown. Pip is happy. Nina laughs. “Silly Pip! You like to dig!” Nina gives Pip a big hug. Then she gives him a bath.",
  qs:[f("Where was Pip?","In the mud",["In the barn","In the coop"],"He is in the mud."),
      t("How does the story end?","Happily 😀",["Sadly 😢","Scarily 😱"],"Nina finds Pip and gives him a hug.")]}
],turn:{q:"Where would you look for a lost pet? Write one sentence.",model:"I would look under my bed."}},
/* 2 NON-FICTION */
{title:"What Do Farm Animals Give Us?",e:"🥛",kind:"Non-fiction",pages:[
 {pic:"🐄🥛",text:"Cows live on farms. A cow eats grass and hay. Farmers milk the cows every day. We drink the milk. Milk can be made into cheese, butter and yogurt. Goats give milk too.",
  qs:[f("What do cows eat?","Grass and hay 🌾",["Fish 🐟","Rocks 🪨"],"A cow eats grass and hay."),
      f("Which other animal gives milk?","Goats 🐐",["Ducks 🦆","Pigs 🐖"],"Goats give milk too.")]},
 {pic:"🐔🥚",text:"Hens live in a coop. A hen lays eggs in a nest. Some eggs are brown. Some eggs are white. Farmers pick up the eggs each day. A mother hen sits on her eggs to keep them warm.",
  qs:[f("What colours can eggs be?","Brown or white",["Red or purple","Black or orange"],"Some eggs are brown. Some eggs are white."),
      p("A mother hen sits on her eggs. What will happen next?","Chicks will hatch 🐣",["The eggs will fly","The eggs will turn into milk"],"Baby chicks hatch from warm eggs.")]},
 {pic:"🐑🧶",text:"Sheep have thick, woolly coats. In spring, a farmer cuts the wool off. This does not hurt the sheep. It is like a haircut! The wool grows back. We spin wool into yarn. Yarn makes warm hats and socks.",
  qs:[f("When does the farmer cut the wool?","In spring 🌷",["At night 🌙","Every hour ⏰"],"In spring, a farmer cuts the wool off."),
      t("Why is it good that the wool grows back?","The sheep can give wool again",["The sheep gets cold forever","The farmer gets sad"],"The wool grows back, so there is more next year.")]},
 {pic:"🐴🐝",text:"Some animals help in other ways. Horses can pull carts. Dogs help farmers move the sheep. Bees make honey and help plants grow. Farm animals help us a lot. We must be kind to them. They need food, water and a home.",
  qs:[f("What can horses pull?","Carts 🛒",["Boats ⛵","Planes ✈️"],"Horses can pull carts."),
      t("What do farm animals need from us?","Food, water and a home",["Toys and TV","Hats and socks"],"They need food, water and a home.")]}
],turn:{q:"Which gift from farm animals do you like best: milk, eggs or wool? Write one sentence.",model:"I like wool because it makes warm hats."}},
/* 3 PATTERNED TEXT */
{title:"I See a Farm",e:"👀",kind:"Pattern book",pages:[
 {pic:"🐷🐔🐄",text:"I see a pig. Can you see the pig? The pig can dig. I see a hen. Can you see the hen? The hen can peck. I see a cow. Can you see the cow? The cow can moo.",
  qs:[f("What can the pig do?","Dig 🕳️",["Fly 🕊️","Swim 🏊"],"The pig can dig."),
      f("What can the hen do?","Peck",["Moo","Dig"],"The hen can peck.")]},
 {pic:"🐎🦆🐑",text:"I see a horse. Can you see the horse? The horse can run fast. I see a duck. Can you see the duck? The duck can swim in the pond. I see a sheep. The sheep can say baa.",
  qs:[f("Where does the duck swim?","In the pond",["In the barn","In the mud"],"The duck can swim in the pond."),
      t("Which animal is fast in this story?","The horse 🐎",["The duck 🦆","The sheep 🐑"],"The horse can run fast.")]},
 {pic:"🐐🐤",text:"I see a kid. It is a baby goat! Can you see the kid? The kid can jump on a rock. I see a little chick. Can you see the chick? The chick can sit on the hay.",
  qs:[f("What is a kid in this story?","A baby goat 🐐",["A baby duck 🦆","A big cow 🐄"],"I see a kid. It is a baby goat!"),
      p("What might the next page show?","More farm animals",["A space rocket 🚀","A city bus 🚌"],"Every page shows farm animals.")]},
 {pic:"🌅😴",text:"I see the sun go down. The pig can sleep. The hen can sleep. The cow and the horse can sleep. The kid and the chick can sleep. Can you sleep too? Good night, farm!",
  qs:[f("What do the animals do at the end?","Sleep 😴",["Run 🏃","Swim 🏊"],"The pig can sleep. The hen can sleep."),
      t("Which words come again and again in this book?","I see",["Good night","Oink, oink"],"The book uses the pattern: I see a...")]}
],turn:{q:"Make your own page: I see a ___. The ___ can ___.",model:"I see a duck. The duck can swim."}},
/* 4 HOW-TO / SEQUENCE */
{title:"How to Feed the Hens",e:"🪣",kind:"How-to text",pages:[
 {pic:"🪣🐔",text:"Hens need food and water every day. You can help! Here is how to feed the hens. You need a bucket of hen food. You need a jug of clean water. Ask a grown-up to help you.",
  qs:[f("What do you need?","Hen food and water",["Mud and sticks","Hats and socks"],"You need a bucket of hen food and a jug of clean water."),
      t("Why should a grown-up help?","To keep you safe",["To eat the food","To sing a song"],"Grown-ups help keep children safe on a farm.")]},
 {pic:"🚪🐓",text:"First, open the gate to the coop. Walk in slowly and quietly. Hens can get scared. Next, fill the feeder with food. The hens will run to eat. Peck, peck, peck!",
  qs:[f("What do you do first?","Open the gate",["Pour the water","Pick up eggs"],"First, open the gate to the coop."),
      t("Why do you walk in slowly?","So the hens do not get scared",["So you can sleep","So it rains"],"Hens can get scared.")]},
 {pic:"💧🥚",text:"Then, pour fresh water into the dish. Hens drink a lot. Last, look in the nest boxes. Are there eggs? Pick them up gently. Put them in a basket. Do not drop them!",
  qs:[f("What do you do last?","Look for eggs 🥚",["Open the gate","Go to sleep"],"Last, look in the nest boxes."),
      p("What will happen if you drop an egg?","It will crack",["It will bounce","It will grow"],"Eggs are easy to break.")]},
 {pic:"🧼🙌",text:"When you are done, shut the gate. This keeps the hens safe from foxes. Then wash your hands with soap. Good job! The hens are fed and happy.",
  qs:[f("Why do you shut the gate?","To keep the hens safe from foxes",["To let the hens out","To keep the eggs warm"],"This keeps the hens safe from foxes."),
      f("What do you do after you shut the gate?","Wash your hands 🧼",["Open it again","Eat the hen food"],"Then wash your hands with soap.")]}
],turn:{q:"What job would you like to do on a farm? Write one sentence.",model:"I would like to brush the horses."}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Farms Around the World",e:"🌍",kind:"Children around the world",pages:[
 {pic:"🇻🇳🐃",text:"Hi! I am Linh. I live in Vietnam. My family grows rice in a paddy. A paddy is a field full of water. Our water buffalo is big and strong. It helps us pull the plough in the mud.",
  qs:[f("Where does Linh live?","Vietnam",["Canada","Nepal"],"I live in Vietnam."),
      f("Which animal helps Linh's family?","A water buffalo 🐃",["A horse 🐎","A duck 🦆"],"Our water buffalo is big and strong. It helps us pull the plough.")]},
 {pic:"🇳🇵🏔️",text:"Hi! I am Tenzin. I live high in the mountains of Nepal. My family keeps yaks. Yaks have long, thick hair. It keeps them warm in the snow. Yaks give us milk. They carry heavy bags up the hills.",
  qs:[f("What animals does Tenzin's family keep?","Yaks",["Pigs","Camels"],"My family keeps yaks."),
      t("Why do yaks have long, thick hair?","To stay warm in the cold",["To look pretty","To swim fast"],"It keeps them warm in the snow.")]},
 {pic:"🇦🇺🐑",text:"G'day! I am Ruby. I live on a sheep station in Australia. A sheep station is a very big sheep farm. We have lots and lots of sheep. My dog, Max, helps us move the sheep. I ride a horse to check on them.",
  qs:[f("What is a sheep station?","A very big sheep farm",["A train station","A small pond"],"A sheep station is a very big sheep farm."),
      p("Some sheep run off. What will Max do?","Help bring them back",["Sleep in the barn","Fly away"],"Max helps move the sheep.")]},
 {pic:"🇨🇦🐄",text:"Hi! I am Sam. I live on a dairy farm in Ontario, Canada. A dairy farm has cows for milk. In winter, our cows stay in a warm barn. Farms are not the same all over the world. But all farmers care for their animals.",
  qs:[f("What kind of farm does Sam live on?","A dairy farm (cows for milk)",["A rice farm","A yak farm"],"I live on a dairy farm in Ontario, Canada."),
      t("How are all the farms the same?","The farmers care for their animals",["They all grow rice","They all have yaks"],"All farmers care for their animals.")]}
],turn:{q:"Which farm would you like to visit? Write one sentence.",model:"I would like to visit Tenzin and the yaks."}},
/* 6 REAL-WORLD TEXT */
{title:"Real-world reading: A farm visit schedule and sign",e:"📋",kind:"Real-world text",pages:[
 {pic:"🌻📅",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🌻 SUNNY HILL FARM · Visit Day</b><table class=\"realtbl\"><tr><th>Time</th><th>What to do</th></tr><tr><td>🕙 10:00</td><td>🐔 Feed the hens</td></tr><tr><td>🕚 11:00</td><td>🐄 Meet the cows</td></tr><tr><td>🕛 12:00</td><td>🐴 Pony rides</td></tr><tr><td>🕐 1:00</td><td>🐑 Pet the lambs</td></tr><tr><td>🕑 2:00</td><td>🚜 Tractor ride</td></tr></table><i>Kids are free!</i></div>",
  qs:[f("What time can you feed the hens?","10:00",["2:00","12:00"],"🕙 10:00 · 🐔 Feed the hens"),
      f("What can you do at 1:00?","Pet the lambs 🐑",["Pony rides 🐴","Tractor ride 🚜"],"🕐 1:00 · 🐑 Pet the lambs")]},
 {pic:"⚠️🚪",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>⚠️ FARM RULES</b><br><br>🧼 Wash your hands.<br>🚪 Close the gates.<br>🚫 Do not feed the animals.<br>🚶 Walk. Do not run.<br>🤫 Be quiet near the animals.</div>",
  qs:[f("What must you do with the gates?","Close them 🚪",["Paint them","Climb them"],"🚪 Close the gates."),
      p("A boy runs past the pigs. What will the farmer say?","Please walk.",["Run faster!","Feed the pigs!"],"The rule says: Walk. Do not run.")]}
],turn:{q:"Write one rule for a farm visit.",model:"Be gentle with the animals."}}
],
poems:[
 {title:"Baa, Baa, Black Sheep (a traditional nursery rhyme, first printed in 1744)",
  lines:["Baa, baa, black sheep,","Have you any wool?","Yes, sir, yes, sir,","Three bags full;","One for the master,","And one for the dame,","And one for the little boy","Who lives down the lane."],
  qs:[f("What does the black sheep have?","Wool 🧶",["Milk 🥛","Eggs 🥚"],"“Have you any wool?” Sheep give us wool."),
      f("How many bags are full?","Three",["One","Ten"],"“Three bags full.”"),
      f("Which word rhymes with “wool”?","full",["sheep","lane"],"Wool and full end with the same sound.")]},
 {title:"Six Little Chicks",
  lines:["Six little chicks went out to play,","Peck, peck, peck in the yellow hay.","A big pink pig said, “Oink! Come in!”","A woolly lamb gave a baa and a grin.","The duck said, “Quack!” by the pond so wide,","The foal ran fast by its mother's side.","The cow said, “Moo,” as the sun went red,","And every animal went to bed."],
  qs:[f("How many chicks went out to play?","Six",["Two","Ten"],"“Six little chicks went out to play.”"),
      f("What did the pig say?","“Oink! Come in!”",["“Moo!”","“Quack!”"],"“A big pink pig said, Oink! Come in!”"),
      f("Which word rhymes with “play”?","hay",["pig","bed"],"Play and hay end with the same sound.")]}
],
words:[
 {w:"cow",e:"🐄",m:"a big farm animal that gives us milk",ex:"The cow eats grass in the field.",fill:"The ___ says moo."},
 {w:"pig",e:"🐷",m:"a pink farm animal with a curly tail",ex:"The pig rolls in the mud.",fill:"The ___ says oink."},
 {w:"hen",e:"🐔",m:"a mother chicken that lays eggs",ex:"The hen sits on her eggs.",fill:"The ___ lays an egg in the nest."},
 {w:"sheep",e:"🐑",m:"a farm animal with a thick woolly coat",ex:"The sheep says baa.",fill:"We get wool from a ___."},
 {w:"goat",e:"🐐",m:"a farm animal with horns and a little beard",ex:"The goat can climb on rocks.",fill:"The ___ has horns and a beard."},
 {w:"horse",e:"🐴",m:"a big, fast animal that people can ride",ex:"I ride the horse.",fill:"The ___ can run very fast."},
 {w:"duck",e:"🦆",m:"a bird that swims and says quack",ex:"The duck swims in the pond.",fill:"The ___ says quack."},
 {w:"donkey",e:"🫏",m:"an animal like a small horse with long ears",ex:"The donkey says hee-haw.",fill:"The ___ has long ears."},
 {w:"goose",e:"🪿",m:"a big white bird with a long neck",ex:"The goose honks at the gate.",fill:"The ___ has a long neck and says honk."},
 {w:"buffalo",e:"🐃",m:"a big, strong animal with long curved horns",ex:"The water buffalo helps in the rice field.",fill:"A water ___ pulls the plough in the paddy."},
 {w:"calf",e:"🐮",m:"the baby of a cow",ex:"The calf drinks milk from its mother.",fill:"A baby cow is a ___."},
 {w:"chick",e:"🐤",m:"the baby of a hen",ex:"The chick is little and yellow.",fill:"A baby hen is a ___."},
 {w:"lamb",e:"🐏",m:"the baby of a sheep",ex:"The lamb stays close to its mother.",fill:"A baby sheep is a ___."},
 {w:"piglet",e:"🐖",m:"the baby of a pig",ex:"The piglet plays in the mud.",fill:"A baby pig is a ___."},
 {w:"foal",e:"🐎",m:"the baby of a horse",ex:"The foal runs next to its mother.",fill:"A baby horse is a ___."},
 {w:"kid",e:"🐐",m:"the baby of a goat",ex:"The kid jumps on the rock.",fill:"A baby goat is a ___."},
 {w:"duckling",e:"🐥",m:"the baby of a duck",ex:"The duckling swims behind its mother.",fill:"A baby duck is a ___."},
 {w:"gosling",e:"🐣",m:"the baby of a goose",ex:"The gosling has soft grey fluff.",fill:"A baby goose is a ___."},
 {w:"wool",e:"🧶",m:"the soft, thick hair of a sheep",ex:"Grandma knits a hat with wool.",fill:"We make warm socks from ___."},
 {w:"feather",e:"🪶",m:"one of the soft parts that cover a bird",ex:"I found a white feather in the coop.",fill:"A bird has a ___ on its wing."},
 {w:"barn",e:"🏚️",m:"a big farm building for animals and hay",ex:"The cows sleep in the red barn.",fill:"The cows go into the ___ at night."},
 {w:"coop",e:"🛖",m:"a little house where hens live",ex:"The hens are in the coop.",fill:"The hens lay eggs in the ___."},
 {w:"pen",e:"🐖",m:"a small place with a fence for animals",ex:"The pigs sleep in a pen.",fill:"The farmer puts the lambs in a ___."},
 {w:"stable",e:"🐴",m:"a building where horses live and sleep",ex:"The horse rests in the stable.",fill:"The horse sleeps in a ___."},
 {w:"field",e:"🏞️",m:"a big, open piece of land with grass",ex:"The sheep eat grass in the field.",fill:"The cows walk in the green ___."},
 {w:"fence",e:"🚧",m:"a wall of wood or wire around a place",ex:"The fence keeps the goats in.",fill:"A ___ goes all around the farm."},
 {w:"gate",e:"🚪",m:"a door in a fence or wall",ex:"Please close the gate.",fill:"Open the ___ to go into the field."},
 {w:"hay",e:"🌾",m:"dry grass that farm animals eat",ex:"The horse eats hay.",fill:"In winter, cows eat dry ___."},
 {w:"tractor",e:"🚜",m:"a big farm machine that pulls things",ex:"The tractor pulls a big cart.",fill:"The farmer drives a ___."},
 {w:"bucket",e:"🪣",m:"a round pail for carrying water or food",ex:"I carry water in a bucket.",fill:"Fill the ___ with water."},
 {w:"moo",e:"🐮",m:"the sound a cow makes",ex:"The cow says moo.",fill:"“___!” says the big cow in the barn."},
 {w:"oink",e:"🐽",m:"the sound a pig makes",ex:"The pig says oink.",fill:"“___, ___!” says the pink pig."},
 {w:"baa",e:"🐑",m:"the sound a sheep makes",ex:"The lamb says baa.",fill:"“___!” says the sheep in the field."},
 {w:"neigh",e:"🐴",m:"the sound a horse makes",ex:"The horse says neigh.",fill:"“___!” says the horse in the stable."},
 {w:"cluck",e:"🐔",m:"the sound a hen makes",ex:"The hen says cluck.",fill:"“___, ___!” says the hen in the coop."},
 {w:"quack",e:"🦆",m:"the sound a duck makes",ex:"The duck says quack.",fill:"“___!” says the duck in the pond."},
 {w:"peck",e:"🐓",m:"to pick up food with a beak",ex:"The hens peck at the seeds.",fill:"Chicks ___ at seeds on the ground."},
 {w:"dig",e:"⛏️",m:"to make a hole in the ground",ex:"The pig likes to dig in the mud.",fill:"Dogs ___ holes in the yard."},
 {w:"muddy",e:"🟤",m:"covered in wet, sticky dirt",ex:"Pip is muddy after playing.",fill:"The pig is wet and ___."},
 {w:"woolly",e:"🐑",m:"covered in thick, soft wool",ex:"The lamb has a woolly coat.",fill:"Sheep have warm, ___ coats.",alt:["wooly"]}
],
spelling:[],
facts:[
 {e:"🐄",c:"Cows give us milk.",t:true,x:"True! Farmers milk cows every day."},
 {e:"🐓",c:"Roosters lay eggs.",t:false,x:"Not true! Hens lay eggs. A rooster is a boy chicken."},
 {e:"🐑",c:"We get wool from sheep.",t:true,x:"True! The wool is cut off, and it grows back."},
 {e:"🐴",c:"A baby horse is called a calf.",t:false,x:"Not true! A baby horse is a foal. A baby cow is a calf."},
 {e:"🐷",c:"Pigs roll in mud to stay cool.",t:true,x:"True! Pigs cannot sweat much, so cool mud helps them."},
 {e:"🐐",c:"A baby goat is called a kid.",t:true,x:"True! Kids love to jump and play."},
 {e:"🐣",c:"Chicks hatch from eggs.",t:true,x:"True! A mother hen keeps her eggs warm until the chicks hatch."},
 {e:"🦆",c:"Ducks cannot swim.",t:false,x:"Not true! Ducks have webbed feet that help them swim."},
 {e:"🐃",c:"Water buffalo help farmers in rice fields.",t:true,x:"True! In places like Vietnam, they pull ploughs in wet rice fields."},
 {e:"🏔️",c:"Yaks live in hot, sandy deserts.",t:false,x:"Not true! Yaks live high in cold mountains, like in Nepal."},
 {e:"🐎",c:"Horses can sleep standing up.",t:true,x:"True! Horses can doze on their feet. They lie down for deep sleep."},
 {e:"🌾",c:"Cows eat meat.",t:false,x:"Not true! Cows eat plants, like grass and hay."}
],
writing:[
 {e:"🐮",t:"My favourite farm animal",level:"Step 1 · Two sentences",
  prompt:"Write 2 sentences about your favourite farm animal. Start each sentence with a capital letter. End each one with a full stop.",
  minS:2,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Cc]ows?|[Pp]igs?|[Hh]ens?|[Ss]heep|[Gg]oats?|[Hh]orses?|[Dd]ucks?|[Dd]onkeys?|[Gg]oose|[Gg]eese|[Ll]ambs?|[Cc]hicks?|[Yy]aks?|[Bb]uffalo(es)?|[Rr]oosters?)\\b","I named a farm animal"]],
  starters:["I like the ___.","It says ___."],
  model:"I like the cow. It says moo."},
 {e:"🚜",t:"A day on the farm",level:"Step 2 · Three sentences",
  prompt:"Write 3 sentences about a day on a farm. What do you see? What do you do?",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Ff]arms?|[Bb]arns?|[Cc]oops?|[Pp]ens?|[Ff]ields?|[Tt]ractors?|[Hh]ay|[Ss]tables?|[Gg]ates?)\\b","I used a farm word"]],
  starters:["I go to the ___.","I see a ___.","I feed the ___."],
  model:"I go to the farm. I feed the hens in the coop. I see a big pig in the mud."},
 {e:"🐑",t:"All about a farm animal",level:"Step 3 · Animal page",
  prompt:"Write 3 or 4 sentences about one farm animal. Say what it looks like, what sound it makes and what its baby is called.",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["\\b([Cc]ows?|[Pp]igs?|[Hh]ens?|[Ss]heep|[Gg]oats?|[Hh]orses?|[Dd]ucks?|[Dd]onkeys?|[Gg]oose|[Gg]eese|[Yy]aks?|[Bb]uffalo(es)?)\\b","I named a farm animal"],["\\b([Mm]oo|[Oo]ink|[Bb]aa|[Nn]eigh|[Cc]luck|[Qq]uack|[Hh]onk|[Hh]ee-haw|[Mm]aa|says?)\\b","I told what sound it makes"],["\\b(calf|calves|chicks?|lambs?|piglets?|foals?|kids?|ducklings?|goslings?|baby|babies)\\b","I named its baby"]],
  starters:["A ___ lives on the farm.","It has ___.","It says ___.","Its baby is a ___."],
  model:"A sheep lives on the farm. It has a woolly coat. It says baa. Its baby is a lamb."}
]};
UNITS.push(u);

/* ================= PHONICS: SHORT i ================= */
const SI=[["pig","🐷"],["fish","🐟"],["six","6️⃣"],["lip","👄"],["zip","🤐"],["pin","📌"],["bin","🗑️"],["fin","🦈"],["hill","⛰️"],["milk","🥛"],["chick","🐤"],["mitt","🧤"],["kid","🐐"],["dig","⛏️"],["sit","🪑"],["swim","🏊"],["king","👑"],["ring","💍"],["gift","🎁"],["ship","🚢"],["wind","🌬️"],["kick","🦵"],["pink","🩷"],["sing","🎤"],["brick","🧱"]];
const NI=[["cat","🐱"],["hat","🎩"],["dog","🐶"],["sun","☀️"],["bus","🚌"],["bed","🛏️"],["hen","🐔"],["cup","☕"],["box","📦"],["kite","🪁"],["bike","🚲"],["five","5️⃣"],["nine","9️⃣"],["tie","👔"],["moon","🌙"],["cow","🐄"],["goat","🐐"],["duck","🦆"],["frog","🐸"],["bug","🐛"],["map","🗺️"],["van","🚐"],["web","🕸️"],["egg","🥚"],["ten","🔟"],["sock","🧦"]];
const lab=x=>`${x[1]} ${x[0]}`;
const shortI=()=>{const r=Math.random();
  if(r<.6){const a=R(SI.filter(x=>x[0]!=="pig"));const w=SAMPLE(NI,2);return mcQ(`Which word has the <b>short i</b> sound, like in 🐷 <b>pig</b>?`,lab(a),w.map(lab),`${lab(a)} has short i: <b>${a[0].replace("i","<u>i</u>")}</b>.`,"Say each word. Listen for /i/ in the middle, like in pig.",{say:"Which word has the short i sound, like in pig? "+[a].concat(w).map(x=>x[0]).join(", ")})}
  const yes=Math.random()<.5;const x=yes?R(SI):R(NI);return mcQ(`Does <b>${lab(x)}</b> have the <b>short i</b> sound, like in pig?`,yes?"Yes":"No",[yes?"No":"Yes"],yes?`Yes! <b>${x[0]}</b> has short i, like pig.`:`No. <b>${x[0]}</b> does not have short i like pig.`,"Say the word slowly. Do you hear /i/ like in pig?",{say:`Does ${x[0]} have the short i sound?`})};
const picWord=()=>{const a=R(SI);const w=SAMPLE(SI.filter(x=>x!==a),2).map(x=>x[0]);return mcQ(`<span style="font-size:56px">${a[1]}</span><br>Which word goes with the picture?`,a[0],w,`${a[1]} = <b>${a[0]}</b>`,"Say the picture's name. Then find the word that matches.")};
const CVC=[["pig","🐷"],["big",""],["dig","⛏️"],["wig",""],["fig",""],["jig",""],["sit","🪑"],["hit",""],["kit",""],["bit",""],["pit",""],["fit",""],["pin","📌"],["fin","🦈"],["bin","🗑️"],["tin",""],["win","🏆"],["lid",""],["kid","🐐"],["hid",""],["lip","👄"],["hip",""],["dip",""],["zip","🤐"],["rip",""],["sip",""],["six","6️⃣"],["mix",""],["fix","🔧"],["him",""],["rib",""],["bib",""]];
const makeW=()=>{const x=R(CVC),w=x[0];if(Math.random()<.5)return {type:"type",q:`🔤 Put <b>i</b> in the gap to make a word. Type the whole word:<br><b style="font-size:30px;letter-spacing:6px">${w[0]} _ ${w.slice(2)}</b> ${x[1]}`,a:[w],why:`${w[0]} + i + ${w.slice(2)} = <b>${w}</b>`,hint:`Say ${w[0]}… i… ${w.slice(2)}, then put them together.`};
  return {type:"type",q:`🔤 Blend the sounds. Type the word:<br><b style="font-size:30px">${w.split("").join(" - ")}</b> ${x[1]}`,a:[w],why:`${w.split("").join("-")} = <b>${w}</b>`,hint:"Say each sound, then say them fast together."}};
const FAM={"-ig":["pig","big","dig","wig","fig","jig","twig"],"-it":["sit","hit","kit","bit","pit","fit","lit"],"-in":["pin","fin","bin","tin","win","chin","grin","twin"]};
const rhymeI=()=>{const ks=Object.keys(FAM),k=R(ks),others=ks.filter(x=>x!==k);const r=Math.random();
  if(r<.5){const [a,b]=SAMPLE(FAM[k],2);return mcQ(`Which word <b>rhymes</b> with <b>${a}</b>?`,b,others.map(o=>R(FAM[o])),`<b>${a}</b> and <b>${b}</b> both end in <b>${k.slice(1)}</b>.`,`Rhyming words have the same end sound. Listen to the end of ${a}.`)}
  if(r<.8){const three=SAMPLE(FAM[k],3),o=R(FAM[R(others)]);return mcQ(`Which word does <b>NOT</b> rhyme with the others?`,o,three,`${three.join(", ")} all end in <b>${k.slice(1)}</b>. <b>${o}</b> does not.`,"Say the words. Which one has a different end sound?")}
  const three=SAMPLE(FAM[k],3);return mcQ(`What ending do <b>${three.join(", ")}</b> share?`,k,others,`${three.join(", ")} all end in <b>${k}</b>.`,"Look at the last two letters of each word.")};
const ILIST=G4.sp([["pig","The pig is pink.","p-i-g."],["big","The barn is big.","b-i-g."],["sit","Please sit on the hay.","s-i-t."],["lid","Put the lid on the bucket.","l-i-d."],["pin","I have a pin on my hat.","p-i-n."],["fig","The goat ate a fig.","f-i-g."],["kid","The kid is a baby goat.","k-i-d."],["dig","Pigs like to dig.","d-i-g."],["wig","The clown has a red wig.","w-i-g."],["fin","A shark has a fin.","f-i-n."],["six","I see six hens.","s-i-x."],["zip","Zip up your coat.","z-i-p."],["lip","I bit my lip.","l-i-p."],["hit","Hit the ball.","h-i-t."],["bin","Put the paper in the bin.","b-i-n."],["win","Our team can win.","w-i-n."],["fish","The fish swims in the pond.","f-i-sh. The letters sh make one sound."],["milk","The cow gives milk.","m-i-l-k."],["hill","The sheep are on the hill.","h-i-ll. Two l's at the end."],["mix","Mix the hen food.","m-i-x."],["swim","Ducks can swim.","s-w-i-m."],["kick","I can kick the ball.","k-i-ck. ck makes one sound."],["wind","The wind is cold.","w-i-n-d."],["chin","The goat has a beard on its chin.","ch-i-n. ch makes one sound."]]);

/* ================= GRAMMAR: PLURALS WITH -s ================= */
const NOUNS=[["hen","🐔"],["cow","🐄"],["pig","🐖"],["goat","🐐"],["duck","🦆"],["horse","🐎"],["cat","🐈"],["dog","🐕"],["egg","🥚"],["bucket","🪣"],["tractor","🚜"],["rabbit","🐇"],["chick","🐤"],["bird","🐦"],["bee","🐝"],["frog","🐸"],["rooster","🐓"],["turkey","🦃"],["donkey","🫏"],["llama","🦙"],["ant","🐜"],["boot","👢"],["tree","🌳"],["flower","🌸"],["bell","🔔"],["lamb","🐑"]];
const NUMW=["one","two","three","four","five"];
const pl=n=>n+"s";
const oneMore=()=>{const x=R(NOUNS),many=Math.random()<.5,w=many?pl(x[0]):x[0];const ans=many?"more than one":"one";
  const why=many?`<b>${w}</b> ends in <b>-s</b>, so it means more than one.`:`<b>${w}</b> has no <b>-s</b>, so it means just one.`;
  if(Math.random()<.5)return mcQ(`Look at the word <b>${w}</b>.<br>Is it <b>one</b> or <b>more than one</b>?`,ans,[many?"one":"more than one"],why,"Look at the end of the word. Is there an -s?");
  const s=many?`The <b>${w}</b> are on the farm.`:`The <b>${w}</b> is on the farm.`;return mcQ(`${G4.box("Read",s)}Is it <b>one</b> or <b>more than one</b>?`,ans,[many?"one":"more than one"],why,"Look for -s at the end of the word.",{say:s})};
const addS=()=>{const x=R(NOUNS),r=Math.random();
  if(r<.4)return {type:"type",q:`Add <b>-s</b>. Type the word:<br><b>one ${x[0]} ${x[1]}, two ___ ${x[1]}${x[1]}</b>`,a:[pl(x[0])],why:`one ${x[0]}, two <b>${pl(x[0])}</b>`,hint:`Write ${x[0]} and add s.`};
  if(r<.7)return {type:"type",q:`Add <b>-s</b> to make more than one:<br><b>${x[0]} + s = ?</b>`,a:[pl(x[0])],why:`${x[0]} + s = <b>${pl(x[0])}</b>`,hint:`Write ${x[0]}, then add s.`};
  const o=R(NOUNS.filter(y=>y!==x));return mcQ(`Which word means <b>more than one</b> ${x[1]} <b>${x[0]}</b>?`,pl(x[0]),[x[0],pl(o[0])],`one ${x[0]}, many <b>${pl(x[0])}</b>`,`Find ${x[0]} with an -s at the end.`)};
const countPick=()=>{const x=R(NOUNS),n=1+Math.floor(Math.random()*5),nw=NUMW[n-1];const m=R([1,2,3,4,5].filter(k=>k!==n));
  const ans=n===1?`one ${x[0]}`:`${nw} ${pl(x[0])}`;const wrong1=n===1?`one ${pl(x[0])}`:`${nw} ${x[0]}`;const wrong2=m===1?`one ${x[0]}`:`${NUMW[m-1]} ${pl(x[0])}`;
  return mcQ(`How many? Choose the right words.<br><span style="font-size:40px">${x[1].repeat(n)}</span>`,ans,[wrong1,wrong2],n===1?`Just one, so no -s: <b>${ans}</b>.`:`More than one, so add -s: <b>${ans}</b>.`,"Count the pictures. One = no -s. More than one = add -s.")};
const plSent=()=>{const x=R(NOUNS),n=1+Math.floor(Math.random()*5),nw=NUMW[n-1],tp=R(["I see","We have","I can see"]);
  const ans=n===1?x[0]:pl(x[0]),wrong=n===1?pl(x[0]):x[0];const s=`${tp} ${n===1?(/^[aeiou]/.test(x[0])?"an":"a"):nw} ___.`;
  return mcQ(`Choose the right word:<br><b>${s}</b> ${x[1].repeat(n)}`,ans,[wrong],`${s.replace("___","<b>"+ans+"</b>")}`,n===1?"Is it just one? Then do not add -s.":"Is it more than one? Then add -s.",{say:s.replace("___","blank")})};

/* ================= WORD SKILL: ANIMAL BABIES AND SOUNDS ================= */
const BABY=[["cow","calf","🐄"],["hen","chick","🐔"],["sheep","lamb","🐑"],["pig","piglet","🐖"],["horse","foal","🐎"],["goat","kid","🐐"],["duck","duckling","🦆"],["goose","gosling","🪿"],["cat","kitten","🐈"],["dog","puppy","🐕"],["frog","tadpole","🐸"]];
const babyQ=()=>{const x=R(BABY),o=SAMPLE(BABY.filter(y=>y!==x),2),r=Math.random();
  if(r<.4)return mcQ(`A baby ${x[2]} <b>${x[0]}</b> is called a ___.`,x[1],o.map(y=>y[1]),`A baby ${x[0]} is a <b>${x[1]}</b>.`,"Think of the farm babies: calf, chick, lamb, piglet, foal, kid...");
  if(r<.75)return mcQ(`A <b>${x[1]}</b> is the baby of a ___.`,`${x[2]} ${x[0]}`,o.map(y=>`${y[2]} ${y[0]}`),`A <b>${x[1]}</b> is a baby ${x[0]}.`,"Which mother animal has this baby?");
  return {type:"type",q:`Type the baby animal name:<br><b>${x[2]} ${x[0]} → baby ___</b>`,a:[x[1]].concat(x[1]==="kitten"?["kitty"]:x[1]==="puppy"?["pup"]:[]),why:`A baby ${x[0]} is a <b>${x[1]}</b>.`,hint:`It starts with "${x[1][0]}" and has ${x[1].length} letters.`}};
const SOUND=[["cow","moo","🐄"],["pig","oink","🐖"],["sheep","baa","🐑"],["horse","neigh","🐎"],["hen","cluck","🐔"],["duck","quack","🦆"],["rooster","cock-a-doodle-doo","🐓"],["donkey","hee-haw","🫏"],["dog","woof","🐕"],["cat","meow","🐈"],["goose","honk","🪿"],["turkey","gobble","🦃"],["bee","buzz","🐝"],["frog","ribbit","🐸"],["owl","hoot","🦉"]];
const soundQ=()=>{const x=R(SOUND),o=SAMPLE(SOUND.filter(y=>y!==x),2);
  if(Math.random()<.5)return mcQ(`Which animal says <b>“${x[1]}”</b>?`,`${x[2]} ${x[0]}`,o.map(y=>`${y[2]} ${y[0]}`),`The ${x[0]} says <b>${x[1]}</b>.`,"Make the sound. Which animal is it?",{say:`Which animal says ${x[1]}?`});
  return mcQ(`What does the ${x[2]} <b>${x[0]}</b> say?`,x[1],o.map(y=>y[1]),`The ${x[0]} says <b>${x[1]}</b>.`,"Think of the sound you hear on a farm.")};

/* ================= THINKING: ON THE FARM ================= */
const FARMQ=[
 {q:"🐔 Where does a hen sleep at night?",o:["In a coop","In a pond","In a tree house"],a:"In a coop",why:"A coop keeps hens safe at night."},
 {q:"🐴 Where does a horse sleep?",o:["In a stable","In a nest","In a fish tank"],a:"In a stable",why:"A stable is a horse's home."},
 {q:"🐷 It is a hot day. What will a pig do?",o:["Roll in the mud","Put on a coat","Climb a tree"],a:"Roll in the mud",why:"Mud helps pigs stay cool."},
 {q:"🐑 A sheep's wool is very long. What will the farmer do?",o:["Cut the wool","Paint the wool","Hide the sheep"],a:"Cut the wool",why:"Farmers cut wool, and it grows back."},
 {q:"🥚 What comes out of a hen's egg?",o:["A chick","A calf","A lamb"],a:"A chick",why:"Chicks hatch from hen eggs."},
 {q:"🐄 Which animal gives us milk?",o:["A cow","A duck","A hen"],a:"A cow",why:"Cows give us milk."},
 {q:"🧶 What do we get from sheep?",o:["Wool","Eggs","Feathers"],a:"Wool",why:"Sheep give us wool."},
 {q:"🦊 Why do farmers shut the coop at night?",o:["To keep foxes out","To keep the sun out","To keep the rain in"],a:"To keep foxes out",why:"A shut coop keeps hens safe."},
 {q:"🦆 Which animal has webbed feet for swimming?",o:["A duck","A horse","A pig"],a:"A duck",why:"Webbed feet help ducks swim."},
 {q:"🚜 What does a tractor do on a farm?",o:["Pulls heavy things","Lays eggs","Gives milk"],a:"Pulls heavy things",why:"A tractor is a strong farm machine."},
 {q:"🏔️ Which animal helps farmers in cold, high mountains?",o:["A yak","A duck","A camel"],a:"A yak",why:"Yaks have thick hair to stay warm."},
 {q:"🌾 Which animal helps in wet rice fields?",o:["A water buffalo","A rooster","A goose"],a:"A water buffalo",why:"Water buffalo pull ploughs in the mud."},
 {q:"🐕 How does a dog help on a sheep farm?",o:["It moves the sheep","It lays eggs","It makes hay"],a:"It moves the sheep",why:"Farm dogs help move the sheep."},
 {q:"🌙 The sun goes down. What do farm animals do?",o:["Go to sleep","Go to school","Go swimming"],a:"Go to sleep",why:"Animals rest at night."},
 {q:"🧼 You petted a goat. What should you do next?",o:["Wash your hands","Lick your hands","Pet a bee"],a:"Wash your hands",why:"Washing hands keeps you healthy."},
 {q:"🚪 You walk into the field. What should you do with the gate?",o:["Close it","Leave it open","Climb on it"],a:"Close it",why:"A shut gate keeps the animals safe inside."},
 {q:"🐮 A calf is hungry. What does it drink?",o:["Milk from its mother","Juice","Hot tea"],a:"Milk from its mother",why:"Baby cows drink their mother's milk."},
 {q:"🐝 What do bees make?",o:["Honey","Wool","Milk"],a:"Honey",why:"Bees make honey from flowers."},
 {q:"❄️ It is very cold in winter. Where do the cows stay?",o:["In a warm barn","In the pond","On the roof"],a:"In a warm barn",why:"A barn keeps cows warm and dry."},
 {q:"🐐 Which animal likes to climb on rocks?",o:["A goat","A duck","A pig"],a:"A goat",why:"Goats are great climbers."},
 {q:"🧮 3 hens each lay 1 egg. How many eggs?",o:["3","1","4"],a:"3",why:"1 + 1 + 1 = 3."},
 {q:"🧮 2 cows are in the barn. 2 more cows come in. How many cows now?",o:["4","2","5"],a:"4",why:"2 + 2 = 4."},
 {q:"🧮 5 ducks swim in the pond. 1 duck gets out. How many are left?",o:["4","5","6"],a:"4",why:"5 - 1 = 4."},
 {q:"🧮 A pig has 4 legs. How many legs do 2 pigs have?",o:["8","4","6"],a:"8",why:"4 + 4 = 8."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["cow","The cow eats grass.","c-o-w."],["pig","The pig is in the mud.","p-i-g. Short i."],["hen","The hen lays an egg.","h-e-n."],["duck","The duck can swim.","d-u-ck. ck makes one sound."],["goat","The goat can climb.","g-oa-t. oa says long o."],["sheep","The sheep has wool.","sh-ee-p. Double e."],["horse","I ride the horse.","h-or-s-e. Silent e at the end."],["barn","The cows are in the barn.","b-ar-n."],["farm","We visit the farm.","f-ar-m."],["lamb","The lamb is little.","l-a-m-b. Silent b at the end!"],["calf","The calf drinks milk.","c-a-l-f. Silent l!"],["chick","The chick is yellow.","ch-i-ck."],["wool","Wool keeps us warm.","w-oo-l. Double o."],["milk","Cows give us milk.","m-i-l-k."],["coop","The hens sleep in the coop.","c-oo-p. Double o."],["gate","Shut the gate.","g-a-t-e. Silent e makes the a long."],["hay","The horse eats hay.","h-ay. ay says long a."],["egg","I found an egg.","e-gg. Double g."],["fence","The fence is tall.","f-e-n-ce. ce says /s/."],["foal","The foal runs fast.","f-oa-l. oa says long o."]]),
 CHOOSE:null,
 DETAIL:[
  ["The Red Barn","The barn is big and red. Cows sleep in the barn at night. Hay is kept up high in the loft.",[["What colour is the barn?","Red",["Blue","Green"]],["Who sleeps in the barn?","Cows",["Fish","Bees"]],["Where is the hay kept?","Up high in the loft",["In the pond","Under the bed"]]]],
  ["Hen Eggs","Hens lay eggs in nest boxes. Ana picks up the eggs each morning. She puts them in a basket.",[["Where do hens lay eggs?","In nest boxes",["In the pond","On the roof"]],["When does Ana pick up the eggs?","Each morning",["At night","Once a year"]],["Where does Ana put the eggs?","In a basket",["In her hat","In the mud"]]]],
  ["The Sheep","Sheep eat grass in the field. A dog helps the farmer move them. At night, the sheep go into a pen.",[["What do sheep eat?","Grass",["Fish","Eggs"]],["Who helps move the sheep?","A dog",["A cat","A duck"]],["Where do the sheep go at night?","Into a pen",["Into the pond","Up a tree"]]]],
  ["Pigs","Pigs love mud. The mud keeps them cool on hot days. Pigs are very smart animals.",[["What do pigs love?","Mud",["Snow","Sand"]],["How does mud help pigs?","It keeps them cool",["It makes them fly","It keeps them clean"]],["What kind of animals are pigs?","Very smart",["Very tiny","Very slow"]]]],
  ["Yaks","Yaks live in high, cold mountains. They have long, thick hair. People use yak milk and yak hair.",[["Where do yaks live?","In high, cold mountains",["In hot deserts","In the sea"]],["What kind of hair do yaks have?","Long and thick",["Short and thin","Blue and green"]],["What do people use from yaks?","Milk and hair",["Eggs and feathers","Honey and wax"]]]],
  ["Water Buffalo","Water buffalo love water. They help farmers in wet rice fields. They cool off in mud and ponds.",[["What do water buffalo love?","Water",["Snow","Fire"]],["Where do they help farmers?","In wet rice fields",["In the sky","In a shop"]],["How do they cool off?","In mud and ponds",["Under a fan","In the snow"]]]],
  ["Ducks","Ducks have webbed feet. Webbed feet help them swim. Baby ducks walk behind their mother in a line.",[["What kind of feet do ducks have?","Webbed feet",["Hooves","Paws"]],["What do webbed feet help ducks do?","Swim",["Dig","Climb"]],["How do baby ducks walk?","Behind their mother in a line",["Far away alone","Upside down"]]]],
  ["The Foal","A baby horse is a foal. A foal can stand soon after it is born. It drinks milk from its mother.",[["What is a baby horse called?","A foal",["A calf","A chick"]],["When can a foal stand?","Soon after it is born",["When it is ten","Never"]],["What does a foal drink?","Milk from its mother",["Juice","Rain"]]]],
  ["Goats","Goats like to climb. They eat grass and leaves. Some goats give milk.",[["What do goats like to do?","Climb",["Swim","Fly"]],["What do goats eat?","Grass and leaves",["Fish and rocks","Eggs"]],["What can some goats give?","Milk",["Wool socks","Eggs"]]]],
  ["The Tractor","The farmer drives a big tractor. It pulls a cart full of hay. It goes slowly down the road.",[["Who drives the tractor?","The farmer",["A pig","A duck"]],["What does the tractor pull?","A cart full of hay",["A boat","A plane"]],["How does the tractor go?","Slowly",["Very fast","Backwards"]]]],
  ["Bees on the Farm","Some farms keep bees. Bees live in a hive. They make honey from flowers.",[["Where do bees live?","In a hive",["In a coop","In a pen"]],["What do bees make?","Honey",["Milk","Wool"]],["What do bees use to make honey?","Flowers",["Mud","Hay"]]]],
  ["A Sheep Station","Ruby lives on a sheep station in Australia. It is a very big farm. Ruby rides a horse to check the sheep.",[["Where does Ruby live?","In Australia",["In Vietnam","In Nepal"]],["What is a sheep station?","A very big farm",["A bus stop","A small shop"]],["How does Ruby check the sheep?","She rides a horse",["She flies a plane","She swims"]]]]
 ],
 MAIN:[
  ["Cows give milk. Hens give eggs. Sheep give wool.","Farm animals give us things.",["Hens give eggs.","Wool is soft."]],
  ["Pigs dig in the mud. Pigs say oink. Pigs have curly tails.","This is about pigs.",["Mud is wet.","Tails are long."]],
  ["A calf is a baby cow. A foal is a baby horse. A lamb is a baby sheep.","Farm animals have babies with special names.",["Cows are big.","Horses run fast."]],
  ["Hens live in a coop. Horses live in a stable. Pigs live in a pen.","Farm animals have different homes.",["Hens like to peck.","A pen is small."]],
  ["The cow says moo. The duck says quack. The pig says oink.","Farm animals make different sounds.",["Ducks can swim.","Cows eat hay."]],
  ["Ducks can swim. Ducks have webbed feet. Ducks say quack.","This is about ducks.",["Feet can walk.","Ponds are wet."]],
  ["First, open the gate. Next, feed the hens. Last, shut the gate.","This tells how to feed hens.",["Gates are big.","Hens can run."]],
  ["Linh has a water buffalo. Tenzin has yaks. Ruby has sheep.","Children around the world live on farms.",["Yaks are big.","Sheep say baa."]],
  ["Sheep have wool. The farmer cuts the wool. The wool grows back.","This is about sheep and their wool.",["Farmers are busy.","Hair grows."]],
  ["A tractor is big. A tractor pulls things. A farmer drives a tractor.","This is about tractors.",["Farmers drive.","Big things are heavy."]],
  ["Goats can climb. Goats eat leaves. Goats give milk.","This is about goats.",["Leaves are green.","Milk is white."]],
  ["Horses run fast. People ride horses. Horses eat hay.","This is about horses.",["Hay is dry.","People can run."]],
  ["Hens lay eggs. A hen sits on her eggs. Chicks hatch out.","This is about hens and their eggs.",["Chicks are yellow.","Eggs are round."]],
  ["Bees live in a hive. Bees visit flowers. Bees make honey.","This is about bees.",["Flowers are pretty.","Honey is sweet."]],
  ["The barn is big. Cows sleep in the barn. Hay is in the barn.","This is about the barn.",["Cows sleep.","Hay is yellow."]],
  ["Yaks live in the mountains. Yaks have thick hair. Yaks carry bags.","This is about yaks.",["Mountains are tall.","Bags are heavy."]],
  ["Farm dogs move sheep. Farm dogs guard the farm. Farm dogs help farmers.","Farm dogs help on the farm.",["Dogs bark.","Sheep say baa."]],
  ["Wash your hands. Close the gates. Walk, do not run.","These are farm rules.",["Gates are wood.","Hands have fingers."]],
  ["The sun comes up. The rooster crows. The farm wakes up.","It is morning on the farm.",["The sun is hot.","Roosters are birds."]],
  ["A piglet is pink. A piglet is little. A piglet drinks milk.","This is about a piglet.",["Milk is good.","Pink is a colour."]],
  ["Cows eat grass. Sheep eat grass. Horses eat hay.","Farm animals eat plants.",["Grass is green.","Horses are tall."]],
  ["Water buffalo pull ploughs. Horses pull carts. Tractors pull trailers.","Farm animals and machines pull things.",["Carts have wheels.","Ploughs are heavy."]],
  ["In winter, the cows stay in the barn. They eat hay. They keep warm.","Cows stay warm in the barn in winter.",["Hay is dry.","Winter is cold."]],
  ["Nina looks for Pip. Pip is in the mud. Nina is happy.","Nina finds her lost pig.",["Mud is brown.","Nina has a hat."]]
 ],
 FACTS:["Cows give us milk.","Hens lay eggs.","Sheep have wool.","Pigs say oink.","A baby cow is a calf.","Ducks can swim.","Horses have four legs.","A baby sheep is a lamb.","Bees make honey.","Goats can climb.","A baby horse is a foal.","Hens live in a coop.","A tractor is a farm machine.","Yaks live in the mountains.","Water buffalo help in rice fields.","A baby goat is a kid.","Chicks hatch from eggs.","Hay is dry grass.","A rooster can crow.","Ducks have webbed feet.","Cows eat grass.","A baby pig is a piglet.","Farm dogs can help move sheep.","Horses can sleep standing up.","Wool can be made into socks."],
 OPIN:["Pigs are the best farm animals.","Cows are the cutest animals.","Ducks are funny.","Farms are more fun than parks.","Lambs are the softest babies.","Goats are silly.","Hay smells nice.","A tractor ride is the best ride.","Horses are prettier than donkeys.","Chicks are the cutest babies.","Milk tastes great.","Mud is fun.","Roosters are too loud.","Barns are the best places to play.","Sheep are nicer than goats.","Feeding hens is the best job.","Wool hats are the best hats.","Foals are prettier than calves.","Farm work is easy.","Ducks are better than geese.","Yaks are the coolest animals.","Red is the best colour for a barn.","Pony rides are boring.","Piglets are the best pets.","Farm days are better than school days."],
 SEQ:[["Nina calls Pip","Nina looks in the barn","Nina hears an oink","Nina finds Pip in the mud"],["Open the gate","Fill the feeder","Pour the water","Shut the gate"],["A hen lays an egg","The hen sits on the egg","The egg cracks","A chick comes out"],["The sheep's wool grows long","The farmer cuts the wool","The wool is spun into yarn","Grandma knits a hat"],["The sun comes up","The rooster crows","The farmer feeds the animals","The animals eat"],["Get a bucket","Fill it with water","Carry it to the pigs","The pigs drink"],["Put on your boots","Walk to the barn","Milk the cow","Wash your hands"],["A seed is planted","Grass grows in the field","The farmer cuts the grass","The grass dries into hay"],["The cows eat in the field","It gets dark","The cows walk to the barn","The cows go to sleep"],["We get on the tractor","The tractor starts","We ride around the farm","We get off the tractor"]],
 CE:[["The pig was hot, so it rolled in the mud.","The pig was hot","it rolled in the mud"],["The gate was open, so the goat ran out.","The gate was open","the goat ran out"],["Mia dropped the egg, so it cracked.","Mia dropped the egg","it cracked"],["The hens were hungry, so Sam fed them.","The hens were hungry","Sam fed them"],["It was cold, so the cows stayed in the barn.","It was cold","the cows stayed in the barn"],["The sheep had long wool, so the farmer cut it.","The sheep had long wool","the farmer cut it"],["Pip played in the mud, so he got muddy.","Pip played in the mud","he got muddy"],["The rooster crowed, so the farmer woke up.","The rooster crowed","the farmer woke up"],["The calf was hungry, so it drank milk.","The calf was hungry","it drank milk"],["The duck saw the pond, so it went for a swim.","The duck saw the pond","it went for a swim"],["The fox came near, so the hens ran into the coop.","The fox came near","the hens ran into the coop"],["The horse ran a long way, so it was tired.","The horse ran a long way","it was tired"],["It rained all day, so the field was wet.","It rained all day","the field was wet"],["The farmer shut the gate, so the sheep were safe.","The farmer shut the gate","the sheep were safe"],["The dog barked, so the sheep moved.","The dog barked","the sheep moved"],["The lamb lost its mother, so it said baa.","The lamb lost its mother","it said baa"],["The bucket had a hole, so the water ran out.","The bucket had a hole","the water ran out"],["Nina found Pip, so she was happy.","Nina found Pip","she was happy"],["The goat ate the flowers, so the farmer was cross.","The goat ate the flowers","the farmer was cross"],["The tractor got stuck, so the farmer called for help.","The tractor got stuck","the farmer called for help"]],
 CMP:[
  ["A cow and a goat both give milk. A cow is big. A goat is small.","Both give milk","A cow is big, but a goat is small",["Both lay eggs","A goat is bigger"]],
  ["A hen and a duck both lay eggs. A duck can swim. A hen cannot swim well.","Both lay eggs","A duck can swim, but a hen cannot swim well",["Both give wool","A hen swims better"]],
  ["A horse and a donkey both have four legs. A horse is tall. A donkey has long ears.","Both have four legs","A horse is tall, but a donkey has long ears",["Both have wings","A horse has longer ears"]],
  ["A calf and a foal are both babies. A calf is a baby cow. A foal is a baby horse.","Both are babies","A calf is a baby cow, but a foal is a baby horse",["Both are baby ducks","A foal is a baby cow"]],
  ["A barn and a coop are both animal homes. A barn is big. A coop is small.","Both are animal homes","A barn is big, but a coop is small",["Both are in the sea","A coop is bigger"]],
  ["A pig and a sheep both live on farms. A pig says oink. A sheep says baa.","Both live on farms","A pig says oink, but a sheep says baa",["Both say moo","A sheep says oink"]],
  ["Linh and Tenzin both live on farms. Linh has a water buffalo. Tenzin has yaks.","Both live on farms","Linh has a water buffalo, but Tenzin has yaks",["Both live in a city","Tenzin has a water buffalo"]],
  ["A lamb and a kid both like to jump. A lamb is a baby sheep. A kid is a baby goat.","Both like to jump","A lamb is a baby sheep, but a kid is a baby goat",["Both are baby pigs","A kid is a baby sheep"]],
  ["A tractor and a horse can both pull a cart. A tractor is a machine. A horse is an animal.","Both can pull a cart","A tractor is a machine, but a horse is an animal",["Both are machines","A horse is a machine"]],
  ["A yak and a sheep both have thick hair. A yak lives in high mountains. A sheep lives in fields.","Both have thick hair","A yak lives in high mountains, but a sheep lives in fields",["Both live in the sea","A sheep lives in high mountains"]],
  ["A duck and a goose both swim. A duck says quack. A goose says honk.","Both swim","A duck says quack, but a goose says honk",["Both say moo","A goose says quack"]],
  ["Hay and grass are both food for cows. Grass is green and fresh. Hay is dry.","Both are food for cows","Grass is fresh, but hay is dry",["Both are wet","Hay is fresh and green"]]
 ],
 GRP:{"farm animals":["cow","goat","horse","donkey","duck"],"animal homes":["barn","coop","stable","hive","kennel"],"animal sounds":["moo","oink","baa","neigh","quack"],"things animals give us":["milk","eggs","wool","honey","feathers"],"words that rhyme with pig":["big","dig","wig","jig","twig"],"farm tools and machines":["tractor","bucket","rake","shovel","wagon"],"numbers":["one","two","three","four","five"]},
 ANA:[["Cow is to calf as horse is to ___.","foal",["lamb","chick"]],["Hen is to chick as sheep is to ___.","lamb",["kid","foal"]],["Pig is to piglet as duck is to ___.","duckling",["gosling","calf"]],["Goat is to kid as cow is to ___.","calf",["foal","chick"]],["Cow is to moo as pig is to ___.","oink",["baa","quack"]],["Duck is to quack as sheep is to ___.","baa",["neigh","moo"]],["Horse is to neigh as hen is to ___.","cluck",["oink","moo"]],["Hen is to coop as horse is to ___.","stable",["pond","hive"]],["Bee is to hive as cow is to ___.","barn",["nest","pond"]],["Cow is to milk as sheep is to ___.","wool",["eggs","honey"]],["Hen is to eggs as bee is to ___.","honey",["wool","milk"]],["Duck is to pond as pig is to ___.","mud",["tree","sky"]],["Big is to little as tall is to ___.","short",["big","long"]],["One is to hen as two is to ___.","hens",["hen","cows"]],["Cat is to kitten as dog is to ___.","puppy",["calf","lamb"]],["Goose is to gosling as duck is to ___.","duckling",["piglet","foal"]],["Linh is to Vietnam as Tenzin is to ___.","Nepal",["Canada","Australia"]],["Yak is to mountains as water buffalo is to ___.","rice fields",["deserts","ice"]],["Pig is to oink as dog is to ___.","woof",["meow","moo"]],["Sit is to hit as pin is to ___.","win",["pig","sun"]]],
 SENT:["I see Pip in the mud.","Nina has a pig named Pip.","Linh lives in Vietnam.","Tenzin has two yaks.","Ruby lives in Australia.","Sam and I feed the cows.","I ride a horse with Ruby.","Max helps move the sheep.","Mia picks up the eggs.","Can I pet the lamb?","The farm is in Canada.","Tenzin lives in Nepal.","I gave hay to Daisy the cow.","Ben and I shut the gate.","Sam lives on a farm in Ontario.","Is Pip in the barn?","I like the duck at Sunny Hill Farm.","Nina and I look for Pip.","Omar sees six hens.","Linh rides on the water buffalo."],
 ORDER:["The pig is big.","The hen can peck.","The cow says moo.","Six hens sit in the coop.","The duck can swim.","The kid can jump.","The lamb is little.","Pigs dig in the mud.","The horse eats hay.","Close the gate.","The calf drinks milk.","The sheep are in the field.","Two ducks swim.","The goat can climb.","Feed the hens.","The barn is red.","The chick is yellow.","Cows eat grass.","The foal runs fast.","The tractor is green."],
 WP:[
  {q:"Write a sentence about a pig.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Pp]igs?\\b","Uses the word pig"]],model:"The pig likes mud."},
  {q:"Write a sentence about a cow.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Cc]ows?\\b","Uses the word cow"]],model:"The cow says moo."},
  {q:"Write a sentence with <b>two hens</b> in it.",checks:[CHK.cap,CHK.end,["\\btwo hens\\b","Uses two hens"]],model:"I see two hens."},
  {q:"Write a sentence about a baby animal.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b(calf|calves|chicks?|lambs?|piglets?|foals?|kids?|ducklings?|goslings?|kittens?|puppy|puppies|baby)\\b","Names a baby animal"]],model:"The lamb is soft."},
  {q:"Write a sentence that starts with <b>I see</b>.",checks:[["^\\s*I see\\b","Starts with I see"],CHK.end,CHK.w3],model:"I see a big goat."},
  {q:"Write a sentence about what a hen gives us.",checks:[CHK.cap,CHK.end,["\\beggs?\\b","Uses egg or eggs"]],model:"A hen gives us eggs."},
  {q:"Write a sentence about a sheep.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Ss]heep\\b","Uses the word sheep"]],model:"The sheep has a woolly coat."},
  {q:"Write a sentence about a duck. Use <b>can</b>.",checks:[CHK.cap,CHK.end,["\\b[Dd]ucks?\\b","Uses duck"],["\\bcan\\b","Uses can"]],model:"The duck can swim."},
  {q:"Write a sentence with a short i word (pig, sit, big, dig).",checks:[CHK.cap,CHK.end,CHK.w3,["\\b([Pp]ig|[Ss]it|[Bb]ig|[Dd]ig|[Kk]id|[Ll]id|[Pp]in|[Ss]ix|[Ff]ish|[Hh]ill|[Ww]in)s?\\b","Uses a short i word"]],model:"The pig can dig."},
  {q:"Write a sentence about where a horse sleeps.",checks:[CHK.cap,CHK.end,["\\b[Hh]orses?\\b","Uses horse"],["\\b(stable|barn|field)\\b","Names a place"]],model:"The horse sleeps in the stable."},
  {q:"Write a question about a farm.",checks:[CHK.cap,CHK.q,CHK.w3],model:"Can I feed the goats?"},
  {q:"Write a sentence with <b>I</b> and a farm animal.",checks:[CHK.cap,CHK.end,CHK.I,["\\bI\\b","Uses I"]],model:"I like the donkey."},
  {q:"Write a sentence about <b>three pigs</b>.",checks:[CHK.cap,CHK.end,["\\bthree pigs\\b","Uses three pigs"]],model:"The three pigs are in the pen."},
  {q:"Write a sentence about a farm sound.",checks:[CHK.cap,CHK.end,["\\b(moo|oink|baa|neigh|cluck|quack|honk|woof|meow|says?)\\b","Uses a sound word"]],model:"The horse says neigh."},
  {q:"Write a sentence about a tractor.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Tt]ractors?\\b","Uses tractor"]],model:"The tractor is big."},
  {q:"Write a sentence about a goat.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Gg]oats?\\b","Uses goat"]],model:"The goat can jump."},
  {q:"Write a sentence about a barn.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Bb]arns?\\b","Uses barn"]],model:"The cows are in the barn."},
  {q:"Write a sentence with a name and a farm animal.",checks:[CHK.cap,CHK.end,CHK.name],model:"My friend Nina has a pig."},
  {q:"Write a sentence about many ducks. Add <b>-s</b>!",checks:[CHK.cap,CHK.end,["\\bducks\\b","Uses ducks"]],model:"The ducks swim in the pond."},
  {q:"Write a sentence about a job on a farm.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b(feed|milk|brush|clean|ride|shut|open|pick|dig|water|cut)\\b","Uses a job word"]],model:"I feed the hens."}
 ],
 SYN:[["big","large"],["small","little"],["happy","glad"],["fast","quick"],["close","shut"],["start","begin"],["jump","hop"],["shout","yell"],["tired","sleepy"],["sick","ill"],["mom","mother"],["dad","father"],["rock","stone"],["gift","present"],["house","home"],["kid","child"],["friend","pal"],["talk","chat"],["pull","tug"],["sniff","smell"]],
 OPP:[["big","small"],["hot","cold"],["wet","dry"],["up","down"],["in","out"],["fast","slow"],["day","night"],["happy","sad"],["full","empty"],["old","young"],["top","bottom"],["clean","dirty"],["loud","quiet"],["yes","no"],["on","off"],["push","pull"],["long","short"],["hard","soft"],["first","last"],["sit","stand"]],
 COMP:[["sun","flower"],["farm","yard"],["barn","yard"],["hen","house"],["pig","pen"],["cow","boy"],["horse","shoe"],["hay","stack"],["sheep","dog"],["bee","hive"],["butter","fly"],["rain","bow"],["bed","time"],["foot","ball"],["back","pack"],["rain","coat"],["snow","man"],["gold","fish"],["dog","house"],["bird","house"]]
};
B.CHOOSE=G4.ch([["cow","kow","cowe"],["pig","pigg","pyg"],["hen","henn","hne"],["duck","duk","dukc"],["goat","gote","goet"],["sheep","sheap","shep"],["horse","hors","horce"],["barn","barne","baarn"],["farm","farme","faarm"],["lamb","lamm","lahm"],["calf","caf","kalf"],["chick","chik","chikk"],["wool","wul","wooll"],["milk","mylk","milc"],["coop","koop","cooop"],["gate","gayt","gaet"],["hay","haye","hae"],["egg","eg","egge"],["fence","fenc","fense"],["foal","fole","foel"]],B.SP);

const L={
 shorti:"Short <b>i</b> says /i/, like in <b>pig</b> 🐷 and <b>sit</b> 🪑. Say the word slowly and listen for /i/ in the middle.",
 pic:"Say the name of the picture. Listen for each sound. Then find the word: 🐟 = <b>f-i-sh</b>.",
 make:"Put the sounds together to make a word: <b>p + i + g = pig</b> 🐷.",
 rhyme:"Rhyming words end with the same sound: <b>pig, big, dig</b> all end in <b>-ig</b>.",
 listen:"Say the word slowly: <b>p-i-g</b>. Write one letter for each sound.",
 one:"One thing has no -s: <b>one hen</b> 🐔. More than one gets an <b>-s</b>: <b>two hens</b> 🐔🐔.",
 adds:"To show more than one, add <b>-s</b> to the end: <b>cow → cows</b>.",
 count:"Count the pictures. One? No -s: <b>one duck</b>. More than one? Add -s: <b>three ducks</b>.",
 sent:"Look at the number word. <b>a</b> or <b>one</b> = no -s. <b>two, three, four, five</b> = add -s: <i>I see two pigs.</i>",
 baby:"Farm babies have special names. A baby cow is a <b>calf</b>. A baby hen is a <b>chick</b>.",
 sound:"Each animal makes its own sound. The cow says <b>moo</b>. The duck says <b>quack</b>.",
 farm:"Think about what farm animals need and how farmers care for them. Read all the answers, then choose."};
u.review=G4.MIX(oneMore,addS,countPick,plSent,shortI,rhymeI,F.vocab(u.words));
u.cats=G4.std(u,{sets:["Farm animals","Baby animals and what they give us","Farm places and things","Animal sounds and farm actions"],B,
 vocab:[{id:"v_baby",t:"Animal babies (cow → calf)",learn:L.baby,gen:babyQ},{id:"v_sound",t:"Animal sounds (moo, oink, baa)",learn:L.sound,gen:soundQ}],
 grammar:[{id:"g_onemore",t:"One or more than one?",learn:L.one,gen:oneMore},{id:"g_adds",t:"Add -s (one hen, two hens)",learn:L.adds,gen:addS},{id:"g_count",t:"Count and choose (🐔🐔🐔 three hens)",learn:L.count,gen:countPick},{id:"g_plsent",t:"Plurals in sentences",learn:L.sent,gen:plSent}],
 spelling:[{id:"s_shorti",t:"Which word has short i?",learn:L.shorti,gen:shortI},{id:"s_ipic",t:"Short i: picture to word",learn:L.pic,gen:picWord},{id:"s_imake",t:"Make the word (p _ g)",learn:L.make,gen:makeW},{id:"s_irhyme",t:"Rhyming words: -ig, -it, -in",learn:L.rhyme,gen:rhymeI},{id:"s_ilisten",t:"Short i words: listen and write",learn:L.listen,gen:F.listen(ILIST)}],
 thinking:[{id:"t_farm",t:"Farm thinking",learn:L.farm,gen:F.bank(FARMQ)}]});
})();
