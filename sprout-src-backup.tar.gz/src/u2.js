/* ===================== GRADE 3 · UNIT 2 · ANIMALS AROUND THE WORLD (original content) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"animals", num:2, emoji:"🐘🐪🐙", title:"Animals Around the World", badge:"🏅 Animal Explorer",

stories:[
/* ---------- 1. STORY ---------- */
{title:"Pip's Trip Around the World", e:"🐦", kind:"Story", pages:[
 {pic:"🐦🗺️", text:"Pip was a small blue bird with a big dream. Every night, Pip looked at an old map that was stuck to the wall of the bird shop. \"There are so many places in the world,\" Pip said. \"I want to meet the animals that live there!\" One sunny morning, Pip flew out of the open window and began a great adventure.",
  qs:[f("What did Pip want to do?","Meet animals from all over the world",["Build a new nest","Find some seeds"],"Pip said, \"I want to meet the animals that live there!\""),
      t("Which word best describes Pip?","Curious",["Lazy","Angry"],"Pip wants to explore and learn about the world. That is being curious.")]},
 {pic:"🏜️🐪", text:"First, Pip flew to a hot, dry desert. There was sand everywhere and no trees for shade. There Pip met a camel named Kamal. \"How do you live in such a dry place?\" asked Pip. Kamal smiled. \"My hump stores fat, so I can go a long time without food. When I find water, I can drink a lot very fast. And my long eyelashes keep the sand out of my eyes.\"",
  qs:[f("What does Kamal's hump store?","Fat",["Water","Sand"],"Kamal says, \"My hump stores fat.\""),
      t("Why does a camel need long eyelashes?","To keep sand out of its eyes",["To look beautiful","To catch flies"],"The desert is windy and sandy. Long eyelashes protect the camel's eyes.")]},
 {pic:"🌾🐘", text:"Next, Pip flew to the grasslands of Africa. The grass was tall and golden. A herd of elephants walked slowly to a river. The smallest elephant, a calf named Tembo, filled her trunk with water and sprayed it all over Pip. Splash! Pip laughed and shook his wet feathers. \"Elephants use their trunks to drink, to smell and to say hello,\" Tembo explained.",
  qs:[f("What is a baby elephant called?","A calf",["A cub","A chick"],"The story says the smallest elephant was \"a calf named Tembo\"."),
      f("What do elephants use their trunks for?","Drinking, smelling and saying hello",["Flying","Digging holes"],"Tembo explains that elephants use their trunks to drink, to smell and to say hello.")]},
 {pic:"🧊🐻‍❄️", text:"Then Pip flew far north to the freezing Arctic. Everything was white with snow and ice. Pip's feet were so cold! A polar bear named Nanuk was waiting near a hole in the ice, hoping to catch a seal. \"Aren't you cold?\" asked Pip, shivering. \"No,\" said Nanuk. \"My thick fur and a layer of fat keep me warm. You should fly somewhere warmer, little bird!\"",
  qs:[f("What was Nanuk hoping to catch?","A seal",["A fish","A bird"],"Nanuk was waiting near a hole in the ice, hoping to catch a seal."),
      t("Why did Nanuk tell Pip to fly somewhere warmer?","Pip was shivering and does not have thick fur",["Nanuk wanted to be alone","Pip was too noisy"],"Pip was shivering. A small bird is not made for the freezing Arctic like a polar bear.")]},
 {pic:"🌏🦘", text:"After that, Pip flew to Australia. The sun was warm again. A kangaroo hopped past with something wiggling in her pouch. A tiny head peeked out and waved. \"This is my joey,\" said the mother kangaroo. \"He rides in my pouch where he is safe and warm. When he is bigger, he will hop beside me.\"",
  qs:[f("Where does the joey ride?","In his mother's pouch",["On her back","In a tree"],"\"He rides in my pouch where he is safe and warm.\""),
      t("Why does the joey ride in the pouch?","He is too small to keep up and stay safe by himself",["He is lazy","He cannot see"],"The mother says the pouch keeps him safe and warm until he is bigger.")]},
 {pic:"🌊🐙", text:"Last, Pip flew over the deep blue ocean. An octopus waved two of her eight arms from a rock. \"Hello, little bird! Did you know I have three hearts and blue blood?\" Pip was amazed. That night, Pip flew home to the bird shop, tired but happy. He looked at the old map again. \"The world is full of wonderful animals,\" he thought, \"and every one of them lives in the home that suits it best.\"",
  qs:[f("How did Pip feel at the end of the trip?","Tired but happy",["Angry and sad","Scared and lost"],"The story says Pip flew home \"tired but happy\"."),
      t("What did Pip learn on his trip?","Every animal lives in the home that suits it best",["The Arctic is the best place","Birds should never fly far"],"Pip thinks: every animal lives in the home that suits it best.")]}
], turn:{q:"If you could fly anywhere in the world like Pip, where would you go? Which animal would you like to meet there? Write two sentences.",model:"I would fly to the rainforest in Brazil. I would like to meet a sloth."}},

/* ---------- 2. STORY ---------- */
{title:"Ravi and the Baby Turtles", e:"🐢", kind:"Story", pages:[
 {pic:"🏖️🌙", text:"Ravi lived with his Aunt Leela in a small house near a warm, sandy beach. Aunt Leela was a scientist who protected sea turtles. \"Every summer,\" she told Ravi, \"mother turtles swim back to this beach. They crawl out of the ocean at night to lay their eggs in the sand.\"",
  qs:[f("What was Aunt Leela's job?","A scientist who protected sea turtles",["A teacher","A fisher"],"\"Aunt Leela was a scientist who protected sea turtles.\""),
      f("When do mother turtles come out of the ocean to lay eggs?","At night",["At lunchtime","In the early morning"],"They crawl out of the ocean at night.")]},
 {pic:"🐢🥚", text:"One quiet night, Ravi and Aunt Leela hid behind some bushes and watched. A huge mother turtle pulled herself slowly up the beach. With her back flippers, she dug a deep hole and laid about one hundred eggs. Then she covered them with sand and crawled back to the sea. \"She will never meet her babies,\" whispered Aunt Leela. \"They must find the ocean all by themselves.\"",
  qs:[f("About how many eggs did the turtle lay?","About one hundred",["About ten","About two"],"She laid about one hundred eggs."),
      t("Why did Ravi and Aunt Leela hide behind the bushes?","So they would not scare the mother turtle",["Because it was raining","To play hide-and-seek"],"Scientists watch quietly so they do not disturb wild animals.")]},
 {pic:"🦀🚧", text:"The next morning, Aunt Leela put a small fence around the nest. \"This will protect the eggs from crabs, dogs and people's feet,\" she said. Every day, Ravi checked the nest. Weeks went by. Then, after about two months, Ravi saw the sand begin to move!",
  qs:[f("Why did Aunt Leela put a fence around the nest?","To protect the eggs",["To keep the turtle inside","To mark a football goal"],"\"This will protect the eggs from crabs, dogs and people's feet.\""),
      f("About how long did the eggs take to hatch?","About two months",["One day","One year"],"After about two months, the sand began to move.")]},
 {pic:"🐢💡", text:"That night, tiny turtles popped out of the sand, one after another. They were small enough to fit in Ravi's hand. Most of them scrambled towards the shining sea. But a few turned the wrong way and crawled towards the bright lights of a hotel. \"Oh no!\" cried Ravi. \"They're going the wrong way!\"",
  qs:[f("Where did some baby turtles crawl by mistake?","Towards the bright lights of a hotel",["Into a cave","Up a tree"],"A few turned towards the bright lights of a hotel."),
      t("How did Ravi feel when he saw this?","Worried",["Bored","Sleepy"],"He cried, \"Oh no!\" because the babies were in danger.")]},
 {pic:"🏨🔦", text:"\"Baby turtles follow the brightest light,\" Aunt Leela explained. \"They think it is the moon shining on the water.\" Ravi ran up to the hotel as fast as he could. \"Please turn off your beach lights!\" he begged the manager. \"The baby turtles are lost!\" The manager switched off the lights straight away. In the dark, the little turtles turned around and headed for the moonlit sea.",
  qs:[f("Why do baby turtles follow bright lights?","They think it is the moon shining on the water",["They like hotels","They are looking for food"],"Aunt Leela explains that they think it is the moon on the water."),
      t("Which word best describes Ravi in this part?","Brave",["Shy","Lazy"],"Ravi ran to the hotel and spoke to the manager to save the turtles.")]},
 {pic:"🌊💛", text:"Ravi watched the very last turtle reach the waves. \"Will they ever come back?\" he asked. \"If they survive, the girls will return to this same beach to lay their own eggs, many years from now,\" said Aunt Leela. Ravi smiled. He knew what he wanted to be when he grew up: a scientist who protects animals, just like his aunt.",
  qs:[f("Who will come back to the beach one day?","The girl turtles, to lay their own eggs",["All the crabs","The hotel manager"],"The girls will return to the same beach to lay their own eggs."),
      t("What is the big message of this story?","People can help protect animals",["Hotels are bad","Turtles are scary"],"Ravi and Aunt Leela show that people can help animals survive.")]}
], turn:{q:"What can you do to help animals or nature near your home? Write two sentences.",model:"I can put out water for birds in summer. I can pick up rubbish in the park."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"Animal Homes Around the World", e:"🌍", kind:"Fact text", pages:[
 {pic:"🏞️🌍", text:"Every animal has a <b>habitat</b>. A habitat is the natural home where an animal finds food, water, shelter and space. The Earth has many different habitats. Some are hot and some are freezing. Some are wet and some are dry. Each animal's body is suited to its own habitat.",
  qs:[f("What is a habitat?","The natural home where an animal finds what it needs",["A kind of food","A house for pets"],"The text says a habitat is the natural home where an animal finds food, water, shelter and space."),
      f("Which FOUR things does an animal find in its habitat?","Food, water, shelter and space",["Toys, beds, books and shoes","Only food"],"Food, water, shelter and space.")]},
 {pic:"🏜️🦎", text:"<b>Deserts</b> are very dry places. Some deserts are burning hot in the day and cold at night. The Sahara in Africa is the biggest hot desert in the world. Desert animals, like camels, lizards and fennec foxes, can live with very little water. Many of them sleep in the day and come out in the cool night.",
  qs:[f("What is the biggest hot desert in the world?","The Sahara",["The Arctic","The Amazon"],"The Sahara in Africa is the biggest hot desert in the world."),
      t("Why do many desert animals come out at night?","It is cooler at night",["They are afraid of the sun","They cannot see in the day"],"Desert days are burning hot, so many animals stay hidden and come out in the cool night.")]},
 {pic:"🧊🐧", text:"The <b>polar</b> regions are the coldest places on Earth. The Arctic is at the top of the world, and Antarctica is at the bottom. Polar bears and Arctic foxes live in the Arctic. Penguins live in Antarctica and other cold southern places. These animals have thick fur, warm feathers or a layer of fat to keep them warm.",
  qs:[f("Where do penguins live?","In Antarctica and other cold southern places",["In the Sahara","In the Arctic with polar bears"],"Penguins live in Antarctica and other cold southern places. Polar bears and penguins never meet in the wild!"),
      f("How do polar animals stay warm?","Thick fur, warm feathers or a layer of fat",["They wear coats","They drink hot water"],"They have thick fur, warm feathers or a layer of fat.")]},
 {pic:"🌊🐋", text:"The <b>ocean</b> covers more than two-thirds of the Earth. It is home to tiny fish and to the blue whale, the biggest animal that has ever lived. Fish breathe underwater with <b>gills</b>. Whales and dolphins are not fish. They must swim up to the surface to breathe air.",
  qs:[f("What is the biggest animal that has ever lived?","The blue whale",["The elephant","The shark"],"The blue whale is the biggest animal that has ever lived."),
      t("Why must a dolphin swim up to the surface?","It needs to breathe air",["It wants to look at the sky","It is chasing birds"],"Dolphins are not fish. They have no gills, so they must breathe air.")]},
 {pic:"🌳🦥", text:"<b>Rainforests</b> are hot, wet forests where it rains almost every day. The trees grow very tall and close together. More than half of all the kinds of plants and animals on Earth live in rainforests. Monkeys swing in the branches, sloths hang upside down, and colourful parrots fly between the trees.",
  qs:[f("What is the weather like in a rainforest?","Hot and wet",["Cold and dry","Snowy"],"Rainforests are hot, wet forests where it rains almost every day."),
      f("How many kinds of plants and animals live in rainforests?","More than half of all kinds on Earth",["Only a few","None"],"More than half of all the kinds of plants and animals on Earth live in rainforests.")]},
 {pic:"🌾🦓", text:"<b>Grasslands</b> are wide, open lands covered in grass, with only a few trees. In Africa, zebras, giraffes and elephants eat the grass and leaves. Lions and cheetahs hunt them. When people cut down forests or build on grasslands, animals lose their homes. That is why it is important to protect habitats.",
  qs:[f("Which animals hunt in the African grasslands?","Lions and cheetahs",["Zebras and giraffes","Penguins"],"Lions and cheetahs hunt the grass-eating animals."),
      t("Why is it important to protect habitats?","Animals lose their homes when habitats are destroyed",["Habitats are pretty","So people can build more roads"],"The text says that when forests are cut down or grasslands are built on, animals lose their homes.")]}
], turn:{q:"Which habitat would you most like to visit? Write two sentences saying why.",model:"I would like to visit the ocean. I want to see a whale and swim with colourful fish."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"Clever Ways Animals Survive", e:"🦊", kind:"Fact text", pages:[
 {pic:"🦊❄️", text:"Animals have special ways to <b>survive</b>, which means to stay alive. Some ways are part of their bodies, like thick fur or sharp claws. Other ways are things they do, like hiding or travelling. These special features are called <b>adaptations</b>.",
  qs:[f("What does \"survive\" mean?","To stay alive",["To fall asleep","To swim fast"],"The text says survive means to stay alive."),
      f("What are special features that help animals survive called?","Adaptations",["Habitats","Hobbies"],"These special features are called adaptations.")]},
 {pic:"🦎🍃", text:"Some animals use <b>camouflage</b>. Their colours or shapes help them blend in so other animals cannot see them. A stick insect looks just like a twig. The Arctic fox has white fur in the snowy winter. In summer, its coat turns brown or grey to match the rocks and earth.",
  qs:[f("What colour is the Arctic fox's fur in winter?","White",["Brown","Orange"],"The Arctic fox has white fur in the snowy winter."),
      t("Why does the Arctic fox's coat change colour in summer?","To match the rocks and earth when the snow melts",["Because it gets dirty","To look different for fun"],"In summer there is no snow, so a brown or grey coat blends in better.")]},
 {pic:"🐻💤", text:"Some animals <b>hibernate</b>. In winter, food is hard to find and the weather is very cold. So these animals eat a lot in autumn, then go into a deep sleep in a safe place. Hedgehogs sleep in nests of leaves, and bears rest in dens. Their bodies slow down, and they wake up again in spring.",
  qs:[f("When do animals that hibernate wake up?","In spring",["In winter","At midnight"],"They wake up again in spring."),
      t("Why do these animals eat a lot in autumn?","They need to store energy for their long winter sleep",["They are bored","Autumn food tastes better"],"They will not eat while they sleep, so they must build up fat first.")]},
 {pic:"🦋✈️", text:"Some animals <b>migrate</b>. This means they make a long journey to a new place when the seasons change. Every autumn, monarch butterflies fly from Canada and the United States all the way to Mexico, where it is warmer. The Arctic tern, a small seabird, flies from the top of the world to the bottom and back again every year!",
  qs:[f("Where do monarch butterflies fly to in autumn?","Mexico",["The Arctic","Australia"],"They fly from Canada and the United States all the way to Mexico."),
      f("What does \"migrate\" mean?","To make a long journey to a new place when the seasons change",["To sleep all winter","To change colour"],"The text explains: migrate means a long journey when the seasons change.")]},
 {pic:"☀️🌿🦓🦁", text:"Every animal needs food for energy. A <b>food chain</b> shows who eats what. The sun helps grass grow. A zebra eats the grass. A lion eats the zebra. Animals that hunt other animals are called <b>predators</b>. The animals they hunt are called <b>prey</b>.",
  qs:[f("In the food chain, what does the zebra eat?","Grass",["Lions","The sun"],"A zebra eats the grass."),
      t("In this food chain, which animal is the predator?","The lion",["The zebra","The grass"],"The lion hunts the zebra, so the lion is the predator and the zebra is the prey.")]},
 {pic:"🌍🤝", text:"Hiding, sleeping, travelling and hunting are all ways animals survive in their habitats. Every living thing is connected. If one animal disappears, the animals that eat it, and the plants it helps, are affected too. That is why scientists work hard to protect animals, big and small.",
  qs:[f("Which of these is NOT a way animals survive, in this text?","Going shopping",["Hiding","Travelling"],"Hiding, sleeping, travelling and hunting are all in the text. Shopping is not!"),
      t("What happens if one animal disappears from a food chain?","Other animals and plants are affected too",["Nothing changes","All the plants grow bigger"],"The text says every living thing is connected.")]}
], turn:{q:"Choose one adaptation from this text (camouflage, hibernation or migration). Explain it in your own words in two sentences.",model:"Hibernation is a long winter sleep. Bears hibernate because there is not much food in winter."}},

/* ---------- 5. FABLE ---------- */
{title:"Kiko the Chameleon (a fable)", e:"🦎", kind:"Fable", pages:[
 {pic:"🦎🌈", text:"By a quiet lake at the edge of a forest lived a young chameleon named Kiko. Kiko's skin changed colour with his feelings. When he was calm, he was leafy green. When he was excited, he glowed bright yellow. When he was sad, he turned dark brown.",
  qs:[f("What colour was Kiko when he was excited?","Bright yellow",["Dark brown","Leafy green"],"When he was excited, he glowed bright yellow."),
      t("What did Kiko's colours show?","His feelings",["The weather","The time of day"],"His skin changed colour with his feelings.")]},
 {pic:"🦩💗", text:"Kiko's best friend was Flora the flamingo. Flora was always a beautiful pink. \"I wish I were pink all the time, like you,\" Kiko sighed. \"Everyone can see my feelings. It's embarrassing! If I were one colour, everyone would think I'm beautiful.\"",
  qs:[f("What did Kiko wish?","To be pink all the time",["To fly like Flora","To live in the lake"],"\"I wish I were pink all the time, like you.\""),
      t("Why did Kiko feel embarrassed?","Everyone could see his feelings",["He could not swim","Flora laughed at him"],"Kiko said, \"Everyone can see my feelings. It's embarrassing!\"")]},
 {pic:"😐🦎", text:"So Kiko tried very hard to feel nothing at all, so he would stay the same colour. He would not laugh at jokes. He would not cry at sad stories. He stopped playing games with his friends. Soon Kiko became grey, tired and grumpy, and his friends stopped coming to visit.",
  qs:[f("What happened when Kiko tried to feel nothing?","He became grey, tired and grumpy",["He turned pink","He became very popular"],"Soon Kiko became grey, tired and grumpy."),
      t("Was Kiko's plan a good idea?","No, it made him unhappy and lonely",["Yes, it made him happy"],"Hiding all his feelings made Kiko tired, grumpy and alone.")]},
 {pic:"🐦😢", text:"One morning, Kiko heard a baby bird crying under a bush. It had fallen out of its nest. Kiko felt so sorry for it that his skin turned dark brown. He climbed up the tall tree, step by careful step, and found the nest. When the baby bird was safe with its mother again, Kiko felt so happy that he glowed bright yellow from head to tail.",
  qs:[f("Why was the baby bird crying?","It had fallen out of its nest",["It was hungry","It had lost a toy"],"It had fallen out of its nest."),
      t("Why did Kiko glow bright yellow at the end?","He was happy that the baby bird was safe",["He was cold","He was sick"],"Yellow shows Kiko is excited and happy.")]},
 {pic:"🦎💛🦩", text:"The mother bird sang, \"Thank you, Kiko! Your colours showed us your kind heart.\" Flora hugged him with her long wing. \"Your colours are what make you YOU,\" she said. From that day on, Kiko never wished to be pink again. He laughed, cried and played, and he was proud of every colour he turned. <b>Lesson: Be proud of who you are.</b>",
  qs:[t("What is the lesson of this fable?","Be proud of who you are",["Always stay the same colour","Never climb trees"],"Kiko learned that his changing colours made him special."),
      f("What did the mother bird say Kiko's colours showed?","His kind heart",["His age","The way home"],"\"Your colours showed us your kind heart.\"")]}
], turn:{q:"What is something that makes YOU special? Write two sentences.",model:"I can speak three languages. I am also very good at making people laugh."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A day at the zoo", e:"🎫", kind:"Real-world text", pages:[
 {pic:"🦒🎫", text:"Read this sign at the entrance of Green Hill Zoo.<div class=\"realdoc\"><b>🦁 Welcome to Green Hill Zoo! 🦁</b><br>Open every day: 9:00 a.m. to 5:00 p.m.<br>Last entry: 4:00 p.m.<br><br><b>Please help us care for our animals:</b><br>🚫 Do not feed the animals.<br>🚫 Do not tap on the glass.<br>🤫 Use quiet voices near sleeping animals.<br>🧼 Wash your hands after the Petting Farm.<br>🗑️ Put rubbish in the bins.</div>",
  qs:[f("What time does the zoo close?","5:00 p.m.",["4:00 p.m.","9:00 a.m."],"Open from 9:00 a.m. to 5:00 p.m."),
      f("What is the latest time you can go in?","4:00 p.m.",["5:00 p.m.","9:00 a.m."],"Last entry: 4:00 p.m."),
      t("Why should you not feed the animals?","Human food can make them sick",["They are never hungry","It is too expensive"],"Zookeepers give animals the right food. Our food can make them ill."),
      t("Why should you wash your hands after the Petting Farm?","To wash away germs from the animals",["To make your hands smell nice","Because the animals are dirty"],"Animals can carry germs, so washing your hands keeps you healthy.")]},
 {pic:"🐧🕐", text:"This is the zoo's feeding timetable. Visitors can watch the animals being fed.<table class=\"realtbl\"><tr><th>Time</th><th>Animal</th><th>Where</th></tr><tr><td>10:30 a.m.</td><td>Penguins 🐧</td><td>Ice Coast</td></tr><tr><td>11:15 a.m.</td><td>Elephants 🐘</td><td>Savanna Path</td></tr><tr><td>1:00 p.m.</td><td>Sea lions 🦭</td><td>Ocean Pool</td></tr><tr><td>2:30 p.m.</td><td>Giraffes 🦒</td><td>Savanna Path</td></tr><tr><td>3:45 p.m.</td><td>Monkeys 🐒</td><td>Rainforest House</td></tr></table>",
  qs:[f("When are the penguins fed?","10:30 a.m.",["1:00 p.m.","3:45 p.m."],"Penguins: 10:30 a.m. at Ice Coast."),
      f("Where can you watch the sea lions being fed?","Ocean Pool",["Ice Coast","Savanna Path"],"Sea lions: 1:00 p.m. at Ocean Pool."),
      f("Which TWO animals are fed on the Savanna Path?","Elephants and giraffes",["Penguins and monkeys","Sea lions and penguins"],"Elephants (11:15) and giraffes (2:30) are both on the Savanna Path."),
      t("Mia arrives at 2:00 p.m. Which feeding can she still see first?","The giraffes",["The penguins","The sea lions"],"After 2:00 p.m., the next feeding is the giraffes at 2:30.")]}
], turn:{q:"Write a short sign with two rules for visitors to a park or a zoo. Explain why one of the rules is important.",model:"Please stay on the path. Do not pick the flowers, because bees need them for food."}}
],

poems:[
 {title:"Around the World with Pip",
  lines:["Pip flew east and Pip flew west,","To see which animal home was best.","The camel liked the desert sand,","The kangaroo hopped on dry land.","The polar bear loved snow and ice,","The octopus found the ocean nice.","But when the stars came out at night,","Pip's own small nest felt just right."],
  qs:[f("Which word rhymes with 'ice'?","nice",["snow","sand"],"Ice and nice end with the same sound: -ice."),
      f("Which animal liked the desert sand?","The camel",["The polar bear","The octopus"],"\"The camel liked the desert sand.\""),
      t("What does the last line mean?","Pip was happiest back in his own home",["Pip wanted a new nest","Pip was lost"],"After seeing many homes, Pip felt his own nest was just right for him.")]},
 {title:"Winter Sleep",
  lines:["When leaves fall down and winds blow cold,","The bear goes to her den so old.","She curls up tight, she shuts her eyes,","And sleeps beneath the winter skies.","The hedgehog snuggles in his bed","Of crunchy leaves above his head.","Wake up, wake up! The spring is here!","Good morning, friends! Another year!"],
  qs:[f("Which word rhymes with 'cold'?","old",["leaves","bear"],"Cold and old end with the same sound: -old."),
      f("Where does the hedgehog sleep?","In a bed of crunchy leaves",["In a den","In the river"],"\"The hedgehog snuggles in his bed of crunchy leaves.\""),
      t("What is this poem about?","Animals that hibernate in winter",["Animals that migrate","A day at the beach"],"The bear and the hedgehog sleep all winter and wake in spring: they hibernate.")]}
],

words:[
 {w:"habitat",e:"🏞️",m:"the natural home of an animal or plant",ex:"The Arctic is the habitat of the polar bear.",fill:"A forest is the ___ of many birds and monkeys."},
 {w:"desert",e:"🏜️",m:"a very dry place where it almost never rains",ex:"Camels can live in the hot desert.",fill:"It almost never rains in the ___."},
 {w:"Arctic",e:"🧊",m:"the very cold area at the top of the world",ex:"There is snow and ice in the Arctic all year.",fill:"Polar bears live in the cold ___."},
 {w:"ocean",e:"🌊",m:"a very big area of salty water",ex:"Whales swim in the ocean.",fill:"Whales and octopuses swim in the ___."},
 {w:"rainforest",e:"🌳",m:"a hot, wet forest where it rains almost every day",ex:"Monkeys swing through the rainforest.",fill:"Sloths and parrots live in the hot, wet ___."},
 {w:"grassland",e:"🌾",m:"wide, open land covered with grass",ex:"Zebras eat grass on the grassland.",fill:"Lions and zebras live on the open ___."},
 {w:"pond",e:"🐸",m:"a small area of still water",ex:"A frog jumped into the pond.",fill:"Ducks swim on the little ___ in the park."},
 {w:"nest",e:"🪺",m:"a home that a bird builds for its eggs",ex:"The bird laid three eggs in her nest.",fill:"The robin built a ___ out of twigs."},
 {w:"burrow",e:"🕳️",m:"a hole in the ground that an animal digs to live in",ex:"The rabbit hid in its burrow.",fill:"The rabbit dug a ___ under the ground."},
 {w:"den",e:"🐻",m:"the hidden home of a wild animal, like a bear or a fox",ex:"The bear slept in her den all winter.",fill:"The fox cubs played outside their ___."},

 {w:"trunk",e:"🐘",m:"the long nose of an elephant",ex:"The elephant sprayed water with its trunk.",fill:"The elephant picked up a peanut with its ___."},
 {w:"hump",e:"🐪",m:"the round bump on a camel's back",ex:"The camel's hump stores fat.",fill:"The camel has a big ___ on its back."},
 {w:"pouch",e:"🦘",m:"a pocket of skin where a kangaroo carries its baby",ex:"The joey sleeps in the pouch.",fill:"The baby kangaroo sleeps in its mother's ___."},
 {w:"fur",e:"🐻‍❄️",m:"the thick, soft hair on an animal",ex:"The polar bear's fur keeps it warm.",fill:"The rabbit has soft, white ___."},
 {w:"feathers",e:"🪶",m:"the soft, light coverings on a bird's body",ex:"Pip shook his wet feathers.",fill:"The parrot has bright green and red ___."},
 {w:"scales",e:"🐍",m:"small, hard, flat plates that cover fish and snakes",ex:"The snake's scales are smooth and shiny.",fill:"A fish is covered in shiny ___."},
 {w:"fins",e:"🐟",m:"flat parts on a fish's body that help it swim",ex:"The fish moved its fins to swim.",fill:"The shark used its ___ to swim fast."},
 {w:"beak",e:"🦜",m:"the hard, pointed mouth of a bird",ex:"The bird picked up a seed with its beak.",fill:"The parrot cracked the nut with its strong ___."},
 {w:"claws",e:"🐾",m:"sharp, curved nails on an animal's feet",ex:"The cat has sharp claws.",fill:"The eagle held the fish in its sharp ___."},
 {w:"tusks",e:"🦣",m:"two very long, pointed teeth, like an elephant's",ex:"The elephant has two long tusks.",fill:"The walrus has two long white ___."},

 {w:"hunt",e:"🦁",m:"to chase and catch animals for food",ex:"Lions hunt zebras on the grassland.",fill:"Owls ___ for mice at night."},
 {w:"prey",e:"🐭",m:"an animal that is hunted and eaten by another animal",ex:"The mouse is prey for the owl.",fill:"The zebra is ___ for the lion."},
 {w:"predator",e:"🦈",m:"an animal that hunts other animals for food",ex:"The shark is a fast predator.",fill:"The lion is a ___ because it hunts other animals."},
 {w:"camouflage",e:"🦎",m:"colours or shapes that help an animal hide",ex:"The stick insect uses camouflage to look like a twig.",fill:"The tiger's stripes are ___ in the tall grass."},
 {w:"hibernate",e:"💤",m:"to sleep deeply through the whole winter",ex:"Hedgehogs hibernate in nests of leaves.",fill:"Some bears ___ in their dens all winter."},
 {w:"migrate",e:"🦋",m:"to travel far to a new place when the seasons change",ex:"Monarch butterflies migrate to Mexico.",fill:"Many birds ___ south when winter comes."},
 {w:"hatch",e:"🐣",m:"to break out of an egg",ex:"The baby turtles hatch from their eggs.",fill:"The chicks will ___ from their eggs soon."},
 {w:"survive",e:"💪",m:"to stay alive",ex:"Camels can survive in the hot desert.",fill:"Plants need water to ___."},
 {w:"protect",e:"🛡️",m:"to keep someone or something safe",ex:"The fence will protect the turtle eggs.",fill:"A mother bird will ___ her babies."},
 {w:"herd",e:"🐃",m:"a big group of animals that live and move together",ex:"A herd of elephants walked to the river.",fill:"A ___ of cows ate grass in the field."},

 {w:"enormous",e:"🐋",m:"very, very big",ex:"The blue whale is enormous.",fill:"The elephant is ___ compared to the mouse."},
 {w:"tiny",e:"🐜",m:"very, very small",ex:"An ant is a tiny insect.",fill:"The baby turtle was so ___ it fit in my hand."},
 {w:"fierce",e:"🐯",m:"angry, strong and ready to attack",ex:"The fierce tiger roared loudly.",fill:"The ___ lion showed its sharp teeth."},
 {w:"swift",e:"🐆",m:"able to move very fast",ex:"The swift cheetah ran across the grass.",fill:"The ___ horse won the race."},
 {w:"wild",e:"🌿",m:"living free in nature, not with people",ex:"Wild animals find their own food.",fill:"Lions are ___ animals, not pets."},
 {w:"rare",e:"💎",m:"not seen or found very often",ex:"The white tiger is very rare.",fill:"It is ___ to see a snow leopard."},
 {w:"endangered",e:"🐼",m:"in danger of disappearing from the Earth forever",ex:"Some sea turtles are endangered.",fill:"We must protect ___ animals so they do not disappear."},
 {w:"curious",e:"🧐",m:"wanting to know or learn about something",ex:"The curious monkey looked inside the bag.",fill:"The ___ kitten wanted to see what was in the box."},
 {w:"explore",e:"🧭",m:"to travel around a place to learn about it",ex:"Pip wanted to explore the world.",fill:"Let's ___ the forest and look for animal tracks."},
 {w:"amazed",e:"😲",m:"very, very surprised",ex:"Pip was amazed to meet an octopus.",fill:"We were ___ to see a whale jump out of the water."}
],

spelling:[
 {w:"animal",s:"A camel is a desert animal."},
 {w:"camel",s:"The camel walked across the sand."},
 {w:"desert",s:"It is very hot in the desert."},
 {w:"ocean",s:"Whales live in the ocean.",tip:"o-c-e-a-n. The 'c' sounds like 'sh'."},
 {w:"elephant",s:"The elephant has a long trunk.",tip:"'ph' sounds like 'f': ele-ph-ant."},
 {w:"bird",s:"Pip is a small blue bird."},
 {w:"fish",s:"The bear caught a fish."},
 {w:"bear",s:"The polar bear has thick fur."},
 {w:"snow",s:"The Arctic is covered in snow."},
 {w:"water",s:"The elephant sprayed water."},
 {w:"feather",s:"Pip lost a blue feather.",tip:"f-ea-th-er. The 'ea' sounds like 'e'."},
 {w:"kangaroo",s:"The kangaroo hopped away.",tip:"Double o at the end: kangar-oo."},
 {w:"world",s:"Pip flew around the world."},
 {w:"turtle",s:"The turtle swam into the sea.",tip:"t-ur-t-le. The ending '-le' sounds like 'ul'."},
 {w:"monkey",s:"The monkey swung from the tree.",tip:"Ends in -ey: monk-ey."}
],

facts:[
 {e:"🐙",c:"An octopus has three hearts.",t:true,x:"True! Two hearts pump blood to its gills and one pumps blood to the rest of its body. Its blood is blue!"},
 {e:"🐪",c:"A camel's hump is full of water.",t:false,x:"Not true! The hump stores fat. The camel's body can turn that fat into energy."},
 {e:"🐻‍❄️",c:"Polar bears have black skin under their white fur.",t:true,x:"True! Their dark skin helps them soak up warmth from the sun."},
 {e:"🦋",c:"Butterflies taste with their feet.",t:true,x:"True! Butterflies have taste sensors on their feet, so they can taste a leaf just by standing on it."},
 {e:"🕷️",c:"Spiders are insects.",t:false,x:"Not true! Insects have six legs. Spiders have eight legs, so they belong to a different group called arachnids."},
 {e:"🦇",c:"Bats are blind.",t:false,x:"Not true! Bats can see. Many bats also use echoes to find their way in the dark."},
 {e:"🐬",c:"Dolphins sleep with one half of their brain at a time.",t:true,x:"True! One half rests while the other half stays awake, so the dolphin can keep swimming and breathing."},
 {e:"🐠",c:"Goldfish can only remember things for three seconds.",t:false,x:"Not true! Scientists have shown that goldfish can remember things for months."},
 {e:"🦉",c:"An owl can turn its head most of the way around.",t:true,x:"True! An owl cannot move its eyes, so it turns its head instead, about three-quarters of the way around."},
 {e:"🐸",c:"Frogs can drink water through their skin.",t:true,x:"True! Frogs soak up water through their skin instead of drinking with their mouths."},
 {e:"⭐",c:"A starfish is a kind of fish.",t:false,x:"Not true! A starfish has no gills, fins or bones. Scientists now call it a sea star."},
 {e:"🐨",c:"Koalas can sleep for up to 20 hours a day.",t:true,x:"True! Koalas eat eucalyptus leaves, which give them very little energy, so they rest most of the day."}
],

writing:[
 {e:"🦋",t:"Imagine you are an animal",level:"Step 1 · Sentences",
  prompt:"If you could be any animal for one day, which animal would you be? Where would you live? What would you eat? What would you do all day? Write at least 4 sentences and use a word from the word bank.",
  minS:4,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["If I were a ","I would live in ","I would eat ","All day, I would ","My best friend would be "],
  model:"If I were a dolphin, I would live in the ocean. I would eat fish and squid. All day, I would swim fast and jump over the waves. My best friend would be a curious sea turtle."},
 {e:"📝",t:"An animal fact report",level:"Step 2 · Report",
  prompt:"Choose one real animal. Write a report of at least 6 sentences. Say where it lives (its habitat), what it eats, what its body is like, how it survives, and one amazing fact. Use at least 3 words from the word bank.",
  minS:6,minWords:3,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["The ","lives in ","Its habitat is ","It eats ","Its body has ","To survive, it ","An amazing fact is that "],
  model:"The emperor penguin is a large bird. Its habitat is the icy land and ocean of Antarctica. It eats fish and squid that it catches in the ocean. Its body has thick feathers and a layer of fat to survive the cold. Penguins huddle together in a big group to stay warm. An amazing fact is that the father penguin keeps the egg warm on his feet for about two months."},
 {e:"📖",t:"Pip's new adventure",level:"Step 3 · Story",
  prompt:"Write a story of at least 7 sentences about Pip visiting a new animal in a new habitat. Write in the past tense (Pip flew, Pip saw, Pip asked). Give your story a beginning, a middle and an end. Use time words like First, Then, Next and Finally.",
  minS:7,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],
      ["\\b(First|Then|Next|After that|Finally|Later|One day)\\b","I used a time word (First, Then, Next, Finally…)"],
      ["(\\b(\\w+ed|flew|saw|went|said|met|ate|swam|ran|came|found|took|had|was|were|made|got|told|sang|slept|caught|dug|hid|knew|thought)\\b[\\s\\S]*){3}","I used at least 3 past-tense verbs"]],
  starters:["One day, Pip flew to ","First, ","Then, ","Pip asked, \"","Next, ","Finally, Pip "],
  model:"One day, Pip flew to the rainforest. First, he saw tall trees and heard parrots singing. Then he met a sloth hanging upside down from a branch. \"Why do you move so slowly?\" Pip asked. The sloth yawned and said that moving slowly helps it save energy. Next, Pip saw that tiny green plants were growing on the sloth's fur, which was perfect camouflage. Finally, Pip flew home and told his friends about his amazing new friend."}
]
});
})();
