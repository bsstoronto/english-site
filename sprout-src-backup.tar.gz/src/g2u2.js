/* ===================== GRADE 2 · UNIT 2 · AMAZING ANIMALS ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:2,id:"g2_animals",num:2,emoji:"🦁🐘🦒",title:"Amazing Animals",short:"long e, common and proper nouns, animal parts and homes",badge:"🦁 Animal Expert",
stories:[
/* 1 STORY: PROBLEM AND HAPPY ENDING */
{title:"Benny and the Broken Dam",e:"🦫",kind:"Story",pages:[
 {pic:"🦫🌲🏞️",text:"Benny is a young beaver. He lives with his family in Canada. Their home is a lodge made of sticks and mud. The lodge sits in a quiet pond. Next to the lodge is a long dam. The dam holds back the water. It keeps the pond deep and safe. Benny is proud of his home.",
  qs:[f("What is Benny's home made of?","Sticks and mud 🪵",["Rocks and sand 🪨","Snow and ice ❄️"],"Their home is a lodge made of sticks and mud."),
      f("What does the dam do?","It holds back the water 💧",["It makes food 🍎","It keeps the sun out ☀️"],"The dam holds back the water.")]},
 {pic:"⛈️🌊😟",text:"One night, a big storm comes. Rain falls and falls. The wind blows very hard. In the morning, Benny swims out to look. Oh no! There is a big hole in the dam. Water is rushing out of the pond. The pond is getting low. \"Our lodge will not be safe,\" says Mama Beaver.",
  qs:[f("What made the hole in the dam?","A big storm ⛈️",["A bear 🐻","Benny's tail"],"One night, a big storm comes. Then there is a hole in the dam."),
      p("What will the beavers do next?","Fix the dam 🪵",["Move to a city 🏙️","Go to sleep 😴"],"Beavers are good builders, so they will try to fix it.")]},
 {pic:"🦫🦫🦫🪵",text:"Benny's whole family gets to work. Papa Beaver cuts sticks with his sharp teeth. Mama Beaver pushes mud with her paws. Benny's big sister carries small rocks. Benny is little, but he wants to help. He drags little sticks to the hole. He packs them in tight with mud. \"I can help too!\" he says.",
  qs:[f("What does Papa Beaver cut sticks with?","His sharp teeth 🦷",["His tail","A saw 🪚"],"Papa Beaver cuts sticks with his sharp teeth."),
      t("How does Benny feel about the work?","He wants to help 💪",["He is bored 🥱","He is angry 😠"],"Benny is little, but he wants to help.")]},
 {pic:"🦫😊🏞️",text:"By night time, the hole is gone. The water stops rushing out. Slowly, the pond fills up again. The lodge is safe! Benny swims a happy loop around the pond. \"We did it together,\" says Papa Beaver. Mama gives Benny a big hug. Benny smiles. Even small helpers can do big jobs.",
  qs:[f("What happens to the pond?","It fills up again 💧",["It dries up ☀️","It turns to ice ❄️"],"Slowly, the pond fills up again."),
      t("What is the lesson of the story?","Small helpers can do big jobs",["Storms are fun","Beavers cannot swim"],"Benny is little, but his help made a big difference.")]}
],turn:{q:"What animal home would you like to build? Write one or two sentences.",model:"I would like to build a lodge with sticks. It would be cosy in the winter."}},
/* 2 NON-FICTION */
{title:"Animal Homes",e:"🏠",kind:"Non-fiction",pages:[
 {pic:"🐝🍯",text:"Animals need homes, just like people. A home keeps animals safe and dry. It is a place to rest and raise babies. Honeybees live in a hive. A hive has many small rooms with six sides. The bees make honey and keep it in those rooms. Thousands of bees can live in one hive!",
  qs:[f("Where do honeybees live?","In a hive 🐝",["In a den 🐻","In a burrow 🕳️"],"Honeybees live in a hive."),
      f("How many sides do the rooms in a hive have?","Six",["Three","Ten"],"A hive has many small rooms with six sides.")]},
 {pic:"🐇🕳️",text:"Some animals dig a home under the ground. This home is called a burrow. It is dark and quiet down there. Rabbits dig burrows with their strong front paws. A burrow has long tunnels and little rooms. It stays cool in summer and warm in winter. Foxes, some owls and even some turtles use burrows too.",
  qs:[f("What is a burrow?","A home under the ground 🕳️",["A home in a tree 🌳","A home on the ice ❄️"],"Some animals dig a home under the ground. It is called a burrow."),
      t("Why is a burrow a good home in summer?","It stays cool 😎",["It is very hot 🔥","It is full of water 💧"],"A burrow stays cool in summer.")]},
 {pic:"🐻🪨",text:"A den is a safe, hidden home. Bears, wolves and foxes use dens. A den can be in a cave. It can be under rocks or tree roots. In winter, many bears sleep in their dens for months. Baby bears, called cubs, are born in the den. They stay inside with their mother until spring.",
  qs:[f("What are baby bears called?","Cubs 🐻",["Joeys 🦘","Tadpoles 🐸"],"Baby bears, called cubs, are born in the den."),
      p("The next page tells about birds. What home will it show?","A nest 🪺",["A hive 🐝","A den 🐻"],"Many birds build nests for their eggs.")]},
 {pic:"🐦🪺",text:"Many birds build nests. They use twigs, grass, mud and even feathers. Some nests sit high up in trees. Some are on cliffs or on the ground. The mother bird lays her eggs in the nest. A parent bird sits on the eggs to keep them warm. Soon, baby birds hatch out!",
  qs:[f("What do birds use to build nests?","Twigs, grass and mud 🌾",["Ice and snow ❄️","Paper and glue 📄"],"They use twigs, grass, mud and even feathers."),
      t("Why does a parent bird sit on the eggs?","To keep them warm 🔥",["To break them","To hide from the sun"],"A parent bird sits on the eggs to keep them warm.")]}
],turn:{q:"Name one animal home and tell who lives there.",model:"A bee lives in a hive with many other bees."}},
/* 3 PATTERNED TEXT */
{title:"Can You Guess Who I Am?",e:"❓",kind:"Pattern book",pages:[
 {pic:"🦒❓",text:"I have a very long neck. I have long legs and brown spots. My tongue is long and dark. I eat leaves from the tops of tall trees. I live on the grassy plains of Africa. Can you guess who I am? Look up high! Yes, I am a giraffe!",
  qs:[f("What does the giraffe eat?","Leaves from tall trees 🌳",["Fish 🐟","Honey 🍯"],"I eat leaves from the tops of tall trees."),
      t("Which question comes again and again?","Can you guess who I am?",["Where is my bag?","What time is it?"],"Every page asks: Can you guess who I am? That is the pattern.")]},
 {pic:"🐧❓",text:"I am a bird, but I cannot fly. I have black and white feathers. My wings are like flippers. I use them to swim fast in the sea. I catch fish to eat. Many of us live in Antarctica, where it is icy and cold. Can you guess who I am? Yes, I am a penguin!",
  qs:[f("How does the penguin use its wings?","To swim fast 🏊",["To fly high ✈️","To dig a hole"],"My wings are like flippers. I use them to swim fast in the sea."),
      f("Where do many penguins live?","Antarctica ❄️",["Africa 🌍","In a desert 🏜️"],"Many of us live in Antarctica, where it is icy and cold.")]},
 {pic:"🦘❓",text:"I have big back legs and a long, strong tail. I hop, hop, hop to get around. I eat grass and leaves. My baby is called a joey. It rides in a pouch on my tummy. I live in Australia. Can you guess who I am? Hop to it! Yes, I am a kangaroo!",
  qs:[f("Where does the baby ride?","In a pouch 👜",["On a leaf 🍃","In a nest 🪺"],"My baby is called a joey. It rides in a pouch on my tummy."),
      p("What do you think the next page will be?","One more animal riddle ❓",["The end of all animals","A cake recipe 🍰"],"Each page has a new riddle, so the next page will too.")]},
 {pic:"🐘❓",text:"I am the biggest kind of animal on land. I have big ears and grey skin. My long nose is called a trunk. I use my trunk to drink water and pick up food. Some of us have long white tusks. I live in Africa and Asia. Can you guess who I am? Yes, I am an elephant!",
  qs:[f("What is the elephant's long nose called?","A trunk 🐘",["A tail","A tusk"],"My long nose is called a trunk."),
      t("Which animal in this book can hop?","The kangaroo 🦘",["The elephant 🐘","The penguin 🐧"],"The kangaroo says: I hop, hop, hop to get around.")]}
],turn:{q:"Write your own animal riddle. End with: Can you guess who I am?",model:"I have black and white stripes. Can you guess who I am?"}},
/* 4 SEQUENCE TEXT */
{title:"How a Frog Grows",e:"🐸",kind:"Sequence text",pages:[
 {pic:"🐸🥚💧",text:"Do you know how a frog grows? It changes a lot! First, a mother frog lays eggs in a pond. The eggs are soft and like jelly. Many eggs float together in a big clump. Each egg has a tiny black dot inside. That dot will grow into a baby frog.",
  qs:[f("Where does the mother frog lay her eggs?","In a pond 💧",["In a tree 🌳","In a nest 🪺"],"First, a mother frog lays eggs in a pond."),
      f("What are the eggs like?","Soft, like jelly",["Hard and white","Hot and dry"],"The eggs are soft and like jelly.")]},
 {pic:"🥚➡️〰️",text:"Next, the eggs hatch. Out come tiny tadpoles! A tadpole looks like a little fish. It has a long tail for swimming. It breathes under the water with gills, like a fish. Tadpoles eat tiny green plants in the pond. They eat and grow bigger every day. Soon, they are ready to change.",
  qs:[f("What hatches out of the eggs?","Tadpoles",["Ducklings 🐥","Snakes 🐍"],"Next, the eggs hatch. Out come tiny tadpoles!"),
      t("Why does a tadpole need a long tail?","To swim 🏊",["To eat","To climb trees"],"It has a long tail for swimming.")]},
 {pic:"🦵🦵〰️",text:"Then, the tadpole starts to change. First, it grows two back legs. Next, it grows two front legs. Its tail gets shorter and shorter. Now it is called a froglet. It looks like a small frog with a little tail. It starts to breathe air with lungs. It can leave the water now.",
  qs:[f("Which legs grow first?","The back legs",["The front legs","No legs"],"First, it grows two back legs."),
      p("What will the froglet become?","A frog 🐸",["A fish 🐟","A bird 🐦"],"A froglet is like a small frog, so it will grow into a frog.")]},
 {pic:"🐸🪲",text:"Last, the tail is gone. The froglet is now a grown-up frog! It hops out of the water onto the land. It catches insects with its long, sticky tongue. One day, a female frog will lay eggs of her own. Then the life cycle starts all over again. Egg, tadpole, froglet, frog!",
  qs:[f("What does a frog catch with its tongue?","Insects 🪲",["Leaves 🍃","Rocks 🪨"],"It catches insects with its long, sticky tongue."),
      t("What is the right order?","Egg, tadpole, froglet, frog",["Frog, egg, froglet, tadpole","Tadpole, frog, egg, froglet"],"Egg, tadpole, froglet, frog! Then it starts again.")]}
],turn:{q:"Write the first step of how a frog grows. Start with First.",model:"First, a frog lays eggs in a pond."}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Animals Around the World",e:"🌍",kind:"Children around the world",pages:[
 {pic:"🇰🇪🦓🦁",text:"This is Amara. She lives in Kenya, in Africa. Her family visits a big national park. Amara sees a herd of zebras. Each zebra has its own stripes. No two zebras are the same! She also sees a lion resting in the shade. \"Lions sleep a lot in the day,\" says her dad.",
  qs:[f("Which continent is Kenya in?","Africa 🌍",["Asia 🌏","Europe"],"She lives in Kenya, in Africa."),
      f("What is special about zebra stripes?","No two are the same",["They are all the same","They are green"],"Each zebra has its own stripes. No two zebras are the same!")]},
 {pic:"🇨🇳🐼🎋",text:"This is Wei. He lives in China, in Asia. Wei visits a panda centre in the mountains. Giant pandas are black and white. They eat bamboo for most of the day. A baby panda is very tiny when it is born. It is pink and has almost no fur! Wei thinks pandas look sleepy.",
  qs:[f("What do giant pandas eat?","Bamboo 🎋",["Fish 🐟","Honey 🍯"],"They eat bamboo for most of the day."),
      t("How is a new baby panda different from a grown-up?","It is tiny and pink",["It is huge","It has stripes"],"A baby panda is very tiny. It is pink and has almost no fur!")]},
 {pic:"🇧🇷🦥🌳",text:"This is Lucas. He lives in Brazil, in South America. Lucas lives near the Amazon rainforest. He looks up into the tall trees. A sloth hangs from a branch by its long claws. It moves very, very slowly. A toucan flies by with its big, bright beak. Lucas waves hello.",
  qs:[f("How does the sloth hang from the branch?","By its long claws",["By its tail","By its beak"],"A sloth hangs from a branch by its long claws."),
      p("The next child lives in the far north of Canada. What animal might she see?","A polar bear 🐻‍❄️",["A giraffe 🦒","A toucan"],"Polar bears live in the cold, icy north.")]},
 {pic:"🇨🇦🐻‍❄️❄️",text:"This is Siku. She lives in Churchill, in the north of Canada. Canada is in North America. Every fall, polar bears walk along the shore near her town. They wait for the sea to freeze. Then they go out on the ice to hunt seals. Siku watches them from a safe place. \"They are amazing, but I stay far away,\" she says.",
  qs:[f("What do polar bears hunt on the ice?","Seals 🦭",["Bees 🐝","Zebras 🦓"],"They go out on the ice to hunt seals."),
      t("Why does Siku stay far away from the bears?","Polar bears can be dangerous",["They are tiny","They are made of ice"],"Polar bears are big and strong, so people stay far away.")]}
],turn:{q:"Which animal from this text would you like to see? Tell why.",model:"I would like to see a panda because it eats bamboo."}},
/* 6 REAL-WORLD TEXT */
{title:"Real-world reading: A wildlife park map and an animal card",e:"🗺️",kind:"Real-world text",pages:[
 {pic:"🗺️🦁",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🗺️ MAPLE WILDLIFE PARK · MAP KEY</b><br><span style=\"font-size:22px;line-height:1.8\">🦁 Lion Rock (Africa)<br>🐼 Panda Forest (Asia)<br>🦘 Kangaroo Walk (Australia)<br>🐧 Penguin Pool (Antarctica)<br>🍦 Snack Hut<br>🚻 Washrooms<br>⏰ Open 9:00 to 5:00</span></div>",
  qs:[f("Where can you see the pandas?","Panda Forest 🐼",["Lion Rock 🦁","Snack Hut 🍦"],"🐼 Panda Forest (Asia)."),
      f("When does the park open?","At 9:00 ⏰",["At 5:00","At noon"],"⏰ Open 9:00 to 5:00.")]},
 {pic:"🦭📇",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>📇 ANIMAL CARD: HARBOUR SEAL 🦭</b><br><span style=\"font-size:22px;line-height:1.8\">🏠 Home: cold ocean coasts<br>🍽️ Food: fish<br>👶 Baby: a pup<br>⭐ Fun fact: Seals can sleep in the water!<br>🚫 Please do not feed the animals.</span></div>",
  qs:[f("What is a baby seal called?","A pup 🦭",["A cub 🐻","A joey 🦘"],"👶 Baby: a pup."),
      p("A boy wants to give the seal his sandwich. What will the keeper say?","Please do not feed the animals 🚫",["Give it more!","Feed it candy 🍬"],"🚫 Please do not feed the animals.")]}
],turn:{q:"Write one rule for visitors at a wildlife park.",model:"Please do not feed the animals."}}
],
poems:[
 {title:"The Caterpillar (by Christina Rossetti, from Sing-Song, 1872)",
  lines:["Brown and furry","Caterpillar in a hurry,","Take your walk","To the shady leaf, or stalk,","Or what not,","Which may be the chosen spot.","No toad spy you,","Hovering bird of prey pass by you;","Spin and die,","To live again a butterfly."],
  qs:[f("What colour is the caterpillar?","Brown 🟤",["Green 🟢","Pink 🩷"],"\"Brown and furry / Caterpillar in a hurry.\""),
      f("Which word rhymes with furry?","hurry",["walk","spot"],"Furry and hurry both end in -urry."),
      t("What will the caterpillar become?","A butterfly 🦋",["A toad 🐸","A bird 🐦"],"\"To live again a butterfly.\" A caterpillar spins a cocoon and changes into a butterfly.")]},
 {title:"Who Lives Here?",
  lines:["A bee in a hive says buzz, buzz, buzz.","A fox in a den has a coat of fuzz.","A bird in a nest sings high in a tree.","A seal on the ice dives into the sea.","A rabbit's burrow is under the ground.","A beaver's lodge is a big stick mound.","Big or small, short or tall,","Animals have homes, one and all!"],
  qs:[f("Who lives in a hive?","A bee 🐝",["A fox 🦊","A seal 🦭"],"\"A bee in a hive says buzz, buzz, buzz.\""),
      f("Which word rhymes with tree?","sea",["nest","fuzz"],"Tree and sea both end with the long e sound."),
      t("What is the poem mostly about?","Animal homes 🏠",["Animal food 🍎","The weather ⛅"],"Each line tells where an animal lives.")]}
],
words:[
 {w:"lion",e:"🦁",m:"a big wild cat with a mane",ex:"The lion rests in the shade.",fill:"The ___ has a big, furry mane."},
 {w:"tiger",e:"🐯",m:"a big wild cat with orange and black stripes",ex:"A tiger has orange fur and black stripes.",fill:"The ___ has black stripes."},
 {w:"zebra",e:"🦓",m:"an animal like a horse with black and white stripes",ex:"The zebra runs across the grass.",fill:"A ___ has black and white stripes."},
 {w:"giraffe",e:"🦒",m:"a tall animal with a very long neck",ex:"The giraffe eats leaves from a tall tree.",fill:"The ___ has a very long neck."},
 {w:"elephant",e:"🐘",m:"a huge grey animal with a trunk",ex:"The elephant sprays water with its trunk.",fill:"An ___ has big ears and a trunk."},
 {w:"kangaroo",e:"🦘",m:"an animal from Australia that hops",ex:"The kangaroo hops fast on its back legs.",fill:"A ___ carries her baby in a pouch."},
 {w:"penguin",e:"🐧",m:"a black and white bird that swims",ex:"The penguin dives into the cold sea.",fill:"A ___ cannot fly, but it can swim."},
 {w:"monkey",e:"🐒",m:"a clever animal that climbs trees",ex:"The monkey swings from branch to branch.",fill:"The ___ climbs up the tree."},
 {w:"seal",e:"🦭",m:"a sea animal with flippers and whiskers",ex:"The seal lies on the ice.",fill:"The ___ swims with its flippers."},
 {w:"crocodile",e:"🐊",m:"a big reptile with a long mouth and teeth",ex:"The crocodile floats in the river.",fill:"A ___ has lots of sharp teeth."},
 {w:"fin",e:"🐟",m:"a flat part a fish uses to swim",ex:"The fish moves its fin to swim.",fill:"A shark has a big ___ on its back."},
 {w:"claw",e:"🦀",m:"a sharp, curved nail on an animal's foot",ex:"The crab pinches with its claw.",fill:"The bear has a sharp ___."},
 {w:"tail",e:"🦊",m:"the part at the back end of an animal",ex:"The monkey holds on with its tail.",fill:"The dog wags its ___."},
 {w:"wing",e:"🪽",m:"the part a bird or bug flies with",ex:"The bird flaps its wing.",fill:"A bird flaps each ___ to fly."},
 {w:"beak",e:"🦜",m:"the hard mouth of a bird",ex:"The parrot cracks a nut with its beak.",fill:"The bird picks up a seed with its ___."},
 {w:"paw",e:"🐾",m:"the soft foot of an animal like a bear",ex:"The bear put its paw in the river.",fill:"The cat licks its ___."},
 {w:"horn",e:"🦏",m:"a hard, pointed part on an animal's head",ex:"The rhino has a horn on its nose.",fill:"A rhino has a ___ on its nose."},
 {w:"trunk",e:"🐘",m:"the long nose of an elephant",ex:"The elephant drinks with its trunk.",fill:"An elephant picks up food with its ___."},
 {w:"shell",e:"🐢",m:"a hard cover that keeps an animal safe",ex:"The turtle hides in its shell.",fill:"A snail carries a ___ on its back."},
 {w:"whisker",e:"🐱",m:"a long, stiff hair near an animal's nose",ex:"The seal has a long whisker on its face.",fill:"The cat has a long ___ by its nose."},
 {w:"den",e:"🐻",m:"a hidden home for bears, foxes or wolves",ex:"The bear sleeps in her den all winter.",fill:"The fox cubs play outside the ___."},
 {w:"hive",e:"🐝",m:"a home where many bees live",ex:"The bees fly back to the hive.",fill:"Bees make honey in a ___."},
 {w:"burrow",e:"🕳️",m:"a hole or tunnel an animal digs for a home",ex:"The rabbit hops into its burrow.",fill:"The rabbit digs a ___ under the ground."},
 {w:"nest",e:"🪺",m:"a home a bird builds for its eggs",ex:"The robin has three eggs in her nest.",fill:"The bird builds a ___ in the tree."},
 {w:"web",e:"🕸️",m:"a sticky net a spider makes",ex:"The spider waits in its web.",fill:"A fly is stuck in the spider's ___."},
 {w:"anthill",e:"🐜",m:"a mound of dirt where ants live",ex:"The ants carry crumbs into the anthill.",fill:"Many ants live in the ___."},
 {w:"lodge",e:"🦫",m:"a beaver home made of sticks and mud",ex:"The beaver swims into its lodge.",fill:"Beavers build a ___ in the pond."},
 {w:"dam",e:"🪵",m:"a wall that holds back water",ex:"The beavers fix the dam after the storm.",fill:"The beavers build a ___ across the stream."},
 {w:"hollow",e:"🌳",m:"an empty hole inside a tree",ex:"The owl sleeps in a hollow in the old tree.",fill:"The squirrel hides nuts in a tree ___."},
 {w:"reef",e:"🪸",m:"a sea home made of coral",ex:"Many bright fish swim near the reef.",fill:"Clownfish live near a coral ___."},
 {w:"cub",e:"🐻",m:"a baby bear, lion or tiger",ex:"The lion cub plays with its mother.",fill:"A baby bear is called a ___."},
 {w:"joey",e:"🦘",m:"a baby kangaroo",ex:"The joey peeks out of the pouch.",fill:"A baby kangaroo is called a ___."},
 {w:"tadpole",e:"🐸",m:"a baby frog with a tail that swims",ex:"The tadpole swims in the pond.",fill:"A ___ grows into a frog."},
 {w:"egg",e:"🥚",m:"a round shell that a baby animal hatches from",ex:"The turtle lays an egg in the sand.",fill:"A baby bird hatches from an ___."},
 {w:"hatch",e:"🐣",m:"to break out of an egg",ex:"The baby birds hatch in spring.",fill:"The chicks ___ from their eggs."},
 {w:"hunt",e:"🐆",m:"to look for and catch animals to eat",ex:"Polar bears hunt seals on the ice.",fill:"Lions ___ for their food."},
 {w:"insect",e:"🐞",m:"a small bug with six legs",ex:"A ladybug is an insect.",fill:"An ant is an ___ with six legs."},
 {w:"honey",e:"🍯",m:"a sweet, sticky food that bees make",ex:"Bees make honey in the hive.",fill:"Bears love sweet ___."},
 {w:"bamboo",e:"🎋",m:"a tall, hard grass that pandas eat",ex:"The panda chews on bamboo.",fill:"Giant pandas eat lots of ___."},
 {w:"pouch",e:"👜",m:"a pocket of skin on a mother kangaroo",ex:"The joey rides in its mother's pouch.",fill:"A baby kangaroo rides in a ___."}
],
spelling:[],
facts:[
 {e:"🐝",c:"Honeybees make honey.",t:true,x:"True! Bees make honey from flower nectar and keep it in the hive."},
 {e:"🦒",c:"A giraffe has a very short neck.",t:false,x:"Not true! A giraffe has a very long neck to reach high leaves."},
 {e:"🐧",c:"Penguins can fly high in the sky.",t:false,x:"Not true! Penguins cannot fly. They use their wings to swim."},
 {e:"🦘",c:"A baby kangaroo is called a joey.",t:true,x:"True! A joey grows in its mother's pouch."},
 {e:"🐻‍❄️",c:"Polar bears live in Antarctica.",t:false,x:"Not true! Polar bears live in the far north, in the Arctic. Penguins live in the south."},
 {e:"🐸",c:"A tadpole grows into a frog.",t:true,x:"True! A tadpole grows legs, loses its tail and becomes a frog."},
 {e:"🦓",c:"Every zebra has its own stripe pattern.",t:true,x:"True! No two zebras have the same stripes."},
 {e:"🐘",c:"Elephants use their trunks to drink water.",t:true,x:"True! An elephant sucks water into its trunk, then sprays it into its mouth."},
 {e:"🕷️",c:"A spider is an insect.",t:false,x:"Not true! A spider has eight legs. An insect has six legs."},
 {e:"🐼",c:"Giant pandas eat mostly bamboo.",t:true,x:"True! Bamboo is almost all of a giant panda's food."},
 {e:"🦫",c:"Beavers build lodges with sticks and mud.",t:true,x:"True! Beavers cut sticks with their strong teeth."},
 {e:"🐋",c:"A whale is a fish.",t:false,x:"Not true! A whale is a mammal. It comes up to breathe air."}
],
writing:[
 {e:"🐯",t:"My favourite wild animal",level:"Step 1 · 3 sentences",
  prompt:"Write 3 sentences about a wild animal you like. What does it look like? What can it do? Use a word from the word bank, like tiger, tail or claw.",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b(has|have|can|is|eats?|lives?)\\b","I told something about the animal"]],
  starters:["I like the ","It has ","It can "],
  model:"I like the tiger. It has orange fur and black stripes. It can hunt with its sharp claws."},
 {e:"🦫",t:"An animal home",level:"Step 2 · 4 sentences",
  prompt:"Write 4 sentences about an animal home, like a den, a hive, a nest or a lodge. Who lives there? What is it made of? Where is it?",
  minS:4,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Dd]ens?|[Hh]ives?|[Bb]urrows?|[Nn]ests?|[Ww]ebs?|[Cc]aves?|[Ll]odges?|[Dd]ams?|[Hh]ollows?|[Rr]eefs?|[Pp]ouch)\\b","I named an animal home"]],
  starters:["A ___ lives in a ","It is made of ","It is in ","I think "],
  model:"A beaver lives in a lodge. The lodge is made of sticks and mud. It is in a quiet pond. I think it is a cosy home."},
 {e:"📋",t:"Animal fact report",level:"Step 3 · 5 sentences",
  prompt:"Write an animal fact report in 5 sentences. Pick one wild animal. Tell where in the world it lives (use a capital letter for the place name), what its home is like, what it eats, and one more fact, like what its baby is called.",
  minS:5,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Ll]ives?|[Hh]omes?)\\b","I told where it lives"],["\\b([Ee]ats?|[Ff]ood)\\b","I told what it eats"],["\\b(Africa|Asia|Europe|Antarctica|Australia|America|Canada|China|India|Kenya|Brazil|Arctic|Mexico|Japan|Egypt|Peru|Indonesia|Madagascar)\\b","I named a place with a capital letter"]],
  starters:["___ live in ","Their home is ","They eat ","A baby ___ is called a ","Did you know that "],
  model:"Giant pandas live in China. China is in Asia. Their home is a forest in the mountains. Pandas eat bamboo for most of the day. A baby panda is called a cub."}
]};
UNITS.push(u);

/* ================= PHONICS: LONG E (ee, ea, y) ================= */
const big=e=>`<span style="font-size:44px">${e}</span>`;
/* [word, picture, spelling of long e]; ok:false = the swapped spelling makes a real word, so skip it in "which spelling" */
const LE=[
 ["tree","🌳","ee"],["bee","🐝","ee"],["feet","🦶","ee",0],["cheese","🧀","ee"],["queen","👑","ee",0],["seed","🌱","ee"],["sleep","😴","ee"],["wheel","🛞","ee",0],["teeth","🦷","ee"],["knee","🦵","ee"],["three","3️⃣","ee"],["sweep","🧹","ee"],["reef","🪸","ee"],["green","🟩","ee"],["beetle","🪲","ee"],
 ["seal","🦭","ea"],["leaf","🍃","ea"],["beach","🏖️","ea",0],["peach","🍑","ea"],["eagle","🦅","ea"],["beans","🫘","ea"],["beads","📿","ea"],["wheat","🌾","ea"],["peas","🫛","ea",0],["seat","💺","ea"],["teacher","🧑‍🏫","ea"],["dream","💭","ea"],
 ["happy","😀","y"],["puppy","🐶","y"],["bunny","🐰","y"],["baby","👶","y"],["candy","🍬","y"],["sunny","☀️","y"],["windy","🌬️","y"],["teddy","🧸","y"],["berry","🍓","y"],["party","🎉","y"],["family","👨‍👩‍👧","y"],["city","🏙️","y"],["penny","🪙","y"],["spiky","🦔","y"]
];
const gapOf=(x)=>{const w=x[0],pt=x[2];const k=pt==="y"?w.length-1:w.indexOf(pt);return w.slice(0,k)+"_".repeat(pt.length)+w.slice(k+pt.length)};
const show=s=>`<b style="font-size:28px;letter-spacing:4px">${s.split("").join(" ")}</b>`;
const swapPat=(x,to)=>{const w=x[0],pt=x[2];const k=pt==="y"?w.length-1:w.indexOf(pt);return w.slice(0,k)+to+w.slice(k+pt.length)};
const leWhich=()=>{const pool=LE.filter(x=>x[3]!==0),x=R(pool),r=Math.random();
  const opts=x[2]==="y"?["y","ee","ea"]:["ee","ea"];
  if(r<.45)return mcQ(`${big(x[1])}<br>${show(gapOf(x))}<br>Which letters spell the <b>long e</b> sound?`,x[2],opts.filter(o=>o!==x[2]),`${x[1]} <b>${x[0]}</b> is spelled with <b>${x[2]}</b>.`,x[2]==="y"?"At the end of a longer word, long e is often spelled y.":"Picture the word. Is it ee or ea?");
  if(r<.75){const bad=opts.filter(o=>o!==x[2]).map(o=>swapPat(x,o));return mcQ(`${big(x[1])} Which spelling is correct?`,x[0],bad,`${x[1]} <b>${x[0]}</b> uses <b>${x[2]}</b>.`,"Say the word, then picture how it looks in a book.",{say:x[0]})}
  return mcQ(`How is the <b>long e</b> sound spelled in <b>${x[0]}</b> ${x[1]}?`,x[2],opts.filter(o=>o!==x[2]).concat(x[2]==="y"?[]:["y"]),`In <b>${x[0]}</b>, long e is spelled <b>${x[2]}</b>.`,"Look at the letters that say /ē/.")};
const lePic=()=>{const x=R(LE);
  if(Math.random()<.55)return mcQ(`What is this? ${big(x[1])}`,x[0],SAMPLE(LE.filter(y=>y!==x),2).map(y=>y[0]),`${x[1]} is <b>${x[0]}</b>. It has the long e sound.`,"Say the name of the picture, then read each word.");
  return mcQ(`Which picture shows <b>${x[0]}</b>?`,x[1],SAMPLE(LE.filter(y=>y!==x),2).map(y=>y[1]),`<b>${x[0]}</b> is ${x[1]}.`,"Read the word slowly, then find the picture.",{say:x[0]})};
const leMake=()=>{const x=R(LE);
  return {type:"type",q:`🧩 Complete the word. Type the <b>whole word</b>.<br>${big(x[1])}<br>${show(gapOf(x))}`,a:[x[0]],why:`${x[1]} <b>${x[0]}</b>: the long e is spelled <b>${x[2]}</b>.`,hint:x[2]==="y"?"The last letter says /ē/. It is y.":"Two vowels make the long e sound here: ee or ea."}};
const SHORTE=[["bed","🛏️"],["hen","🐔"],["web","🕸️"],["net","🥅"],["ten","🔟"],["red","🟥"],["leg","🦵"],["egg","🥚"],["jet","✈️"],["vet","🧑‍⚕️"],["pen","🖊️"],["bell","🔔"],["desk","🗄️"],["nest","🪺"],["tent","⛺"],["sled","🛷"],["shell","🐚"],["vest","🦺"],["belt","🪢"],["wet","💦"],["pet","🐕"],["men","👬"],["step","🪜"],["help","🆘"],["sell","🏷️"]];
const PAIRS=[["bed","bead"],["met","meat"],["fed","feed"],["ten","teen"],["step","steep"],["set","seat"],["men","mean"],["net","neat"],["bet","beet"],["wed","weed"],["red","reed"],["sell","seal"],["check","cheek"],["sped","speed"],["pep","peep"],["best","beast"],["bled","bleed"],["stem","steam"]];
const leShort=()=>{const r=Math.random();
  if(r<.5){const long=Math.random()<.5;const w=long?R(LE.filter(x=>!["berry","penny","teddy"].includes(x[0])))[0]:R(SHORTE)[0];
    return mcQ(`Say <b>${w}</b>. Do you hear <b>long e</b> or <b>short e</b>?`,long?"long e, like 🐝 bee":"short e, like 🥚 egg",[long?"short e, like 🥚 egg":"long e, like 🐝 bee"],long?`<b>${w}</b> has long e. The e says its name: /ē/.`:`<b>${w}</b> has short e: /e/, like in egg.`,"Long e says its name. Short e says /e/, like egg.",{say:w})}
  const pr=R(PAIRS);const askLong=Math.random()<.5;
  return mcQ(`Which word has the <b>${askLong?"long e":"short e"}</b> sound?`,askLong?pr[1]:pr[0],[askLong?pr[0]:pr[1]],`<b>${pr[1]}</b> has long e (two vowels). <b>${pr[0]}</b> has short e (one vowel).`,"Long e is often spelled with two letters: ee or ea.")};
const LELIST=G4.sp([["tree","The bird sits in the tree.","t-r-ee"],["bee","A bee can buzz.","b-ee"],["sleep","Bears sleep in the winter.","s-l-ee-p"],["teeth","A crocodile has many teeth.","t-ee-th"],["green","A frog can be green.","g-r-ee-n"],["three","I see three owls.","th-r-ee"],["feet","A frog has webbed feet.","f-ee-t"],["deep","The sea is very deep.","d-ee-p"],["seed","The bird eats a seed.","s-ee-d"],["week","We go to the zoo next week.","w-ee-k"],["seal","The seal swims in the sea.","s-ea-l"],["leaf","A caterpillar eats a leaf.","l-ea-f"],["beak","The bird has a yellow beak.","b-ea-k"],["eagle","The eagle flies high.","ea-gle"],["eat","Pandas eat bamboo.","ea-t"],["sea","Whales live in the sea.","s-ea"],["beach","Crabs walk on the beach.","b-ea-ch"],["dream","I dream about animals.","d-r-ea-m"],["happy","The puppy is happy.","hap-py: y says /ē/"],["bunny","The bunny hops away.","bun-ny: y says /ē/"],["baby","The baby seal is a pup.","ba-by: y says /ē/"],["furry","A bear is big and furry.","fur-ry: y says /ē/"],["sunny","It is a sunny day.","sun-ny: y says /ē/"],["tiny","An ant is tiny.","ti-ny: y says /ē/"]]);

/* ================= GRAMMAR: COMMON AND PROPER NOUNS ================= */
const COMMON=[["dog","🐶"],["city","🏙️"],["country","🗺️"],["river","🏞️"],["girl","👧"],["boy","👦"],["day","📅"],["month","🗓️"],["lake","🏞️"],["ocean","🌊"],["zoo","🦁"],["park","🌳"],["school","🏫"],["teacher","🧑‍🏫"],["bear","🐻"],["cat","🐱"],["town","🏘️"],["street","🛣️"],["continent","🌍"],["mountain","⛰️"],["tiger","🐯"],["friend","🧒"],["doctor","🧑‍⚕️"],["island","🏝️"],["penguin","🐧"],["elephant","🐘"]];
const PROPER=[["Rex","🐶 a dog's name"],["Toronto","🏙️ a city"],["Canada","🇨🇦 a country"],["Kenya","🇰🇪 a country"],["Africa","🌍 a continent"],["Asia","🌏 a continent"],["Monday","📅 a day"],["July","🗓️ a month"],["Lake Ontario","🏞️ a lake"],["Pacific Ocean","🌊 an ocean"],["Amara","👧 a girl's name"],["Mr. Ali","🧑‍🏫 a teacher's name"],["Ms. Lee","👩 a person's name"],["Nile River","🏞️ a river"],["Mount Everest","⛰️ a mountain"],["China","🇨🇳 a country"],["Brazil","🇧🇷 a country"],["Antarctica","🧊 a continent"],["Vancouver","🏙️ a city"],["Friday","📅 a day"],["December","🗓️ a month"],["Wei","👦 a boy's name"],["Siku","👧 a girl's name"],["High Park","🌳 a park in Toronto"],["Benny","🦫 a beaver's name"]];
const CPL={c:"Common noun",p:"Proper noun"};
const cpQ=()=>{const isP=Math.random()<.5;const x=isP?R(PROPER):R(COMMON);
  return mcQ(`Is <b>${x[0]}</b> ${isP?`<span style="color:var(--muted);font-size:15px">(${x[1]})</span>`:x[1]} a <b>common noun</b> or a <b>proper noun</b>?`,isP?CPL.p:CPL.c,[isP?CPL.c:CPL.p],isP?`<b>${x[0]}</b> is a <b>proper noun</b> (${x[1]}). It is a special name, so it starts with a capital letter.`:`<b>${x[0]}</b> is a <b>common noun</b>. It names any ${x[0]}, so it does not need a capital letter.`,"A proper noun is a special name and starts with a capital letter.")};
const cpPick=()=>{const wantP=Math.random()<.5;
  if(wantP){const x=R(PROPER);return mcQ(`Which one is a <b>proper noun</b>?`,x[0],SAMPLE(COMMON,2).map(y=>y[0]),`<b>${x[0]}</b> is a proper noun: a special name with a capital letter.`,"Look for the special name with a capital letter.")}
  const x=R(COMMON);return mcQ(`Which one is a <b>common noun</b>?`,x[0],SAMPLE(PROPER,2).map(y=>y[0]),`<b>${x[0]}</b> is a common noun. It names any ${x[0]}, not a special one.`,"A common noun is not a special name. It has no capital letter.")};
/* [sentence, the proper noun, two common nouns in the sentence] */
const FINDP=[["My cat Luna sleeps all day.","Luna",["cat","day"]],["Amara lives in a big city.","Amara",["city","lives"]],["We saw a lion at the Toronto Zoo.","Toronto Zoo",["lion","saw"]],["The penguins swim near Antarctica.","Antarctica",["penguins","swim"]],["My dog Rex digs in the yard.","Rex",["dog","yard"]],["The bear cub was born in January.","January",["bear","cub"]],["Wei saw a panda in the mountains.","Wei",["panda","mountains"]],["Kangaroos hop across Australia.","Australia",["Kangaroos","hop"]],["Our class went to the park on Friday.","Friday",["class","park"]],["Lucas spotted a sloth in a tree.","Lucas",["sloth","tree"]],["The giraffe lives in Kenya.","Kenya",["giraffe","lives"]],["Siku watches the bears by the sea.","Siku",["bears","sea"]],["Many tigers live in India.","India",["tigers","live"]],["The teacher read a book about Africa.","Africa",["teacher","book"]],["My rabbit Coco eats carrots.","Coco",["rabbit","carrots"]],["Beavers build dams in Canada.","Canada",["Beavers","dams"]],["Ms. Lee showed us a turtle.","Ms. Lee",["turtle","showed"]],["The whale swam in the Pacific Ocean.","Pacific Ocean",["whale","swam"]],["A toucan flew over Brazil.","Brazil",["toucan","flew"]],["We feed the ducks every Sunday.","Sunday",["ducks","feed"]],["Ben has a goldfish named Bubbles.","Bubbles",["goldfish","has"]],["The frog sat by Lake Ontario.","Lake Ontario",["frog","sat"]],["Mei drew a picture of a zebra.","Mei",["picture","zebra"]],["Pandas live in the forests of China.","China",["Pandas","forests"]]];
const findP=()=>{const x=R(FINDP);return mcQ(`${G4.box("Sentence",x[0])}Which word is a <b>proper noun</b>?`,x[1],x[2],`<b>${x[1]}</b> is a proper noun. It is a special name, so it has a capital letter.`,"Find the special name of a person, pet, place, day or month.",{say:x[0]})};
/* [correct sentence, proper noun (one word), a common noun in it] */
const CAPS=[["My dog is named Rex.","Rex","dog"],["We live in Canada.","Canada","live"],["The zebra is from Africa.","Africa","zebra"],["Amara has a pet turtle.","Amara","turtle"],["We go to the zoo on Saturday.","Saturday","zoo"],["The panda lives in China.","China","panda"],["My birthday is in May.","May","birthday"],["Wei likes to draw tigers.","Wei","tigers"],["The seal swims near Vancouver.","Vancouver","seal"],["The kangaroo hops in Australia.","Australia","kangaroo"],["Our teacher is Mr. Ali.","Ali","teacher"],["The camel walks across Egypt.","Egypt","camel"],["The bears wake up in April.","April","bears"],["We saw a moose in Ontario.","Ontario","moose"],["The sloth sleeps in Brazil.","Brazil","sloth"],["My cat Max likes to nap.","Max","cat"],["The eagle flew over Toronto.","Toronto","eagle"],["The baby elephant lives in India.","India","elephant"],["The owl hoots on Tuesday night.","Tuesday","owl"],["Lucas saw a big crocodile.","Lucas","crocodile"],["The penguins live in Antarctica.","Antarctica","penguins"],["My fish is called Goldie.","Goldie","fish"],["The bees buzz in June.","June","bees"],["Siku lives near the bears.","Siku","bears"]];
const lowP=x=>x[0].replace(new RegExp("\\b"+x[1]+"\\b"),x[1].toLowerCase());
const capQ=()=>{const x=R(CAPS),r=Math.random();
  if(r<.55){const s=lowP(x);const first=s.split(" ")[0];
    const others=SAMPLE(s.replace(/[.!?]$/,"").split(" ").slice(1).filter(w=>w!==x[1].toLowerCase()&&w!==x[2]&&w!==first&&!/^[A-Z]/.test(w)&&w.length>1),1);
    return mcQ(`${G4.box("Sentence",s)}Which word needs a <b>capital letter</b>?`,x[1].toLowerCase(),[x[2]].concat(others),`<b>${x[1]}</b> is a proper noun, so it needs a capital letter: ${x[0]}`,"Look for a special name: a person, pet, place, day or month.")}
  const bad1=lowP(x);const bad2=x[0].replace(new RegExp("\\b"+x[2]+"\\b"),cap(x[2]));
  return mcQ(`Which sentence is written correctly?`,x[0],[bad1,bad2],`<b>${x[1]}</b> is a proper noun, so it gets a capital letter. <b>${x[2]}</b> is a common noun, so it does not.`,"Only special names get a capital letter in the middle of a sentence.")};
const MATCH={"city 🏙️":["Toronto","Vancouver","Montreal","Nairobi","Sydney","Tokyo","Paris","Delhi"],"country 🗺️":["Canada","Kenya","China","Brazil","India","Japan","Mexico","Egypt"],"continent 🌍":["Africa","Asia","Europe","Antarctica","North America","South America"],"day 📅":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],"month 🗓️":["January","March","May","July","October","December"],"ocean 🌊":["Pacific Ocean","Atlantic Ocean","Arctic Ocean","Indian Ocean"],"mountain ⛰️":["Mount Everest","Mount Fuji","Mount Kilimanjaro","Mount Logan"],"river 🏞️":["Nile River","Amazon River","Fraser River","Mackenzie River"]};
const matchQ=()=>{const ks=Object.keys(MATCH),k=R(ks),others=SAMPLE(ks.filter(z=>z!==k),2),x=R(MATCH[k]),cn=k.split(" ")[0];
  if(Math.random()<.5)return mcQ(`<b>${x}</b> is a proper noun. Which <b>common noun</b> goes with it?`,k,others,`<b>${x}</b> is the name of a special ${cn}.`,"Ask: what kind of thing is it? A city, a country, a day...?");
  return mcQ(`Which <b>proper noun</b> names a <b>${cn}</b>?`,x,others.map(o=>R(MATCH[o])),`<b>${x}</b> is the name of a ${cn}. The common noun is <b>${cn}</b>; the proper noun is <b>${x}</b>.`,`Which one is a ${cn}?`)};

/* ================= WORD SKILL: ANIMAL BODY PARTS AND HOMES ================= */
const BODY=[
 {q:"🐝 A bee lives in a ___.",o:["hive","den","web"],a:"hive",why:"Bees live together in a hive."},
 {q:"🦫 A beaver lives in a ___.",o:["lodge","hive","nest"],a:"lodge",why:"A beaver lodge is made of sticks and mud."},
 {q:"🐇 A wild rabbit lives in a ___ under the ground.",o:["burrow","nest","reef"],a:"burrow",why:"Rabbits dig burrows under the ground."},
 {q:"🕷️ A spider waits for bugs on its ___.",o:["web","hive","lodge"],a:"web",why:"A spider spins a sticky web."},
 {q:"🐦 A robin lays her eggs in a ___.",o:["nest","burrow","cave"],a:"nest",why:"Birds build nests for their eggs."},
 {q:"🐻 A bear sleeps all winter in a ___.",o:["den","hive","web"],a:"den",why:"A den is a safe, hidden home for a bear."},
 {q:"🐠 Many bright fish live near a coral ___.",o:["reef","den","nest"],a:"reef",why:"A coral reef is a busy home in the sea."},
 {q:"🦇 Bats hang upside down in a dark ___.",o:["cave","nest","pouch"],a:"cave",why:"Many bats sleep in caves."},
 {q:"🦉 An owl can sleep in a tree ___.",o:["hollow","reef","web"],a:"hollow",why:"A hollow is an empty space inside a tree."},
 {q:"🦘 A joey rides in its mother's ___.",o:["pouch","hive","shell"],a:"pouch",why:"A kangaroo has a pouch on her tummy."},
 {q:"🐟 A fish uses its ___ to swim.",o:["fins","beak","horns"],a:"fins",why:"Fins help a fish move and steer."},
 {q:"🦅 An eagle grabs fish with its sharp ___.",o:["claws","fins","whiskers"],a:"claws",why:"An eagle's sharp claws are called talons."},
 {q:"🦜 A parrot cracks nuts with its strong ___.",o:["beak","tail","fin"],a:"beak",why:"A bird's beak is its hard mouth."},
 {q:"🐘 An elephant drinks with its ___.",o:["trunk","horn","shell"],a:"trunk",why:"An elephant's trunk is its long nose."},
 {q:"🐱 A cat feels its way with its long ___.",o:["whiskers","wings","fins"],a:"whiskers",why:"Whiskers help a cat feel where things are."},
 {q:"🐢 A turtle hides inside its ___.",o:["shell","nest","pouch"],a:"shell",why:"A hard shell keeps a turtle safe."},
 {q:"🦋 A butterfly flies with its ___.",o:["wings","fins","paws"],a:"wings",why:"Butterflies have four thin wings."},
 {q:"🦏 A rhino has a ___ on its nose.",o:["horn","beak","fin"],a:"horn",why:"A rhino's horn is hard and pointed."},
 {q:"🐻 A bear has big, furry ___ with claws.",o:["paws","fins","wings"],a:"paws",why:"A paw is the soft foot of an animal like a bear."},
 {q:"🐒 A spider monkey can hang by its ___.",o:["tail","beak","shell"],a:"tail",why:"A spider monkey's strong tail can hold on to branches."},
 {q:"🦈 Which body part does a shark have?",o:["Fins","Wings","Feathers"],a:"Fins",why:"A shark is a fish, so it has fins."},
 {q:"🐦 Which body part does a bird have?",o:["A beak","A trunk","Fins"],a:"A beak",why:"Every bird has a beak."},
 {q:"🪺 Who lives in a nest?",o:["A bird","A fish","A bear"],a:"A bird",why:"Birds build nests."},
 {q:"🕳️ Who lives in a burrow?",o:["A rabbit","A whale","A bee"],a:"A rabbit",why:"Rabbits dig burrows to live in."},
 {q:"🍯 Who lives in a hive?",o:["Bees","Bears","Frogs"],a:"Bees",why:"Bees make honey in their hive."},
 {q:"🪵 Who builds a dam and a lodge?",o:["A beaver","An eagle","A tiger"],a:"A beaver",why:"Beavers build dams and lodges with sticks and mud."},
 {q:"🦀 Which body part does a crab use to pinch?",o:["Its claw","Its tail","Its wing"],a:"Its claw",why:"A crab pinches with its claws."},
 {q:"🐊 Which animal has a long tail and scaly skin?",o:["A crocodile","A bee","A penguin"],a:"A crocodile",why:"A crocodile has scales and a long, strong tail."}
];

/* ================= READING: ANIMAL FACT CARDS ================= */
/* each field: [right answer, wrong, wrong] */
const CARDS=[
 {n:"Lion",e:"🦁",home:["grassy plains","the sea ice","a hive"],food:["meat","bamboo","nectar"],baby:["a cub","a joey","a tadpole"],where:["Africa","Antarctica","the Arctic"]},
 {n:"Giant panda",e:"🐼",home:["mountain forests","the sea ice","a coral reef"],food:["bamboo","fish","seals"],baby:["a cub","a chick","a pup"],where:["China, in Asia","Antarctica","Australia"]},
 {n:"Kangaroo",e:"🦘",home:["grassland and bush","the sea ice","a coral reef"],food:["grass and leaves","fish","seals"],baby:["a joey","a cub","a chick"],where:["Australia","Antarctica","the Arctic"]},
 {n:"Emperor penguin",e:"🐧",home:["the ice and the sea","a tree hollow","a hot desert"],food:["fish","bamboo","grass"],baby:["a chick","a joey","a cub"],where:["Antarctica","Africa","the Arctic"]},
 {n:"Polar bear",e:"🐻‍❄️",home:["the sea ice","rainforest trees","a hive"],food:["seals","bamboo","grass"],baby:["a cub","a joey","a tadpole"],where:["the Arctic","Antarctica","Australia"]},
 {n:"Beaver",e:"🦫",home:["a lodge in a pond","a hive","the sea ice"],food:["bark and plants","seals","fish"],baby:["a kit","a joey","a chick"],where:["Canada","Antarctica","Australia"]},
 {n:"Giraffe",e:"🦒",home:["grassy plains","the sea ice","a burrow"],food:["leaves from tall trees","fish","seals"],baby:["a calf","a joey","a chick"],where:["Africa","Antarctica","the Arctic"]},
 {n:"Bald eagle",e:"🦅",home:["a big nest high in a tree","a burrow","a coral reef"],food:["fish","bamboo","grass"],baby:["an eaglet","a cub","a joey"],where:["Canada and the United States","Antarctica","Australia"]},
 {n:"Harbour seal",e:"🦭",home:["cold ocean coasts","a tree hollow","a hot desert"],food:["fish","bamboo","grass"],baby:["a pup","a joey","a chick"],where:["the coasts of Canada","the Sahara Desert","the middle of Australia"]},
 {n:"Red fox",e:"🦊",home:["a den","a coral reef","the sea ice"],food:["mice, bugs and berries","bamboo","seals"],baby:["a kit","a joey","a tadpole"],where:["Canada and many other places","Antarctica","only in the sea"]},
 {n:"African elephant",e:"🐘",home:["grassland and forest","the sea ice","a burrow"],food:["grass, leaves and fruit","fish","seals"],baby:["a calf","a joey","a chick"],where:["Africa","Antarctica","the Arctic"]},
 {n:"Koala",e:"🐨",home:["eucalyptus trees","the sea ice","a burrow"],food:["eucalyptus leaves","fish","meat"],baby:["a joey","a cub","a chick"],where:["Australia","Antarctica","the Arctic"]}
];
const card=()=>{const c=R(CARDS);const doc=`<div class="realdoc" style="text-align:left;font-size:20px;line-height:1.8"><b>📇 ANIMAL CARD: ${c.n.toUpperCase()} ${c.e}</b><br>🏠 Home: ${c.home[0]}<br>🍽️ Food: ${c.food[0]}<br>👶 Baby: ${c.baby[0]}<br>🌍 Where: ${c.where[0]}</div>`;
  const k=R(["home","food","baby","where"]);const Q={home:"Where is its <b>home</b>?",food:"What does it <b>eat</b>?",baby:"What is its <b>baby</b> called?",where:"Where in the <b>world</b> does it live?"};
  const IC={home:"🏠 Home",food:"🍽️ Food",baby:"👶 Baby",where:"🌍 Where"};
  return mcQ(`${doc}${Q[k]}`,c[k][0],c[k].slice(1),`The card says: ${IC[k]}: <b>${c[k][0]}</b>.`,`Find the line with ${IC[k]}.`)};

/* ================= THINKING: ANIMAL DETECTIVE ================= */
const DET=[
 {q:"🐻‍❄️ A polar bear lives where it is very cold. What helps it stay warm?",o:["Thick fur and fat","Big wings","A long trunk"],a:"Thick fur and fat",why:"Thick fur and a layer of fat keep polar bears warm."},
 {q:"🐫 A camel lives in a hot, dry desert. What can it do?",o:["Go a long time without water","Swim under ice","Fly over sand"],a:"Go a long time without water",why:"Camels can go many days without drinking."},
 {q:"🦓 Why do zebras live in big groups?",o:["To stay safe from lions","To keep the grass short","To build nests"],a:"To stay safe from lions",why:"In a big herd, more eyes can watch for danger."},
 {q:"🐢 A turtle sees a fox. What will it most likely do?",o:["Hide in its shell","Fly away","Climb a tree fast"],a:"Hide in its shell",why:"A turtle's shell keeps it safe."},
 {q:"🦎 A chameleon can change colour. How does this help it?",o:["It can hide","It can fly","It can swim faster"],a:"It can hide",why:"Changing colour helps a chameleon blend in."},
 {q:"🐿️ It is fall. Why does a squirrel hide nuts?",o:["To eat in winter","To make a nest","To play a game"],a:"To eat in winter",why:"Squirrels save food for the cold months."},
 {q:"🦉 Owls hunt at night. What helps them?",o:["Big eyes and good ears","A long trunk","Fins"],a:"Big eyes and good ears",why:"Owls see and hear very well in the dark."},
 {q:"🐧 Penguins cannot fly. How do they get food?",o:["They swim and catch fish","They pick fruit","They dig for roots"],a:"They swim and catch fish",why:"Penguins are great swimmers."},
 {q:"🦒 Why is a long neck useful for a giraffe?",o:["It reaches high leaves","It helps it swim","It keeps it warm"],a:"It reaches high leaves",why:"Giraffes eat leaves from tall trees."},
 {q:"🐝 A bee lands on a flower. What is it looking for?",o:["Nectar","Fish","Sticks"],a:"Nectar",why:"Bees drink nectar and use it to make honey."},
 {q:"🦫 Why do beavers build a dam?",o:["To make a deep pond","To catch birds","To dry up the river"],a:"To make a deep pond",why:"A deep pond keeps the beaver lodge safe."},
 {q:"🐸 A tadpole has gills. Where does it live?",o:["In the water","In a tree","In a desert"],a:"In the water",why:"Gills help it breathe under water."},
 {q:"🐋 A whale comes up to the top of the sea. Why?",o:["To breathe air","To catch birds","To sleep on land"],a:"To breathe air",why:"Whales are mammals, so they breathe air."},
 {q:"🐻 It is winter and food is hard to find. What do many bears do?",o:["Sleep in a den","Fly south","Build a web"],a:"Sleep in a den",why:"Many bears rest in their dens all winter."},
 {q:"🦆 In fall, many birds in Canada fly south. Why?",o:["To find warm places and food","To see the snow","To build igloos"],a:"To find warm places and food",why:"Many birds fly to warmer places for winter."},
 {q:"🐆 A cheetah is the fastest land animal. What helps it hunt?",o:["Its speed","Its shell","Its fins"],a:"Its speed",why:"A cheetah runs very fast to catch food."},
 {q:"🦔 A hedgehog is scared. What does it do?",o:["Rolls into a spiky ball","Spits water","Climbs a tall tree"],a:"Rolls into a spiky ball",why:"Its spikes keep it safe."},
 {q:"🕷️ How does a spider catch flies?",o:["In its sticky web","With a net from a store","With its beak"],a:"In its sticky web",why:"Flies get stuck in the web."},
 {q:"🌍 You see a wild kangaroo hopping. Where are you?",o:["Australia","Canada","Antarctica"],a:"Australia",why:"Wild kangaroos live in Australia."},
 {q:"🐾 You find big paw prints in the snow. Who might have walked here?",o:["A bear","A fish","A bee"],a:"A bear",why:"Bears have big paws, and fish and bees have none."},
 {q:"🧮 A spider has 8 legs. How many legs do 2 spiders have?",o:["16","10","8"],a:"16",why:"8 + 8 = 16."},
 {q:"🧮 A bird lays 4 eggs. 3 eggs hatch. How many eggs have not hatched yet?",o:["1","7","3"],a:"1",why:"4 − 3 = 1."},
 {q:"🧮 Amara sees 5 zebras and 3 giraffes. How many animals does she see?",o:["8","2","7"],a:"8",why:"5 + 3 = 8."},
 {q:"🧮 An insect has 6 legs. How many legs do 2 insects have?",o:["12","8","6"],a:"12",why:"6 + 6 = 12."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["lion","The lion has a big mane.","l-i-on"],["tiger","The tiger has stripes.","ti-ger"],["zebra","A zebra runs fast.","ze-bra"],["giraffe","The giraffe is very tall.","gi-raffe: double f and a quiet e"],["penguin","A penguin can swim.","pen-gu-in"],["monkey","The monkey climbs a tree.","mon-key: ey at the end"],["seal","The seal sits on the ice.","s-ea-l"],["fin","A fish has a fin.","f-i-n"],["claw","The bear has a sharp claw.","cl-aw"],["tail","The fox has a bushy tail.","t-ai-l"],["wing","The bird flaps its wing.","w-i-ng"],["beak","The bird has a long beak.","b-ea-k"],["shell","The snail has a shell.","sh-e-ll: double l"],["nest","The eggs are in the nest.","n-e-s-t"],["lodge","Beavers live in a lodge.","l-o-dge: d-g-e says /j/"],["hive","The bees fly to the hive.","h-i-v-e: the e is quiet"],["burrow","The rabbit digs a burrow.","bur-row: double r"],["insect","An ant is an insect.","in-sect"],["honey","Bees make honey.","hon-ey"],["egg","The bird lays an egg.","e-gg: double g"]]),
 CHOOSE:null,
 DETAIL:[
  ["The Busy Bees","Honeybees live in a hive. Worker bees fly from flower to flower. They bring nectar back to make honey.",[["Where do honeybees live?","In a hive",["In a den","In a cave"]],["Where do worker bees fly?","From flower to flower",["Into the sea","Under the ground"]],["What do they make?","Honey",["Milk","Bread"]]]],
  ["The Sleepy Bear","In fall, the bear eats lots of food. Then it finds a den. It sleeps there all winter long.",[["When does the bear eat lots of food?","In fall",["In summer","At lunch"]],["Where does the bear sleep?","In a den",["In a nest","In a pond"]],["How long does it sleep?","All winter",["One hour","All summer"]]]],
  ["Penguin Dads","Emperor penguins live in Antarctica. The dad holds the egg on his feet. He keeps it warm for about two months.",[["Where do emperor penguins live?","Antarctica",["Africa","Canada"]],["Where does the dad hold the egg?","On his feet",["In his beak","In a nest in a tree"]],["Why does he hold it?","To keep it warm",["To eat it","To hide it from the sun"]]]],
  ["A Clever Crow","Crows are very smart birds. Some crows use sticks as tools. They poke the sticks into holes to get bugs.",[["What kind of animal is a crow?","A bird",["A fish","An insect"]],["What do some crows use as tools?","Sticks",["Rocks","Leaves"]],["Why do they poke sticks into holes?","To get bugs",["To build a dam","To play music"]]]],
  ["Spider Webs","A spider spins a web with silk. The web is very sticky. Flies and other bugs get stuck in it.",[["What does a spider use to spin a web?","Silk",["Mud","Grass"]],["What is the web like?","Very sticky",["Very hot","Very hard"]],["What gets stuck in the web?","Flies and other bugs",["Fish","Birds and bears"]]]],
  ["The Big Blue Whale","The blue whale is the biggest animal on Earth. It lives in the ocean. It eats tiny animals called krill.",[["What is the biggest animal on Earth?","The blue whale",["The elephant","The giraffe"]],["Where does it live?","In the ocean",["In a forest","In a cave"]],["What does it eat?","Krill",["Bamboo","Honey"]]]],
  ["Sea Turtles","A mother sea turtle crawls onto a beach. She digs a hole in the sand. She lays her eggs in the hole.",[["Where does the mother turtle go?","Onto a beach",["Up a tree","Into a cave"]],["What does she dig?","A hole in the sand",["A burrow in the snow","A pond"]],["What does she lay?","Eggs",["Sticks","Leaves"]]]],
  ["Koalas","Koalas live in Australia. They climb eucalyptus trees. They sleep for most of the day.",[["Where do koalas live?","Australia",["Antarctica","Canada"]],["What trees do they climb?","Eucalyptus trees",["Apple trees","Palm trees"]],["What do they do most of the day?","Sleep",["Swim","Run"]]]],
  ["The Snowy Owl","The snowy owl has white feathers. It lives in the cold Arctic. Its white feathers help it hide in the snow.",[["What colour are its feathers?","White",["Red","Black"]],["Where does it live?","In the cold Arctic",["In a hot desert","In the sea"]],["How do the white feathers help?","They help it hide in the snow",["They help it swim","They make it hot"]]]],
  ["Camels","Camels live in hot, dry deserts. They have humps on their backs. A camel can walk a long way without water.",[["Where do camels live?","In hot, dry deserts",["On the sea ice","In a pond"]],["What is on a camel's back?","Humps",["Wings","A shell"]],["What can a camel do?","Walk a long way without water",["Fly over the sand","Swim under ice"]]]],
  ["Baby Joeys","A baby kangaroo is called a joey. A new joey is as small as a bean. It grows inside its mother's pouch.",[["What is a baby kangaroo called?","A joey",["A cub","A kit"]],["How small is a new joey?","As small as a bean",["As big as a dog","As big as a car"]],["Where does it grow?","In its mother's pouch",["In a nest","In a hive"]]]],
  ["Flamingos","Flamingos are pink birds. They often stand on one leg. Their pink colour comes from the food they eat.",[["What colour are flamingos?","Pink",["Blue","Green"]],["How do they often stand?","On one leg",["On their heads","On three legs"]],["Where does their pink colour come from?","The food they eat",["The sun","Pink paint"]]]]
 ],
 MAIN:[
  ["A bird has wings. A bird has a beak. A bird has feathers.","Birds have wings, beaks and feathers.",["A bird has a beak.","Feathers are soft."]],
  ["Bees live in a hive. Bears sleep in a den. Birds lay eggs in a nest.","Animals live in different homes.",["Bees can buzz.","Birds lay eggs."]],
  ["A frog lays eggs. Tadpoles hatch. The tadpoles grow into frogs.","A frog grows from an egg to a tadpole to a frog.",["Frogs are green.","Tadpoles can swim."]],
  ["Lions live in Africa. Pandas live in Asia. Kangaroos live in Australia.","Animals live on different continents.",["Lions are big.","Pandas eat bamboo."]],
  ["Benny's dam broke. His family fixed it with sticks and mud. The pond filled up again.","Benny's family fixed the broken dam.",["Mud is wet.","Ponds have water."]],
  ["A fish has fins. It has gills. It swims in water.","A fish is made to live in water.",["Fins are flat.","Water is wet."]],
  ["A polar bear has thick fur. It has a layer of fat. It lives on the cold ice.","A polar bear's body keeps it warm in the cold.",["Ice is slippery.","Bears have paws."]],
  ["A zebra has stripes. A leopard has spots. A tiger has stripes too.","Some wild animals have stripes or spots.",["Tigers are orange.","Zebras run fast."]],
  ["The elephant uses its trunk to drink. It uses its trunk to smell. It picks up food with its trunk.","An elephant uses its trunk in many ways.",["Elephants are grey.","Elephants drink water."]],
  ["Squirrels hide nuts in fall. Bears eat lots of food. Some birds fly south.","Animals get ready for winter.",["Nuts are hard.","Birds can fly."]],
  ["Penguins cannot fly. They swim very fast. They dive deep to catch fish.","Penguins are great swimmers.",["Fish are slippery.","Penguins are black and white."]],
  ["A turtle has a shell. A hedgehog has spikes. A skunk can make a bad smell.","Animals have ways to stay safe.",["Skunks are black.","Shells are hard."]],
  ["A spider spins a web. Flies get stuck in it. Then the spider eats them.","A spider catches food in its web.",["Flies are small.","Webs are thin."]],
  ["Amara sees zebras. She sees a lion. She sees giraffes eating leaves.","Amara sees many animals in Kenya.",["Lions sleep a lot.","Leaves are green."]],
  ["A cub is a baby bear. A joey is a baby kangaroo. A tadpole is a baby frog.","Baby animals have special names.",["Bears are big.","Frogs can hop."]],
  ["Owls hunt at night. Bats fly at night. Raccoons look for food at night.","Some animals are busy at night.",["Owls hoot.","The moon is bright."]],
  ["Giant pandas eat bamboo. They eat for many hours each day. Bamboo is most of their food.","Giant pandas eat lots of bamboo.",["Pandas are black and white.","Bamboo is green."]],
  ["The beaver cuts trees with its teeth. It drags sticks to the water. It builds a dam and a lodge.","Beavers are busy builders.",["Trees are tall.","Beavers have tails."]],
  ["Camels can go a long time without water. Their wide feet walk on sand. They live in hot deserts.","Camels are made for life in the desert.",["Sand is hot.","Camels have humps."]],
  ["A whale breathes air. It feeds milk to its baby. It is a mammal, not a fish.","A whale is a mammal.",["Whales are big.","The sea is deep."]],
  ["Bees carry pollen from flower to flower. This helps plants make seeds. Bees also make honey.","Bees are helpful insects.",["Flowers are pretty.","Honey is sticky."]],
  ["Siku sees polar bears in the fall. They wait for the sea to freeze. Then they hunt seals on the ice.","Polar bears near Siku's town wait for the ice so they can hunt.",["Seals are grey.","Fall is cold."]],
  ["A giraffe eats leaves. A lion eats meat. A bear eats berries and fish.","Animals eat different foods.",["Lions roar.","Leaves are green."]],
  ["Tree, bee and green have ee. Seal, leaf and beach have ea. Happy and bunny end in y.","Long e can be spelled ee, ea or y.",["Bees are insects.","Bunnies hop."]]
 ],
 FACTS:["A bird has a beak.","Bees make honey.","A spider has eight legs.","An insect has six legs.","A tadpole grows into a frog.","Penguins live in Antarctica.","Kangaroos live in Australia.","A baby bear is called a cub.","Fish breathe with gills.","A giraffe has a long neck.","Pandas eat bamboo.","Beavers build dams.","A whale breathes air.","A turtle has a shell.","Zebras have stripes.","Elephants have trunks.","Polar bears live in the Arctic.","Bats can fly.","A seal has flippers.","Camels live in deserts.","Owls can hunt at night.","A crab has claws.","Birds lay eggs.","Africa is a continent.","Canada is in North America."],
 OPIN:["Pandas are the cutest animals.","Lions are the best animals.","Spiders are scary.","Penguins are funny.","Zebras are prettier than horses.","Bees are annoying.","Frogs are yucky.","Owls are the smartest birds.","Giraffes look silly.","Tigers are more beautiful than lions.","A cave would be a fun home.","Monkeys are the most fun to watch.","Snakes are creepy.","Seals are cuter than walruses.","Honey is the best food.","Elephants are the coolest animals.","Kangaroos are the best jumpers.","Visiting a zoo is boring.","Crocodiles are the scariest animals.","Baby animals are the sweetest.","Butterflies are prettier than moths.","Sloths are lazy.","Parrots are the best pets.","Hedgehogs are adorable.","Whales are more interesting than sharks."],
 SEQ:[["A frog lays eggs","Tadpoles hatch","Tadpoles grow legs","They become frogs"],["A bird builds a nest","She lays eggs","She sits on the eggs","Baby birds hatch"],["A storm breaks the dam","The beavers cut sticks","They fix the hole","The pond fills up"],["The bear eats lots of food","It finds a den","It sleeps all winter","It wakes up in spring"],["A bee finds a flower","It drinks nectar","It flies to the hive","It helps make honey"],["A caterpillar hatches","It eats leaves","It makes a cocoon","It becomes a butterfly"],["A turtle crawls onto the beach","She digs a hole","She lays her eggs","Baby turtles go to the sea"],["Polar bears wait on the shore","The sea freezes","They walk onto the ice","They hunt seals"],["A spider spins a web","A fly lands on it","The fly gets stuck","The spider eats it"],["A joey is born","It crawls into the pouch","It grows and drinks milk","It hops out on its own"],["Pick an animal","Read about it","Write your facts","Share your report"]],
 CE:[["The storm broke the dam, so the pond got low.","the storm broke the dam","the pond got low"],["It was cold, so the bear slept in its den.","it was cold","the bear slept in its den"],["The turtle was scared, so it hid in its shell.","the turtle was scared","it hid in its shell"],["The bee found a flower, so it drank nectar.","the bee found a flower","it drank nectar"],["The sea froze, so the polar bears went onto the ice.","the sea froze","the polar bears went onto the ice"],["A fly landed on the web, so it got stuck.","a fly landed on the web","it got stuck"],["The fox saw the rabbit, so the rabbit hopped into its burrow.","the fox saw the rabbit","the rabbit hopped into its burrow"],["The mother bird sat on the eggs, so they stayed warm.","the mother bird sat on the eggs","they stayed warm"],["The tadpole grew legs, so it could hop.","the tadpole grew legs","it could hop"],["It was hot, so the lion rested in the shade.","it was hot","the lion rested in the shade"],["The joey was scared, so it jumped into the pouch.","the joey was scared","it jumped into the pouch"],["The hedgehog felt danger, so it rolled into a ball.","the hedgehog felt danger","it rolled into a ball"],["The panda was hungry, so it ate bamboo.","the panda was hungry","it ate bamboo"],["The bees were busy, so the hive was full of honey.","the bees were busy","the hive was full of honey"],["The beavers fixed the dam, so the lodge was safe.","the beavers fixed the dam","the lodge was safe"],["Winter was coming, so the birds flew south.","winter was coming","the birds flew south"],["The giraffe was tall, so it reached the top leaves.","the giraffe was tall","it reached the top leaves"],["The owl heard a mouse, so it flew down.","the owl heard a mouse","it flew down"],["The pond dried up, so the frogs moved away.","the pond dried up","the frogs moved away"],["The seal was tired, so it slept on the ice.","the seal was tired","it slept on the ice"]],
 CMP:[
  ["A bee and a butterfly both have wings. A bee can sting. A butterfly cannot sting.","Both have wings","A bee can sting, but a butterfly cannot",["Both have fins","A butterfly can sting"]],
  ["A lion and a tiger are both big cats. A lion has a mane. A tiger has stripes.","Both are big cats","A lion has a mane, but a tiger has stripes",["Both are birds","A tiger has a mane"]],
  ["A penguin and an eagle are both birds. A penguin swims. An eagle flies high.","Both are birds","A penguin swims, but an eagle flies high",["Both are fish","A penguin flies high"]],
  ["A frog and a fish can both swim. A frog can hop on land. A fish must stay in water.","Both can swim","A frog can hop on land, but a fish must stay in water",["Both can fly","A fish can hop on land"]],
  ["A den and a burrow are both animal homes. A den can be in a cave. A burrow is dug under the ground.","Both are animal homes","A den can be in a cave, but a burrow is dug under the ground",["Both are made by bees","A burrow is in the sky"]],
  ["A polar bear and a penguin both live in icy places. Polar bears live in the north. Penguins live in the south.","Both live in icy places","Polar bears live in the north, but penguins live in the south",["Both live in deserts","Penguins live in the north"]],
  ["A kangaroo and a koala both have pouches. A kangaroo hops. A koala climbs trees.","Both have pouches","A kangaroo hops, but a koala climbs trees",["Both have fins","A koala hops"]],
  ["A turtle and a snail both have shells. A turtle has four legs. A snail has no legs.","Both have shells","A turtle has four legs, but a snail has no legs",["Both have wings","A snail has four legs"]],
  ["A zebra and a giraffe both live in Africa. A zebra has stripes. A giraffe has spots.","Both live in Africa","A zebra has stripes, but a giraffe has spots",["Both live in Antarctica","A zebra has spots"]],
  ["A whale and a shark both live in the sea. A whale breathes air. A shark breathes with gills.","Both live in the sea","A whale breathes air, but a shark uses gills",["Both live in trees","A shark breathes air at the top"]],
  ["A cub and a joey are both baby animals. A cub is a baby bear. A joey is a baby kangaroo.","Both are baby animals","A cub is a baby bear, but a joey is a baby kangaroo",["Both are birds","A joey is a baby bear"]],
  ["A spider and an ant are both small. A spider has eight legs. An ant has six legs.","Both are small","A spider has eight legs, but an ant has six",["Both are huge","An ant has eight legs"]]
 ],
 GRP:{"fish":["salmon","shark","trout","tuna","clownfish"],"birds":["eagle","owl","parrot","penguin","robin"],"insects":["ant","bee","beetle","butterfly","ladybug"],"animal homes":["den","hive","nest","burrow","lodge"],"baby animals":["cub","joey","tadpole","kitten","calf"],"animal body parts":["fin","claw","beak","paw","horn"],"continents":["Africa","Asia","Europe","Antarctica","South America"]},
 ANA:[["Cat is to kitten as bear is to ___.","cub",["joey","chick"]],["Kangaroo is to joey as frog is to ___.","tadpole",["calf","cub"]],["Bee is to hive as bird is to ___.","nest",["den","web"]],["Bear is to den as beaver is to ___.","lodge",["hive","nest"]],["Fish is to fin as bird is to ___.","wing",["paw","horn"]],["Elephant is to trunk as bird is to ___.","beak",["tail","fin"]],["Fish is to swim as bird is to ___.","fly",["hop","dig"]],["Kangaroo is to hop as snake is to ___.","slither",["fly","hop"]],["Big is to small as fast is to ___.","slow",["quick","run"]],["Hot is to cold as wet is to ___.","dry",["rain","damp"]],["Lion is to roar as bee is to ___.","buzz",["bark","neigh"]],["Panda is to bamboo as bee is to ___.","nectar",["meat","fish"]],["Penguin is to Antarctica as kangaroo is to ___.","Australia",["Canada","Europe"]],["Spider is to web as rabbit is to ___.","burrow",["nest","reef"]],["Day is to night as up is to ___.","down",["top","high"]],["Tiger is to stripes as giraffe is to ___.","spots",["wings","fins"]],["Spider is to 8 legs as ant is to ___ legs.","6",["8","4"]],["Egg is to chick as tadpole is to ___.","frog",["fish","bird"]],["Bird is to feathers as bear is to ___.","fur",["scales","shell"]],["Fish is to water as camel is to ___.","desert",["ice","sea"]],["Seal is to flipper as bear is to ___.","paw",["fin","wing"]],["Polar bear is to cold as camel is to ___.","hot",["wet","icy"]]],
 SENT:["Amara and I saw a zebra.","Wei lives in China.","I saw a seal in Vancouver.","Lucas lives in Brazil.","Siku saw a polar bear.","My dog Rex can swim.","Benny is a beaver.","We went to the zoo on Monday.","I like the lions at the Toronto Zoo.","Mei and I saw a frog.","Kangaroos live in Australia.","Penguins swim near Antarctica.","Can Ali come to see the tigers?","My cat Luna sleeps all day.","I read a book about Africa.","Ben saw a moose in Ontario.","Is Mr. Ali our guide today?","The bees wake up in April.","Kofi and I found a nest.","Elephants live in Africa and Asia."],
 ORDER:["The bee is busy.","A fish has fins.","The bear is sleeping.","Birds build nests.","The frog can hop.","A seal can swim.","Bees make honey.","The cub is small.","A tiger has stripes.","The owl hoots at night.","Pandas eat bamboo.","The egg will hatch.","A spider spins a web.","The monkey has a tail.","The eagle has a beak.","A crab has claws.","The zebra runs fast.","The lion can roar.","A turtle has a shell.","Bats sleep in caves."],
 WP:[
  {q:"Write a sentence about a wild animal you like.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I like the giraffe."},
  {q:"Write a sentence about an animal home, like a nest or a den.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Dd]ens?|[Hh]ives?|[Bb]urrows?|[Nn]ests?|[Ww]ebs?|[Cc]aves?|[Ll]odges?|[Hh]ollows?|[Rr]eefs?)\\b","Names an animal home"]],model:"A bird lays eggs in a nest."},
  {q:"Write a sentence about what a panda eats.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Pp]andas?\\b","Uses the word panda"]],model:"A panda eats bamboo."},
  {q:"Write a sentence with a long e word, like tree, seal or happy.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b\\w*(ee|ea)\\w*\\b|\\b\\w+y\\b","Uses a long e word"]],model:"The seal is happy."},
  {q:"Write a sentence with a <b>proper noun</b>: the name of a pet.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,CHK.name],model:"My dog is named Rex."},
  {q:"Write a sentence with the name of a <b>country</b> or <b>continent</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b(Africa|Asia|Europe|Antarctica|Australia|America|Canada|China|India|Kenya|Brazil|Mexico|Japan|Egypt|Peru|France|Italy|Spain|Pakistan|Nigeria|Ghana|Ethiopia|Iran|Vietnam|Korea|Philippines|Russia|Germany|England|Jamaica|Somalia|Bangladesh)\\b","Names a country or continent with a capital letter"]],model:"Kangaroos live in Australia."},
  {q:"Write a sentence with a <b>common noun</b> and a <b>proper noun</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,CHK.name],model:"My friend Wei has a turtle."},
  {q:"Write a sentence about a baby animal.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Bb]aby|[Cc]ubs?|[Jj]oeys?|[Tt]adpoles?|[Cc]hicks?|[Pp]ups?|[Kk]its?|[Cc]alf|[Kk]ittens?|[Ee]ggs?)\\b","Tells about a baby animal"]],model:"A baby bear is called a cub."},
  {q:"Write a sentence about a body part of an animal.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ff]ins?|[Cc]laws?|[Tt]ails?|[Ww]ings?|[Bb]eaks?|[Pp]aws?|[Hh]orns?|[Tt]runks?|[Ss]hells?|[Ww]hiskers?|[Ff]ur|[Ff]eathers?|[Ss]tripes|[Ss]pots|[Tt]eeth|[Ll]egs?|[Nn]eck)\\b","Names a body part"]],model:"A fish swims with its fins."},
  {q:"Write a question about an animal. End it with <b>?</b>",checks:[CHK.cap,CHK.q,CHK.w3,CHK.I],model:"Can a penguin fly?"},
  {q:"Write a sentence that starts with <b>I saw</b>.",checks:[CHK.end,CHK.w3,["^\\s*I saw\\b","Starts with I saw"]],model:"I saw a frog in the pond."},
  {q:"Write a sentence about what a bee does.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Bb]ees?\\b","Uses the word bee"]],model:"A bee makes honey."},
  {q:"Write a sentence about how a frog grows.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Ff]rogs?|[Tt]adpoles?)\\b","Uses frog or tadpole"]],model:"A tadpole grows into a frog."},
  {q:"Write a sentence about an animal that lives in the cold.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Cc]old|[Ii]ce|[Ii]cy|[Ss]now\\w*|Arctic|Antarctica)\\b","Tells about the cold"]],model:"Polar bears live on the cold ice."},
  {q:"Write a sentence with <b>and</b> that names two animals.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\band\\b","Uses and"]],model:"Lions and zebras live in Africa."},
  {q:"Write a sentence about an animal you saw at a zoo or a park.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I saw a big tiger at the zoo."},
  {q:"Write a sentence that tells how an animal stays safe.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"A turtle hides in its shell."},
  {q:"Write a sentence with your name and the word <b>I</b>.",checks:[CHK.cap,CHK.end,CHK.I,CHK.name,["\\bI\\b","Uses I"]],model:"I am Amara."},
  {q:"Write a sentence about a day of the week. Remember the capital letter!",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\\b","Names a day with a capital letter"]],model:"On Saturday, I went to the zoo."},
  {q:"Write a sentence about what a lion eats.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b[Ll]ions?\\b","Uses the word lion"]],model:"A lion eats meat."}
 ],
 SYN:[["big","large"],["little","small"],["fast","quick"],["happy","glad"],["scared","afraid"],["shout","yell"],["jump","leap"],["tired","sleepy"],["rock","stone"],["start","begin"],["end","finish"],["angry","mad"],["smart","clever"],["shut","close"],["gift","present"],["pick","choose"],["sick","ill"],["quiet","silent"],["kind","nice"],["below","under"]],
 OPP:[["hot","cold"],["wet","dry"],["fast","slow"],["up","down"],["first","last"],["day","night"],["full","empty"],["loud","quiet"],["open","shut"],["in","out"],["push","pull"],["top","bottom"],["tall","short"],["heavy","light"],["sink","float"],["awake","asleep"],["wild","tame"],["young","old"],["front","back"],["near","far"]],
 COMP:[["star","fish"],["jelly","fish"],["gold","fish"],["cat","fish"],["sword","fish"],["butter","fly"],["dragon","fly"],["fire","fly"],["lady","bug"],["bull","frog"],["sea","horse"],["sea","shell"],["bird","house"],["honey","bee"],["bee","hive"],["grass","hopper"],["rattle","snake"],["wood","pecker"],["black","bird"],["blue","bird"],["rain","forest"]]
};
B.CHOOSE=G4.ch([["lion","lyon","lionn"],["tiger","tigar","tieger"],["zebra","zeebra","zebrah"],["giraffe","jiraffe","girafe"],["penguin","pengwin","penguen"],["monkey","munkey","monkee"],["seal","seel","sele"],["fin","fyn","phin"],["claw","clawe","klaw"],["tail","tayl","taile"],["wing","wingg","weing"],["beak","beek","beack"],["shell","shel","shelle"],["nest","nesst","nset"],["lodge","lodj","lodje"],["hive","hyve","hiev"],["burrow","burow","burroe"],["insect","insekt","insectt"],["honey","hunny","honee"],["egg","eg","egge"]],B.SP);

const L={
 lewhich:"Long e says its name: /ē/. It can be spelled <b>ee</b> (🌳 tree), <b>ea</b> (🦭 seal) or <b>y</b> at the end of a longer word (😀 happy).",
 lepic:"Look at the picture and say its name: 🐝 <b>bee</b>. Then find the word that matches.",
 lemake:"Say the picture word and listen for /ē/. Then fill the gap: 🍃 l _ _ f is <b>leaf</b>.",
 leshort:"<b>Long e</b> says its name, like 🐝 b<b>ee</b>. <b>Short e</b> says /e/, like 🥚 <b>e</b>gg. Two vowels (ee, ea) usually make long e: bed → b<b>ea</b>d.",
 lelisten:"Listen for the long e sound. Then choose ee, ea or y: s-ea-l spells <b>seal</b>.",
 cp:"A <b>common noun</b> names any person, place or thing: <i>dog, city</i>. A <b>proper noun</b> is a special name and starts with a capital letter: <i>Rex, Toronto</i>.",
 findp:"A proper noun is the name of a special person, pet, place, day or month. In <i>My cat Luna sleeps</i>, the proper noun is <b>Luna</b>.",
 capq:"Proper nouns always start with a capital letter, even in the middle of a sentence: <i>We live in <b>C</b>anada.</i>",
 match:"Every proper noun has a common noun that goes with it. <b>Toronto</b> is a <i>city</i>. <b>Monday</b> is a <i>day</i>.",
 body:"Animals have special body parts (fin, claw, beak, trunk) and special homes (den, hive, burrow, nest). Example: <i>A bee lives in a hive.</i>",
 card:"An animal card gives facts in short lines. Find the picture clue (🏠, 🍽️, 👶, 🌍), then read that line.",
 det:"Think like a scientist. Ask: where does the animal live, and how does its body help it?"
};
u.review=G4.MIX(cpQ,cpPick,findP,capQ,matchQ,leWhich,leShort,F.vocab(u.words));
u.cats=G4.std(u,{sets:["Wild animals","Animal body parts","Animal homes","Food and growing up"],B,
 reading:[{id:"r_card",t:"Read an animal fact card",learn:L.card,gen:card}],
 vocab:[{id:"v_body",t:"Animal body parts and homes",learn:L.body,gen:F.bank(BODY)}],
 grammar:[{id:"g_cp",t:"Common or proper noun?",learn:L.cp,gen:G4.MIX(cpQ,cpPick)},{id:"g_findp",t:"Find the proper noun",learn:L.findp,gen:findP},{id:"g_capq",t:"Which word needs a capital letter?",learn:L.capq,gen:capQ},{id:"g_match",t:"Match the common noun to the proper noun",learn:L.match,gen:matchQ},{id:"g_mixed",t:"Mixed review: nouns and long e",learn:"Use what you learned about common and proper nouns and the long e sound.",gen:u.review}],
 spelling:[{id:"s_lewhich",t:"Long e: ee, ea or y?",learn:L.lewhich,gen:leWhich},{id:"s_lepic",t:"Long e: picture to word",learn:L.lepic,gen:lePic},{id:"s_lemake",t:"Long e: complete the word",learn:L.lemake,gen:leMake},{id:"s_leshort",t:"Long e or short e?",learn:L.leshort,gen:leShort},{id:"s_lelisten",t:"Long e words: listen and write",learn:L.lelisten,gen:F.listen(LELIST)}],
 thinking:[{id:"t_detect",t:"Animal detective: how do animals live?",learn:L.det,gen:F.bank(DET)}]});
})();
