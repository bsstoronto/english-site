/* ===================== GRADE 4 · SHARED HELPERS ===================== */
const G4=(function(){
const MIX=(...g)=>()=>R(g)();
const rint=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
const box=(t,txt)=>`<div class="qbox" style="margin:0 0 12px;font-size:18px;line-height:1.6;font-weight:400"><b>${t}</b><br>${txt}</div>`;
const detail=D=>()=>{const p=R(D),x=R(p[2]);return mcQ(`${box(p[0],p[1])}${x[0]}`,x[1],x[2],`Look back at the text: the answer is there.`,"Read the text again and find the words.",{say:p[1]+" "+x[0]})};
const main=M=>()=>{const m=R(M);return mcQ(`${box("Read",m[0])}What is the <b>main idea</b>? (What is it mostly about?)`,m[1],m[2],`The main idea is what the whole text is about: <b>${m[1]}</b>`,"Which answer fits ALL the sentences, not just one?",{say:m[0]})};
const factop=(FA,OP)=>()=>{const f=Math.random()<.5;const s=f?R(FA):R(OP);return mcQ(`Is this a <b>fact</b> or an <b>opinion</b>?<br><b>${s}</b>`,f?"Fact":"Opinion",[f?"Opinion":"Fact"],f?"A <b>fact</b> can be checked in a reliable source.":"An <b>opinion</b> is what someone thinks or feels. Others may disagree.","Could you check it? Or is it a belief or feeling? Watch for words like best, worst, should, beautiful.")};
const order=SQ=>()=>{const s=R(SQ),t=R(["first","last","next"]);
  if(t==="first")return mcQ(`What comes <b>FIRST</b>?`,s[0],SAMPLE(s.slice(1),2),`Order: ${s.join(" → ")}`,"What must come before everything else?");
  if(t==="last")return mcQ(`What comes <b>LAST</b>?`,s[s.length-1],SAMPLE(s.slice(0,-1),2),`Order: ${s.join(" → ")}`,"What comes at the very end?");
  const k=Math.floor(Math.random()*(s.length-1));return mcQ(`What comes right <b>AFTER</b> this?<br><b>${s[k]}</b>`,s[k+1],SAMPLE(s.filter((_,i)=>i!==k&&i!==k+1),2),`Order: ${s.join(" → ")}`,"What is the very next step?")};
const cause=CE=>()=>{const c=R(CE),other=R(CE.filter(x=>x!==c));const askCause=Math.random()<.5;
  return mcQ(`${box("Read",c[0])}What is the <b>${askCause?"cause":"effect"}</b>? <span style="color:var(--muted);font-size:15px">(${askCause?"WHY it happened":"WHAT happened"})</span>`,askCause?c[1]:c[2],[askCause?c[2]:c[1],askCause?other[1]:other[2]].filter(z=>z!==(askCause?c[1]:c[2])),`Cause (why): <b>${c[1]}</b>. Effect (what happened): <b>${c[2]}</b>.`,"Look for signal words: because, so, as a result, since, therefore.",{say:c[0]})};
const compare=CM=>()=>{const c=R(CM);const same=Math.random()<.5;
  return mcQ(`${box("Read",c[0])}${same?"How are they <b>alike</b>?":"What is one <b>difference</b>?"}`,same?c[1]:c[2],[same?c[2]:c[1],R(c[3])],same?`Alike: <b>${c[1]}</b>.`:`Different: <b>${c[2]}</b>.`,same?"Look for both, also, similarly.":"Look for but, however, whereas, while.",{say:c[0]})};
const odd=GR=>()=>{const ks=Object.keys(GR);const k=R(ks),k2=R(ks.filter(x=>x!==k));const three=SAMPLE(GR[k],3),o=R(GR[k2].filter(x=>!GR[k].includes(x)));
  return mcQ(`🤔 Which one does NOT belong?`,o,three,`${three.join(", ")} are all ${k}. <b>${o}</b> is not.`,"Find what three of them have in common.")};
const ana=AN=>()=>{const x=R(AN);return mcQ("🔗 "+x[0],x[1],x[2],`${x[0].replace("___","<b>"+x[1]+"</b>")} Think about how the first two words are linked.`,"How are the first two words linked? Use the same link.")};
const fix=SE=>()=>{const s=R(SE);return {type:"type",strict:true,q:`Fix this sentence. Add the capital letters and the end punctuation:<br><b>${breakSentence(s)}</b>`,a:[s],hint:"Capital letter at the start and for proper nouns (names, places, days, months, languages), plus the end mark.",why:`Correct: <b>${s}</b>`}};
const L={
 detail:"Read the passage carefully. The answer is <b>stated in the text</b>, so go back and find the exact words.",
 main:"The <b>main idea</b> is what the whole passage is mostly about. Details support it. Ask: which answer covers <b>every</b> sentence?",
 factop:"A <b>fact</b> can be proved or checked. An <b>opinion</b> tells what someone believes or feels. Signal words for opinions: <i>best, worst, should, beautiful, boring, I think</i>.",
 order:"Events, processes and instructions happen in an <b>order</b>. Signal words: <i>first, next, then, after that, finally, meanwhile</i>.",
 cause:"The <b>cause</b> is <b>why</b> something happened. The <b>effect</b> is <b>what happened</b>. Signal words: <i>because, so, since, as a result, therefore</i>.",
 compare:"<b>Compare</b> = how things are alike (<i>both, also, similarly</i>). <b>Contrast</b> = how they are different (<i>but, however, whereas, while</i>).",
 vocab:"Read the word, say it aloud, read the example, and use it in a sentence of your own.",
 syn:"<b>Synonyms</b> are words with almost the same meaning. Good writers use them to avoid repeating words.",
 opp:"<b>Antonyms</b> are words with opposite meanings.",
 comp:"<b>Compound words</b> join two smaller words to make a new word.",
 fix:"Check every sentence: <b>1.</b> capital letter at the start, <b>2.</b> capitals for proper nouns, <b>3.</b> correct end punctuation.",
 orderW:"Find the word with the capital letter: it usually starts the sentence. Then build: <b>who/what? → did what? → where/when/how?</b>",
 write:"Plan first, then write. Check: capital letters, end marks, complete sentences, and the special skill in the task.",
 spell:"Use <b>Look → Say → Cover → Write → Check</b>. Notice the tricky part of each word.",
 choose:"Say the word slowly in syllables and picture it. Look for the tricky letters.",
 odd:"Three belong to the same group. Find the one that does <b>not</b> belong.",
 ana:"An <b>analogy</b> compares two pairs. Work out how the first pair is linked, then use the <b>same link</b>.",
 review:"These questions come from earlier units in this grade, so you keep everything you learned fresh."
};
/* Build the full skill list for a unit.
   X = {sets:[4 titles], reading:[extra items], vocab:[extra items], grammar:[items], spelling:[items], thinking:[items],
        B:{DETAIL,MAIN,FACTS,OPIN,SEQ,CE,CMP,GRP,ANA,SENT,WP,SYN,OPP,COMP,SP,CHOOSE}} */
function std(u,X){const B=X.B,set=k=>u.words.slice(k*10,k*10+10);
  const rd=u.stories.map((s,i)=>({id:"r_t"+(i+1),t:`${s.kind}: ${s.title.replace(/ \(.*\)$/,"")}`,act:"story",si:i})).concat(u.poems.map((p,i)=>({id:"r_p"+(i+1),t:`Poem: ${p.title.replace(/ \(.*\)$/,"")}${/\(by /.test(p.title)?" ("+p.title.match(/\(by ([^,)]+)/)[1]+")":""}`,act:"poem",pi:i})));
  const before=UNITS.slice(0,UNITS.indexOf(u)).filter(x=>x.grade===u.grade&&x.review);
  return [
   {n:"Reading",e:"📖",items:rd.concat(X.reading||[],[
     {id:"r_detail",t:"Read and find the details",learn:L.detail,gen:detail(B.DETAIL)},
     {id:"r_main",t:"Main idea and supporting details",learn:L.main,gen:main(B.MAIN)},
     {id:"r_factop",t:"Fact or opinion?",learn:L.factop,gen:factop(B.FACTS,B.OPIN)},
     {id:"r_order",t:"Sequence of events",learn:L.order,gen:order(B.SEQ)},
     {id:"r_cause",t:"Cause and effect",learn:L.cause,gen:cause(B.CE)},
     {id:"r_compare",t:"Compare and contrast",learn:L.compare,gen:compare(B.CMP)}])},
   {n:"Vocabulary",e:"🔤",items:[0,1,2,3].map(k=>({id:"v_s"+(k+1),t:X.sets[k],learn:L.vocab,gen:F.vocab(set(k))})).concat(
     [{id:"v_fill",t:"Use the right word in a sentence",learn:L.vocab,gen:F.fill(u.words)}],X.vocab||[],
     [{id:"v_syn",t:"Synonyms",learn:L.syn,gen:F.pairs(B.SYN,"synonym")},{id:"v_opp",t:"Antonyms (opposites)",learn:L.opp,gen:F.pairs(B.OPP,"opposite")}],
     B.COMP?[{id:"v_comp",t:"Compound words",learn:L.comp,gen:MIX(F.compoundJoin(B.COMP),F.compoundPick(B.COMP))}]:[])},
   {n:"Grammar",e:"🧩",items:(X.grammar||[]).concat([
     {id:"g_fix",t:"Fix the sentence (capitals and punctuation)",learn:L.fix,gen:fix(B.SENT)},
     {id:"g_order",t:"Put the words in order",learn:L.orderW,gen:G.order(B.ORDER||B.SENT.filter(x=>(x.match(/\b[A-Z]/g)||[]).length===1&&!/[,'"]/.test(x)))},
     {id:"g_write",t:"Write your own sentences",learn:L.write,gen:F.write(B.WP)}])},
   {n:"Spelling",e:"🎧",items:[{id:"s_unit",t:"Unit words: listen and write",learn:L.spell,gen:F.listen(B.SP)}].concat(X.spelling||[],[
     {id:"s_choose",t:"Choose the correct spelling",learn:L.choose,gen:F.chooseSpelling(B.CHOOSE)},
     {id:"s_missing",t:"Missing letters",learn:L.spell,gen:F.missing(B.SP)}])},
   {n:"Thinking",e:"🧠",items:(X.thinking||[]).concat([
     {id:"t_odd",t:"Odd one out",learn:L.odd,gen:odd(B.GRP)},
     {id:"t_ana",t:"Word links (analogies)",learn:L.ana,gen:ana(B.ANA)}])}]
   .concat(before.length?[{n:"Review earlier units",e:"🔁",items:before.map(x=>({id:"rv_"+x.id,t:`Review: Unit ${x.num} (${x.short||x.title})`,learn:L.review,gen:x.review}))}]:[])
   .concat([{n:"Explore and write",e:"✏️",items:[{id:"x_facts",t:"Did you know? Amazing facts",act:"facts"}].concat(u.writing.map((w,i)=>({id:"x_w"+(i+1),t:`Writing step ${i+1}: ${w.t}`,act:"write",wi:i})))}]);
}
const sp=(list)=>list.map(x=>({w:x[0],s:x[1],tip:x[2]}));
const ch=(list,SP)=>list.map(x=>({w:x[0],bad:[x[1],x[2]],tip:((SP||[]).find(y=>y.w===x[0])||{}).tip}));
const q=(lv)=>(q,a,o,why)=>({lv,q,o:[a].concat(o),a:[a],why});
return {MIX,rint,box,detail,main,factop,order,cause,compare,odd,ana,fix,L,std,sp,ch,f:q("find"),t:q("think"),p:q("predict")};
})();
