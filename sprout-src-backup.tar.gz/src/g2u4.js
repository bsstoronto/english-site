/* ===================== GRADE 2 · UNIT 4 · LET'S MEASURE AND BUILD ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:2,id:"g2_build",num:4,emoji:"📏🧱🏗️",title:"Let's Measure and Build",short:"long o, past -ed, shape words",badge:"🏗️ Super Builder",
stories:[
/* 1 STORY: PROBLEM AND HAPPY ENDING */
{title:"The Wobbly Tower",e:"🗼",kind:"Story",pages:[
 {pic:"🧱🏫",text:"Kofi and Lena are in Grade 2. Today their class has a building day. Each team must build a tall tower. The tower must stand up for one whole minute. Kofi and Lena get a big box of blocks. “Let's make the tallest tower!” says Kofi. They start to stack the blocks.",
  qs:[f("What must each team build?","A tall tower 🗼",["A boat ⛵","A bridge 🌉"],"Each team must build a tall tower."),
      f("How long must the tower stand up?","One minute ⏱️",["One hour","One day"],"The tower must stand up for one whole minute.")]},
 {pic:"😟💥",text:"Kofi and Lena stack the blocks up high. Soon the tower is taller than Lena! But then it starts to shake. It wobbles to the left. It wobbles to the right. Crash! The blocks fall on the floor. Lena looks sad. “Our tower is too wobbly,” she says. Kofi picks up a block and thinks hard.",
  qs:[f("What happens to the tower?","It falls down 💥",["It grows taller","It flies away"],"Crash! The blocks fall on the floor."),
      p("What will Kofi and Lena do next?","Try again with a new idea 💡",["Go home 🏠","Stop building for good"],"Kofi picks up a block and thinks hard.")]},
 {pic:"💡👩🏽‍🏫",text:"Their teacher, Ms. Rao, comes to help. “Look at the bottom of your tower,” she says. “It is very narrow. A tall tower needs a wide base.” Kofi and Lena try again. They put big blocks on the bottom. They put small blocks on the top. Now the tower looks a bit like a pyramid.",
  qs:[f("What does a tall tower need?","A wide base",["A narrow base","A flag on top"],"“A tall tower needs a wide base.”"),
      t("Why do they put big blocks on the bottom?","To make it strong 💪",["To make it pretty","To make it fall"],"Big blocks make a wide, strong base.")]},
 {pic:"🗼🎉",text:"The new tower is tall and steady. The class counts out loud. “One, two, three…” The tower does not wobble. It stands for one whole minute! Everyone claps. Kofi and Lena smile. “We learned something,” says Lena. “Wide at the bottom makes a tower strong.” Then they measure the tower. It is one metre tall!",
  qs:[f("How tall is the new tower?","One metre 📏",["Ten metres","One centimetre"],"They measure the tower. It is one metre tall!"),
      t("How do Kofi and Lena feel at the end?","Happy and proud 😊",["Sad 😢","Angry 😠"],"Everyone claps, and they smile.")]}
],turn:{q:"Have you ever built a tower? Write one or two sentences about it.",model:"I built a tower with blocks. It was very tall."}},
/* 2 NON-FICTION */
{title:"How Do We Measure?",e:"📏",kind:"Non-fiction",pages:[
 {pic:"📏✏️",text:"We measure to find out how big things are. We can measure how long something is. This is called its length. We use a ruler for short things, like a pencil. A ruler shows centimetres. A new pencil is about 19 centimetres long. For long things, like a room, we use a measuring tape.",
  qs:[f("What do we use to measure short things?","A ruler 📏",["A scale ⚖️","A spoon 🥄"],"We use a ruler for short things, like a pencil."),
      t("What would you use to measure a big room?","A measuring tape",["A tiny ruler","A cup ☕"],"For long things, like a room, we use a measuring tape.")]},
 {pic:"⚖️🍎",text:"We can also find out how heavy something is. We use a scale to weigh things. Put an apple on the scale. The scale shows how heavy the apple is. Heavy things are hard to lift. Light things are easy to lift. A brick is heavy. A feather is light.",
  qs:[f("What do we use to weigh things?","A scale ⚖️",["A ruler 📏","A clock 🕒"],"We use a scale to weigh things."),
      f("Which thing is light?","A feather 🪶",["A brick 🧱","A big rock 🪨"],"A feather is light.")]},
 {pic:"🦒📈",text:"We can measure how tall something is, too. This is called height. Many children measure their height on a wall chart. You stand with your back to the wall. A grown-up makes a mark at the top of your head. Next year, you can measure again. What do you think will happen?",
  qs:[f("What is height?","How tall something is",["How heavy it is","How hot it is"],"How tall something is is called height."),
      p("What will happen when you measure again next year?","You will be taller 📈",["You will be shorter","You will be a giraffe"],"Children grow, so next year you will be taller.")]},
 {pic:"👷🪵",text:"Builders measure all the time. They measure the wood before they cut it. They measure the walls and the windows. If they measure wrong, the pieces will not fit. That is why builders say, “Measure twice, cut once.” It means check your work before you cut.",
  qs:[f("What do builders measure before they cut it?","The wood 🪵",["The sky ☁️","The cat 🐱"],"They measure the wood before they cut it."),
      t("What does “Measure twice, cut once” mean?","Check before you cut ✅",["Cut two times","Never measure"],"It means check your work before you cut.")]}
],turn:{q:"What would you like to measure? Write one or two sentences.",model:"I would like to measure my dog. I think he is very long."}},
/* 3 PATTERNED TEXT */
{title:"Can You Build It?",e:"🏗️",kind:"Pattern book",pages:[
 {pic:"🧱🧱🧱",text:"Can you build a wall? Yes, I can! I stack one brick. I stack two bricks. I put the bricks in a long row. Then I put more bricks on top. Can you build a wall? Yes, I can! My wall is long and low. My cat sits on it.",
  qs:[f("What does the child stack?","Bricks 🧱",["Books 📚","Cups 🥤"],"I stack one brick. I stack two bricks."),
      t("Which words come again and again?","Can you build…? Yes, I can!",["Good night, moon!","Look out below!"],"This question and answer come on every page. That is the pattern.")]},
 {pic:"🗼⬆️",text:"Can you build a tower? Yes, I can! I stack the blocks up, up, up. I put the big blocks at the bottom. My tower is tall and thin. Can you build a tower? Yes, I can! Look at my tower go up! It is taller than my chair.",
  qs:[f("What is the tower like?","Tall and thin",["Short and wide","Round and flat"],"My tower is tall and thin."),
      f("What is the tower taller than?","The chair 🪑",["The house 🏠","The tree 🌳"],"It is taller than my chair.")]},
 {pic:"🌉🚗",text:"Can you build a bridge? Yes, I can! I put two boxes on the floor. I put a long board across the top. My toy car can go over it. Can you build a bridge? Yes, I can! Beep, beep! Over the bridge it goes.",
  qs:[f("What goes over the bridge?","A toy car 🚗",["A real bus 🚌","A big boat ⛵"],"My toy car can go over it."),
      p("What do you think the child will build on the next page?","Something new 🏰",["The same bridge again","Nothing at all"],"Each page shows something new to build.")]},
 {pic:"🏰🚩",text:"Can you build a castle? Yes, I can! I make four tall towers. I make a big gate at the front. I put a flag on the very top. Can you build a castle? Yes, I can! Now it is your turn. What can you build?",
  qs:[f("How many towers does the castle have?","Four 4️⃣",["Two 2️⃣","Ten 🔟"],"I make four tall towers."),
      t("Who is “your turn” for?","You, the reader 👀",["The cat","The bridge"],"The book asks you what you can build.")]}
],turn:{q:"Write your own pattern: Can you build a ___? Yes, I can!",model:"Can you build a house? Yes, I can!"}},
/* 4 HOW-TO */
{title:"How to Build a Paper Bridge",e:"🌉",kind:"How-to text",pages:[
 {pic:"📄📚🪙",text:"Can paper hold up coins? Let's find out! You will build a paper bridge. You need two piles of books. You need one sheet of paper. You need some coins. Ask a grown-up to help you. Put everything on a table. Let's start!",
  qs:[f("What do you need?","Books, paper and coins",["Glue and sticks","Water and soap"],"You need books, one sheet of paper and some coins."),
      p("What do you think the first step will be?","Make two piles of books 📚",["Eat the paper","Paint the coins"],"The books hold up the bridge, so they come first.")]},
 {pic:"1️⃣2️⃣",text:"First, make two piles of books. Each pile must be the same height. Put the piles a little bit apart. Next, lay the flat paper across the gap. Put one coin in the middle. Does the paper bend? Oh no! The paper bends, and the coin falls down.",
  qs:[f("What do you do first?","Make two piles of books",["Fold the paper","Add coins"],"First, make two piles of books."),
      f("What happens to the flat paper?","It bends, and the coin falls",["It flies away","It gets wet"],"The paper bends, and the coin falls down.")]},
 {pic:"3️⃣〰️",text:"Then, pick up the paper. Fold it back and forth, like a fan. Now it has lots of folds. Lay the folded paper across the gap. Put one coin on it. Does it bend now? No! The folds make the paper strong.",
  qs:[f("How do you fold the paper?","Back and forth, like a fan 🪭",["Into a ball","Into a hat"],"Fold it back and forth, like a fan."),
      t("Why does the folded paper hold the coin?","The folds make it strong 💪",["It is wet","It is a new colour"],"The folds make the paper strong.")]},
 {pic:"4️⃣🪙",text:"Last, add more coins, one at a time. Count them as you go. How many coins can your bridge hold? Write the number down. Try again with a new fold if you like. Real bridges use strong shapes, too. Now you are a bridge builder!",
  qs:[f("What do you do last?","Add more coins",["Make piles of books","Throw the paper"],"Last, add more coins, one at a time."),
      t("Why do you write the number down?","To remember it 📝",["To make it heavy","To hide it"],"Writing the number helps you remember how many coins it held.")]}
],turn:{q:"Write one step for building a paper bridge. Start with First, Next, Then or Last.",model:"First, I make two piles of books."}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Amazing Buildings Around the World",e:"🌍",kind:"Children around the world",pages:[
 {pic:"🇪🇬🔺",text:"This is Omar. He lives in Egypt. Near his city, there are very old pyramids. People built them more than 4,000 years ago. They used huge blocks of stone. Each pyramid has a square bottom. Its four sides are triangles. The triangles meet at the top in a point.",
  qs:[f("Where does Omar live?","Egypt 🇪🇬",["Canada 🇨🇦","China 🇨🇳"],"He lives in Egypt."),
      f("What did people use to build the pyramids?","Huge blocks of stone 🪨",["Snow ❄️","Paper 📄"],"They used huge blocks of stone.")]},
 {pic:"🇲🇱🕌",text:"This is Awa. She lives in Djenné, a town in Mali. Her town has a huge mosque made of mud bricks. Rain can wash some of the mud away. So every year, the people fix it together. They spread fresh mud on the walls. It is a big, happy day for the whole town.",
  qs:[f("What is the mosque made of?","Mud bricks 🧱",["Ice 🧊","Glass 🪟"],"Her town has a huge mosque made of mud bricks."),
      t("Why do the people fix the mosque every year?","Rain washes mud away 🌧️",["They are bored","It is too small"],"Rain can wash some of the mud away.")]},
 {pic:"🇨🇦❄️",text:"This is Elisapie. She lives in Nunavut, in the north of Canada. Her grandfather knows how to build an igloo. He cuts blocks of hard snow with a long knife. He stacks them round and round. The blocks lean in at the top. The igloo is shaped like a dome.",
  qs:[f("What does Grandfather cut?","Blocks of hard snow ❄️",["Wood 🪵","Stone 🪨"],"He cuts blocks of hard snow with a long knife."),
      p("Elisapie wants to build an igloo one day. What will she need to learn?","How to cut snow blocks",["How to fly a plane","How to bake bread"],"Her grandfather cuts snow blocks to build an igloo.")]},
 {pic:"🇨🇳🧱",text:"This is Wei. He lives in China. He visits the Great Wall with his family. The wall is very, very long. People built it over hundreds of years. Wei climbs lots and lots of steps. “This wall goes up and down the hills!” he says. His legs are tired, but he is happy.",
  qs:[f("What does Wei visit?","The Great Wall 🧱",["The pyramids 🔺","An igloo ❄️"],"He visits the Great Wall with his family."),
      t("How are the pyramids, the mosque, the igloo and the wall alike?","People built them all 👷",["They are all made of snow","They are all in Canada"],"They are all different, but people built every one.")]}
],turn:{q:"Which building would you like to visit? Write one or two sentences.",model:"I would like to see the pyramids. They are very old and big."}},
/* 6 REAL-WORLD TEXT */
{title:"Real-world reading: Signs, rules and a height chart",e:"🚧",kind:"Real-world text",pages:[
 {pic:"🚧⚠️",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>⚠️ BUILDING SITE ⚠️</b><br><span style=\"font-size:22px;line-height:1.8\">🚫 Keep out! No children.<br>⛑️ Wear a hard hat.<br>🦺 Wear a safety vest.<br>🥾 Wear safety boots.<br>🕳️ Danger: deep hole!</span></div>",
  qs:[f("What must workers wear on their heads?","A hard hat ⛑️",["A sun hat 👒","A crown 👑"],"⛑️ Wear a hard hat."),
      t("Why must children keep out?","It is not safe 🚫",["It is too clean","It is a park"],"A building site has big machines and deep holes.")]},
 {pic:"🧱📜",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🧱 BLOCK CORNER RULES</b><br><span style=\"font-size:22px;line-height:1.8\">⬇️ Build on the floor.<br>📏 Towers no taller than your chin.<br>🙅 Do not knock down a friend's tower.<br>🤝 Share the blocks.<br>🧺 Put the blocks back in the bin.</span></div>",
  qs:[f("Where do you build?","On the floor ⬇️",["On a table","On a chair"],"⬇️ Build on the floor."),
      p("Max knocks down Ana's tower. What will the teacher say?","Do not knock down a friend's tower 🙅",["Knock down more!","Build on the roof!"],"🙅 Do not knock down a friend's tower is a rule.")]},
 {pic:"📏🧒",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>📏 HOW TALL ARE WE? · ROOM 7</b><br><span style=\"font-size:22px;line-height:1.8\">🧒🏽 Amir: 120 cm<br>👧🏻 Bella: 115 cm<br>👦🏿 Tunde: 128 cm<br>👧🏽 Priya: 122 cm</span></div>",
  qs:[f("Who is the tallest?","Tunde 👦🏿",["Bella 👧🏻","Amir 🧒🏽"],"128 cm is the biggest number, so Tunde is the tallest."),
      f("How tall is Bella?","115 cm",["120 cm","128 cm"],"👧🏻 Bella: 115 cm")]},
 {pic:"🧰🏷️",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🧰 OUR CLASS TOOLBOX</b><br><span style=\"font-size:22px;line-height:1.8\">🔨 hammer<br>🪛 screwdriver<br>📏 measuring tape<br>🥽 goggles: put them on first!<br>⚠️ Use tools only with a grown-up.</span></div>",
  qs:[f("What do you put on first?","Goggles 🥽",["A hammer 🔨","A cape 🦸"],"🥽 goggles: put them on first!"),
      t("Who must be with you when you use tools?","A grown-up 🧑",["A baby 👶","Nobody"],"⚠️ Use tools only with a grown-up.")]}
],turn:{q:"Write one safety rule for building.",model:"Always wear a hard hat on a building site."}}
],
poems:[
 {title:"There Was a Crooked Man (a traditional nursery rhyme, more than 150 years old)",
  lines:["There was a crooked man, and he walked a crooked mile,","He found a crooked sixpence against a crooked stile;","He bought a crooked cat, which caught a crooked mouse,","And they all lived together in a little crooked house."],
  qs:[f("What did the crooked man find?","A crooked sixpence 🪙",["A crooked hat 🎩","A straight stick"],"He found a crooked sixpence. A sixpence is an old coin."),
      t("What does crooked mean?","Bent, not straight 〰️",["Very straight","Brand new"],"Crooked things bend and twist. They are not straight."),
      f("Which word rhymes with mouse?","house",["cat","mile"],"Mouse and house both end in -ouse.")]},
 {title:"Up Goes My Tower",
  lines:["One block, two blocks, stack them up high,","Three blocks, four blocks, up to the sky!","Big ones on the bottom, small ones on top,","Five blocks, six blocks… wobble… STOP!","I make the bottom wide and strong,","And now my tower stands all day long!"],
  qs:[f("Where do the big blocks go?","On the bottom ⬇️",["On the top ⬆️","In a box 📦"],"\"Big ones on the bottom, small ones on top.\""),
      f("Which word rhymes with high?","sky",["top","strong"],"High and sky both end with the long i sound."),
      t("Why does the child say STOP?","The tower starts to wobble",["It is time for bed","The blocks are hungry"],"\"Wobble… STOP!\" The tower is not steady yet.")]}
],
words:[
 {w:"scale",e:"⚖️",m:"a tool that shows how heavy things are",ex:"I stand on the scale.",fill:"Put the apples on the ___ to weigh them."},
 {w:"weigh",e:"🍎⚖️",m:"to find out how heavy something is",ex:"We weigh the pumpkin.",fill:"Let's ___ the box on the scale."},
 {w:"heavy",e:"🐘",m:"hard to lift because it weighs a lot",ex:"The bag of rocks is heavy.",fill:"An elephant is very ___."},
 {w:"light",e:"🪶",m:"easy to lift; not heavy",ex:"A feather is light.",fill:"The empty box is ___, so I can lift it."},
 {w:"height",e:"🦒",m:"how tall something or someone is",ex:"We mark my height on the wall.",fill:"Stand by the wall so we can check your ___."},
 {w:"length",e:"🐍",m:"how long something is from end to end",ex:"What is the length of the table?",fill:"The ruler shows the ___ of the pencil."},
 {w:"metre",alt:["meter"],e:"📏",m:"a length of 100 centimetres",ex:"The door is two metres tall.",fill:"One hundred centimetres make one ___."},
 {w:"kilogram",e:"🏋️",m:"a unit for how heavy things are",ex:"This bag of rice weighs one kilogram.",fill:"The big bag of flour weighs one ___."},
 {w:"wide",e:"↔️",m:"far from one side to the other",ex:"The river is very wide.",fill:"The door is ___, so the big table fits."},
 {w:"narrow",e:"🤏",m:"thin; not far from side to side",ex:"The path is narrow.",fill:"The ___ path only fits one person."},
 {w:"dome",e:"🕌",m:"a round roof shaped like half a ball",ex:"The building has a gold dome.",fill:"An igloo is shaped like a ___."},
 {w:"arch",e:"🌈",m:"a curved shape over a door or path",ex:"We walk under the stone arch.",fill:"The bridge has a curved ___ under it."},
 {w:"cone",e:"🍦",m:"a shape with a round bottom and a point",ex:"My ice cream is in a cone.",fill:"The orange traffic ___ has a point on top."},
 {w:"oval",e:"🥚",m:"a shape like an egg",ex:"Our table is an oval.",fill:"An egg is shaped like an ___."},
 {w:"diamond",e:"🔷",m:"a shape with four sides, like a kite",ex:"My kite is a diamond.",fill:"The sign is a ___ with four sides."},
 {w:"column",e:"🏛️",m:"a tall round post that holds up a roof",ex:"The old building has big columns.",fill:"A tall ___ holds up the roof."},
 {w:"pyramid",e:"🔺",m:"a shape with triangle sides that meet at the top",ex:"Omar sees a pyramid in Egypt.",fill:"The ___ has four sides that meet at a point."},
 {w:"roof",e:"🏠",m:"the top part that covers a building",ex:"The rain falls on the roof.",fill:"The bird sits on the ___ of the house."},
 {w:"wall",e:"🧱🧱",m:"a side of a room or a building",ex:"We hang a picture on the wall.",fill:"The builder makes a ___ with bricks."},
 {w:"round",e:"⚪",m:"shaped like a circle or a ball",ex:"A ball is round.",fill:"A wheel is ___, so it can roll."},
 {w:"builder",e:"👷",m:"a person whose job is to build things",ex:"The builder makes a new house.",fill:"The ___ wears a hard hat."},
 {w:"hammer",e:"🔨",m:"a tool for hitting nails",ex:"Dad hits the nail with a hammer.",fill:"Bang, bang! I use a ___ to hit the nail."},
 {w:"saw",e:"🪚",m:"a tool with sharp teeth that cuts wood",ex:"The builder cuts the wood with a saw.",fill:"Cut the board with a ___."},
 {w:"screwdriver",e:"🪛",m:"a tool that turns screws",ex:"Mom fixes the chair with a screwdriver.",fill:"Turn the screw with a ___."},
 {w:"wrench",e:"🔧",m:"a tool that turns nuts and bolts",ex:"I turn the nut with a wrench.",fill:"Use a ___ to make the nut tight."},
 {w:"ladder",e:"🪜",m:"steps you climb to reach high places",ex:"The painter climbs the ladder.",fill:"Climb the ___ to reach the roof."},
 {w:"crane",e:"🏗️",m:"a tall machine that lifts heavy things",ex:"The crane lifts the steel beam.",fill:"A ___ lifts heavy things up high."},
 {w:"bolt",e:"🔩",m:"a thick metal pin that holds things together",ex:"The bolt holds the two pieces together.",fill:"Put a ___ through the holes to hold the wood."},
 {w:"toolbox",e:"🧰",m:"a box to keep tools in",ex:"The hammer is in the toolbox.",fill:"Put the tools back in the ___."},
 {w:"goggles",e:"🥽",m:"glasses that keep your eyes safe",ex:"I wear goggles when I use tools.",fill:"Wear ___ to keep your eyes safe."},
 {w:"brick",e:"🧱",m:"a hard block used to build walls",ex:"The house is made of red bricks.",fill:"The builder puts one ___ on top of another."},
 {w:"tower",e:"🗼",m:"a tall, thin building",ex:"We see a tall tower in the city.",fill:"The ___ is so tall, I can see it from far away."},
 {w:"bridge",e:"🌉",m:"a road or path that goes over water",ex:"We walk over the bridge.",fill:"The car goes over the ___ above the river."},
 {w:"castle",e:"🏰",m:"a big, strong building with towers and walls",ex:"The king lives in a castle.",fill:"The ___ has four towers and a big gate."},
 {w:"skyscraper",e:"🏙️",m:"a very, very tall building in a city",ex:"The skyscraper has 80 floors.",fill:"A ___ is so tall it seems to touch the sky."},
 {w:"temple",e:"🛕",m:"a building where people go to pray",ex:"We visit an old temple in India.",fill:"People go to the ___ to pray."},
 {w:"stadium",e:"🏟️",m:"a big place for sports with many seats",ex:"We watch soccer at the stadium.",fill:"Many people sit in the ___ to watch the game."},
 {w:"tunnel",e:"🚇",m:"a path that goes under the ground",ex:"The train goes through a tunnel.",fill:"The road goes under the hill in a ___."},
 {w:"build",e:"🔨🏠",m:"to make something by putting parts together",ex:"We build a fort with boxes.",fill:"Let's ___ a house with bricks."},
 {w:"stack",e:"🥞",m:"to put things on top of each other",ex:"I stack the cups.",fill:"___ the blocks to make a tower."}
],
spelling:[],
facts:[
 {e:"🔺",c:"The pyramids in Egypt are made of huge blocks of stone.",t:true,x:"True! People built them more than 4,000 years ago."},
 {e:"🪶",c:"A feather is heavier than a brick.",t:false,x:"Not true! A feather is light. A brick is heavy."},
 {e:"📏",c:"100 centimetres make 1 metre.",t:true,x:"True! A metre stick has 100 centimetres on it."},
 {e:"🗼",c:"The CN Tower is in Toronto, Canada.",t:true,x:"True! It is one of the tallest towers in the world."},
 {e:"❄️",c:"An igloo can be built from blocks of snow.",t:true,x:"True! Inuit builders cut blocks of hard snow to make igloos."},
 {e:"🌉",c:"All bridges are made of wood.",t:false,x:"Not true! Bridges can be made of stone, steel, rope or wood."},
 {e:"🔺",c:"A triangle has four sides.",t:false,x:"Not true! A triangle has three sides."},
 {e:"⛑️",c:"Builders wear hard hats to keep their heads safe.",t:true,x:"True! A hard hat protects your head if something falls."},
 {e:"🧱",c:"The Great Wall of China was built in one week.",t:false,x:"Not true! People built it over hundreds of years."},
 {e:"🎲",c:"A cube has 6 flat faces.",t:true,x:"True! Count the faces on a dice: there are 6."},
 {e:"🕌",c:"The Great Mosque in Djenné, Mali, is made of mud bricks.",t:true,x:"True! The people of the town put fresh mud on it every year."},
 {e:"⚖️",c:"A scale is a tool for measuring how long things are.",t:false,x:"Not true! A scale shows how heavy things are. A ruler shows how long."}
],
writing:[
 {e:"🧱",t:"Something I built",level:"Step 1 · 3 sentences",
  prompt:"Write 3 sentences about something you built. What did you build? What did you use? Use a word from the word bank, like tower, bridge or stack.",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Bb]uil[dt]|[Mm]ade|[Ss]tack)","I told what I built or made"]],
  starters:["I built a ","I used ","It was "],
  model:"I built a tower with blocks. I used big blocks at the bottom. It was very tall!"},
 {e:"⚖️",t:"Measure and compare",level:"Step 2 · 4 sentences",
  prompt:"Find two things at home. Write 4 sentences to compare them. Which one is heavy? Which one is light? Which one is longer? Use the word than.",
  minS:4,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\b([Hh]eav|[Ll]ight|[Ll]ong|[Ss]hort|[Tt]all|[Ww]ide|[Nn]arrow|[Bb]ig|[Ss]mall)","I used a size word"],["\\bthan\\b","I compared with than"]],
  starters:["I found a ","The ___ is heavier than the ___.","The ___ is longer than the ___.","The ___ is light, so "],
  model:"I found a book and a pencil. The book is heavier than the pencil. The pencil is longer than my finger. The pencil is light, so it is easy to lift."},
 {e:"🗼",t:"How-to: build it in 5 steps",level:"Step 3 · How-to, 5 steps with order words",
  prompt:"Write how to build something, like a tower, a bridge or a fort. Write 5 steps. Use order words: First, Next, Then, After that, Last.",
  minS:5,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"],["\\bFirst\\b","I used First"],["\\b(Next|Then|After that)\\b","I used Next, Then or After that"],["\\b(Last|Finally)\\b","I used Last or Finally"]],
  starters:["First, get ","Next, ","Then, ","After that, ","Last, "],
  model:"First, get a box of blocks. Next, put big blocks on the floor to make a wide base. Then, stack smaller blocks on top. After that, check that the tower does not wobble. Last, measure your tower with a ruler."}
]};
UNITS.push(u);

/* ================= PHONICS: LONG O (o_e, oa, ow) ================= */
const big=e=>`<span style="font-size:44px">${e}</span>`;
// [word, picture, spelling pattern, a near word that is not the picture]
const LOPIC=[["bone","🦴","o_e","bun"],["rose","🌹","o_e","rise"],["stone","🪨","o_e","stun"],["cone","🍦","o_e","can"],["nose","👃","o_e","nice"],["rope","🪢","o_e","ripe"],["globe","🌍","o_e","glob"],["smoke","💨","o_e","smock"],["home","🏠","o_e","hum"],["hole","🕳️","o_e","hill"],["note","📝","o_e","not"],["phone","📱","o_e","fun"],
 ["boat","⛵","oa","bat"],["coat","🧥","oa","cot"],["goat","🐐","oa","got"],["road","🛣️","oa","rod"],["toad","🐸","oa","tad"],["soap","🧼","oa","sip"],["loaf","🍞","oa","leaf"],["goal","🥅","oa","gull"],
 ["snow","❄️","ow","snap"],["crow","🐦‍⬛","ow","crew"],["bowl","🥣","ow","bell"],["arrow","🏹","ow","army"],["window","🪟","ow","wonder"],["rainbow","🌈","ow","rainy"],["snowman","☃️","ow","snowy"],["pillow","🛌","ow","pill"]];
const LOW={"o_e":["bone","cone","stone","home","hole","pole","note","rope","nose","rose","joke","globe","smoke","phone","hope","robe","code","zone","stove","froze"],
 "oa":["boat","coat","goat","road","toad","load","soap","loaf","oak","foam","float","goal","coal","coach","toast","roast","soak","cloak","throat","moat"],
 "ow":["snow","crow","blow","grow","show","slow","low","tow","throw","glow","flow","mow","bowl","own","window","yellow","arrow","elbow","pillow","shadow"]};
const SPL={"o_e":"o_e (o + magic e)","oa":"oa","ow":"ow"};
const gapOf=(w,k)=>{if(k==="o_e"){const i=w.lastIndexOf("o");return w.split("").map((c,j)=>j===i||j===w.length-1?"_":c).join(" ")}
  const i=w.indexOf(k);return w.split("").map((c,j)=>j===i||j===i+1?"_":c).join(" ")};
const loWhich=()=>{const r=Math.random(),ks=["o_e","oa","ow"];
  if(r<.45){const x=R(LOPIC);return mcQ(`Which spelling fills the gaps? ${big(x[1])}<br><b style="font-size:26px;letter-spacing:5px">${gapOf(x[0],x[2])}</b>`,SPL[x[2]],ks.filter(k=>k!==x[2]).map(k=>SPL[k]),`${x[1]} <b>${x[0]}</b> spells long o with <b>${x[2]}</b>.`,"Say the word. Then picture how it looks in a book.")}
  if(r<.75){const k=R(ks),w=R(LOW[k]),others=ks.filter(z=>z!==k).map(z=>R(LOW[z]));const ref={"o_e":"🦴 bone","oa":"⛵ boat","ow":"❄️ snow"}[k];const pick=R(LOW[k].filter(z=>z!==w&&z!==ref.split(" ")[1]));
    return mcQ(`Which word spells long o the same way as <b>${w}</b>?`,pick,others,`<b>${w}</b> and <b>${pick}</b> both use <b>${k}</b>.`,`Look at the letters that make the long o in ${w}.`)}
  const k=R(ks),w=R(LOW[k]);return mcQ(`How is long o spelled in <b>${w}</b>?`,SPL[k],ks.filter(z=>z!==k).map(z=>SPL[z]),`<b>${w}</b> uses <b>${k}</b> to say long o.`,"Find the letters that say /ō/.")};
const loPic=()=>{const x=R(LOPIC);
  if(Math.random()<.55){const other=R(LOPIC.filter(y=>y!==x&&y[2]!==x[2]))[0];return mcQ(`What is this? ${big(x[1])}`,x[0],[x[3],other],`${x[1]} is <b>${x[0]}</b>. The long o is spelled <b>${x[2]}</b>.`,"Say the picture word slowly. Listen for the long o.")}
  return mcQ(`Which picture shows <b>${x[0]}</b>?`,x[1],SAMPLE(LOPIC.filter(y=>y!==x),2).map(y=>y[1]),`<b>${x[0]}</b> is ${x[1]}.`,"Read the word sound by sound, then find the picture.",{say:x[0]})};
const loMake=()=>{const x=R(LOPIC),shown=gapOf(x[0],x[2]);
  return {type:"type",q:`🧩 Complete the word. Fill the gaps and type the <b>whole word</b>.<br>${big(x[1])}<br><b style="font-size:28px;letter-spacing:6px">${shown}</b>`,a:[x[0]],why:`${x[1]} <b>${x[0]}</b>: long o is spelled <b>${x[2]}</b>.`,hint:x[2]==="o_e"?"Add o in the middle and a quiet e at the end.":x[2]==="oa"?"Two letters go together: o and a.":"Two letters go together: o and w."}};
const SHO=["hop","pot","dog","fox","mop","rod","not","cot","hot","got","top","box","log","frog","sock","rock","clock","stop","pond","job","rob","cod","dot","lot","jog","spot","shop","lock"];
const LONGS=LOW["o_e"].concat(LOW["oa"],LOW["ow"]);
const PAIRS=[["hop","hope"],["not","note"],["rod","rode"],["cod","code"],["rob","robe"],["glob","globe"],["got","goat"],["cot","coat"],["sock","soak"],["cost","coast"],["rod","road"],["clock","cloak"],["mop","moat"],["shop","show"],["blob","blow"],["slot","slow"]];
const LS={long:"long o, like 🦴 bone",short:"short o, like 🐶 dog"};
const loLong=()=>{const r=Math.random();
  if(r<.45){const lg=Math.random()<.55,w=lg?R(LONGS):R(SHO);return mcQ(`Does <b>${w}</b> have a <b>long o</b> or a <b>short o</b>?`,lg?LS.long:LS.short,[lg?LS.short:LS.long],lg?`<b>${w}</b> has long o. The o says its name: /ō/.`:`<b>${w}</b> has short o: /o/, like in dog.`,"Say the word. Does the o say its name?",{say:w})}
  if(r<.75){const x=R(PAIRS),askLong=Math.random()<.5;return mcQ(`Which word has the <b>${askLong?"long":"short"} o</b> sound?`,askLong?x[1]:x[0],[askLong?x[0]:x[1]],`<b>${x[1]}</b> has long o. <b>${x[0]}</b> has short o.`,"Long o says its name. Short o says /o/, like in dog.")}
  const x=R(PAIRS.filter(y=>y[1]===y[0]+"e"));return {type:"type",q:`🪄 Add a magic <b>e</b> to make a long o word:<br><b style="font-size:26px">${x[0]} + e = ?</b>`,a:[x[1]],why:`<b>${x[0]}</b> + e = <b>${x[1]}</b>. The magic e makes the o say its name.`,hint:"Just put an e on the end."}};
const LOLIST=G4.sp([["boat","We sail in a little boat.","b-oa-t"],["coat","Put on your warm coat.","c-oa-t"],["goat","The goat eats grass.","g-oa-t"],["road","The bus goes down the road.","r-oa-d"],["soap","Wash your hands with soap.","s-oa-p"],["toast","I eat toast for breakfast.","t-oa-st"],["float","Can a stone float?","fl-oa-t"],["bone","The dog has a bone.","b-o-n-e: the e is quiet"],["home","I walk home after school.","h-o-m-e: the e is quiet"],["stone","The wall is made of stone.","st-o-n-e: the e is quiet"],["hole","The builder digs a deep hole.","h-o-l-e: the e is quiet"],["note","I write a note to my mom.","n-o-t-e: the e is quiet"],["hope","I hope the tower stands up.","h-o-p-e: the e is quiet"],["globe","Find Egypt on the globe.","gl-o-b-e: the e is quiet"],["snow","An igloo is made of snow.","sn-ow"],["grow","Children grow taller.","gr-ow"],["slow","The crane is slow.","sl-ow"],["throw","Do not throw the blocks.","thr-ow"],["bowl","Mix the mud in a bowl.","b-ow-l"],["yellow","The crane is yellow.","yell-ow"],["window","Look out of the window.","wind-ow"],["show","Show me your tower.","sh-ow"],["load","The truck has a big load.","l-oa-d"],["smoke","Smoke comes out of the chimney.","sm-o-k-e: the e is quiet"]]);

/* ================= GRAMMAR: VERBS NOW AND BEFORE (-ed) ================= */
// [base, he/she form, past, rest of sentence]
const VB=[["stack","stacks","stacked","the blocks"],["paint","paints","painted","the fence"],["fix","fixes","fixed","the chair"],["measure","measures","measured","the table"],["weigh","weighs","weighed","the apples"],["lift","lifts","lifted","the box"],["push","pushes","pushed","the cart"],["pull","pulls","pulled","the wagon"],["climb","climbs","climbed","the ladder"],["fill","fills","filled","the bucket"],["roll","rolls","rolled","the ball"],["count","counts","counted","the bricks"],["mark","marks","marked","the line"],["check","checks","checked","the bridge"],["open","opens","opened","the toolbox"],["clean","cleans","cleaned","the tools"],["test","tests","tested","the tower"],["use","uses","used","a ruler"],["glue","glues","glued","the sticks"],["tape","tapes","taped","the paper"],["help","helps","helped","Grandpa"],["plant","plants","planted","a tree"],["wash","washes","washed","the brush"],["fold","folds","folded","the card"],["visit","visits","visited","the castle"],["watch","watches","watched","the crane"],["nail","nails","nailed","the board"],["look at","looks at","looked at","the map"]];
const NM=["Kofi","Lena","Omar","Awa","Wei","Priya","Max","Ana","Elisapie","Tunde","Mia","Ravi"],PR=["I","We","They","You"];
const subj=()=>Math.random()<.6?{s:R(NM),he:true}:{s:R(PR),he:false};
const lowS=s=>PR.includes(s)&&s!=="I"?s.toLowerCase():s;
const NOW="Now ⏰ (present)",BEF="Before ⏪ (past)";
const nowBefore=()=>{const v=R(VB),x=subj(),past=Math.random()<.5;
  if(Math.random()<.6){const s=`${x.s} ${past?v[2]:(x.he?v[1]:v[0])} ${v[3]}.`;
    return mcQ(`${G4.box("Read",s)}Is this happening <b>now</b>, or did it happen <b>before</b>?`,past?BEF:NOW,[past?NOW:BEF],past?`<b>${v[2]}</b> ends in <b>-ed</b>, so it already happened.`:`<b>${x.he?v[1]:v[0]}</b> has no -ed, so it is happening now.`,"Look at the end of the action word. Does it end in -ed?",{say:s})}
  const pS=`${x.s} ${v[2]} ${v[3]}.`,nS=`${x.s} ${x.he?v[1]:v[0]} ${v[3]}.`;
  return mcQ(`Which sentence tells about the <b>${past?"past (before)":"present (now)"}</b>?`,past?pS:nS,[past?nS:pS],past?`<b>${v[2]}</b> ends in -ed. It tells about the past.`:`<b>${x.he?v[1]:v[0]}</b> tells about now.`,"Past actions often end in -ed.")};
const VB1=VB.filter(v=>!/ /.test(v[0]));
const addEd=()=>{const v=R(VB1),e=/e$/.test(v[0]),r=Math.random();
  if(r<.4)return {type:"type",q:`Add <b>-ed</b> to show it happened before:<br><b style="font-size:24px">${v[0]} → ?</b>`,a:[v[2]],why:e?`<b>${v[0]}</b> ends in e, so just add <b>d</b>: <b>${v[2]}</b>.`:`<b>${v[0]}</b> + ed = <b>${v[2]}</b>.`,hint:e?"It already ends in e. Just add d.":"Add e and d to the end."};
  if(r<.75){const x=subj();return {type:"type",q:`Type the past form of <b>${v[0]}</b>:<br><b>Yesterday, ${lowS(x.s)} ___ ${v[3]}.</b>`,a:[v[2]],why:`Yesterday, ${lowS(x.s)} <b>${v[2]}</b> ${v[3]}.`,hint:e?"It ends in e. Just add d.":"Add -ed to the action word."}}
  const right=v[2],wrong=e?[v[0]+"ed",v[1]]:[v[0]+"d",v[1]];
  return mcQ(`Which word shows that <b>${v[0]}</b> happened <b>before</b>?`,right,wrong,e?`<b>${v[0]}</b> ends in e, so add only <b>d</b>: <b>${right}</b>.`:`Add <b>-ed</b>: <b>${right}</b>.`,"Past words end in -ed.")};
const PASTT=["Yesterday","Last week","Last night","Last Saturday","Two days ago"],NOWT=["Every day","Every morning","On Mondays","Every week","After school each day"];
const verbDay=()=>{const v=R(VB),x=subj(),past=Math.random()<.5,tw=past?R(PASTT):R(NOWT);const pres=x.he?v[1]:v[0],other=x.he?v[0]:v[1];
  const ans=past?v[2]:pres,wr=past?[pres,other]:[v[2],other];
  return mcQ(`Choose the right verb:<br><b>${tw}, ${lowS(x.s)} ___ ${v[3]}.</b>`,ans,wr,past?`<b>${tw}</b> means before, so we use <b>${v[2]}</b>.`:`<b>${tw}</b> tells about now and every day, so we use <b>${pres}</b>.`,past?"Yesterday and last week need -ed.":(x.he?"For one person, like Kofi, add -s or -es.":"For I, we, you and they, use the plain word."),{say:`${tw}, ${lowS(x.s)} blank ${v[3]}.`})};

/* ================= WORD SKILL: SHAPE, SIZE AND COMPARE WORDS ================= */
const DIM={heavy:["heavier","lighter","heaviest","lightest"],tall:["taller","shorter","tallest","shortest"],long:["longer","shorter","longest","shortest"],big:["bigger","smaller","biggest","smallest"],wide:["wider","narrower","widest","narrowest"]};
const CPAIR=[["🐘 elephant","🐭 mouse","heavy"],["🦒 giraffe","🐈 cat","tall"],["🐍 snake","🐛 worm","long"],["🏙️ skyscraper","🏠 house","tall"],["🚌 bus","🚗 car","long"],["🪨 rock","🪶 feather","heavy"],["🍉 watermelon","🍇 grape","heavy"],["🌳 tree","🌷 flower","tall"],["🚂 train","🚲 bike","long"],["🐋 whale","🐟 goldfish","big"],["🚪 door","📱 phone","wide"],["🐻 bear","🐝 bee","heavy"],["🧱 brick","📄 paper","heavy"],["🦕 dinosaur","🦎 lizard","big"],["✏️ pencil","📌 pin","long"],["🧍 grown-up","👶 baby","tall"],["🛏️ bed","📕 book","wide"],["🎃 pumpkin","🫐 blueberry","big"]];
const CTRI=[[["🐜 ant","🐕 dog","🐘 elephant"],"heavy"],[["🌷 flower","🧍 girl","🌳 tree"],"tall"],[["🐛 worm","🐍 snake","🚂 train"],"long"],[["🏠 house","🏰 castle","🏙️ skyscraper"],"tall"],[["🍇 grape","🍎 apple","🍉 watermelon"],"big"],[["🪶 feather","📕 book","🧱 brick"],"heavy"],[["📌 pin","✏️ pencil","📏 metre stick"],"long"],[["🐭 mouse","🐈 cat","🐴 horse"],"big"],[["🚲 bike","🚗 car","🚌 bus"],"long"],[["📱 phone","🚪 door","🏟️ stadium"],"wide"]];
const SHAPEQ=[
 {q:"🕌 A round roof shaped like half a ball is a…",a:"dome",o:["cone","column"],why:"A dome is round like half a ball."},
 {q:"🌈 A curved shape over a door or a path is an…",a:"arch",o:["oval","angle"],why:"An arch curves over the top."},
 {q:"🍦 An ice cream cone has a round top and a point. It is a…",a:"cone",o:["cube","dome"],why:"A cone has a round end and a point."},
 {q:"🥚 An egg shape is called an…",a:"oval",o:["arch","edge"],why:"An oval is shaped like an egg."},
 {q:"🔷 A shape with four sides, like a kite, is a…",a:"diamond",o:["circle","dome"],why:"A diamond has four sides, like a kite."},
 {q:"🏛️ A tall round post that holds up a roof is a…",a:"column",o:["tunnel","cone"],why:"Columns hold up roofs."},
 {q:"🔺 The sides of a pyramid are shaped like…",a:"triangles",o:["circles","ovals"],why:"Each side of a pyramid is a triangle."},
 {q:"⚽ A ball is…",a:"round",o:["flat","square"],why:"A ball is round all over."},
 {q:"🎲 A dice has 6 square faces. It is a…",a:"cube",o:["cone","dome"],why:"A cube has 6 square faces."},
 {q:"🛞 Which shape lets a wheel roll?",a:"round",o:["square","pointy"],why:"Round things roll."},
 {q:"🌉 Which word means not wide?",a:"narrow",o:["heavy","round"],why:"Narrow means thin from side to side."},
 {q:"🐘 Which word means hard to lift?",a:"heavy",o:["light","narrow"],why:"Heavy things are hard to lift."}];
const cmpPair=()=>{const c=R(CPAIR),d=DIM[c[2]],first=Math.random()<.5,word=first?d[0]:d[1];
  return mcQ(`Which one is <b>${word}</b>?<br><span style="font-size:22px">${c[0]} or ${c[1]}</span>`,first?c[0]:c[1],[first?c[1]:c[0]],`The ${(first?c[0]:c[1]).split(" ").slice(1).join(" ")} is <b>${word}</b>.`,"Picture the two things side by side.")};
const cmpTri=()=>{const c=R(CTRI),d=DIM[c[1]],most=Math.random()<.5,word=most?d[2]:d[3];const ans=most?c[0][2]:c[0][0];
  return mcQ(`Which one is the <b>${word}</b>?`,ans,c[0].filter(z=>z!==ans),`Order: ${c[0].join(" → ")}. The ${ans.split(" ").slice(1).join(" ")} is the <b>${word}</b>.`,"Put the three in order in your head.")};
const shapeQ=F.bank(SHAPEQ);
const shapeSize=()=>{const r=Math.random();return r<.4?cmpPair():r<.7?cmpTri():shapeQ()};

/* ================= READING: A MEASURING CHART ================= */
const OBJ=[["✏️","pencil",19],["🖍️","crayon",9],["🥄","spoon",16],["🔑","key",6],["📱","phone",14],["🖌️","paintbrush",22],["📕","book",25],["👟","shoe",27],["🍌","banana",20],["🧦","sock",24],["📎","paper clip",3],["🥢","chopstick",23],["🪥","toothbrush",18],["🥕","carrot",15],["🍴","fork",17],["✂️","pair of scissors",13]];
const mchart=()=>{const s=SAMPLE(OBJ,4),lb=o=>o[0]+" "+o[1];const doc=`<div class="realdoc" style="text-align:left;font-size:20px;line-height:1.8"><b>📏 How long is it?</b><br>${s.map(o=>`${lb(o)}: ${o[2]} cm`).join("<br>")}</div>`;
  const srt=s.slice().sort((a,b)=>a[2]-b[2]),r=Math.random();
  if(r<.22)return mcQ(`${doc}Which one is the <b>longest</b>?`,lb(srt[3]),srt.slice(0,3).map(lb),`${srt[3][2]} cm is the biggest number, so the <b>${srt[3][1]}</b> is the longest.`,"Find the biggest number.");
  if(r<.44)return mcQ(`${doc}Which one is the <b>shortest</b>?`,lb(srt[0]),srt.slice(1).map(lb),`${srt[0][2]} cm is the smallest number, so the <b>${srt[0][1]}</b> is the shortest.`,"Find the smallest number.");
  const a=s[0],b=s[1];
  if(r<.64)return mcQ(`${doc}How long is the <b>${a[1]}</b>?`,a[2]+" cm",s.slice(1).map(o=>o[2]+" cm"),`${lb(a)}: <b>${a[2]} cm</b>`,"Find the word, then read the number next to it.");
  const L1=a[2]>b[2]?a:b,S1=a[2]>b[2]?b:a;
  if(r<.84)return mcQ(`${doc}Which is <b>longer</b>: the ${a[1]} or the ${b[1]}?`,lb(L1),[lb(S1)],`${L1[2]} cm is more than ${S1[2]} cm, so the <b>${L1[1]}</b> is longer.`,"The bigger number is longer.");
  const d=L1[2]-S1[2];return mcQ(`${doc}How much <b>longer</b> is the ${L1[1]} than the ${S1[1]}?`,d+" cm",uniq([(d+2)+" cm",(L1[2]+S1[2])+" cm",(d+1)+" cm"]).filter(z=>z!==d+" cm").slice(0,2),`${L1[2]} − ${S1[2]} = <b>${d} cm</b>`,"Take the small number away from the big number.")};

/* ================= THINKING: BUILDER SMARTS ================= */
const BUILD=[
 {q:"🗼 Your block tower keeps falling down. What can you try?",o:["Make the bottom wider","Put the big blocks on top","Build it on a soft pillow"],a:"Make the bottom wider",why:"A wide base makes a tower steady."},
 {q:"⛑️ Why do builders wear hard hats?",o:["To keep their heads safe","To look taller","To keep their hair dry"],a:"To keep their heads safe",why:"A hard hat protects your head if something falls."},
 {q:"🥽 You will use a saw with a grown-up. What do you put on first?",o:["Goggles","A swimsuit","Mittens"],a:"Goggles",why:"Goggles keep bits of wood out of your eyes."},
 {q:"📏 Which tool tells how long a table is?",o:["A measuring tape","A scale","A hammer"],a:"A measuring tape",why:"A measuring tape shows length."},
 {q:"⚖️ Which tool tells how heavy a pumpkin is?",o:["A scale","A ruler","A saw"],a:"A scale",why:"A scale shows how heavy things are."},
 {q:"🔨 Which tool do you use to hit a nail?",o:["A hammer","A wrench","A ladder"],a:"A hammer",why:"A hammer hits nails into wood."},
 {q:"🪜 How can a painter reach the top of a high wall?",o:["Climb a ladder","Jump very high","Stand on a ball"],a:"Climb a ladder",why:"A ladder helps you reach high places safely."},
 {q:"🌉 A river is in the way. What can people build to get across?",o:["A bridge","A tower","A fence"],a:"A bridge",why:"A bridge goes over water."},
 {q:"🚇 A big hill is in the way of a train. What can people build?",o:["A tunnel","A roof","A castle"],a:"A tunnel",why:"A tunnel goes under or through a hill."},
 {q:"🧱 Which is best for building a strong wall?",o:["Bricks","Paper","Jelly"],a:"Bricks",why:"Bricks are hard and strong."},
 {q:"🕌 Rain washes some mud off the mosque in Djenné. What do people do?",o:["Put on fresh mud","Let it fall down","Paint it blue"],a:"Put on fresh mud",why:"Every year the town puts fresh mud on the walls."},
 {q:"❄️ Why do builders in the far north often use snow for igloos?",o:["There is lots of snow and few trees","Snow is very hot","They do not like wood"],a:"There is lots of snow and few trees",why:"In the far north, snow is easy to find, but trees are not."},
 {q:"🚧 A sign at a building site says KEEP OUT. What do you do?",o:["Stay out","Go in to play","Climb the fence"],a:"Stay out",why:"Building sites are not safe for children."},
 {q:"🧰 The tools are all over the floor. What should you do?",o:["Put them back in the toolbox","Leave them there","Throw them outside"],a:"Put them back in the toolbox",why:"Tools on the floor can make someone trip."},
 {q:"📐 Builders say, “Measure twice, cut once.” Why?",o:["So the pieces fit","To use more wood","Just for fun"],a:"So the pieces fit",why:"Checking first stops mistakes."},
 {q:"😢 Your friend's tower falls down. What can you say?",o:["Let's build it again together!","Ha ha, it fell!","Your tower is bad."],a:"Let's build it again together!",why:"Kind words help a friend try again."},
 {q:"🔺 Builders often use triangles in roofs and bridges. Why?",o:["Triangles are strong shapes","Triangles are soft","Triangles can roll"],a:"Triangles are strong shapes",why:"A triangle keeps its shape when you push on it."},
 {q:"📄 Flat paper bends under a coin. How can you make it stronger?",o:["Fold it like a fan","Get it wet","Cut it in half"],a:"Fold it like a fan",why:"Folds make paper strong."},
 {q:"🏙️ Why do big cities have skyscrapers?",o:["Many people can fit on a small piece of land","They scare away birds","They hold up the sky"],a:"Many people can fit on a small piece of land",why:"Tall buildings stack lots of rooms on a small space."},
 {q:"🪨 Which one is the heaviest?",o:["A big rock","A feather","A leaf"],a:"A big rock",why:"A big rock is hard to lift."},
 {q:"🧮 Kofi stacks 6 blocks. Lena adds 4 more. How many blocks are in the tower now?",o:["10","2","9"],a:"10",why:"6 + 4 = 10."},
 {q:"🧮 A tower has 12 blocks. 5 blocks fall off. How many are left?",o:["7","17","6"],a:"7",why:"12 − 5 = 7."},
 {q:"🧮 A pencil is 19 cm long. A crayon is 9 cm long. How much longer is the pencil?",o:["10 cm","28 cm","9 cm"],a:"10 cm",why:"19 − 9 = 10."},
 {q:"🧮 A wall has 3 rows. Each row has 5 bricks. How many bricks are there in all?",o:["15","8","10"],a:"15",why:"5 + 5 + 5 = 15."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["heavy","The box of books is heavy.","hea-vy: ea says short e"],["weigh","Let's weigh the melon.","w-eigh: eigh says long a"],["scale","Stand on the scale.","sc-a-l-e: the e is quiet"],["metre","The rope is one metre long.","me-tre: tre at the end"],["wide","The gate is very wide.","w-i-d-e: the e is quiet"],["dome","The igloo is a dome.","d-o-m-e: the e is quiet"],["arch","We walk under the arch.","ar-ch"],["cone","Put the cone on the road.","c-o-n-e: the e is quiet"],["roof","Snow is on the roof.","r-oo-f"],["wall","Paint the wall blue.","w-a-ll: double l"],["hammer","Hold the hammer by the handle.","ham-mer: double m"],["ladder","Hold the ladder still.","lad-der: double d"],["crane","The crane is very tall.","cr-a-n-e: the e is quiet"],["builder","The builder has a hard hat.","build-er: u is quiet"],["toolbox","My saw is in the toolbox.","tool-box: two small words"],["brick","Put one more brick on top.","b-r-i-ck"],["tower","The tower is tall and thin.","t-ow-er"],["bridge","The train crosses the bridge.","br-i-dge: d is quiet"],["castle","The castle has a big gate.","cas-tle: the t is quiet"],["tunnel","The train goes into the tunnel.","tun-nel: double n"]]),
 CHOOSE:null,
 DETAIL:[
  ["The Tall Crane","A crane stands by the new school. It is yellow and very tall. It lifts heavy steel beams up high.",[["Where does the crane stand?","By the new school",["By the sea","In a park"]],["What colour is the crane?","Yellow",["Red","Blue"]],["What does it lift?","Heavy steel beams",["Feathers","Toy cars"]]]],
  ["Mia's Bridge","Mia builds a bridge with sticks. She ties the sticks with string. Her toy car rolls over it.",[["What does Mia build?","A bridge",["A tower","A boat"]],["What does she tie the sticks with?","String",["Tape","Glue"]],["What rolls over the bridge?","Her toy car",["A ball","Her cat"]]]],
  ["Measuring Day","Today we measure our feet. Ravi's foot is 18 centimetres long. Ana's foot is 17 centimetres long.",[["What do we measure?","Our feet",["Our hands","Our hair"]],["How long is Ravi's foot?","18 centimetres",["17 centimetres","8 centimetres"]],["Whose foot is 17 centimetres?","Ana's",["Ravi's","The teacher's"]]]],
  ["The Igloo","Elisapie's grandfather builds an igloo. He cuts blocks of hard snow. He stacks them in a circle.",[["Who builds the igloo?","Her grandfather",["Her sister","Her teacher"]],["What does he cut?","Blocks of hard snow",["Wood","Paper"]],["How does he stack them?","In a circle",["In a line","In a box"]]]],
  ["The Old Castle","Omar visits an old castle. It has thick stone walls. It has four towers and a big gate.",[["What does Omar visit?","An old castle",["A new school","A shop"]],["What are the walls made of?","Stone",["Snow","Glass"]],["How many towers are there?","Four",["Two","Ten"]]]],
  ["Weighing Fruit","Wei puts a melon on the scale. It weighs two kilograms. A lemon weighs much less.",[["What does Wei put on the scale?","A melon",["A lemon","A brick"]],["How much does the melon weigh?","Two kilograms",["Ten kilograms","One gram"]],["What weighs much less?","A lemon",["A melon","A truck"]]]],
  ["Safety First","Before Dad cuts wood, he puts on goggles. He wears thick gloves too. Then he picks up the saw.",[["What does Dad put on first?","Goggles",["A hat","Boots"]],["What does he wear on his hands?","Thick gloves",["Rings","Paint"]],["What does he pick up last?","The saw",["The hammer","A cup"]]]],
  ["The Mud Mosque","In Djenné, Mali, the mosque is made of mud. Every year, people put fresh mud on it. Children help carry the mud.",[["Where is the mud mosque?","In Djenné, Mali",["In Toronto","In China"]],["When do people put on fresh mud?","Every year",["Every hour","Never"]],["Who helps carry the mud?","Children",["Cats","Robots"]]]],
  ["Lena's Fort","Lena makes a fort with boxes and a blanket. The blanket is the roof. She reads a book inside.",[["What does Lena use?","Boxes and a blanket",["Bricks and mud","Snow and ice"]],["What is the roof?","The blanket",["A box","A book"]],["What does she do inside?","Reads a book",["Sleeps all night","Bakes a cake"]]]],
  ["The Tunnel","The train goes into a dark tunnel. The tunnel goes under a big hill. Then the train comes out into the sun.",[["Where does the tunnel go?","Under a big hill",["Over the sea","Up to the sky"]],["What is it like inside?","Dark",["Sunny","Snowy"]],["Where does the train come out?","Into the sun",["Into a lake","Into a house"]]]],
  ["The Toolbox","Kofi opens the toolbox. He finds a hammer and some nails. He also finds a measuring tape.",[["Who opens the toolbox?","Kofi",["Lena","Omar"]],["What does he find with the hammer?","Some nails",["Some apples","A ball"]],["What else does he find?","A measuring tape",["A scale","A crane"]]]],
  ["The Great Wall","The Great Wall is in China. It is very, very long. People built it over hundreds of years.",[["Where is the Great Wall?","In China",["In Egypt","In Canada"]],["How long is it?","Very, very long",["Very short","One metre"]],["How long did it take to build?","Hundreds of years",["One day","One week"]]]]
 ],
 MAIN:[
  ["A ruler measures length. A scale measures weight. A measuring tape measures long things.","We use tools to measure things.",["A scale is heavy.","Tapes are long."]],
  ["Builders wear hard hats. They wear safety vests. They wear strong boots.","Builders wear things to stay safe.",["Boots are strong.","Vests are bright."]],
  ["Kofi's tower fell down. He made the bottom wider. Then the tower stood up tall.","Kofi fixed his tower by making a wide base.",["Towers are tall.","Kofi likes blocks."]],
  ["The pyramids are in Egypt. They are made of stone. They are more than 4,000 years old.","The pyramids are very old stone buildings in Egypt.",["Stone is hard.","Egypt is hot."]],
  ["A bridge can go over a river. A bridge can go over a road. A bridge helps us get across.","Bridges help us get across things.",["Rivers are wet.","Roads are long."]],
  ["A hammer hits nails. A saw cuts wood. A wrench turns bolts.","Each tool has its own job.",["Wood is brown.","A saw has teeth."]],
  ["An igloo is made of snow. The blocks go round and round. The top is a dome.","An igloo is a snow house shaped like a dome.",["Snow is white.","Blocks are heavy."]],
  ["We folded the paper. The paper bridge held ten coins. Folds made it strong.","Folding made the paper bridge strong.",["Coins are round.","Paper is white."]],
  ["A skyscraper is very tall. It has many floors. Lots of people work inside.","A skyscraper is a tall building with many floors.",["People work.","Floors are flat."]],
  ["Ravi stacks the blocks. Ana adds a roof. Max puts a flag on top.","The friends build something together.",["Flags are red.","Max has a flag."]],
  ["A cone has a point. A dome is round on top. A column is tall and round.","Buildings have many shapes.",["A cone is orange.","Columns are old."]],
  ["We weighed an apple. We weighed a melon. The melon was heavier.","We weighed fruit to compare it.",["Apples are red.","Melons are sweet."]],
  ["A crane is tall. It lifts heavy things. It helps build skyscrapers.","A crane is a tall machine that lifts heavy things.",["Cranes are yellow.","Skyscrapers have windows."]],
  ["Put on goggles. Wear gloves. Use tools with a grown-up.","These are rules to stay safe with tools.",["Gloves are warm.","Goggles are clear."]],
  ["In Mali, people fix the mosque each year. They spread fresh mud. Everyone helps.","People in Djenné work together to fix their mosque.",["Mud is wet.","Mali is a country."]],
  ["The Great Wall is long. It goes up and down hills. People built it long ago.","The Great Wall is a long, old wall over the hills.",["Hills are steep.","People walk."]],
  ["We measured our height. Tunde was the tallest. Bella was the shortest.","We measured and compared how tall we are.",["Tunde is tall.","Bella has a hat."]],
  ["A brick is heavy. A rock is heavy. A big bag of rice is heavy.","Some things are heavy and hard to lift.",["Rice is white.","Bricks are red."]],
  ["A feather is light. A leaf is light. A paper cup is light.","Some things are light and easy to lift.",["Leaves are green.","Cups hold water."]],
  ["First, get the blocks. Next, stack them. Last, measure the tower.","The text tells how to build and measure a tower.",["Blocks are fun.","Towers fall."]],
  ["A castle has thick walls. It has tall towers. It has a big gate.","A castle is a big, strong building.",["Gates open.","Walls are grey."]],
  ["The tunnel goes under the river. Cars drive through it. It is long and dark.","A tunnel lets cars go under the river.",["Cars are fast.","Rivers are blue."]],
  ["Builders measure the wood. Then they cut it. Then they nail it in place.","Builders measure, cut and nail wood.",["Nails are sharp.","Wood comes from trees."]],
  ["Boat, coat and goat have oa. Bone and home have o_e. Snow and grow have ow.","There are three ways to spell long o.",["Goats eat grass.","Snow is cold."]]
 ],
 FACTS:["A ruler can measure length.","A scale can weigh things.","A brick is heavier than a feather.","There are 100 centimetres in a metre.","The pyramids are in Egypt.","The Great Wall is in China.","An igloo can be made of snow.","A triangle has three sides.","A square has four sides.","A crane can lift heavy things.","A hammer can hit nails.","A saw can cut wood.","Toronto is a city in Canada.","A bridge can go over a river.","A tunnel can go under a hill.","Goggles cover your eyes.","Bricks can be used to build walls.","A cube has six faces.","An egg is shaped like an oval.","A ladder has steps.","Some houses have a flat roof.","A ball is round.","A metre is longer than a centimetre.","Mali is a country in Africa.","Steel is a strong metal."],
 OPIN:["Building towers is the most fun.","Castles are the coolest buildings.","Hammers are better than saws.","Red bricks are the prettiest.","Measuring is boring.","Skyscrapers are scary.","Igloos are the best houses.","Yellow cranes look silly.","Bridges are more fun than tunnels.","Building with blocks is easy.","Round roofs are the nicest.","Paper bridges are the best project.","Every house should be blue.","Tunnels are too dark.","Tall towers are better than short towers.","The pyramids are the most amazing place.","Wood is nicer than stone.","Old buildings are more interesting than new ones.","Toolboxes should be pink.","Measuring with a ruler is fun.","Domes are more beautiful than arches.","Being a builder is the best job.","Stadiums are too noisy.","Long walls are boring.","Ladders are fun to climb."],
 SEQ:[["Get the blocks","Make a wide base","Stack more blocks","Measure the tower"],["Make two piles of books","Fold the paper","Lay it across the gap","Add coins"],["Put on goggles","Measure the wood","Cut the wood","Nail the pieces"],["Cut snow blocks","Stack them in a circle","Lean them in at the top","Crawl inside the igloo"],["Dig a hole","Pour in cement","Build the walls","Put on the roof"],["Stand by the wall","Make a mark at your head","Measure from the floor","Write the number"],["Put the melon on the scale","Look at the number","Write it down","Take the melon off"],["Kofi's tower falls","Ms. Rao helps","They make a wide base","The tower stands"],["Draw a plan","Get the tools","Build the birdhouse","Paint the birdhouse"],["Open the toolbox","Take out the hammer","Hit the nail","Put the hammer back"],["Rain washes mud away","People mix fresh mud","They spread it on the walls","The mosque looks new"]],
 CE:[["The base was narrow, so the tower fell.","the base was narrow","the tower fell"],["Lena made the base wide, so the tower stood up.","Lena made the base wide","the tower stood up"],["The paper was flat, so it bent.","the paper was flat","it bent"],["We folded the paper, so it got strong.","we folded the paper","it got strong"],["The box was heavy, so Max could not lift it.","the box was heavy","Max could not lift it"],["Dad wore goggles, so his eyes were safe.","Dad wore goggles","his eyes were safe"],["It rained hard, so mud washed off the mosque.","it rained hard","mud washed off the mosque"],["A river was in the way, so they built a bridge.","a river was in the way","they built a bridge"],["The builder measured wrong, so the pieces did not fit.","the builder measured wrong","the pieces did not fit"],["Ravi bumped the table, so the blocks fell.","Ravi bumped the table","the blocks fell"],["The ladder was not steady, so Mom held it.","the ladder was not steady","Mom held it"],["The nail was loose, so the board wobbled.","the nail was loose","the board wobbled"],["Ana grew a lot, so her height mark was higher.","Ana grew a lot","her height mark was higher"],["The crane lifted the beam, so the builders could fix it on top.","the crane lifted the beam","the builders could fix it on top"],["The tunnel was dark, so the train turned on its lights.","the tunnel was dark","the train turned on its lights"],["Tools were on the floor, so Kofi tripped.","tools were on the floor","Kofi tripped"],["The snow was hard, so Grandpa could cut blocks.","the snow was hard","Grandpa could cut blocks"],["The feather was light, so it blew away.","the feather was light","it blew away"],["We shared the blocks, so everyone could build.","we shared the blocks","everyone could build"],["The glue was wet, so we waited.","the glue was wet","we waited"]],
 CMP:[
  ["A ruler and a measuring tape both measure length. A ruler is short and stiff. A tape is long and bends.","Both measure length","A ruler is stiff, but a tape bends",["Both weigh things","A ruler bends"]],
  ["A tower and a skyscraper are both tall. A tower is often thin. A skyscraper has many floors for people.","Both are tall","A skyscraper has many floors for people, but a tower is often thin",["Both are short","A tower has many offices"]],
  ["A bridge and a tunnel both help us travel. A bridge goes over things. A tunnel goes under things.","Both help us travel","A bridge goes over, but a tunnel goes under",["Both go under rivers","A tunnel goes over"]],
  ["An igloo and the Djenné mosque are both built by hand. An igloo is made of snow. The mosque is made of mud.","Both are built by hand","An igloo is snow, but the mosque is mud",["Both are made of glass","The mosque is snow"]],
  ["A hammer and a saw are both tools. A hammer hits nails. A saw cuts wood.","Both are tools","A hammer hits, but a saw cuts",["Both are toys","A hammer cuts wood"]],
  ["A dome and an arch are both curved. A dome is a round roof. An arch goes over a door.","Both are curved","A dome is a roof, but an arch goes over a door",["Both are flat","An arch is a roof"]],
  ["A feather and a leaf are both light. A feather comes from a bird. A leaf comes from a tree.","Both are light","A feather is from a bird, but a leaf is from a tree",["Both are heavy","A leaf is from a bird"]],
  ["Kofi and Lena both built towers. Kofi's tower fell. Lena's tower stood up.","Both built towers","Kofi's fell, but Lena's stood",["Both towers fell","Lena's tower fell"]],
  ["A scale and a ruler both measure. A scale shows weight. A ruler shows length.","Both measure","A scale shows weight, but a ruler shows length",["Both cut wood","A ruler shows weight"]],
  ["A castle and a house are both homes. A castle is big with towers. A house is often small.","Both are homes","A castle is big with towers, but a house is often small",["Both are tunnels","A house has towers"]],
  ["A cone and a pyramid both have a point on top. A cone has a round bottom. A pyramid has a square bottom.","Both have a point on top","A cone has a round bottom, but a pyramid has a square bottom",["Both are round","A pyramid has a round bottom"]],
  ["Bricks and stones are both hard. Bricks are made by people. Stones are found in nature.","Both are hard","Bricks are made by people, but stones are found in nature",["Both are soft","Stones are made by people"]]
 ],
 GRP:{"tools":["hammer","saw","wrench","screwdriver","drill"],"measuring words":["length","height","metre","centimetre","kilogram"],"shapes":["dome","cone","oval","diamond","pyramid"],"buildings":["castle","temple","skyscraper","stadium","igloo"],"building materials":["brick","stone","wood","steel","mud"],"ways to cross water":["bridge","tunnel","ferry","boat","canoe"],"people who build":["builder","painter","plumber","carpenter","electrician"]},
 ANA:[["Hammer is to nail as wrench is to ___.","bolt",["saw","roof"]],["Ruler is to length as scale is to ___.","weight",["colour","sound"]],["Tall is to short as wide is to ___.","narrow",["long","big"]],["Heavy is to light as long is to ___.","short",["tall","wide"]],["Bridge is to over as tunnel is to ___.","under",["up","on"]],["Saw is to cut as hammer is to ___.","hit",["sing","fold"]],["Igloo is to snow as pyramid is to ___.","stone",["paper","jelly"]],["Big is to bigger as tall is to ___.","taller",["tallest","tall"]],["Long is to longest as heavy is to ___.","heaviest",["heavier","heavy"]],["Walk is to walked as stack is to ___.","stacked",["stacks","stack"]],["Paint is to painted as measure is to ___.","measured",["measureed","measures"]],["Egg is to oval as ball is to ___.","round",["flat","square"]],["Builder is to hard hat as swimmer is to ___.","goggles",["mittens","boots"]],["Boat is to water as car is to ___.","road",["sky","snow"]],["Brick is to wall as snow block is to ___.","igloo",["castle","bridge"]],["Coat is to oa as snow is to ___.","ow",["oa","ee"]],["Hop is to hope as not is to ___.","note",["nut","net"]],["Ruler is to centimetres as scale is to ___.","kilograms",["metres","minutes"]],["Ladder is to climb as crane is to ___.","lift",["swim","bake"]],["Roll is to rolled as fix is to ___.","fixed",["fix","fixes"]]],
 SENT:["Kofi and I built a tower.","Lena lives in Toronto.","Omar saw the pyramids in Egypt.","Awa lives in Mali.","Wei walked on the Great Wall.","I measured my desk with Ana.","Ms. Rao helps us build.","Elisapie lives in Nunavut.","Can Max help me lift this box?","Priya and I made a bridge.","The Eiffel Tower is in Paris.","I visited a castle in Scotland.","Tunde is taller than Bella.","Dad and I fixed the chair.","Ravi has a red toolbox.","Mia painted the fence on Monday.","I saw a crane in Vancouver.","Is the bridge in Montreal long?","Grandpa and I built an igloo.","My friend Sara likes to measure."],
 ORDER:["The tower is tall.","We stack the blocks.","The brick is heavy.","A feather is light.","The crane lifts steel.","We measure the desk.","The bridge is long.","Put on your goggles.","The roof is red.","We painted the fence.","The box is wide.","The path is narrow.","Hold the ladder.","The saw cuts wood.","We built a fort.","The dome is round.","My hammer is new.","We weighed the melon.","The tunnel is dark.","Look at the castle."],
 WP:[
  {q:"Write a sentence about a tower.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b[Tt]ower","Uses the word tower"]],model:"The tower is very tall."},
  {q:"Write a sentence about something <b>heavy</b>.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b[Hh]eavy","Uses heavy"]],model:"My school bag is heavy."},
  {q:"Write a sentence about something <b>light</b>.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b[Ll]ight","Uses light"]],model:"A feather is very light."},
  {q:"Write a sentence that uses <b>yesterday</b> and an -ed word.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b[Yy]esterday","Uses yesterday"],["[a-z]ed\\b","Uses an -ed word"]],model:"Yesterday, I painted a box."},
  {q:"Write a sentence that tells what you do <b>every day</b>.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b[Ee]very day","Uses every day"]],model:"I walk to school every day."},
  {q:"Write a sentence with a long o word, like boat, snow or bone.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b([Bb]oats?|[Cc]oats?|[Gg]oats?|[Rr]oads?|[Ss]oap|[Tt]oast|[Ss]now|[Gg]row|[Ss]low|[Bb]owl|[Ww]indow|[Yy]ellow|[Bb]ones?|[Hh]ome|[Ss]tones?|[Hh]ole|[Nn]ote|[Hh]ope|[Rr]ope|[Nn]ose|[Rr]ose|[Cc]ones?|[Gg]lobe|[Ss]moke|[Pp]hone|[Ff]loat|[Ll]oad|[Tt]oad|[Ss]how|[Tt]hrow|[Cc]row|[Bb]low)\\b","Uses a long o word"]],model:"The goat is in the snow."},
  {q:"Write a sentence that compares two things. Use <b>than</b>.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\bthan\\b","Uses than"]],model:"A brick is heavier than a leaf."},
  {q:"Write a sentence about a tool, like a hammer or a saw.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b([Hh]ammer|[Ss]aw|[Ww]rench|[Ss]crewdriver|[Rr]uler|[Ss]cale|[Ll]adder|[Dd]rill|[Tt]ools?)\\b","Names a tool"]],model:"I use a hammer to hit a nail."},
  {q:"Write a safety rule for building.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I],model:"Always wear goggles when you cut wood."},
  {q:"Write a sentence about a bridge.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b[Bb]ridge","Uses the word bridge"]],model:"The bridge goes over the river."},
  {q:"Write a sentence with a shape word, like round, dome or cone.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b([Rr]ound|[Dd]omes?|[Cc]ones?|[Oo]val|[Dd]iamond|[Aa]rch|[Pp]yramids?|[Cc]olumns?|[Tt]riangles?|[Ss]quares?|[Cc]ircles?|[Cc]ubes?)\\b","Uses a shape word"]],model:"The igloo is a round dome."},
  {q:"Write a sentence about something you measured.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b[Mm]easur","Uses measure or measured"]],model:"I measured my desk with a ruler."},
  {q:"Write a sentence about a building you like.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I],model:"I like the old castle on the hill."},
  {q:"Write a sentence that starts with <b>First,</b>.",checks:[CHK.end,CHK.w4,CHK.I,["^\\s*First,","Starts with First,"]],model:"First, get the blocks."},
  {q:"Write a sentence that starts with <b>Last,</b>.",checks:[CHK.end,CHK.w4,CHK.I,["^\\s*Last,","Starts with Last,"]],model:"Last, measure the tower."},
  {q:"Write a sentence with the word <b>wide</b> or <b>narrow</b>.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b([Ww]ide|[Nn]arrow)","Uses wide or narrow"]],model:"The road is wide and long."},
  {q:"Write a sentence about what you built last week. Use an -ed word or built.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["([a-z]ed\\b|\\b[Bb]uilt\\b)","Uses an -ed word or built"]],model:"Last week, I built a fort."},
  {q:"Write a question about a building. End it with <b>?</b>",checks:[CHK.cap,CHK.q,CHK.w4,CHK.I],model:"How tall is the tower?"},
  {q:"Write a sentence with a name and the word <b>I</b>.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,CHK.name,["\\bI\\b","Uses I"]],model:"I stack the blocks with Lena."},
  {q:"Write a sentence about a famous place, like the pyramids or the Great Wall.",checks:[CHK.cap,CHK.end,CHK.w4,CHK.I,["\\b([Pp]yramids?|Great Wall|[Ii]gloo|[Cc]astle|[Tt]ower|[Mm]osque|[Tt]emple|[Bb]ridge)","Names a famous kind of place"]],model:"The pyramids are in Egypt."}
 ],
 SYN:[["big","large"],["small","little"],["build","make"],["fix","repair"],["pile","heap"],["strong","sturdy"],["shaky","wobbly"],["shout","yell"],["start","begin"],["end","finish"],["quick","fast"],["rock","stone"],["glad","happy"],["lift","raise"],["pick","choose"],["hold","grip"],["throw","toss"],["wet","damp"],["neat","tidy"],["ill","sick"]],
 OPP:[["heavy","light"],["long","short"],["wide","narrow"],["top","bottom"],["full","empty"],["open","closed"],["push","pull"],["strong","weak"],["early","late"],["first","last"],["in","out"],["front","back"],["hard","soft"],["before","after"],["tidy","messy"],["fast","slow"],["old","new"],["near","far"],["rough","smooth"],["straight","crooked"]],
 COMP:[["sky","scraper"],["tool","box"],["wheel","barrow"],["light","house"],["sand","castle"],["card","board"],["saw","dust"],["work","shop"],["play","house"],["tree","house"],["bird","house"],["rail","road"],["up","stairs"],["down","stairs"],["foot","bridge"],["drive","way"],["hand","rail"],["sun","light"],["fire","place"],["hall","way"],["door","way"],["snow","man"]]
};
B.CHOOSE=G4.ch([["heavy","hevy","heavey"],["weigh","wiegh","waigh"],["scale","scail","skale"],["metre","metr","meetre"],["wide","wyde","wied"],["dome","doam","dowm"],["arch","artch","arsh"],["cone","coan","kone"],["roof","rufe","roov"],["wall","wal","wawl"],["hammer","hamer","hammar"],["ladder","lader","laddar"],["crane","crain","crayn"],["builder","bilder","buildar"],["toolbox","tulbox","toolbocks"],["brick","brik","brikc"],["tower","towr","touwer"],["bridge","brige","bridj"],["castle","casle","kastle"],["tunnel","tunel","tunnle"]],B.SP);

const L={
 which:"Long o says its name: /ō/. It can be spelled three ways: <b>o_e</b> (b<b>o</b>n<b>e</b>), <b>oa</b> (b<b>oa</b>t) and <b>ow</b> (sn<b>ow</b>). <b>ow</b> is often at the end of a word.",
 pic:"Look at the picture and say its name slowly: ⛵ b-oa-t. Then find the word that matches.",
 make:"Say the picture word. Which long o spelling fits? 🐐 g _ _ t needs <b>oa</b>: <b>goat</b>.",
 long:"<b>Short o</b> says /o/, like in 🐶 d<b>o</b>g. <b>Long o</b> says its name, like in 🦴 b<b>o</b>n<b>e</b>. A magic e changes <b>hop</b> into <b>hope</b>.",
 listen:"Listen to the word. Say each sound and choose o_e, oa or ow: s-n-ow spells <b>snow</b>.",
 now:"A verb is an action word. <b>Now</b> (present): <i>Kofi stacks the blocks.</i> <b>Before</b> (past): <i>Kofi stack<b>ed</b> the blocks.</i> The <b>-ed</b> tells us it already happened.",
 ed:"To tell about the past, add <b>-ed</b>: paint → paint<b>ed</b>. If the word ends in <b>e</b>, just add <b>d</b>: measure → measure<b>d</b>.",
 day:"<b>Yesterday</b> and <b>last week</b> need the -ed verb: <i>Yesterday, Omar fix<b>ed</b> the chair.</i> <b>Every day</b> needs the now verb: <i>Every day, Omar fix<b>es</b> the chair.</i>",
 shape:"Size words help us compare: <b>heavy → heavier → heaviest</b>, <b>long → longer → longest</b>. Shape words name shapes: a <b>dome</b> is round like half a ball.",
 chart:"A measuring chart shows how long things are. The biggest number is the longest. The smallest number is the shortest.",
 build:"Think like a builder: plan, measure, stay safe and work together."
};
u.review=G4.MIX(nowBefore,addEd,verbDay,loWhich,loLong,F.vocab(u.words));
u.cats=G4.std(u,{sets:["Measuring words","Shapes in buildings","Builders and tools","Towers, bridges and more"],B,
 reading:[{id:"r_measure",t:"Read a measuring chart",learn:L.chart,gen:mchart}],
 vocab:[{id:"v_shape",t:"Shape, size and compare words",learn:L.shape,gen:shapeSize}],
 grammar:[{id:"g_nowbef",t:"Now or before? (present or past)",learn:L.now,gen:nowBefore},{id:"g_ed",t:"Add -ed to show the past",learn:L.ed,gen:addEd},{id:"g_verbday",t:"Yesterday or every day? Choose the verb",learn:L.day,gen:verbDay},{id:"g_mixed",t:"Mixed review: verbs and long o",learn:"Use what you learned about -ed verbs and long o spellings.",gen:u.review}],
 spelling:[{id:"s_owhich",t:"Long o: which spelling? (o_e, oa, ow)",learn:L.which,gen:loWhich},{id:"s_opic",t:"Long o: picture to word",learn:L.pic,gen:loPic},{id:"s_omake",t:"Long o: complete the word",learn:L.make,gen:loMake},{id:"s_olong",t:"Long o or short o?",learn:L.long,gen:loLong},{id:"s_olisten",t:"Long o words: listen and write",learn:L.listen,gen:F.listen(LOLIST)}],
 thinking:[{id:"t_build",t:"Builder smarts: what should you do?",learn:L.build,gen:F.bank(BUILD)}]});
})();
