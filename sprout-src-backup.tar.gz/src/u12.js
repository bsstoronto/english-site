/* ===================== GRADE 3 · UNIT 12 · STORIES AND FABLES (original content, retold public-domain fables and one public-domain poem) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
const p=(q,a,o,why)=>({lv:"predict",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"stories", num:12, emoji:"📚🦊🐢", title:"Stories and Fables", badge:"📚 Master Storyteller",

stories:[
/* ---------- 1. FABLE ---------- */
{title:"The Lion and the Mouse (an Aesop fable, retold)", e:"🦁", kind:"Fable", pages:[
 {pic:"🦁😴", text:"On a hot afternoon, a mighty lion lay sleeping in the shade of a tree. A tiny mouse was scurrying home and, without looking, ran right across the lion's nose. The lion woke with a roar and trapped the mouse under his huge paw. \"How dare you wake me!\" he growled. \"I will eat you for my snack!\"",
  qs:[f("Where was the lion sleeping?","In the shade of a tree",["In a cave","In a river"],"…a mighty lion lay sleeping in the shade of a tree."),
      f("What did the lion say?","\"How dare you wake me!\"",["\"Hello, little friend!\"","\"Let's play!\""],"The words inside the quotation marks are what the lion said."),
      t("Who are the two characters so far?","A lion and a mouse",["A fox and a crow","A tortoise and a hare"],"Characters are the people or animals in a story.")]},
 {pic:"🐭🙏", text:"\"Please, Your Majesty,\" squeaked the mouse, trembling. \"Let me go, and one day I will help you.\" The lion laughed so hard that his whiskers shook. \"You? Help ME? You're so small that you couldn't help a beetle!\" But the mouse had made him smile, so the lion lifted his paw. \"Go on, then,\" he said. The mouse ran off quickly.",
  qs:[f("What did the mouse promise?","To help the lion one day",["To bring him food","To leave the forest"],"\"Let me go, and one day I will help you.\""),
      t("Why did the lion laugh?","He thought a tiny mouse could never help a big lion",["The mouse told a joke","He was tickled"],"\"You're so small that you couldn't help a beetle!\""),
      p("Do you think the mouse will keep his promise?","Yes, he will find a way to help the lion",["No, he will forget","The lion will never see him again"],"Fables often bring the characters back together.")]},
 {pic:"🕸️🦁", text:"A few days later, hunters set a trap in the forest. As the lion walked along the path, a heavy rope net fell on top of him. He pulled and twisted, but the more he struggled, the tighter the ropes became. \"Help!\" he roared. His roar echoed through the whole forest, all the way to the mouse's little home.",
  qs:[f("What trapped the lion?","A rope net set by hunters",["A big hole","A cage of iron"],"…a heavy rope net fell on top of him."),
      f("What happened when the lion struggled?","The ropes became tighter",["The ropes broke","The net disappeared"],"The more he struggled, the tighter the ropes became."),
      t("What is the lion's problem now?","He is trapped in a net and can't get out",["He is hungry","He is lost"],"The problem is the challenge the character must solve.")]},
 {pic:"🐭✂️", text:"The mouse heard the roar and raced to the lion. \"Don't worry,\" she said. \"I'm here.\" She began to nibble the ropes with her sharp little teeth. She nibbled and gnawed, one rope after another, until there was a hole big enough for the lion to climb through. The mighty lion stepped out, free at last.",
  qs:[f("How did the mouse free the lion?","She nibbled through the ropes with her teeth",["She called the hunters","She pulled the net with her paws"],"She began to nibble the ropes with her sharp little teeth."),
      f("What did the mouse say when she arrived?","\"Don't worry. I'm here.\"",["\"I told you so!\"","\"Goodbye!\""],"\"Don't worry,\" she said. \"I'm here.\""),
      t("What is the solution in this story?","The mouse nibbles through the net",["The lion eats the mouse","The hunters let the lion go"],"The solution is how the problem is solved.")]},
 {pic:"🦁🤝🐭", text:"The lion bowed his great head. \"Thank you, little friend,\" he said softly. \"I laughed at you because you were small, but today you saved my life.\" From that day on, the lion and the mouse were the best of friends. <b>Lesson: Even the smallest friend can be a great help. Kindness is never wasted.</b>",
  qs:[t("What is the moral (lesson) of this fable?","Even the smallest friend can be a great help",["Lions are scary","Never sleep under a tree"],"The mouse was small, but she saved the mighty lion."),
      f("What did the lion say at the end?","\"Thank you, little friend.\"",["\"Go away!\"","\"I'm still hungry.\""],"\"Thank you, little friend,\" he said softly."),
      t("How did the lion change?","He learned not to judge someone by their size",["He became smaller","He stopped roaring forever"],"He laughed at the mouse at first, then thanked her.")]}
], turn:{q:"Write two sentences about a time someone small or young helped you. Use quotation marks to show what someone said.",model:"My little sister found my lost key under the sofa. \"Here it is!\" she shouted happily."}},

/* ---------- 2. FABLE ---------- */
{title:"The Tortoise and the Hare (an Aesop fable, retold)", e:"🐢", kind:"Fable", pages:[
 {pic:"🐇💨", text:"In a green meadow lived a hare who was very fast and very boastful. Every day he bragged to the other animals. \"I'm the fastest animal in the whole meadow!\" he would say. \"Nobody can beat me!\" One morning, he saw a tortoise walking slowly along the path. The hare laughed. \"Do you ever get anywhere, Slowpoke?\"",
  qs:[f("Where did the hare live?","In a green meadow",["In the ocean","In a city"],"In a green meadow lived a hare…"),
      f("What word describes the hare?","Boastful",["Shy","Humble"],"…a hare who was very fast and very boastful."),
      t("What is the setting of this story?","A green meadow",["A school","A castle"],"The setting is where (and when) a story happens.")]},
 {pic:"🐢🏁", text:"The tortoise stopped and looked up calmly. \"I may be slow,\" she said, \"but I will race you, and I think I can win.\" All the animals gasped. The hare rolled on the grass, laughing. \"You? Beat ME? All right, let's race to the big oak tree on the hill!\" The fox agreed to be the judge. \"Ready, steady, GO!\" he called.",
  qs:[f("Where was the finish line?","The big oak tree on the hill",["The river","The tortoise's house"],"\"Let's race to the big oak tree on the hill!\""),
      f("Who was the judge?","The fox",["The owl","The mouse"],"The fox agreed to be the judge."),
      p("Who do you think will win?","The tortoise, because she is steady and the hare is too proud",["The hare, easily","Nobody"],"Fables often surprise us, and proud characters usually learn a lesson.")]},
 {pic:"🐇😴", text:"The hare shot off like an arrow and was soon far ahead. He looked back. The tortoise was just a tiny dot. \"This is too easy,\" he yawned. \"I have time for a nap.\" He lay down under a shady bush and fell fast asleep. Meanwhile, the tortoise kept walking: step, step, step. She didn't stop once.",
  qs:[f("What did the hare do when he was far ahead?","He took a nap",["He ran faster","He went home"],"\"I have time for a nap.\""),
      f("What did the tortoise do?","She kept walking and didn't stop",["She took a nap too","She gave up"],"She didn't stop once."),
      t("Why did the hare take a nap?","He was too sure he would win",["He was hurt","The judge told him to"],"\"This is too easy.\" He was overconfident.")]},
 {pic:"🐢🌳", text:"The sun moved across the sky. When the hare finally woke up, he heard cheering in the distance. He jumped up and raced towards the hill as fast as his legs could go. But it was too late! The tortoise was just crossing the finish line under the oak tree. All the animals cheered. \"Hooray for the tortoise!\" they shouted.",
  qs:[f("What did the hare hear when he woke up?","Cheering in the distance",["Thunder","Silence"],"…he heard cheering in the distance."),
      f("Who won the race?","The tortoise",["The hare","The fox"],"The tortoise was just crossing the finish line."),
      t("How do you think the hare felt?","Embarrassed and surprised",["Proud","Happy"],"He bragged that nobody could beat him, and then he lost.")]},
 {pic:"🐢🏆", text:"The hare walked up, panting and red-faced. \"How did you beat me?\" he asked quietly. The tortoise smiled kindly. \"You are faster than me,\" she said, \"but you stopped. I kept going.\" The hare was quiet for a long time. Then he said, \"I'm sorry I laughed at you. I won't boast again.\" <b>Lesson: Slow and steady wins the race. Don't be too proud.</b>",
  qs:[t("What is the moral of this fable?","Slow and steady wins the race",["Hares are lazy","Never race"],"The tortoise kept going and won."),
      f("What did the tortoise say?","\"You are faster than me, but you stopped. I kept going.\"",["\"I'm the fastest!\"","\"Let's not race again.\""],"\"You are faster than me,\" she said, \"but you stopped. I kept going.\""),
      t("Which pair of words describes the two characters?","The hare was boastful; the tortoise was patient",["Both were lazy","The tortoise was boastful"],"The hare bragged, and the tortoise worked steadily.")]}
], turn:{q:"Write a short conversation (two lines) between the tortoise and the hare after the race. Use quotation marks.",model:"\"Will you race me again tomorrow?\" asked the hare.\n\"Only if you promise not to nap!\" laughed the tortoise."}},

/* ---------- 3. FOLKTALE FROM INDIA ---------- */
{title:"The Monkey and the Crocodile (a Panchatantra tale from India, retold)", e:"🐒", kind:"Folktale", pages:[
 {pic:"🐒🌳", text:"Long ago in India, a monkey lived in a rose-apple tree beside a wide river. The tree was full of sweet, juicy fruit. One day, a crocodile swam up to the bank. \"I'm so hungry,\" he said. The kind monkey threw him some rose-apples. \"Thank you!\" said the crocodile. Soon the two became friends, and the crocodile visited every day.",
  qs:[f("Where did the monkey live?","In a rose-apple tree beside a river",["In a cave","In a city zoo"],"…a monkey lived in a rose-apple tree beside a wide river."),
      f("What did the monkey give the crocodile?","Rose-apples",["Fish","Bananas"],"The kind monkey threw him some rose-apples."),
      t("What kind of character is the monkey at the start?","Kind and generous",["Mean and greedy","Lazy and rude"],"He shared his fruit with a hungry stranger.")]},
 {pic:"🐊👑", text:"The crocodile took some rose-apples home to his wife. She loved them. Then she had a greedy idea. \"If the fruit is so sweet,\" she said, \"the monkey's heart must be even sweeter! Bring me his heart to eat!\" The crocodile didn't want to hurt his friend, but his wife insisted. So he made a plan to trick the monkey.",
  qs:[f("Who wanted the monkey's heart?","The crocodile's wife",["The crocodile","Another monkey"],"\"Bring me his heart to eat!\""),
      t("Which word describes the crocodile's wife?","Greedy",["Generous","Humble"],"She wanted more and more, even her husband's friend's heart."),
      p("What do you think the crocodile will do?","Try to trick the monkey",["Tell the monkey to run away","Move to another river"],"\"So he made a plan to trick the monkey.\"")]},
 {pic:"🐊🐒🌊", text:"The next day, the crocodile said, \"My friend, my wife wants to thank you. Come to dinner at our home across the river. Sit on my back, and I'll carry you.\" The monkey happily climbed on. But in the middle of the deep river, the crocodile said, \"I'm sorry, friend. My wife wants to eat your heart.\" The monkey couldn't swim. He was in great danger!",
  qs:[f("Where did the crocodile say they were going?","To dinner at his home across the river",["To a party in the forest","To the mountains"],"\"Come to dinner at our home across the river.\""),
      f("Why was the monkey in danger in the middle of the river?","He couldn't swim",["He was too heavy","It was raining"],"The monkey couldn't swim."),
      t("What is the monkey's problem?","He is on the crocodile's back in the river, and the crocodile wants his heart",["He is hungry","He lost his tree"],"The problem is a big danger the character must escape.")]},
 {pic:"🧠🐒", text:"The monkey thought quickly. \"Oh, my friend!\" he said calmly. \"Why didn't you tell me before? We monkeys keep our hearts safely in the tree when we go out. Take me back, and I'll fetch it for your wife.\" The foolish crocodile believed him and swam back to the bank. The moment they arrived, the monkey leapt high into his tree.",
  qs:[f("Where did the monkey say he kept his heart?","In the tree",["In his pocket","Under a rock"],"\"We monkeys keep our hearts safely in the tree when we go out.\""),
      t("Why did the monkey speak calmly?","So the crocodile would believe his trick",["He wasn't scared at all","He was sleepy"],"If he panicked, the crocodile might not believe him."),
      t("Which word describes the crocodile here?","Foolish",["Clever","Wise"],"He believed the monkey's trick.")]},
 {pic:"🐒🌳😌", text:"From the top of the tree, the monkey called down, \"You foolish crocodile! Nobody can take their heart out of their body. You tried to trick your friend, so our friendship is over.\" The crocodile swam away, ashamed. The monkey ate a rose-apple and thought about what had happened. <b>Lesson: Keep calm and think clearly in times of danger. And be careful whom you trust.</b>",
  qs:[t("What is the lesson of this tale?","Keep calm and think clearly in danger",["Monkeys can swim","Always share your heart"],"The monkey escaped by staying calm and using his brain."),
      f("Where was the monkey at the end?","Safe at the top of his tree",["In the river","At the crocodile's house"],"From the top of the tree, the monkey called down…"),
      t("How is this tale like 'The Lion and the Mouse'?","Both have animal characters and teach a lesson",["Both are set in a meadow","Both have a race"],"Fables and folktales often use animals to teach lessons."),
      t("What is the Panchatantra?","A very old collection of animal stories from India",["A kind of crocodile","A fruit"],"These stories were told in India for about 2,000 years to teach wisdom.")]}
], turn:{q:"The monkey stayed calm in danger. Write about a time you stayed calm when something went wrong.",model:"When I lost my mom at the market, I stayed calm. I stood still and asked a shopkeeper for help."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"How Stories Work", e:"🧩", kind:"Fact text", pages:[
 {pic:"🧑‍🤝‍🧑🦊", text:"Every story has <b>characters</b>. Characters are the people, animals or creatures in a story. The most important character is called the <b>main character</b>. In fables, characters are often animals that act like people: they talk, think and make choices. We learn about characters from what they say, what they do and how others treat them.",
  qs:[f("What are characters?","The people, animals or creatures in a story",["The place where a story happens","The lesson of a story"],"Characters are the people, animals or creatures in a story."),
      f("What do animal characters in fables often do?","Talk, think and make choices like people",["Never speak","Only eat"],"…animals that act like people: they talk, think and make choices."),
      t("How can we learn what a character is like?","From what they say and do",["From the page number","From the cover colour only"],"We learn about characters from what they say, what they do and how others treat them.")]},
 {pic:"🏰🌲", text:"The <b>setting</b> is where and when a story happens. It might be a meadow, a castle, a busy city, a spaceship or a river in India. It could be long ago, today or in the future. Good writers use describing words to help us picture the setting: <i>a dark, whispering forest</i> or <i>a sunny, crowded beach</i>.",
  qs:[f("What is the setting?","Where and when a story happens",["Who is in the story","How the story ends"],"The setting is where and when a story happens."),
      f("Which is an example of a setting?","A dark, whispering forest",["A brave knight","A happy ending"],"…a dark, whispering forest…"),
      t("Why do writers use describing words for the setting?","To help readers picture it",["To make the story longer","Because they must"],"…to help us picture the setting.")]},
 {pic:"⚠️💡", text:"Every good story has a <b>problem</b>: something goes wrong, or a character wants something that is hard to get. The lion is caught in a net. The monkey is in danger. The middle of the story shows how the characters try to deal with it. Then the <b>solution</b> is how the problem is solved. Without a problem, a story would be very boring!",
  qs:[f("What is the problem in a story?","Something that goes wrong or is hard to get",["The title","The last word"],"…something goes wrong, or a character wants something that is hard to get."),
      f("What is the solution?","How the problem is solved",["Where the story happens","The main character's name"],"The solution is how the problem is solved."),
      t("Why would a story without a problem be boring?","Nothing exciting would happen",["It would be too short","It would have no characters"],"The problem makes us want to know what happens next.")]},
 {pic:"1️⃣2️⃣3️⃣", text:"Stories have a <b>beginning</b>, a <b>middle</b> and an <b>end</b>. The beginning introduces the characters and the setting. The middle is where the problem happens and grows. The end shows the solution. Many fables finish with a <b>moral</b>, a lesson that the reader can use in real life, such as \"Slow and steady wins the race.\"",
  qs:[f("What happens in the beginning of a story?","We meet the characters and the setting",["The problem is solved","The moral is given"],"The beginning introduces the characters and the setting."),
      f("What is a moral?","A lesson the reader can use in real life",["A kind of animal","The title of the story"],"…a moral, a lesson that the reader can use in real life."),
      t("In which part of a story is the solution usually found?","The end",["The beginning","The title"],"The end shows the solution.")]},
 {pic:"💬✍️", text:"When characters talk, writers use <b>quotation marks</b> (\" \") around the exact words they say. This is called <b>dialogue</b>. For example: <i>\"Let me go,\" squeaked the mouse.</i> Writers use interesting words instead of always writing <i>said</i>: whispered, shouted, giggled, grumbled or begged. Dialogue makes characters come alive. When you tell a story aloud, change your voice for each character!",
  qs:[f("What are quotation marks used for?","To show the exact words a character says",["To end a question","To show a list"],"…writers use quotation marks around the exact words they say."),
      f("What is dialogue?","The words characters say to each other",["The setting","The moral"],"This is called dialogue."),
      t("In \"Let me go,\" squeaked the mouse, which words did the mouse say?","Let me go",["squeaked the mouse","the mouse"],"Only the words inside the quotation marks are spoken."),
      t("What is the main idea of this whole text?","Stories have parts like characters, setting, problem, solution and dialogue",["Stories are always about lions","Only adults write stories"],"Each page explains one part of a story.")]}
], turn:{q:"Think of your favourite story or film. Write the character, the setting and the problem.",model:"In my favourite story, the main character is a brave girl named Moana. The setting is an island in the Pacific Ocean. The problem is that her island is dying, and she must sail across the ocean to save it."}},

/* ---------- 5. STORY ---------- */
{title:"Neel and Grandma Write a Fable", e:"✍️", kind:"Story", pages:[
 {pic:"🌧️📓", text:"It was a rainy Saturday, and Neel was bored. \"There's nothing to do,\" he sighed. Grandma Kiran put down her tea. \"Then let's write a fable together,\" she said, \"and tonight you can tell it to the family at dinner.\" Neel's eyes lit up. \"Can it have animals that talk?\" \"Of course!\" laughed Grandma. \"That's what fables do best.\"",
  qs:[f("What was the weather like?","Rainy",["Sunny","Snowy"],"It was a rainy Saturday."),
      f("What did Grandma suggest?","Writing a fable together",["Watching TV","Going to the park"],"\"Then let's write a fable together.\""),
      t("Why does Neel want animals that talk?","Fables often have talking animals",["He doesn't like people","Animals are quiet"],"\"That's what fables do best.\"")]},
 {pic:"🧠📝", text:"Grandma drew a story map on a page. \"First, every story needs characters,\" she said. Neel thought. \"A peacock who is very proud of his feathers… and a little brown sparrow.\" \"Good! And the setting?\" \"A garden in a city, next to a fountain.\" Grandma nodded. \"Now the most important part: what's the problem?\"",
  qs:[f("Who are the characters in Neel's fable?","A proud peacock and a little brown sparrow",["A lion and a mouse","A tortoise and a hare"],"\"A peacock who is very proud of his feathers… and a little brown sparrow.\""),
      f("What is the setting?","A garden in a city, next to a fountain",["A deep ocean","A snowy mountain"],"\"A garden in a city, next to a fountain.\""),
      t("What is a story map?","A plan that shows the parts of a story",["A map of a city","A treasure map"],"Grandma drew a story map with characters, setting and problem.")]},
 {pic:"🦚🐦", text:"Neel bounced in his chair. \"The peacock laughs at the sparrow because she's plain and brown. He says, 'Nobody will ever look at you!' Then one day, a cat sneaks into the garden. The peacock's long, heavy tail gets stuck in a bush, and he can't fly away!\" Grandma clapped. \"What a problem! And how is it solved?\"",
  qs:[f("Why does the peacock laugh at the sparrow?","Because she is plain and brown",["Because she sings badly","Because she is fast"],"\"The peacock laughs at the sparrow because she's plain and brown.\""),
      f("What is the problem in Neel's fable?","A cat comes, and the peacock's tail gets stuck in a bush",["The fountain breaks","The sparrow loses her nest"],"The peacock's long, heavy tail gets stuck in a bush, and he can't fly away!"),
      p("How do you think the problem will be solved?","The sparrow will help the peacock",["The cat will become a vegetarian","The peacock will grow wings"],"Fables often have the character who was teased become the helper.")]},
 {pic:"🐦🔔", text:"\"The sparrow sees the cat,\" said Neel. \"She's small and quick, so she flies right in front of the cat's nose and chirps loudly. The cat chases her, and that gives the peacock time to pull his tail free. Then the sparrow flies up to a high branch where the cat can't reach.\" \"And the ending?\" asked Grandma. Neel grinned. \"The peacock says, 'Thank you. I was wrong. Being useful is better than being beautiful.'\"",
  qs:[f("How did the sparrow help?","She flew in front of the cat to distract it",["She fought the cat","She called the police"],"She flies right in front of the cat's nose and chirps loudly."),
      f("What does the peacock say at the end?","\"Thank you. I was wrong. Being useful is better than being beautiful.\"",["\"Go away, sparrow!\"","\"My tail is the best.\""],"The peacock's words are inside the quotation marks."),
      t("What is the moral of Neel's fable?","Being useful (and kind) is better than being beautiful",["Cats are bad","Peacocks are pretty"],"The peacock learned that looks aren't everything.")]},
 {pic:"🍽️🎭", text:"That night at dinner, Neel stood up. \"Once upon a time, in a city garden…\" he began. He used a proud, booming voice for the peacock and a quick, chirpy voice for the sparrow. He made a sneaky \"meow\" for the cat. Everyone leaned in to listen. When he finished, the whole family clapped. \"You're a real storyteller!\" said Dad. Neel beamed. \"Can we write another one next Saturday, Grandma?\"",
  qs:[f("How did Neel begin his story?","\"Once upon a time, in a city garden…\"",["\"The end.\"","\"Hello, everyone.\""],"\"Once upon a time, in a city garden…\" he began."),
      f("What kind of voice did Neel use for the peacock?","A proud, booming voice",["A tiny, squeaky voice","A sleepy voice"],"He used a proud, booming voice for the peacock."),
      t("Why did Neel use different voices?","To make the characters come alive for listeners",["Because he had a cold","To confuse his family"],"Changing your voice helps listeners know who is speaking."),
      t("What steps did Neel and Grandma follow to write the fable?","Characters, setting, problem, solution, moral",["Title, end, beginning","Pictures only"],"They planned each part on a story map.")]}
], turn:{q:"Plan your own fable. Write the characters, the setting and the problem in three sentences.",model:"My characters are a lazy bear and a hard-working beaver. The setting is a forest beside a river in Canada. The problem is that a big storm is coming, and the bear has not built a shelter."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A story map and a book review", e:"🗂️", kind:"Real-world text", pages:[
 {pic:"🗺️📖", text:"Ms. Chen's class filled in a <b>story map</b> for \"The Lion and the Mouse\".<table class=\"realtbl\"><tr><th>Story part</th><th>The Lion and the Mouse</th></tr><tr><td>📛 Title</td><td>The Lion and the Mouse</td></tr><tr><td>🧑‍🤝‍🧑 Characters</td><td>A mighty lion, a tiny mouse, hunters</td></tr><tr><td>🌳 Setting</td><td>A forest, on a hot afternoon</td></tr><tr><td>⚠️ Problem</td><td>The lion is caught in a hunters' net.</td></tr><tr><td>➡️ Events</td><td>1. The mouse wakes the lion. 2. The lion lets her go. 3. The lion is trapped.</td></tr><tr><td>✅ Solution</td><td>The mouse nibbles through the ropes.</td></tr><tr><td>💡 Moral</td><td>Even the smallest friend can be a great help.</td></tr></table>",
  qs:[f("What is the setting on the story map?","A forest, on a hot afternoon",["A meadow at night","A city"],"🌳 Setting: A forest, on a hot afternoon."),
      f("What is the solution?","The mouse nibbles through the ropes.",["The lion lets the mouse go.","The hunters leave."],"✅ Solution: The mouse nibbles through the ropes."),
      t("Why is a story map useful?","It organizes the important parts of a story",["It shows how to get to school","It replaces the story"],"A story map helps you understand and retell a story."),
      f("Which event happens first?","The mouse wakes the lion",["The lion is trapped","The lion lets her go"],"Events: 1. The mouse wakes the lion.")]},
 {pic:"⭐📚", text:"Ada wrote a book review for the school newsletter.<div class=\"realdoc\" style=\"text-align:left\"><b>📚 Book Review: <i>Anansi and the Pot of Wisdom</i></b><br>Reviewer: Ada, Grade 3 · Rating: ⭐⭐⭐⭐⭐<br><br>This folktale comes from Ghana, in West Africa. The main character is Anansi, a clever but selfish spider. He tries to hide all the wisdom in the world in a pot at the top of a tree. His problem is that he can't climb with the pot in front of him. His young son gives him a smart idea, and Anansi realizes that nobody has all the wisdom.<br><br>My favourite part is when the pot breaks and the wind carries wisdom around the world. I recommend this book to anyone who likes funny animal stories with a big lesson. My grandmother says she heard Anansi stories when she was a little girl in Nigeria!</div>",
  qs:[f("How many stars did Ada give the book?","Five",["Three","One"],"Rating: ⭐⭐⭐⭐⭐"),
      f("Who is the main character?","Anansi, a clever but selfish spider",["Ada's grandmother","A lion"],"The main character is Anansi, a clever but selfish spider."),
      f("What is Ada's favourite part?","When the pot breaks and the wind carries wisdom around the world",["When Anansi climbs the tree","When the son is born"],"My favourite part is when the pot breaks…"),
      t("Which sentence in the review is an opinion?","I recommend this book to anyone who likes funny animal stories.",["This folktale comes from Ghana.","The main character is a spider."],"A recommendation is what Ada thinks."),
      t("What is the purpose of a book review?","To tell others about a book and whether to read it",["To sell spiders","To write a new story"],"Reviews share an opinion about a book.")]}
], turn:{q:"Write a short book review (three sentences) of any story from this unit. Give it a star rating.",model:"I give \"The Tortoise and the Hare\" four stars. The main character is a patient tortoise who wins a race against a boastful hare. I like it because it teaches us not to give up."}}
],

poems:[
 {title:"The Spider and the Fly (by Mary Howitt, 1829: the first and last verses)",
  lines:["\"Will you walk into my parlour?\" said the Spider to the Fly,","\"'Tis the prettiest little parlour that ever you did spy;","The way into my parlour is up a winding stair,","And I've a many curious things to shew when you are there.\"","\"Oh no, no,\" said the little Fly, \"to ask me is in vain,","For who goes up your winding stair can ne'er come down again.\"","","(… In the middle verses, the Spider flatters the Fly again and again, praising her beautiful wings and bright eyes. At last, the silly Fly believes the sweet words, flies in, and is caught in the Spider's web …)","","And now, dear little children, who may this story read,","To idle, silly flattering words, I pray you ne'er give heed:","Unto an evil counsellor close heart and ear and eye,","And take a lesson from this tale, of the Spider and the Fly."],
  qs:[f("What does the Spider ask the Fly at the start?","\"Will you walk into my parlour?\"",["\"Can I come to your house?\"","\"Are you hungry?\""],"The first line is the Spider's question, inside quotation marks."),
      t("What does 'parlour' mean?","A sitting room (here, the spider's web)",["A garden","A kitchen"],"A parlour is an old word for a sitting room. The Spider means its web."),
      t("Why does the Fly say no at first?","Whoever goes up the stair never comes down again",["She is tired","She doesn't like stairs"],"\"For who goes up your winding stair can ne'er come down again.\""),
      t("What is the lesson of the poem?","Don't trust someone just because they say nice (flattering) things",["Spiders are pretty","Always visit new friends"],"\"To idle, silly flattering words, I pray you ne'er give heed.\""),
      t("How is this poem like a fable?","It has talking animals and a lesson",["It is very short","It has no characters"],"The poet even tells children to 'take a lesson from this tale'.")]},
 {title:"Once Upon a Time",
  lines:["Once upon a time, a story starts to grow,","With characters to meet and places we should know.","A setting by the sea, a forest, or a town,","A problem comes along to turn things upside down.","The hero tries and fails, then tries a different way,","Until the problem's solved, and it's a happy day.","And if it is a fable, there's one thing left to tell:","A lesson we can keep, to help us live as well."],
  qs:[f("Which words start the poem?","Once upon a time",["The end","Long, long ago"],"\"Once upon a time, a story starts to grow.\""),
      f("Which settings does the poem name?","The sea, a forest or a town",["A rocket, the Moon or Mars","A school only"],"\"A setting by the sea, a forest, or a town.\""),
      t("What does 'turn things upside down' mean here?","Cause big trouble or change",["Flip the book over","Stand on your head"],"A problem makes things go wrong."),
      f("Which word rhymes with 'way'?","day",["tell","grow"],"Way and day end with the same sound."),
      t("What extra part does the poem say a fable has?","A lesson",["A song","A map"],"\"And if it is a fable, there's one thing left to tell: a lesson…\"")]}
],

words:[
 /* story parts */
 {w:"character",e:"🦊",m:"a person, animal or creature in a story",ex:"The tortoise is my favourite character.",fill:"The lion is the main ___ in the story."},
 {w:"setting",e:"🏞️",m:"where and when a story happens",ex:"The setting of the fable is a meadow.",fill:"The ___ of the story is a castle long ago."},
 {w:"plot",e:"🗺️",m:"the events that happen in a story, in order",ex:"The plot of the story was full of surprises.",fill:"The ___ tells what happens first, next and last."},
 {w:"problem",e:"⚠️",m:"something that goes wrong in a story",ex:"The lion's problem was the hunters' net.",fill:"Every good story has a ___ to solve."},
 {w:"solution",e:"✅",m:"how the problem in a story is solved",ex:"The solution was the mouse nibbling the ropes.",fill:"The ___ came when the sparrow distracted the cat."},
 {w:"beginning",e:"1️⃣",m:"the first part of a story",ex:"We meet the characters at the beginning.",fill:"\"Once upon a time\" is a ___."},
 {w:"ending",e:"🏁",m:"the last part of a story",ex:"The story has a happy ending.",fill:"I didn't expect that surprising ___!"},
 {w:"moral",e:"💡",m:"the lesson a fable teaches",ex:"The moral is: slow and steady wins the race.",fill:"The ___ of the fable is to be kind."},
 {w:"narrator",e:"🗣️",m:"the person who tells the story",ex:"The narrator told us what the lion was thinking.",fill:"In this book, the ___ is a little girl."},
 {w:"dialogue",e:"💬",m:"the words characters say to each other",ex:"The dialogue is inside quotation marks.",fill:"Writers put ___ inside quotation marks."},
 /* kinds of stories and people */
 {w:"fable",e:"🐢",m:"a short story, often with animals, that teaches a lesson",ex:"The Tortoise and the Hare is a fable.",fill:"A ___ ends with a moral."},
 {w:"folktale",e:"🕷️",m:"a story told by people for a long time, passed down from parents to children",ex:"Anansi stories are folktales from Ghana.",fill:"My grandma told me a ___ from her village."},
 {w:"myth",e:"⚡",m:"an old story that explains how something in nature began",ex:"Some myths explain why the sun crosses the sky.",fill:"The Greek ___ told how thunder began."},
 {w:"legend",e:"🗡️",m:"an old story about a hero that may be partly true",ex:"The legend tells of a brave king.",fill:"The ___ of the lost city is very old."},
 {w:"hero",e:"🦸",m:"the brave main character who solves the problem",ex:"The little mouse was the hero of the story.",fill:"The ___ saved the village from the dragon."},
 {w:"villain",e:"🦹",m:"a bad character who causes trouble in a story",ex:"The sly fox was the villain.",fill:"In the story, the ___ tried to steal the treasure."},
 {w:"author",e:"✍️",m:"the person who writes a story or book",ex:"Mary Howitt is the author of the poem.",fill:"The ___ of this book lives in Toronto."},
 {w:"illustrator",e:"🎨",m:"the person who draws the pictures in a book",ex:"The illustrator painted beautiful animals.",fill:"The ___ drew a colourful lion on the cover."},
 {w:"title",e:"📛",m:"the name of a story or book",ex:"The title of the fable is The Lion and the Mouse.",fill:"Write the ___ at the top of your story."},
 {w:"chapter",e:"📑",m:"one part of a longer book",ex:"I read one chapter every night.",fill:"Let's read the next ___ tomorrow."},
 /* character traits */
 {w:"foolish",e:"🤪",m:"not sensible; silly",ex:"The foolish crocodile believed the trick.",fill:"It was ___ to nap in the middle of a race."},
 {w:"greedy",e:"🤑",m:"wanting more than you need",ex:"The greedy wife wanted the monkey's heart.",fill:"The ___ dog wanted both bones."},
 {w:"generous",e:"🎁",m:"happy to give and share",ex:"The generous monkey shared his fruit.",fill:"My ___ aunt gave me her old bike."},
 {w:"boastful",e:"📣",m:"talking too proudly about yourself",ex:"The boastful hare said he was the fastest.",fill:"Don't be ___; let others praise you."},
 {w:"humble",e:"🙇",m:"not thinking you are better than others",ex:"After the race, the hare was humble.",fill:"The champion was ___ and thanked her team."},
 {w:"wise",e:"🦉",m:"having good judgment and knowledge",ex:"The wise owl gave good advice.",fill:"Grandma always gives ___ advice."},
 {w:"sly",e:"🦊",m:"clever in a sneaky way",ex:"The sly fox tricked the crow.",fill:"The ___ fox crept up quietly."},
 {w:"timid",e:"🐇",m:"shy and easily frightened",ex:"The timid rabbit hid in its burrow.",fill:"The ___ kitten hid under the bed."},
 {w:"stubborn",e:"🐐",m:"refusing to change your mind",ex:"The stubborn goat would not move off the bridge.",fill:"My ___ little brother won't wear his coat."},
 {w:"lazy",e:"🦥",m:"not wanting to work",ex:"The lazy grasshopper played all summer.",fill:"The ___ cat slept all day."},
 /* speech words */
 {w:"whispered",e:"🤫",m:"spoke very softly",ex:"\"It's a secret,\" she whispered.",fill:"\"Shh, the baby is sleeping,\" Mom ___."},
 {w:"shouted",e:"📢",m:"said something very loudly",ex:"\"Help!\" shouted the lion.",fill:"\"Watch out!\" Leo ___."},
 {w:"replied",e:"↩️",m:"answered",ex:"\"Yes, please,\" replied the mouse.",fill:"\"I'm fine, thank you,\" she ___."},
 {w:"asked",e:"❓",m:"said a question",ex:"\"How did you beat me?\" asked the hare.",fill:"\"Where are you going?\" ___ Grandma."},
 {w:"exclaimed",e:"❗",m:"said something suddenly with strong feeling",ex:"\"What a surprise!\" exclaimed Neel.",fill:"\"I won!\" she ___ happily."},
 {w:"grumbled",e:"😒",m:"complained in a low, unhappy voice",ex:"\"I don't want to clean my room,\" he grumbled.",fill:"\"It's always raining,\" Sam ___."},
 {w:"begged",e:"🥺",m:"asked very strongly and desperately",ex:"\"Please let me go!\" begged the mouse.",fill:"\"Please, just one more story!\" Neel ___."},
 {w:"announced",e:"📯",m:"told everyone something important",ex:"\"The race will begin now!\" announced the fox.",fill:"\"We're having a party!\" the teacher ___."},
 {w:"explained",e:"🧑‍🏫",m:"made something clear by telling more about it",ex:"\"Fables teach lessons,\" Grandma explained.",fill:"\"This is how a story map works,\" Ms. Chen ___."},
 {w:"sighed",e:"😮‍💨",m:"breathed out slowly because you were tired, sad or bored",ex:"\"There's nothing to do,\" Neel sighed.",fill:"\"I'm so tired,\" she ___."}
],

spelling:[
 {w:"story",s:"Tell me a story.",tip:"'or' as in for."},
 {w:"once",s:"Once upon a time…",tip:"Tricky: it sounds like 'wunce'."},
 {w:"upon",s:"Once upon a time…"},
 {w:"said",s:"\"Hello,\" said the fox.",tip:"Tricky: 'ai' sounds like short e."},
 {w:"asked",s:"\"Why?\" asked the mouse.",tip:"ask + ed."},
 {w:"lion",s:"The lion roared."},
 {w:"mouse",s:"The mouse was tiny.",tip:"'ou' as in out."},
 {w:"tortoise",s:"The tortoise won the race.",tip:"tor-toise. It sounds like 'tor-tus'."},
 {w:"monkey",s:"The monkey climbed the tree.",tip:"Ends with -ey."},
 {w:"fable",s:"A fable teaches a lesson.",tip:"Ends with -le."},
 {w:"hero",s:"The mouse was the hero."},
 {w:"title",s:"Write the title.",tip:"Ends with -le."},
 {w:"chapter",s:"Read one chapter.",tip:"chap-ter."},
 {w:"ending",s:"It had a happy ending.",tip:"end + ing."},
 {w:"moral",s:"What is the moral?",tip:"mor-al."}
],

facts:[
 {e:"🏛️",c:"Aesop, the famous teller of fables, lived in ancient Greece about 2,500 years ago.",t:true,x:"True! Stories say Aesop was a clever storyteller. Many fables we know, like The Tortoise and the Hare, are named after him."},
 {e:"🇮🇳",c:"The Panchatantra is a collection of animal stories from ancient India.",t:true,x:"True! It is about 2,000 years old and was created to teach young princes how to be wise."},
 {e:"👠",c:"There are hundreds of different versions of the Cinderella story from around the world.",t:true,x:"True! One of the oldest is Ye Xian, a story from China written down more than 1,000 years ago."},
 {e:"🐾",c:"Fables always have human characters.",t:false,x:"Not true! Fables very often have animals that talk and act like people."},
 {e:"💬",c:"Quotation marks go around the exact words a character says.",t:true,x:"True! They are also called speech marks."},
 {e:"🏞️",c:"The setting is the main character in a story.",t:false,x:"Not true! The setting is where and when a story happens."},
 {e:"🇩🇪",c:"The Brothers Grimm collected fairy tales in Germany.",t:true,x:"True! In the 1800s, they wrote down stories like Hansel and Gretel that people had told for generations."},
 {e:"🇩🇰",c:"Hans Christian Andersen, who wrote The Ugly Duckling, was from Denmark.",t:true,x:"True! He wrote more than 150 fairy tales."},
 {e:"✍️",c:"Aesop wrote his fables in English.",t:false,x:"Not true! Aesop lived in ancient Greece. His fables were told in Greek and later translated into many languages."},
 {e:"🕷️",c:"Anansi stories travelled from West Africa to the Caribbean.",t:true,x:"True! People carried the stories with them, and they are still told today."},
 {e:"📚",c:"People told stories long before writing was invented.",t:true,x:"True! For thousands of years, stories were passed down by telling them aloud."},
 {e:"🐢",c:"In Aesop's fable, the hare won the race.",t:false,x:"Not true! The slow and steady tortoise won because the hare stopped for a nap."}
],

writing:[
 {e:"🦊",t:"Create a character and a setting",level:"Step 1 · Description",
  prompt:"Invent an animal character for your own fable. Write at least 4 sentences: what your character looks like, what they are like inside (a character trait like greedy, generous, boastful or wise), and where they live (the setting). Use at least 2 words from the word bank.",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],["\\b(foolish|greedy|generous|boastful|humble|wise|sly|timid|stubborn|lazy|kind|brave|clever|proud|selfish|patient|honest|curious|shy|helpful)\\b","I used a character-trait word"],["\\b(lives?|lived|in a|in the|by the|near)\\b","I described the setting"]],
  starters:["My character is a ","It has ","It is very ","It lives in "],
  model:"My character is a little red fox named Rusty. He has a bushy tail and bright, shiny eyes. Rusty is clever, but he is also boastful, and he always tells everyone how smart he is. He lives in a dark, whispering forest beside a cold river in Canada."},
 {e:"💬",t:"Write a conversation",level:"Step 2 · Dialogue",
  prompt:"Write a conversation between two characters with at least 4 lines of dialogue. Put each speaker's exact words inside quotation marks. Use a different speech word each time (said, asked, replied, whispered, shouted…). Start a new line each time a new character speaks.",
  minS:4,minWords:2,
  rx:[["([\"“][^\"”]+[\"”][\\s\\S]*){4}","I wrote at least 4 lines inside quotation marks"],["\\b(asked|replied|whispered|shouted|exclaimed|grumbled|begged|announced|explained|sighed|cried|laughed|giggled|answered)\\b","I used an interesting speech word"],["\\?","One character asks a question"],["\\n","Each speaker starts on a new line"]],
  starters:["\"Hello,\" said the ","\"Where are you going?\" asked ","\"","replied "],
  model:"\"Where are you going in such a hurry?\" asked the owl.\n\"I'm going to the river to show everyone my new tail,\" boasted Rusty the fox.\n\"Be careful,\" whispered the owl. \"The ice is thin.\"\n\"I'm too clever to fall in!\" laughed Rusty, and he ran off."},
 {e:"📚",t:"Write your own fable (and retell it aloud!)",level:"Step 3 · Fable",
  prompt:"Write your own fable of at least 8 sentences. Include animal characters, a setting, a problem, at least 2 lines of dialogue in quotation marks, a solution, and a moral at the end (Lesson: … or Moral: …). When you finish, press 🔊 Read my writing, then retell your fable aloud to your family, using a different voice for each character!",
  minS:8,minWords:3,
  rx:[["\\b(Once upon a time|Long ago|One day|There once was)\\b","My beginning uses a story opening"],["([\"“][^\"”]+[\"”][\\s\\S]*){2}","I used dialogue in quotation marks (at least 2)"],["\\b(But|Suddenly|One day|Then)\\b","My middle has a problem (But, Suddenly, Then…)"],["\\b(Finally|In the end|At last|From that day)\\b","My ending shows the solution"],["\\b(Lesson|Moral)\\s*:","I wrote the moral (Lesson: or Moral:)"],["(\\b(\\w+ed|was|were|said|ran|saw|thought|felt|went|came|took|made|got|told|knew|began|fell|flew|swam)\\b[\\s\\S]*){3}","I wrote in the past tense"]],
  starters:["Once upon a time, in ","\"","Suddenly, ","But ","Finally, ","Lesson: "],
  model:"Once upon a time, in a forest beside a cold river, lived a boastful fox named Rusty. \"I'm the cleverest animal in the forest!\" he told everyone. One winter morning, the wise old owl warned him, \"Don't walk on the river. The ice is thin.\" But Rusty laughed and ran onto the ice to show off. Suddenly, the ice cracked, and Rusty fell into the freezing water! A timid little beaver heard his cries and quickly pushed a long branch towards him. Rusty grabbed it, and the beaver pulled him safely to the shore. Finally, the shivering fox said, \"Thank you. I wasn't clever at all. I was foolish.\" From that day on, Rusty listened to others and never boasted again.\nLesson: Being wise means listening to good advice."}
]
});
})();
