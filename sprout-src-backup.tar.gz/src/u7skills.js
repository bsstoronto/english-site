/* ===================== UNIT 7 · SKILL BANKS AND SKILL LIST (original content) ===================== */
(function(){
const u=UNITS.find(x=>x.id==="maths");
const set=k=>u.words.slice(k*10,k*10+10);
const MIX=(...g)=>()=>R(g)();
const box=(t,txt)=>`<div class="qbox" style="margin:0 0 12px;font-size:18px;line-height:1.6;font-weight:400"><b>${t}</b><br>${txt}</div>`;
const rint=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
const NUMW=["zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve"];

/* ================= PICTURES: CLOCK FACES AND SHAPES ================= */
function clockSVG(h,m){
  let s=`<svg viewBox="0 0 120 120" width="150" height="150" style="display:block;margin:8px auto" role="img" aria-label="clock"><circle cx="60" cy="60" r="56" fill="#fff" stroke="#2f6b4f" stroke-width="4"/>`;
  for(let i=1;i<=12;i++){const a=(i*30-90)*Math.PI/180;s+=`<text x="${(60+44*Math.cos(a)).toFixed(1)}" y="${(60+44*Math.sin(a)+4.5).toFixed(1)}" text-anchor="middle" font-size="13" font-family="sans-serif" fill="#1d3b2c" font-weight="700">${i}</text>`}
  for(let i=0;i<60;i++){if(i%5===0)continue;const a=(i*6-90)*Math.PI/180;s+=`<circle cx="${(60+53*Math.cos(a)).toFixed(1)}" cy="${(60+53*Math.sin(a)).toFixed(1)}" r="0.9" fill="#7a9a88"/>`}
  const ha=((h%12)+m/60)*30-90,ma=m*6-90,rad=d=>d*Math.PI/180;
  s+=`<line x1="60" y1="60" x2="${(60+26*Math.cos(rad(ha))).toFixed(1)}" y2="${(60+26*Math.sin(rad(ha))).toFixed(1)}" stroke="#1d3b2c" stroke-width="6" stroke-linecap="round"/>`;
  s+=`<line x1="60" y1="60" x2="${(60+40*Math.cos(rad(ma))).toFixed(1)}" y2="${(60+40*Math.sin(rad(ma))).toFixed(1)}" stroke="#3a9a6a" stroke-width="3.5" stroke-linecap="round"/><circle cx="60" cy="60" r="4" fill="#1d3b2c"/></svg>`;
  return s;
}
const SHAPES=[{n:"triangle",s:3},{n:"square",s:4},{n:"rectangle",s:4},{n:"pentagon",s:5},{n:"hexagon",s:6},{n:"octagon",s:8},{n:"circle",s:0}];
function shapeSVG(name){
  const st=`fill="#cfeedd" stroke="#2f6b4f" stroke-width="3"`;let body="";
  if(name==="circle")body=`<circle cx="60" cy="60" r="44" ${st}/>`;
  else if(name==="rectangle")body=`<rect x="12" y="32" width="96" height="56" ${st}/>`;
  else if(name==="square")body=`<rect x="22" y="22" width="76" height="76" ${st}/>`;
  else{const n={triangle:3,pentagon:5,hexagon:6,octagon:8}[name];const off=name==="octagon"?22.5:-90;const pts=[];
    for(let i=0;i<n;i++){const a=(off+i*360/n)*Math.PI/180;pts.push((60+46*Math.cos(a)).toFixed(1)+","+(64+46*Math.sin(a)).toFixed(1))}body=`<polygon points="${pts.join(" ")}" ${st}/>`}
  return `<svg viewBox="0 0 120 120" width="130" height="130" style="display:block;margin:8px auto" role="img" aria-label="shape">${body}</svg>`;
}

/* ================= TIME ================= */
const hourW=h=>NUMW[h];
function timeWords(h,m){const nh=h%12+1;
  if(m===0)return `${hourW(h)} o'clock`;if(m===30)return `half past ${hourW(h)}`;if(m===15)return `quarter past ${hourW(h)}`;if(m===45)return `quarter to ${hourW(nh)}`;
  return `${h}:${String(m).padStart(2,"0")}`}
const digital=(h,m)=>`${h}:${String(m).padStart(2,"0")}`;
const clockQ=()=>{const h=rint(1,12),m=R([0,0,30,15,45]);const right=timeWords(h,m);
  const pool=uniq([timeWords(h,R([0,30,15,45].filter(z=>z!==m))),timeWords(h%12+1,m),timeWords(((h+10)%12)+1,m)].filter(z=>z!==right));
  return mcQ(`${clockSVG(h,m)}What time does the clock show?`,right,SAMPLE(pool,2),`The short hour hand is ${m===0?"on":m===45?"almost at":"just past"} ${m===45?h%12+1:h}. The long minute hand is on ${m===0?"12 (o'clock)":m===30?"6 (half past)":m===15?"3 (quarter past)":"9 (quarter to)"}. So it is <b>${right}</b>.`,"Short hand = hour. Long hand: 12 → o'clock, 3 → quarter past, 6 → half past, 9 → quarter to.")};
const clock5=()=>{const h=rint(1,12),m=5*rint(1,11);const right=digital(h,m);
  const wr=uniq([digital(h,(m+5)%60||5),digital(h,(m+55)%60||55),digital(h%12+1,m),digital(m/5,(h*5)%60)].filter(z=>z!==right));
  return mcQ(`${clockSVG(h,m)}What time does the clock show?`,right,SAMPLE(wr,2),`The hour hand is just past <b>${h}</b>. The minute hand points to ${m/5}, and ${m/5} × 5 = <b>${m}</b> minutes. So it is <b>${right}</b>.`,"Count by fives from the 12 to the long hand.")};
const clockType=()=>{const h=rint(1,12),m=5*rint(0,11);
  return {type:"type",q:`${clockSVG(h,m)}Write the time in numbers, like <b>4:25</b>.`,a:[digital(h,m)].concat(m===0?[`${h} o'clock`,`${h}:00`]:[]),why:`Hour hand: just past ${h}. Minute hand: ${m/5||12} → ${m} minutes. Time: <b>${digital(h,m)}</b>.`,hint:"Hours first, then a colon (:), then the minutes. Count the minutes by fives."}};
const wordsToNum=()=>{const h=rint(1,12),m=R([0,15,30,45]);const w=timeWords(h,m);const right=digital(m===45?h:h,m);
  return mcQ(`Which time is the same as <b>${w}</b>?`,right,SAMPLE(uniq([digital(h,(m+30)%60),digital(h%12+1,m),digital(h,m===15?45:m===45?15:m===0?30:0)]).filter(z=>z!==right),2),`<b>${w}</b> = <b>${right}</b>. Quarter past = :15, half past = :30, quarter to = :45 (of the hour before the next one).`,"o'clock = :00 · quarter past = :15 · half past = :30 · quarter to = :45")};
const fmtT=mins=>{let h=Math.floor(mins/60)%12;if(h===0)h=12;return digital(h,mins%60)};
const elapsed=()=>{const t=R(["end","long"]);const sh=rint(1,9),sm=R([0,15,30]);const dur=R([15,30,45,60,90,120]);const st=sh*60+sm,en=st+dur;
  const durW=dur===60?"1 hour":dur===90?"1 and a half hours":dur===120?"2 hours":dur+" minutes";
  const act=R(["The film","The football game","The art class","The bus trip","The swimming lesson","The party"]);
  if(t==="end")return mcQ(`⏱️ ${act} starts at <b>${fmtT(st)}</b> and lasts <b>${durW}</b>. What time does it end?`,fmtT(en),SAMPLE(uniq([fmtT(en+15),fmtT(en-15),fmtT(en+60),fmtT(st+dur/2|0)]).filter(z=>z!==fmtT(en)),2),`${fmtT(st)} + ${durW} = <b>${fmtT(en)}</b>.`,"Add the hours first, then the minutes.");
  const opts=["15 minutes","30 minutes","45 minutes","1 hour","1 and a half hours","2 hours"];
  return mcQ(`⏱️ ${act} starts at <b>${fmtT(st)}</b> and ends at <b>${fmtT(en)}</b>. How long is it?`,durW,SAMPLE(opts.filter(z=>z!==durW),2),`From ${fmtT(st)} to ${fmtT(en)} is <b>${durW}</b>.`,"Count on from the start time to the end time.")};
const DAYS=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];
const calQ=()=>{const t=R(["dayAfter","dayBefore","monAfter","monBefore","days","season"]);
  if(t==="dayAfter"){const i=rint(0,6);return mcQ(`📅 Which day comes right <b>after</b> ${DAYS[i]}?`,DAYS[(i+1)%7],SAMPLE(DAYS.filter((_,k)=>k!==(i+1)%7&&k!==i),2),`${DAYS[i]} → <b>${DAYS[(i+1)%7]}</b>.`,"Say the days of the week in order.")}
  if(t==="dayBefore"){const i=rint(0,6);return mcQ(`📅 Which day comes right <b>before</b> ${DAYS[i]}?`,DAYS[(i+6)%7],SAMPLE(DAYS.filter((_,k)=>k!==(i+6)%7&&k!==i),2),`<b>${DAYS[(i+6)%7]}</b> → ${DAYS[i]}.`,"Say the days of the week in order.")}
  if(t==="monAfter"){const i=rint(0,11);return mcQ(`📅 Which month comes right <b>after</b> ${MONTHS[i]}?`,MONTHS[(i+1)%12],SAMPLE(MONTHS.filter((_,k)=>k!==(i+1)%12&&k!==i),2),`${MONTHS[i]} → <b>${MONTHS[(i+1)%12]}</b>.`,"Say the months of the year in order.")}
  if(t==="monBefore"){const i=rint(0,11);return mcQ(`📅 Which month comes right <b>before</b> ${MONTHS[i]}?`,MONTHS[(i+11)%12],SAMPLE(MONTHS.filter((_,k)=>k!==(i+11)%12&&k!==i),2),`<b>${MONTHS[(i+11)%12]}</b> → ${MONTHS[i]}.`,"Say the months of the year in order.")}
  if(t==="days"){const i=rint(0,11);const d=i===1?"28 (or 29 in a leap year)":[3,5,8,10].includes(i)?"30":"31";return mcQ(`📅 How many days does <b>${MONTHS[i]}</b> have?`,d,["28 (or 29 in a leap year)","30","31"].filter(z=>z!==d),`<b>${MONTHS[i]}</b> has ${d} days. Remember: "Thirty days hath September, April, June, and November…"`,"Use the rhyme: Thirty days hath September…")}
  const i=rint(0,11);const k=R([1,2,3]);return mcQ(`📅 What month is it <b>${k} month${k>1?"s":""} after</b> ${MONTHS[i]}?`,MONTHS[(i+k)%12],SAMPLE(MONTHS.filter((_,j)=>j!==(i+k)%12),2),`Count on ${k} from ${MONTHS[i]}: <b>${MONTHS[(i+k)%12]}</b>.`,"Count on one month at a time.")};
const TF=[
 {q:"How many minutes are in one hour?",a:"60",o:["100","12"],why:"1 hour = 60 minutes."},
 {q:"How many seconds are in one minute?",a:"60",o:["100","10"],why:"1 minute = 60 seconds."},
 {q:"How many hours are in one whole day?",a:"24",o:["12","60"],why:"A day and a night together = 24 hours."},
 {q:"How many days are in one week?",a:"7",o:["5","10"],why:"Monday to Sunday = 7 days."},
 {q:"How many months are in one year?",a:"12",o:["10","52"],why:"January to December = 12 months."},
 {q:"How many days are in a normal year?",a:"365",o:["100","52"],why:"A leap year has 366."},
 {q:"How many minutes are in half an hour?",a:"30",o:["50","15"],why:"Half of 60 is 30."},
 {q:"How many minutes are in a quarter of an hour?",a:"15",o:["25","4"],why:"60 ÷ 4 = 15."},
 {q:"Which hand on a clock shows the hours?",a:"The short hand",o:["The long hand","Both hands"],why:"Short = hour, long = minutes."},
 {q:"Which is longer: one hour or 50 minutes?",a:"One hour",o:["50 minutes","They are the same"],why:"One hour is 60 minutes."},
 {q:"Which is the shortest?",a:"One second",o:["One minute","One hour"],why:"Second < minute < hour."},
 {q:"How many years are in a century?",a:"100",o:["10","1,000"],why:"A century = 100 years."},
 {q:"What does a.m. mean?",a:"The time from midnight to noon (morning)",o:["The time from noon to midnight","Only at night"],why:"7 a.m. is in the morning; 7 p.m. is in the evening."},
 {q:"You eat breakfast at 7:30. Is that a.m. or p.m.?",a:"a.m.",o:["p.m.","Neither"],why:"Breakfast is in the morning: a.m."},
 {q:"You go to bed at 8:00 at night. Is that a.m. or p.m.?",a:"p.m.",o:["a.m.","Neither"],why:"Evening and night times after noon are p.m."},
 {q:"How many weeks are in about one year?",a:"52",o:["12","100"],why:"There are about 52 weeks in a year."},
 {q:"How many days are in two weeks?",a:"14",o:["7","20"],why:"7 + 7 = 14."},
 {q:"What do we call 12 o'clock in the middle of the day?",a:"Noon",o:["Midnight","Dawn"],why:"Noon = 12 p.m. Midnight = 12 a.m."},
 {q:"What do we call 12 o'clock in the middle of the night?",a:"Midnight",o:["Noon","Lunchtime"],why:"Midnight is when a new day begins."},
 {q:"Which tool measures time using sand?",a:"An hourglass",o:["A sundial","A ruler"],why:"Sand trickles from the top to the bottom."},
 {q:"Which tool uses a shadow to show the time?",a:"A sundial",o:["An hourglass","A calendar"],why:"The Sun's shadow moves across the dial."},
 {q:"Which day comes after Friday?",a:"Saturday",o:["Thursday","Monday"],why:"Friday → Saturday → Sunday."}
];

/* ================= SHAPES ================= */
const shapeName=()=>{const s=R(SHAPES);return mcQ(`${shapeSVG(s.n)}What is this shape called?`,s.n,SAMPLE(SHAPES.filter(x=>x.n!==s.n).map(x=>x.n),2),`This is a <b>${s.n}</b>. ${s.s?`It has ${s.s} sides and ${s.s} corners.`:"It has no sides and no corners."}`,"Count the sides.")};
const SOBJ={circle:["a coin","a wheel","a clock face","a dinner plate"],square:["a square sticky note","one square on a chessboard","a square window","a slice of square cheese"],rectangle:["a door","a book","a phone","a dollar bill"],triangle:["a slice of pizza","a sandwich cut corner to corner","a roof","a yield sign"],hexagon:["one cell of a honeycomb","a nut that fits a bolt","a hexagon floor tile","a soccer ball's dark patch? no"],octagon:["a stop sign","an octagon table","an umbrella seen from above","an octagon window"],pentagon:["a baseball home plate","a simple drawing of a house","the Pentagon building in the USA","a pentagon sticker"]};
SOBJ.hexagon[3]="a hexagon-shaped pencil seen from the end";
const shapeObj=()=>{const s=R(SHAPES);const right=R(SOBJ[s.n]);const wr=SAMPLE(SHAPES.filter(x=>x.n!==s.n&&x.s!==s.s),2).map(x=>R(SOBJ[x.n]));
  return mcQ(`${shapeSVG(s.n)}Which of these is usually shaped like this <b>${s.n}</b>?`,right,wr,`<b>${cap(right)}</b> is shaped like a ${s.n}.`,"Picture each object. Count its sides.")};
const shapeCount=()=>{const s=R(SHAPES.filter(x=>x.s));const what=R(["sides","corners"]);
  if(Math.random()<.4)return {type:"type",q:`${shapeSVG(s.n)}How many <b>${what}</b> does this ${s.n} have? Type the number.`,a:[String(s.s),NUMW[s.s]],why:`A ${s.n} has <b>${s.s} ${what}</b>.`,hint:"Put your finger on one and count all the way around."};
  return mcQ(`${shapeSVG(s.n)}How many <b>${what}</b> does this shape have?`,String(s.s),SAMPLE(["3","4","5","6","8"].filter(z=>z!==String(s.s)),2),`A ${s.n} has <b>${s.s} ${what}</b>.`,"Put your finger on one and count all the way around.")};
const SH=[
 {q:"Which shape has 3 sides?",a:"Triangle",o:["Square","Hexagon"],why:"Tri means three."},
 {q:"Which shape has 6 sides?",a:"Hexagon",o:["Pentagon","Octagon"],why:"Hex means six."},
 {q:"Which shape has 5 sides?",a:"Pentagon",o:["Hexagon","Triangle"],why:"Penta means five."},
 {q:"Which shape has 8 sides?",a:"Octagon",o:["Hexagon","Rectangle"],why:"Octo means eight, like an octopus's eight arms."},
 {q:"Which shape has four equal sides?",a:"Square",o:["Rectangle","Triangle"],why:"A rectangle has two longer sides."},
 {q:"What shape is a stop sign?",a:"Octagon",o:["Hexagon","Circle"],why:"A stop sign has eight sides."},
 {q:"What 3D shape is a ball?",a:"Sphere",o:["Cube","Cylinder"],why:"A sphere is round all over."},
 {q:"What 3D shape is a dice?",a:"Cube",o:["Sphere","Cone"],why:"A cube has six square faces."},
 {q:"What 3D shape is a can of soup?",a:"Cylinder",o:["Cube","Cone"],why:"Two circle faces and a curved side."},
 {q:"What 3D shape is an ice cream cone?",a:"Cone",o:["Cylinder","Sphere"],why:"A circle face and a point."},
 {q:"What 3D shape is a cereal box?",a:"Rectangular prism (cuboid)",o:["Sphere","Cone"],why:"It has six rectangle faces."},
 {q:"What 3D shape are the Great Pyramids of Egypt?",a:"Pyramid",o:["Cube","Cylinder"],why:"Triangle faces that meet at a point on top."},
 {q:"How many faces does a cube have?",a:"6",o:["4","8"],why:"Top, bottom and four sides."},
 {q:"Which 3D shape has no flat faces at all?",a:"Sphere",o:["Cube","Cylinder"],why:"A sphere is curved everywhere."},
 {q:"What is the flat shape of a pizza?",a:"Circle",o:["Square","Triangle"],why:"Most pizzas are round."},
 {q:"What flat shape is a door?",a:"Rectangle",o:["Circle","Hexagon"],why:"A door has four corners and two long sides."},
 {q:"What do we call the point where two sides of a shape meet?",a:"A corner",o:["A face","A line"],why:"A square has four corners."},
 {q:"How many corners does a circle have?",a:"0",o:["1","4"],why:"A circle is perfectly round."},
 {q:"You cut a square from corner to corner. What two shapes do you get?",a:"Two triangles",o:["Two circles","Two squares"],why:"The cut makes two shapes with three sides each."},
 {q:"Which shape do bees use for honeycombs?",a:"Hexagon",o:["Circle","Square"],why:"Hexagons fit together with no gaps."},
 {q:"Which shape is strongest for building bridges?",a:"Triangle",o:["Circle","Square"],why:"Triangles keep their shape when pushed."},
 {q:"Which 3D shape can roll AND stand flat?",a:"Cylinder",o:["Cube","Sphere"],why:"It rolls on its curved side and stands on a circle face."}
];

/* ================= MONEY ================= */
const fmt=c=>c<100?`${c}¢`:(c%100===0?`$${c/100}`:`$${Math.floor(c/100)}.${String(c%100).padStart(2,"0")}`);
const COINS=[1,5,10,25,100,200];
const coinTxt=c=>`<span style="display:inline-block;border:2px solid #b8962e;background:#fff6d6;border-radius:999px;padding:2px 9px;margin:2px;font-weight:700">${c>=100?"$"+c/100:c+"¢"}</span>`;
const coinsQ=()=>{const n=rint(2,5);const cs=[];for(let i=0;i<n;i++)cs.push(R(Math.random()<.7?[5,10,25]:[1,5,10,25,100]));cs.sort((a,b)=>b-a);const tot=cs.reduce((a,b)=>a+b,0);
  return mcQ(`🪙 How much money is this?<br>${cs.map(coinTxt).join(" ")}`,fmt(tot),SAMPLE(uniq([tot+5,tot-5,tot+10,tot+25,tot-10].filter(z=>z>0&&z!==tot)).map(fmt),2),`${cs.map(c=>c>=100?"$"+c/100:c+"¢").join(" + ")} = <b>${fmt(tot)}</b>. (100¢ = $1)`,"Start with the biggest coin and count on.")};
const changeQ=()=>{if(Math.random()<.5){const price=5*rint(3,19);const tot=100-price;return mcQ(`🧾 A pencil costs <b>${price}¢</b>. You pay with <b>$1</b>. How much change do you get?`,fmt(tot),SAMPLE(uniq([tot+5,tot-5,tot+10,price].filter(z=>z>0&&z!==tot)).map(fmt),2),`$1 = 100¢. 100¢ − ${price}¢ = <b>${tot}¢</b>.`,"$1 is 100 cents. Take away the price.")}
  const paid=R([5,10,20]);const price=rint(1,paid-1);const ch=paid-price;const it=R(["a book","a toy car","a ball","a jar of honey","a kite","a box of crayons"]);
  return mcQ(`🧾 ${cap(it)} costs <b>$${price}</b>. You pay with <b>$${paid}</b>. How much change do you get?`,`$${ch}`,SAMPLE(uniq([ch+1,ch-1,price,ch+2].filter(z=>z>0&&z!==ch)),2).map(z=>"$"+z),`$${paid} − $${price} = <b>$${ch}</b>.`,"Change = what you pay − the price.")};
const MENU=[["🍎 an apple",1],["🥕 a bunch of carrots",2],["🍞 a loaf of bread",3],["💐 some flowers",4],["🥚 a box of eggs",5],["🍯 a jar of honey",6],["🧃 a juice",2],["🧁 a cupcake",3]];
const shopQ=()=>{const items=SAMPLE(MENU,R([2,3]));const tot=items.reduce((a,b)=>a+b[1],0);
  if(Math.random()<.5)return mcQ(`🛒 Price list: ${MENU.map(m=>`${m[0]} $${m[1]}`).join(" · ")}<br><br>You buy <b>${items.map(i=>i[0].replace(/^\S+ /,"")).join(" and ")}</b>. What is the total?`,`$${tot}`,SAMPLE(uniq([tot+1,tot-1,tot+2,tot+3].filter(z=>z>0&&z!==tot)),2).map(z=>"$"+z),`${items.map(i=>"$"+i[1]).join(" + ")} = <b>$${tot}</b>.`,"Find each price, then add them all.");
  const bud=Math.max(1,tot+R([-3,-2,-1,0,1,2,3]));const ok=tot<=bud;return mcQ(`🛒 Your budget is <b>$${bud}</b>. You want ${items.map(i=>i[0].replace(/^\S+ /,"")+" ($"+i[1]+")").join(", ")}. Do you have enough money?`,ok?"Yes":"No",[ok?"No":"Yes"],`Total = ${items.map(i=>"$"+i[1]).join(" + ")} = $${tot}. ${ok?`$${tot} is not more than $${bud}, so <b>yes</b>${bud>tot?`, and you have $${bud-tot} left`:""}.`:`$${tot} is more than $${bud}, so <b>no</b>. You need $${tot-bud} more.`}`,"Add the prices, then compare with your budget.")};
const MB=[
 {q:"How many cents make one dollar?",a:"100",o:["10","50"],why:"$1 = 100¢."},
 {q:"How many 25¢ coins make one dollar?",a:"4",o:["2","25"],why:"25 + 25 + 25 + 25 = 100."},
 {q:"How many 10¢ coins make one dollar?",a:"10",o:["5","100"],why:"10 × 10 = 100."},
 {q:"How many 5¢ coins make 25¢?",a:"5",o:["25","2"],why:"5 + 5 + 5 + 5 + 5 = 25."},
 {q:"Which is worth more: three 10¢ coins or one 25¢ coin?",a:"Three 10¢ coins",o:["One 25¢ coin","They are the same"],why:"30¢ is more than 25¢."},
 {q:"What is the money of India called?",a:"Rupee",o:["Dollar","Yen"],why:"₹ is the symbol of the rupee."},
 {q:"What is the money of Japan called?",a:"Yen",o:["Euro","Peso"],why:"¥ is the yen symbol."},
 {q:"Which money is used in many countries in Europe?",a:"Euro",o:["Rupee","Yen"],why:"€ is the euro."},
 {q:"What do we call money that you keep for later?",a:"Savings",o:["Change","A price"],why:"You save money in a bank or piggy bank."},
 {q:"What is a budget?",a:"A plan for how to use your money",o:["A kind of coin","A shop"],why:"A budget helps you not spend too much."},
 {q:"Which is a NEED, not a want?",a:"Food",o:["A toy","Sweets"],why:"We need food to live."},
 {q:"Which is a WANT, not a need?",a:"A video game",o:["Water","A warm coat in winter"],why:"We can live without a video game."},
 {q:"What do you call the money you get back when you pay too much?",a:"Change",o:["Price","Total"],why:"Pay $5 for a $3 book and get $2 change."},
 {q:"What did people do before money was invented?",a:"Traded (bartered) things",o:["Used phones","Used cards"],why:"They swapped goods, like wheat for a cow."},
 {q:"Which shells were once used as money?",a:"Cowrie shells",o:["Clam shells","Turtle shells"],why:"Cowrie shells were used in Africa and Asia."},
 {q:"Where was paper money first used?",a:"China",o:["Canada","Australia"],why:"About 1,000 years ago."},
 {q:"Two items cost $3 and $4. What is the total?",a:"$7",o:["$1","$12"],why:"3 + 4 = 7."},
 {q:"Which is the best way to spend money wisely?",a:"Make a list and a budget first",o:["Buy everything you see","Never count your money"],why:"Planning helps you buy what you really need."},
 {q:"What do we call how much something costs?",a:"Its price",o:["Its change","Its shape"],why:"The price is on the tag."},
 {q:"How do people earn money?",a:"By working",o:["By sleeping","By wishing"],why:"People are paid for their work."}
];

/* ================= MATHS WORDS AND WORD PROBLEMS ================= */
const NAMES=["Priya","Sam","Arjun","Mia","Leo","Grandma","Asha","Dev","Sofia","Lula"];
const OPS=["add","subtract","multiply","divide"];
const wpGen=()=>{const op=R(OPS),nm=R(NAMES);let q,ans,kw;
  if(op==="add"){const a=rint(5,40),b=rint(3,30);ans=a+b;const t=R([
    [`${nm} has ${a} stickers. A friend gives ${nm} ${b} more. How many stickers does ${nm} have <b>altogether</b>?`,"altogether"],
    [`There are ${a} red apples and ${b} green apples. How many apples are there <b>in all</b>?`,"in all"],
    [`A book costs $${a} and a pen costs $${b}. What is the <b>total</b> cost?`,"total"],
    [`On Monday ${nm} read ${a} pages. On Tuesday ${nm} read ${b} pages. How many pages is that <b>altogether</b>?`,"altogether"]]);q=t[0];kw=t[1]}
  else if(op==="subtract"){const a=rint(20,60),b=rint(3,a-5);ans=a-b;const t=R([
    [`${nm} had ${a} coins and spent ${b}. How many coins are <b>left</b>?`,"left"],
    [`There were ${a} cookies. The children ate ${b}. How many cookies are <b>left</b>?`,"left"],
    [`A tree is ${a} metres tall. A house is ${b} metres tall. What is the <b>difference</b> in height?`,"difference"],[`${nm} has ${a} marbles. Sam has ${b}. How many <b>more</b> marbles does ${nm} have?`,"how many more"]]);q=t[0];kw=t[1]}
  else if(op==="multiply"){const a=rint(2,6),b=rint(2,10);ans=a*b;const t=R([
    [`There are ${a} boxes. <b>Each</b> box has ${b} crayons. How many crayons are there?`,"each"],
    [`${nm} plants ${a} <b>rows</b> of flowers with ${b} flowers in each row. How many flowers are there?`,"rows of"],
    [`A spider has 8 legs. How many legs do ${a} spiders have?`,"each (8 legs on each spider)"],
    [`There are ${a} <b>groups of</b> ${b} children. How many children are there?`,"groups of"]]);if(t[0].includes("spider"))ans=a*8;q=t[0];kw=t[1]}
  else{const a=rint(2,6),k=rint(2,10);ans=k;const t=R([
    [`${nm} has ${a*k} sweets to <b>share equally</b> between ${a} friends. How many does each friend get?`,"share equally"],
    [`${a*k} children get into ${a} equal teams. How many children are in <b>each</b> team?`,"equal teams"],
    [`${a*k} eggs are put into boxes of ${a}. How many boxes are needed?`,"boxes of (equal groups)"]]);if(t[0].includes("boxes of"))ans=k;q=t[0];kw=t[1]}
  return {op,q,ans,kw}};
const opWord={add:"add ➕",subtract:"subtract ➖",multiply:"multiply ✖️",divide:"divide ➗"};
const whichOp=()=>{const w=wpGen();return mcQ(`${box("Word problem",w.q)}Which do you need to do?`,opWord[w.op],SAMPLE(OPS.filter(z=>z!==w.op).map(z=>opWord[z]),2),`The key words <b>${w.kw}</b> tell us to <b>${w.op}</b>.`,"altogether, in all, total → add · left, difference, how many more → subtract · each, rows of, groups of → multiply · share equally → divide")};
const solveWP=()=>{const w=wpGen();const a=w.ans;
  if(Math.random()<.35)return {type:"type",q:`${box("Word problem",w.q)}Type the answer (just the number).`,a:[String(a),"$"+a],why:`You need to <b>${w.op}</b>. The answer is <b>${a}</b>.`,hint:`Key words: ${w.kw}. Do you add, subtract, multiply or divide?`};
  return mcQ(`${box("Word problem",w.q)}What is the answer?`,String(a),SAMPLE(uniq([a+1,a-1,a+2,a+10].filter(z=>z>=0&&z!==a)),2).map(String),`You need to <b>${w.op}</b> (key words: ${w.kw}). The answer is <b>${a}</b>.`,"Find the key words first.")};
const MW=[
 {q:"Which word tells you to ADD?",a:"altogether",o:["left","share"],why:"altogether, in all, total, sum → add."},
 {q:"Which word tells you to SUBTRACT?",a:"left",o:["altogether","total"],why:"left, difference, how many more, fewer → subtract."},
 {q:"Which word tells you to DIVIDE?",a:"share equally",o:["in all","sum"],why:"share equally, split, each get → divide."},
 {q:"What is the answer to an addition called?",a:"The sum (or total)",o:["The difference","The half"],why:"3 + 4 = 7. 7 is the sum."},
 {q:"What is the answer to a subtraction called?",a:"The difference",o:["The sum","The double"],why:"9 − 4 = 5. 5 is the difference."},
 {q:"What does 'double' mean?",a:"Two times as much",o:["Half as much","Take away two"],why:"Double 5 = 10."},
 {q:"What does 'half' mean?",a:"One of two equal parts",o:["Two times as much","One of four parts"],why:"Half of 8 = 4."},
 {q:"What is double 7?",a:"14",o:["9","49"],why:"7 + 7 = 14."},
 {q:"What is half of 20?",a:"10",o:["40","5"],why:"20 ÷ 2 = 10."},
 {q:"What is half of 12?",a:"6",o:["24","4"],why:"6 + 6 = 12."},
 {q:"What does 'equal' mean?",a:"The same amount",o:["More","Less"],why:"5 + 5 is equal to 10."},
 {q:"What does it mean to 'estimate'?",a:"To make a careful guess",o:["To count every one exactly","To give up"],why:"About 50 beans in the jar is an estimate."},
 {q:"Which number is an estimate of 49?",a:"About 50",o:["Exactly 47","About 10"],why:"49 is very close to 50."},
 {q:"What do we use to measure length?",a:"A ruler",o:["A clock","A calendar"],why:"Rulers measure length in centimetres."},
 {q:"What do we use to measure time?",a:"A clock",o:["A ruler","A scale"],why:"Clocks show hours and minutes."},
 {q:"Which sign means 'equals'?",a:"=",o:["+","−"],why:"2 + 3 = 5."},
 {q:"Which sign means 'take away'?",a:"−",o:["+","×"],why:"The minus sign means subtract."},
 {q:"What does 'fewer' mean?",a:"A smaller number of",o:["A bigger number of","The same number"],why:"3 is fewer than 7."},
 {q:"What is 'one quarter' of 8?",a:"2",o:["4","8"],why:"8 shared into 4 equal parts = 2 each."},
 {q:"What is a pattern?",a:"Something that repeats in a regular way",o:["A mistake","A single number"],why:"2, 4, 6, 8… is a pattern."}
];
const patternQ=()=>{if(Math.random()<.35){const sets=[["🔺","⭕"],["🟥","🔺","⭕"],["⭐","⭐","🌙"],["🟦","🟨"],["🍎","🍌","🍌"],["⬡","🔺","🔺"]];const pat=R(sets);const len=rint(5,8);const seq=[];for(let i=0;i<len;i++)seq.push(pat[i%pat.length]);const ans=pat[len%pat.length];
    return mcQ(`🔁 What comes next in the pattern?<br><span style="font-size:28px;letter-spacing:4px">${seq.join(" ")} ___</span>`,ans,uniq(["🔺","⭕","🟥","⭐","🌙","🟦","🟨","🍎","🍌","⬡"].filter(z=>z!==ans&&pat.includes(z))).concat([R(["🟩","💎"])]).slice(0,2),`The pattern repeats: <b>${pat.join(" ")}</b>. Next comes <b>${ans}</b>.`,"Find the part that repeats.")}
  const t=R(["up","down","double"]);let a,d,seq;
  if(t==="double"){a=rint(1,3);seq=[a,a*2,a*4,a*8];const ans=a*16;return mcQ(`🔁 What number comes next?<br><b>${seq.join(", ")}, ___</b>`,String(ans),[String(a*8+a*4),String(a*10)].filter(z=>z!==String(ans)),`Each number is <b>double</b> the one before: ${a*8} × 2 = <b>${ans}</b>.`,"How does each number change? Add, take away or double?")}
  d=R([2,3,4,5,10,25]);a=t==="up"?rint(0,20):rint(5*d,10*d);seq=[0,1,2,3].map(i=>t==="up"?a+i*d:a-i*d);const ans=t==="up"?a+4*d:a-4*d;
  if(Math.random()<.4)return {type:"type",q:`🔁 Type the next number:<br><b>${seq.join(", ")}, ___</b>`,a:[String(ans)],why:`The rule is <b>${t==="up"?"add":"take away"} ${d}</b>. ${seq[3]} ${t==="up"?"+":"−"} ${d} = <b>${ans}</b>.`,hint:"What is the difference between each number?"};
  return mcQ(`🔁 What number comes next?<br><b>${seq.join(", ")}, ___</b>`,String(ans),SAMPLE(uniq([ans+1,ans-1,t==="up"?ans+d:ans-d,seq[3]+1].filter(z=>z>=0&&z!==ans)),2).map(String),`The rule is <b>${t==="up"?"add":"take away"} ${d}</b>. ${seq[3]} ${t==="up"?"+":"−"} ${d} = <b>${ans}</b>.`,"What is the difference between each number?")};

/* ================= GRAMMAR: HAS AND HAVE ================= */
const HS=["Priya","Sam","My brother","Grandma","He","She","Arjun","My teacher","The shopkeeper","Lula"],HP=["I","You","We","They","Priya and Sam","The children","My friends","Grandma and Grandpa","My cousins","You and I"];
const HO=["a piggy bank","ten coins","a new watch","a maths test today","five dollars","a red kite","a big calendar","a blue ruler","three pencils","a lemonade stand","a clock in the kitchen","a lot of homework"];
const HFACT=[["A triangle","has","three sides"],["Squares","have","four equal sides"],["A cube","has","six faces"],["A circle","has","no corners"],["Hexagons","have","six sides"],["The clock","has","two hands"],["A week","has","seven days"],["A year","has","twelve months"],["An hour","has","sixty minutes"],["Spiders","have","eight legs"],["A stop sign","has","eight sides"],["Most months","have","thirty or thirty-one days"],["February","has","twenty-eight days in most years"],["Rectangles","have","four corners"],["Bees","have","six legs"],["One dollar","has","one hundred cents"]];
const hasHave=()=>{let s,v,o;if(Math.random()<.35){const f=R(HFACT);[s,v,o]=f}else{const pl=Math.random()<.5;s=pl?R(HP):R(HS);v=pl?"have":"has";o=R(HO)}
  if(Math.random()<.3)return {type:"type",q:`Type <b>has</b> or <b>have</b>:<br><b>${s} ___ ${o}.</b>`,a:[v],why:`<b>${s} ${v} ${o}.</b> ${v==="has"?"One person or thing (he, she, it) → has.":"I, you, we, they, or more than one → have."}`,hint:"he / she / it / one thing → has · I / you / we / they / more than one → have"};
  return mcQ(`Choose <b>has</b> or <b>have</b>:<br><b>${s} ___ ${o}.</b>`,v,[v==="has"?"have":"has"],`<b>${s} ${v} ${o}.</b> ${v==="has"?"One person or thing (he, she, it) → has.":"I, you, we, they, or more than one → have."}`,"he / she / it / one thing → has · I / you / we / they / more than one → have")};
const hasFix=()=>{const pl=Math.random()<.5;const s=pl?R(HP):R(HS);const right=pl?"have":"has",wrong=pl?"has":"have";const o=R(HO);
  return {type:"type",q:`Find the mistake and type the correct word:<br><b>${s} ${wrong} ${o}.</b>`,a:[right],why:`<b>${s} ${right} ${o}.</b>`,hint:"Is the subject one person (has) or I / you / we / they / more than one (have)?"}};
const doesHave=()=>{const pl=Math.random()<.5;const s=pl?R(["you","they","we","your friends","the children"]):R(["she","he","Priya","Sam","your brother","the shop"]);const o=R(HO);const right=pl?"Do":"Does";
  return mcQ(`Choose <b>Do</b> or <b>Does</b> to make a question:<br><b>___ ${s} have ${o}?</b>`,right,[pl?"Does":"Do"],`<b>${right} ${s} have ${o}?</b> In questions we use <b>does</b> with he/she/it, and the verb stays <b>have</b>.`,"he / she / it → Does … have? · I / you / we / they → Do … have?")};

/* ================= GRAMMAR: SOME, MANY, FEW ================= */
const SMF=[
 ["There are ___ stars in the sky tonight. You can't count them all!","many"],["Can I have ___ water, please?","some"],["Very ___ people came to the stand because it was raining.","few"],
 ["Please buy ___ bread at the market.","some"],["So ___ children came to the party that we needed more chairs!","many"],["Only a ___ leaves were left on the tree in November.","few"],
 ["Let's add ___ sugar to the lemonade.","some"],["There are ___ grains of sand on the beach, far too many to count.","many"],["Lula found only a ___ acorns before the snow came.","few"],
 ["Would you like ___ honey on your toast?","some"],["How ___ coins do you have?","many"],["Very ___ animals can live in the hottest part of the desert.","few"],
 ["Grandma gave us ___ milk with our cookies.","some"],["There are so ___ books in the library that it would take years to read them all.","many"],["The shop had only a ___ blankets left, so we bought them quickly.","few"],
 ["I need ___ help with my homework.","some"],["How ___ sides does a hexagon have?","many"],["Very ___ people can run as fast as a cheetah. Almost nobody can!","few"],
 ["Put ___ rice in the pot.","some"],["We saw ___ fish at the aquarium, hundreds of them!","many"],["Only a ___ students were late today. Almost everyone was on time.","few"],
 ["Can you lend me ___ money for the bus?","some"],["There were ___ people at the market, a big crowd!","many"],["Very ___ days in the year are as cold as today.","few"],
 ["Let's have ___ fresh air. Open the window!","some"],["How ___ minutes are in an hour?","many"],["There were only a ___ cookies left, so we shared them.","few"],
 ["Mom bought ___ juice for the picnic.","some"],["Bees visit ___ flowers every day, thousands of them!","many"],["Very ___ squirrels forget to gather nuts, but Lula did.","few"]
];
const smfQ=()=>{const x=R(SMF);return mcQ(`Choose <b>some</b>, <b>many</b> or <b>few</b>:<br><b>${x[0]}</b>`,x[1],["some","many","few"].filter(z=>z!==x[1]),x[1]==="many"?`<b>many</b> = a lot of things you can count. (How many…? There are many…)`:x[1]==="few"?`<b>few</b> = not many. We often say <b>very few</b> or <b>only a few</b>.`:`<b>some</b> = an amount of something, often things we can't count one by one (water, bread, sugar, money).`,"many = a lot · few = not many · some = an amount (water, bread, sugar)")};

/* ================= GRAMMAR: QUESTION WORDS AND QUESTION MARKS ================= */
const QW=["Who","What","Where","When","Why","How","How many","How much","Which","Whose"];
const QA=[
 ["___ is at the door?","Grandma is at the door.","Who"],["___ is the animal shelter?","It is next to the park.","Where"],["___ does the market open?","At eight o'clock in the morning.","When"],
 ["___ coins do you have?","I have seven coins.","How many"],["___ does the bread cost?","It costs three dollars.","How much"],["___ did you get up early?","Because I wanted to see the sunrise.","Why"],
 ["___ do you go to school?","I go by bus.","How"],["___ are you holding?","I am holding a ruler.","What"],["___ bag is this?","It is Sam's bag.","Whose"],
 ["___ shape has three sides?","A triangle.","What"],["___ is your birthday?","It is on May 5th.","When"],["___ made the lemonade?","Priya and Sam made it.","Who"],
 ["___ sides does a square have?","It has four sides.","How many"],["___ money is in the box?","There is forty-three dollars.","How much"],["___ did Lula cry?","Because she had no food for winter.","Why"],
 ["___ do you spell 'circle'?","C-I-R-C-L-E.","How"],["___ do you keep your coins?","In my piggy bank.","Where"],["___ is your teacher?","Mr. Lopez is my teacher.","Who"],
 ["___ watch is on the table?","It is Grandpa's watch.","Whose"],["___ colour do you want, red or blue?","Blue, please.","Which"],["___ time is it?","It is half past three.","What"],
 ["___ days are in a week?","There are seven days.","How many"],["___ does the bus come?","At a quarter past eight.","When"],["___ is the clock?","It is on the wall in the hall.","Where"],
 ["___ are you so happy?","Because we bought blankets for the dogs.","Why"],["___ juice is left?","Only a little.","How much"],["___ old are you?","I am eight years old.","How"],
 ["___ helped Lula in the winter?","Tock the woodpecker.","Who"],["___ way is the park, left or right?","Turn left.","Which"],["___ is the price of the honey?","It is six dollars.","What"]
];
const qwQ=()=>{const x=R(QA);const ban={What:["Which","How much"],Which:["What"],How:["What"],"How much":["What"],When:["What"]}[x[2]]||[];
  return mcQ(`Choose the question word:<br><b>${x[0]}</b><br><span style="color:var(--muted);font-size:16px">Answer: ${x[1]}</span>`,x[2],SAMPLE(QW.filter(z=>z!==x[2]&&!ban.includes(z)),2),`<b>${x[0].replace("___",x[2])}</b> → ${x[1]}<br>Who = a person · Where = a place · When = a time · Why = a reason · How many = a number of things · How much = an amount or a price.`,"Look at the answer. Is it a person, a place, a time, a reason, a number or a price?")};
const qMatch=()=>{const x=R(QA),others=SAMPLE(QA.filter(y=>y[2]!==x[2]),2);const qq=x[0].replace("___",x[2]);
  return mcQ(`Which is the best answer to this question?<br><b>${qq}</b>`,x[1],others.map(o=>o[1]),`<b>${qq}</b> → ${x[1]}`,"A Where question needs a place; a When question needs a time; a Who question needs a person.")};
const TELL=["The bus comes at eight o'clock.","A triangle has three sides.","Priya sold forty cups of lemonade.","The market opens on Saturday.","I have five coins.","Grandma baked cookies.","There are twelve months in a year.","The clock is on the wall.","Lula gathered nuts.","Bees build hexagons."];
const ASK=["What time is it?","How many sides does a hexagon have?","Where is my ruler?","How much does the honey cost?","When does the bus come?","Who made the lemonade?","Why is the sky blue?","Do you have a coin?","Can you tell the time?","Is it half past three?","Does a cube have six faces?","Which shape is round?","Whose watch is this?","Are the cookies ready?","How long is the film?","Can we go to the market on Saturday?","What shape is a stop sign?","How many days are in June?","Is the shop open on Sunday?","Do you have any coins?","Where did you put the calendar?","Why did Lula cry?","When is your birthday?","How much money do we need?","Who has the ruler?"];
const EXCL=["Wow, we made forty-three dollars!","Hurry, we're late!","What a beautiful honeycomb!","Look out!","Hooray, I caught the bus!"];
const qFix=()=>{const s=R(ASK);return {type:"type",strict:true,q:`Fix this question. Add the capital letter and the question mark:<br><b>${s.charAt(0).toLowerCase()+s.slice(1,-1)}</b>`,a:[s],hint:"A question starts with a capital letter and ends with a question mark (?).",why:`Correct: <b>${s}</b>`}};
const isQ=()=>{const q=R(ASK),t=SAMPLE(TELL,2);return mcQ("Which sentence is a <b>question</b>?",q,t,`<b>${q}</b> asks something, so it ends with a question mark.`,"A question asks something. Look for question words and the ? mark.")};
const TURNQ=[["Sam has a coin.","Does Sam have a coin?"],["They have a clock.","Do they have a clock?"],["The bus is late.","Is the bus late?"],["You can tell the time.","Can you tell the time?"],["It is four o'clock.","Is it four o'clock?"],["Priya has a piggy bank.","Does Priya have a piggy bank?"],["The shop is open.","Is the shop open?"],["You have a ruler.","Do you have a ruler?"],["She can count to one hundred.","Can she count to one hundred?"],["The cookies are fifty cents.","Are the cookies fifty cents?"],["We have enough money.","Do we have enough money?"],["Grandpa has a watch.","Does Grandpa have a watch?"],["The market is busy.","Is the market busy?"],["You can count by fives.","Can you count by fives?"],["Arjun has a new clock.","Does Arjun have a new clock?"],["The children are ready.","Are the children ready?"],["It is half past two.","Is it half past two?"],["They can see the triangle.","Can they see the triangle?"],["The honey is six dollars.","Is the honey six dollars?"],["Your friends have a kite.","Do your friends have a kite?"],["The film is long.","Is the film long?"],["Lula has some nuts.","Does Lula have some nuts?"],["We can buy three blankets.","Can we buy three blankets?"],["The lessons are one hour long.","Are the lessons one hour long?"]];
const turnQ=()=>{const x=R(TURNQ);const words=x[1].replace("?","").split(" ");const bad1=x[0].replace(".","?"),bad2=words.slice(1).concat(words[0].toLowerCase()).join(" ")+"?";
  return mcQ(`Which sentence turns this into a <b>question</b> correctly?<br><b>${x[0]}</b>`,x[1],[bad1,cap(bad2)],`<b>${x[1]}</b> A question often starts with <b>Is, Are, Can, Do</b> or <b>Does</b>, and ends with <b>?</b>`,"Start with Is, Are, Can, Do or Does. End with a question mark.")};

const SENT=["Priya and Sam opened a lemonade stand in Toronto.","Arjun lives in Delhi.","The market is open on Saturday.","Grandma baked cookies in October.","I have five dollars.","Mr. Lopez works at the animal shelter.","School starts on Monday.","The bus comes at a quarter past eight.","Lula gathered nuts in September.","We visited the Eiffel Tower in Paris.","Japan uses the yen.","India uses the rupee.","My birthday is in July.","The clock has two hands.","A triangle has three sides.","Bees build honeycombs from hexagons.","A cube has six faces.","We measured the table with a ruler.","The cookies cost fifty cents.","My sister saves her coins in a piggy bank.","The dogs slept on warm blankets.","A stop sign has eight sides.","The lesson lasts one hour.","There are twelve months in a year."];
const fix=()=>{const s=R(SENT);return {type:"type",strict:true,q:`Fix this sentence. Add the capital letters and the full stop:<br><b>${breakSentence(s)}</b>`,a:[s],hint:"Capital letter at the start, capitals for names, places, days, months and I, and a full stop at the end.",why:`Correct: <b>${s}</b>`}};
const D=[CHK.cap,CHK.end,CHK.w4,CHK.I];
const WP=[
 {q:"Write a sentence using <b>has</b>.",checks:[...D,["\\bhas\\b","Uses has"]],model:"My brother has a new watch."},
 {q:"Write a sentence using <b>have</b>.",checks:[...D,["\\bhave\\b","Uses have"]],model:"We have maths after lunch."},
 {q:"Write a sentence about a shape. Say how many sides it has.",checks:[...D,["\\b(triangle|square|rectangle|pentagon|hexagon|octagon|circle)s?\\b","Names a shape"],["\\b(\\d|one|two|three|four|five|six|seven|eight|no)\\b","Uses a number"]],model:"A hexagon has six sides."},
 {q:"Write a question that starts with <b>How many</b>.",checks:[["^\\s*How many\\b","Starts with How many"],CHK.q,CHK.w4],model:"How many coins are in your piggy bank?"},
 {q:"Write a question that starts with <b>How much</b>.",checks:[["^\\s*How much\\b","Starts with How much"],CHK.q,CHK.w4],model:"How much does the honey cost?"},
 {q:"Write a question that starts with <b>When</b>.",checks:[["^\\s*When\\b","Starts with When"],CHK.q,CHK.w3],model:"When does the market open?"},
 {q:"Write a question that starts with <b>Where</b>.",checks:[["^\\s*Where\\b","Starts with Where"],CHK.q,CHK.w3],model:"Where is my ruler?"},
 {q:"Write a question that starts with <b>Why</b>.",checks:[["^\\s*Why\\b","Starts with Why"],CHK.q,CHK.w3],model:"Why do bees build hexagons?"},
 {q:"Write a question that starts with <b>Does</b>.",checks:[["^\\s*Does\\b","Starts with Does"],CHK.q,CHK.w3],model:"Does a cube have six faces?"},
 {q:"Write a sentence using <b>many</b>.",checks:[...D,["\\bmany\\b","Uses many"]],model:"There are many shapes in our classroom."},
 {q:"Write a sentence using <b>a few</b> or <b>very few</b>.",checks:[...D,["\\b(a|very|only a) few\\b","Uses a few or very few"]],model:"Only a few people came because of the rain."},
 {q:"Write a sentence using <b>some</b>.",checks:[...D,["\\b[Ss]ome\\b","Uses some"]],model:"Can I have some water, please?"},
 {q:"Write a sentence that tells the time you wake up.",checks:[...D,["\\b(o'clock|half past|quarter past|quarter to|\\d{1,2}:\\d{2})","Gives a time"]],model:"I wake up at half past six."},
 {q:"Write a sentence about something you want to save money for.",checks:[...D,["\\bsav(e|ing)\\b","Uses save or saving"]],model:"I am saving money for a new bike."},
 {q:"Write a sentence using <b>because</b> about why we need clocks.",checks:[...D,["\\bbecause\\b","Uses because"]],model:"We need clocks because we must be on time."},
 {q:"Write a sentence with a price in it.",checks:[...D,["(\\$\\s?\\d|\\d+\\s?¢|\\b(dollars?|cents?|rupees?)\\b)","Gives a price"]],model:"The jar of honey costs six dollars."},
 {q:"Write a sentence about a 3D shape you can find at home.",checks:[...D,["\\b(cube|sphere|cylinder|cone|pyramid|prism)s?\\b","Names a 3D shape"]],model:"My ball is a sphere."},
 {q:"Write a sentence with two days of the week. Remember the capital letters!",checks:[...D,["(\\b(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\\b[\\s\\S]*){2}","Has two days with capital letters"]],model:"We have art on Monday and gym on Friday."},
 {q:"Write a sentence comparing two amounts of money using <b>more</b> or <b>less</b>.",checks:[...D,["\\b(more|less)\\b","Uses more or less"]],model:"Five dollars is more than three dollars."},
 {q:"Write a sentence about your favourite month and why you like it.",checks:[...D,["\\b(January|February|March|April|May|June|July|August|September|October|November|December)\\b","Names a month with a capital letter"],["\\bbecause\\b","Uses because"]],model:"My favourite month is July because it is warm and sunny."}
];

/* ================= VOCABULARY EXTRAS ================= */
const SYN=[["total","sum"],["cost","price"],["quick","fast"],["begin","start"],["finish","end"],["share","split"],["shop","store"],["purchase","buy"],["round","circular"],["correct","right"],["mistake","error"],["huge","enormous"],["tiny","small"],["shiny","gleaming"],["clever","smart"],["count","number"],["middle","centre"],["glad","happy"],["path","way"],["choose","pick"]];
const OPP=[["add","subtract"],["early","late"],["more","less"],["buy","sell"],["spend","save"],["first","last"],["morning","evening"],["before","after"],["full","empty"],["long","short"],["heavy","light"],["open","closed"],["noon","midnight"],["win","lose"],["double","half"],["equal","unequal"],["start","finish"],["minimum","maximum"],["past","future"],["sunrise","sunset"]];
const COMP=[["birth","day"],["week","end"],["after","noon"],["mid","night"],["lunch","time"],["half","way"],["sun","dial"],["hour","glass"],["week","day"],["day","time"],["bed","time"],["piggy","bank"],["shop","keeper"],["price","tag"],["home","work"],["foot","ball"],["some","thing"],["every","one"],["note","book"],["black","board"],["over","time"],["time","table"],["wrist","watch"],["honey","comb"]];

/* ================= SPELLING ================= */
const SP=u.spelling.concat([{w:"triangle",s:"A triangle has three sides.",tip:"tri-an-gle. Ends with -le."},{w:"rectangle",s:"A door is a rectangle.",tip:"rec-tan-gle."},{w:"cube",s:"A dice is a cube.",tip:"Magic e: c-u-be."},{w:"calendar",s:"Look at the calendar.",tip:"cal-en-dar, ends with -ar."},{w:"dollar",s:"It costs one dollar.",tip:"Double l, ends with -ar."},{w:"cent",s:"I have one cent.",tip:"c sounds like s."},{w:"week",s:"There are seven days in a week.",tip:"Double e."},{w:"month",s:"My birthday is next month.",tip:"'o' sounds like 'u'."},{w:"year",s:"There are twelve months in a year."},{w:"early",s:"I woke up early.",tip:"'ear' says 'er'."},{w:"spend",s:"Don't spend all your money."},{w:"save",s:"I save my coins.",tip:"Magic e: s-a-ve."},{w:"equal",s:"Cut it into equal parts.",tip:"'qu' says 'kw'."},{w:"double",s:"Double 4 is 8.",tip:"'ou' says 'u' here, ends with -le."},{w:"pattern",s:"Red, blue, red, blue is a pattern.",tip:"Double t."}]);
const NUMS=[["eleven","Ten plus one is eleven."],["twelve","A year has twelve months."],["thirteen","Ten plus three is thirteen."],["fourteen","Two weeks is fourteen days."],["fifteen","A quarter of an hour is fifteen minutes."],["sixteen","Eight plus eight is sixteen."],["seventeen","Ten plus seven is seventeen."],["eighteen","Priya sold eighteen cups."],["nineteen","Nineteen comes before twenty."],["twenty","Two tens make twenty."],["thirty","Half an hour is thirty minutes."],["forty","They needed forty dollars."],["fifty","The cookie costs fifty cents."],["sixty","An hour has sixty minutes."],["hundred","One dollar is one hundred cents."],["thousand","Ten hundreds make one thousand."],["first","January is the first month."],["second","February is the second month."],["third","March is the third month."],["half","Half of ten is five."]].map(x=>({w:x[0],s:x[1],tip:x[0]==="forty"?"No 'u' in forty!":x[0]==="eight"?"":x[0].endsWith("teen")?"Ends with -teen.":x[0].endsWith("ty")?"Ends with -ty.":undefined}));
const QWS=[["who","Who is at the door?"],["what","What time is it?"],["where","Where is the clock?"],["when","When does the bus come?"],["why","Why are you late?"],["which","Which shape is round?"],["whose","Whose coin is this?"],["how","How old are you?"],["who","Who made the lemonade?"],["what","What shape is a dice?"],["where","Where is the market?"],["when","When is lunch?"],["why","Why do bees build hexagons?"],["which","Which coin is bigger?"],["whose","Whose bag is red?"],["how","How many coins do you have?"],["who","Who is your teacher?"],["what","What does it cost?"],["where","Where do you live?"],["when","When does school start?"],["why","Why is the shop closed?"],["which","Which month is your birthday?"],["whose","Whose turn is it?"],["how","How much is the bread?"]].map(x=>({w:x[0],s:x[1],tip:"Question words start with 'wh' (or 'h' in how)."}));
const CHOOSE=[["clock","klock","clok"],["hour","our","howr"],["minute","minit","minnute"],["circle","sircle","circel"],["square","sqare","skware"],["triangle","triangel","tryangle"],["rectangle","rectangel","recktangle"],["money","muney","monney"],["coin","coyn","koin"],["price","prise","pryce"],["calendar","calandar","calendur"],["dollar","doller","dolar"],["twelve","twelv","twelfe"],["forty","fourty","fortie"],["thousand","thousend","thowsand"],["hundred","hundered","hunderd"],["equal","eqaul","equel"],["double","duble","dubble"],["early","erly","urly"],["half","haf","harf"]].map(x=>({w:x[0],bad:[x[1],x[2]],tip:(SP.find(y=>y.w===x[0])||NUMS.find(y=>y.w===x[0])||{}).tip}));
CHOOSE.find(x=>x.w==="hour").bad=["howr","houre"];

/* ================= READING ================= */
const DETAIL=[
 ["Sundials","Thousands of years ago, people in Egypt and other places told the time with sundials. A sundial has a stick or a pointed piece that makes a shadow. As the Sun moves across the sky, the shadow moves around the dial. Sundials have one big problem: they don't work at night or on cloudy days.",[["What does a sundial use to tell the time?","A shadow made by the Sun",["Sand","Water"]],["When does a sundial NOT work?","At night or on cloudy days",["In summer","At noon"]],["Where were sundials used thousands of years ago?","In Egypt and other places",["Only in Canada","On the Moon"]]]],
 ["Big Ben","Big Ben is the name of the giant bell inside a famous clock tower in London, England. The tower has four huge clock faces, one on each side. Each minute hand is about as long as a bus! The bell has rung out the hours for more than 150 years.",[["What is Big Ben?","A giant bell in a clock tower",["A big man","A bridge"]],["How many clock faces does the tower have?","Four",["One","Twelve"]],["How long is each minute hand?","About as long as a bus",["As long as a pencil","As long as a football field"]]]],
 ["The Hourglass","An hourglass is made of two glass bulbs joined by a narrow neck. Sand trickles slowly from the top bulb to the bottom. When all the sand has fallen, a certain amount of time has passed. Sailors long ago used hourglasses to measure time at sea. Today, people use small ones to time games or brushing their teeth.",[["What trickles through an hourglass?","Sand",["Water","Oil"]],["Who used hourglasses long ago?","Sailors at sea",["Astronauts","Bees"]],["What do people use small hourglasses for today?","Timing games or brushing teeth",["Cooking pizza","Measuring height"]]]],
 ["The Number Zero","The idea of zero as a real number was developed by mathematicians in ancient India. A mathematician named Brahmagupta wrote rules for using zero about 1,400 years ago. The idea travelled through the Middle East to Europe. Without zero, we couldn't easily write numbers like 10, 100 or 2026.",[["Where was zero as a number developed?","Ancient India",["Ancient Canada","Antarctica"]],["Who wrote rules for using zero?","Brahmagupta",["Big Ben","Arjun"]],["Why is zero important?","It helps us write numbers like 10 and 100",["It is the biggest number","It is a kind of shape"]]]],
 ["Canada's Coins","Canada has some coins with funny nicknames. The one-dollar coin has a picture of a loon, a water bird, so people call it the \"loonie\". The two-dollar coin is called the \"toonie\", because it is worth two loonies. Canada stopped making one-cent coins, called pennies, in 2012.",[["What bird is on Canada's one-dollar coin?","A loon",["An eagle","A goose"]],["Why is the two-dollar coin called the toonie?","It is worth two loonies",["It has a cartoon on it","It is shaped like a tooth"]],["When did Canada stop making pennies?","2012",["1900","2025"]]]],
 ["The Calendar and the Months","Our calendar has twelve months. Some months are named after Roman gods and leaders from long ago. July is named after Julius Caesar, and August is named after Augustus, a Roman emperor. Every four years, February gets an extra day. That year is called a leap year.",[["Who is July named after?","Julius Caesar",["A king of Canada","A planet"]],["What happens every four years?","February gets an extra day",["We skip a month","The year has 13 months"]],["What is a year with an extra day called?","A leap year",["A jump year","A long year"]]]],
 ["Time Zones","When it is morning in Toronto, it is already evening in Delhi! The Earth spins, so the Sun rises at different times in different places. That is why the world is divided into time zones. Delhi is about nine and a half hours ahead of Toronto in the summer. When Arjun eats dinner, children in Toronto are eating breakfast.",[["When it is morning in Toronto, what time of day is it in Delhi?","Evening",["Early morning","Noon"]],["Why do different places have different times?","The Earth spins, so the Sun rises at different times",["Clocks are broken","People like different times"]],["What are children in Toronto doing when Arjun eats dinner?","Eating breakfast",["Sleeping at midnight","Eating dinner too"]]]],
 ["Rangoli Patterns","In India, people make colourful patterns called rangoli on the ground, especially during the festival of Diwali. Rangoli is made with coloured powder, rice or flower petals. Many designs use circles, triangles, squares and flower shapes that repeat around a centre. Making rangoli takes patience and careful counting.",[["When do many people make rangoli?","During Diwali",["Only on birthdays","On Canada Day"]],["What is rangoli made with?","Coloured powder, rice or flower petals",["Paint on paper only","Snow"]],["What do rangoli designs often use?","Shapes that repeat around a centre",["Only letters","Only straight lines"]]]],
 ["The Great Pyramid","The Great Pyramid of Giza in Egypt was built more than 4,500 years ago. Its base is a square, and its four sides are triangles that meet at a point on top. It was made from more than two million stone blocks. For almost 4,000 years, it was the tallest building made by people.",[["What shape is the base of the Great Pyramid?","A square",["A circle","A hexagon"]],["What shape are its sides?","Triangles",["Rectangles","Circles"]],["How many stone blocks were used?","More than two million",["About one hundred","Ten"]]]],
 ["Piggy Banks","Long ago in Europe, people kept their coins in jars made of a cheap orange clay called \"pygg\". Over time, people began making the jars in the shape of pigs, and the name \"piggy bank\" was born. Today, piggy banks help children save money a little at a time.",[["What was the clay called?","Pygg",["Piggy","Mud"]],["Why are they called piggy banks?","They were made of pygg clay and later shaped like pigs",["Pigs invented them","Only farmers used them"]],["What do piggy banks help children do?","Save money a little at a time",["Spend money fast","Buy pigs"]]]],
 ["Measuring With Your Body","Before rulers, people measured with their bodies. In ancient Egypt, a \"cubit\" was the length from your elbow to the tip of your middle finger. A \"foot\" was about the length of a foot! But everyone's arms and feet are different sizes, so people agreed on standard measures, like the metre and the centimetre.",[["What was a cubit?","The length from your elbow to the tip of your middle finger",["The length of a horse","A kind of coin"]],["Why did people need standard measures?","Everyone's body is a different size",["Rulers were too heavy","Feet were too small"]],["Which is a standard measure we use today?","The metre",["The elbow","The finger"]]]],
 ["Origami","Origami is the art of folding paper into shapes without cutting or gluing. It became popular in Japan hundreds of years ago. One square piece of paper can become a crane, a frog, a boat or a box. Folding a square in half, corner to corner, makes a triangle, and that is how many models begin.",[["What is origami?","The art of folding paper into shapes",["Painting on rocks","Building with clay"]],["Where did origami become popular?","Japan",["Mexico","Egypt"]],["What shape do you get when you fold a square corner to corner?","A triangle",["A circle","A hexagon"]]]]
];
const detail=()=>{const p=R(DETAIL),x=R(p[2]);return mcQ(`${box(p[0],p[1])}${x[0]}`,x[1],x[2],`Look back at the text: the answer is there.`,"Read the text again and find the words.",{say:p[1]+" "+x[0]})};
const MAIN=[
 ["Clocks help us every day. They tell us when to wake up. They tell us when school starts. They help us catch buses and trains on time.","Clocks help us every day.",["Buses are big.","School starts early."]],
 ["Shapes are everywhere in a kitchen. Plates are circles. The table is a rectangle. Ice cubes are cubes. Cans are cylinders.","Shapes are everywhere in a kitchen.",["Plates are round.","Ice is cold."]],
 ["Saving money takes patience. You put away a little each week. You don't spend it on small things. After many weeks, you have enough for something special.","Saving money takes patience.",["Weeks are long.","Small things are cheap."]],
 ["People have measured time in many ways. Long ago they used shadows and sundials. Later they used sand in hourglasses. Today we use clocks, watches and phones.","People have measured time in many ways.",["Sand is yellow.","Phones are new."]],
 ["Triangles make buildings strong. Bridges use triangles. Roofs use triangles. Towers like the Eiffel Tower are full of triangles.","Triangles make buildings strong.",["Roofs keep rain out.","Paris is in France."]],
 ["Money has changed over time. People traded goods. Then they used shells and coins. Then came paper money, and now cards and phones.","Money has changed over time.",["Shells are pretty.","Phones can call people."]],
 ["A good plan helps you solve problems. First you think about what you need. Then you make a list. Then you check your plan as you go.","A good plan helps you solve problems.",["Lists are long.","Thinking is quiet."]],
 ["Calendars help us organise our lives. They show the days and months. We mark birthdays and holidays on them. They help us remember appointments.","Calendars help us organise our lives.",["Birthdays are fun.","Months have names."]],
 ["Patterns are all around us. Zebras have striped patterns. Music has repeating beats. Even the days of the week repeat in a pattern.","Patterns are all around us.",["Zebras are black and white.","Music is loud."]],
 ["Nature uses clever shapes. Bees build hexagons. Snowflakes have six arms. Sunflowers grow seeds in spirals.","Nature uses clever shapes.",["Bees make honey.","Snow is cold."]],
 ["Different countries use different money. Canada uses the dollar. India uses the rupee. Japan uses the yen and Mexico uses the peso.","Different countries use different money.",["Japan is an island.","Canada is big."]],
 ["Maths is useful when you go shopping. You add up the prices. You check that you have enough money. You count your change.","Maths is useful when you go shopping.",["Shops are busy.","Prices change."]],
 ["Being on time is important. If you are late, you might miss the bus. Your friends might wait for you. You might miss the start of a lesson.","Being on time is important.",["Buses are yellow.","Lessons are long."]],
 ["The number zero is very important. It lets us write 10, 100 and 1,000. It means nothing at all. It is also the starting point on a number line.","The number zero is very important.",["One thousand is big.","Lines are straight."]],
 ["Measuring helps us in many jobs. Builders measure wood. Cooks measure flour. Doctors measure how tall children are.","Measuring helps us in many jobs.",["Wood is hard.","Flour is white."]],
 ["Sharing money can help others. People give to food banks. Children raise money for animal shelters. Neighbours help each other in hard times.","Sharing money can help others.",["Food banks have food.","Shelters have dogs."]],
 ["The year is full of different seasons and months. Spring brings flowers. Summer is warm. Autumn brings falling leaves, and winter brings snow.","The year is full of different seasons.",["Snow is white.","Flowers smell nice."]],
 ["3D shapes are solid, not flat. A ball is a sphere. A dice is a cube. A can is a cylinder.","3D shapes are solid, not flat.",["Balls bounce.","Cans hold soup."]],
 ["Budgets help families. A budget shows how much money comes in. It shows how much is spent on food, rent and bills. It helps families save for the future.","Budgets help families plan their money.",["Rent is paid monthly.","Food is tasty."]],
 ["Estimating is a useful skill. You can estimate how long a trip will take. You can estimate how many sweets are in a jar. You can estimate the total before you pay.","Estimating is a useful skill.",["Trips are fun.","Sweets are sugary."]],
 ["Every day has a pattern of times. We wake up in the morning. We eat lunch around noon. We go to bed at night.","Every day has a pattern of times.",["Lunch is tasty.","Night is dark."]],
 ["Fractions help us share fairly. Half a pizza is one of two equal parts. A quarter is one of four equal parts. Equal parts mean everyone gets the same.","Fractions help us share fairly.",["Pizza is round.","Four is more than two."]],
 ["Problem-solvers don't give up. When their first plan fails, they think again. They try a new idea. They ask for help when they need it.","Problem-solvers don't give up.",["Plans are on paper.","Ideas are new."]],
 ["Coins are designed carefully. They have pictures of animals, leaders or buildings. They have numbers that show their value. Some even have special edges so blind people can feel the difference.","Coins are designed carefully.",["Animals are cute.","Buildings are tall."]]
];
const mainIdea=()=>{const m=R(MAIN);return mcQ(`${box("Read",m[0])}What is the <b>main idea</b>? (What is it mostly about?)`,m[1],m[2],`The main idea is what the whole text is about: <b>${m[1]}</b>`,"Which answer fits ALL the sentences, not just one?",{say:m[0]})};
const FACTS=["There are 60 minutes in an hour.","A triangle has three sides.","A week has seven days.","India uses the rupee.","A dice is a cube.","There are 12 months in a year.","100 cents make one dollar.","A stop sign is an octagon.","Bees build hexagons.","February is the shortest month.","Paper money was first used in China.","A square has four equal sides.","Big Ben is in London.","Japan uses the yen.","Sundials use shadows to tell the time.","A sphere is round all over.","Half of ten is five.","There are 24 hours in a day.","Canada's one-dollar coin is called the loonie.","An hourglass uses sand.","July has 31 days.","A circle has no corners.","The Great Pyramid is in Egypt.","Double six is twelve.","Zero as a number was developed in ancient India."];
const OPIN=["Maths is the most fun subject.","Circles are the prettiest shape.","Saturday is the best day of the week.","Lemonade is tastier than juice.","Saving money is boring.","Hexagons are cooler than squares.","Analogue clocks are more beautiful than digital ones.","July is the best month.","Shopping is exciting.","Word problems are easy.","Triangles are the most interesting shape.","Mornings are better than evenings.","The toonie is a funny name.","Origami is the best hobby.","Counting coins is fun.","Rangoli patterns are the most beautiful art.","Piggy banks are cute.","Winter is the worst season.","Everyone should learn to tell the time by age seven.","Cookies are better than cupcakes.","Time goes too slowly in school.","Fifty cents is too much for a cookie.","Big Ben is the most famous clock in the world.","Patterns are more fun than puzzles.","Lula's story is the best fable."];
const factOp=()=>{const f=Math.random()<.5;const s=f?R(FACTS):R(OPIN);return mcQ(`Is this a <b>fact</b> or an <b>opinion</b>?<br><b>${s}</b>`,f?"Fact":"Opinion",[f?"Opinion":"Fact"],f?"A <b>fact</b> can be checked in a book, on a clock or with maths.":"An <b>opinion</b> is what someone thinks or feels. Others may disagree.","Could you check it? Or is it a feeling?")};
const SEQ=[["Make a shopping list","Go to the shop","Pay for the things","Get your change"],["Morning","Noon","Afternoon","Evening"],["Monday","Tuesday","Wednesday","Thursday"],["January","February","March","April"],["Priya wants to help the dogs","They plan a lemonade stand","It rains, so they move to the porch","They buy three blankets"],["Arjun misses the bus","Grandpa teaches him the clock","He learns quarter past","He catches the bus"],["People traded goods","People used shells as money","People made metal coins","People began using paper money"],["Lula says 'later'","Winter comes","Tock shares his seeds","Lula works first and plays after"],["7:00","7:15","7:30","7:45"],["Second","Minute","Hour","Day"],["Day","Week","Month","Year"],["Fold the square paper in half","Fold it again","Shape the wings","You have an origami crane"]];
const order=()=>{const s=R(SEQ),t=R(["first","last","next"]);
  if(t==="first")return mcQ(`What comes <b>FIRST</b>?`,s[0],SAMPLE(s.slice(1),2),`Order: ${s.join(" → ")}`,"What must come before everything else?");
  if(t==="last")return mcQ(`What comes <b>LAST</b>?`,s[s.length-1],SAMPLE(s.slice(0,-1),2),`Order: ${s.join(" → ")}`,"What comes at the very end?");
  const k=Math.floor(Math.random()*(s.length-1));return mcQ(`What comes right <b>AFTER</b> this?<br><b>${s[k]}</b>`,s[k+1],SAMPLE(s.filter((_,i)=>i!==k&&i!==k+1),2),`Order: ${s.join(" → ")}`,"What is the very next step?")};
const CE=[["Because Arjun couldn't read the clock, he missed the bus.","Arjun couldn't read the clock","he missed the bus"],["It started to rain, so everyone hurried home.","it started to rain","everyone hurried home"],["Because Priya made a shopping list, she didn't forget anything.","Priya made a shopping list","she didn't forget anything"],["Lula played all autumn, so she had no food in winter.","Lula played all autumn","she had no food in winter"],["Because triangles are strong, engineers use them in bridges.","triangles are strong","engineers use them in bridges"],["Coins were heavy to carry, so people began using paper money.","coins were heavy to carry","people began using paper money"],["Because hexagons fit with no gaps, bees use them for honeycombs.","hexagons fit with no gaps","bees use them for honeycombs"],["Sam saved his coins every week, so he could buy a new kite.","Sam saved his coins every week","he could buy a new kite"],["Because it was cloudy, the sundial didn't work.","it was cloudy","the sundial didn't work"],["Grandma baked cookies, so the children had something new to sell.","Grandma baked cookies","the children had something new to sell"],["Because the market closes at one o'clock, we went early.","the market closes at one o'clock","we went early"],["Mia spent all her money on sweets, so she couldn't buy the book.","Mia spent all her money on sweets","she couldn't buy the book"],["Because the Earth spins, places have different times.","the Earth spins","places have different times"],["The alarm clock rang, so Dev woke up.","the alarm clock rang","Dev woke up"],["Because the price was too high, Sofia didn't buy the toy.","the price was too high","Sofia didn't buy the toy"],["Tock gathered extra seeds, so he could share with Lula.","Tock gathered extra seeds","he could share with Lula"],["Because Leo paid with ten dollars for a seven-dollar book, he got three dollars change.","Leo paid with ten dollars for a seven-dollar book","he got three dollars change"],["The shop sold out of blankets, so we had to wait a week.","the shop sold out of blankets","we had to wait a week"],["Because February is short, it has only twenty-eight days most years.","February is short","it has only twenty-eight days most years"],["Arjun practised reading the clock, so he was never late again.","Arjun practised reading the clock","he was never late again"]];
const cause=()=>{const c=R(CE),other=R(CE.filter(x=>x!==c));const askCause=Math.random()<.5;
  return mcQ(`${box("Read",c[0])}What is the <b>${askCause?"cause":"effect"}</b>? <span style="color:var(--muted);font-size:15px">(${askCause?"WHY it happened":"WHAT happened"})</span>`,askCause?c[1]:c[2],[askCause?c[2]:c[1],askCause?other[1]:other[2]],`Cause (why): <b>${c[1]}</b>. Effect (what happened): <b>${c[2]}</b>.`,"Look for because and so.",{say:c[0]})};
const CMP=[
 ["A square and a rectangle both have four sides and four corners. A square's sides are all equal. A rectangle has two longer sides.","Both have four sides and four corners","A square's sides are equal, but a rectangle has two longer sides",["Both have three sides","A rectangle's sides are all equal"]],
 ["A sundial and a clock both tell the time. A sundial uses the Sun's shadow. A clock uses moving hands or numbers and works at night too.","Both tell the time","A sundial needs the Sun, but a clock works at night too",["Both use sand","A clock needs the Sun"]],
 ["Coins and paper money are both kinds of money. Coins are made of metal and are heavy. Paper money is light and easy to carry.","Both are kinds of money","Coins are metal and heavy, but paper money is light",["Both are made of metal","Paper money is heavy"]],
 ["A cube and a sphere are both 3D shapes. A cube has six flat faces and corners. A sphere is round all over with no corners.","Both are 3D shapes","A cube has flat faces and corners, but a sphere is round all over",["Both are flat","A sphere has six faces"]],
 ["Saving and spending are both ways to use money. When you spend, you buy something now. When you save, you keep money for later.","Both are ways to use money","Spending is for now, but saving is for later",["Both mean giving money away","Saving means buying now"]],
 ["An hourglass and a sundial both measured time long ago. An hourglass uses falling sand. A sundial uses a moving shadow.","Both measured time long ago","An hourglass uses sand, but a sundial uses a shadow",["Both use water","A sundial uses sand"]],
 ["The dollar and the rupee are both kinds of money. The dollar is used in Canada and the United States. The rupee is used in India.","Both are kinds of money","The dollar is used in Canada, but the rupee is used in India",["Both are used in Japan","The rupee is used in Canada"]],
 ["A triangle and a hexagon are both flat shapes with straight sides. A triangle has three sides. A hexagon has six sides.","Both are flat shapes with straight sides","A triangle has three sides, but a hexagon has six",["Both have six sides","A hexagon has three sides"]],
 ["Lula and Tock both lived in the forest. Lula played and said 'later'. Tock worked every morning and saved extra food.","Both lived in the forest","Lula put things off, but Tock worked every morning",["Both said 'later'","Tock played all day"]],
 ["Addition and multiplication both make numbers bigger. Addition puts two numbers together. Multiplication adds the same number many times.","Both make numbers bigger","Addition joins two numbers, but multiplication adds equal groups",["Both make numbers smaller","Multiplication takes away"]],
 ["An analogue clock and a digital clock both show the time. An analogue clock has hands that point to numbers. A digital clock shows the time in numbers, like 8:15.","Both show the time","An analogue clock has hands, but a digital clock shows numbers",["Both have hands","A digital clock has hands"]],
 ["A cylinder and a cone both have a circle face and a curved side. A cylinder has two circle faces. A cone has one circle face and a point.","Both have a circle face and a curved side","A cylinder has two circle faces, but a cone has one and a point",["Both have points","A cone has two circle faces"]]
];
const compare=()=>{const c=R(CMP);const same=Math.random()<.5;
  return mcQ(`${box("Read",c[0])}${same?"How are they the <b>same</b>?":"What is one <b>difference</b>?"}`,same?c[1]:c[2],[same?c[2]:c[1],R(c[3])],same?`Same: <b>${c[1]}</b>.`:`Different: <b>${c[2]}</b>.`,same?"Look for the word both.":"Look for the word but.",{say:c[0]})};

/* ================= THINKING ================= */
const PUZ=[
 {q:"🧩 Riddle: I have hands but I can't clap. I have a face but I can't smile. What am I?",o:["A clock","A doll","A robot"],a:"A clock",why:"A clock has hands and a face."},
 {q:"🧩 Riddle: I have three sides and three corners. What am I?",o:["A triangle","A square","A circle"],a:"A triangle",why:"Tri means three."},
 {q:"🧩 Riddle: I am round, I have no corners, and you can find me on a bicycle. What am I?",o:["A wheel (a circle)","A triangle","A cube"],a:"A wheel (a circle)",why:"Wheels are circles."},
 {q:"🧩 Riddle: I have six faces, all squares, and you roll me in games. What am I?",o:["A dice (a cube)","A ball","A coin"],a:"A dice (a cube)",why:"A dice is a cube."},
 {q:"🧩 Riddle: I come once in a minute, twice in a moment, but never in a thousand years. What am I?",o:["The letter M","A second","A clock"],a:"The letter M",why:"Look at the spelling: minute, moMent, thousand years."},
 {q:"🧩 Riddle: The more you take, the more you leave behind. What am I?",o:["Footsteps","Coins","Hours"],a:"Footsteps",why:"Every step leaves a footprint."},
 {q:"🧩 Riddle: What has 12 months, 52 weeks and 365 days?",o:["A year","A week","A century"],a:"A year",why:"A normal year has 365 days."},
 {q:"🧩 I am a number. Double me and you get 10. What am I?",o:["5","20","8"],a:"5",why:"5 + 5 = 10."},
 {q:"🧩 I am a number. Half of me is 7. What am I?",o:["14","3","70"],a:"14",why:"7 + 7 = 14."},
 {q:"🧩 Sam is older than Priya. Priya is older than Mia. Who is the youngest?",o:["Mia","Sam","Priya"],a:"Mia",why:"Sam > Priya > Mia."},
 {q:"🧩 Today is Monday. What day will it be in two days?",o:["Wednesday","Tuesday","Sunday"],a:"Wednesday",why:"Monday → Tuesday → Wednesday."},
 {q:"🧩 Yesterday was Friday. What day is tomorrow?",o:["Sunday","Saturday","Thursday"],a:"Sunday",why:"Yesterday Friday, today Saturday, tomorrow Sunday."},
 {q:"🧩 You have two coins that make 35¢. One is NOT a 10¢ coin. What are the coins?",o:["25¢ and 10¢","20¢ and 15¢","30¢ and 5¢"],a:"25¢ and 10¢",why:"One is a 25¢ coin (not a 10¢ coin), and the other IS a 10¢ coin!"},
 {q:"🧩 A shop has 3 apples. You take 2. How many apples do YOU have?",o:["2","1","3"],a:"2",why:"You took 2, so you have 2!"},
 {q:"🧩 Which is heavier: a kilogram of feathers or a kilogram of stones?",o:["They weigh the same","Stones","Feathers"],a:"They weigh the same",why:"Both weigh one kilogram."},
 {q:"🧩 How many triangles can you make by cutting a square once from corner to corner?",o:["2","4","1"],a:"2",why:"The cut makes two triangles."},
 {q:"⏰ Lunch is at 12:00. It is 11:30 now. How long until lunch?",o:["30 minutes","1 hour","11 minutes"],a:"30 minutes",why:"From 11:30 to 12:00 is half an hour."},
 {q:"⏰ The bus comes at 8:15. You get to the stop at 8:20. What happened?",o:["You missed the bus","You are early","The bus is late"],a:"You missed the bus",why:"8:20 is after 8:15."},
 {q:"⏰ Your alarm says 6:45. Is that before or after seven o'clock?",o:["Before","After","Exactly seven"],a:"Before",why:"6:45 is quarter to seven."},
 {q:"🛒 You have $5. Which can you buy?",o:["A $4 book","A $6 toy","A $9 game"],a:"A $4 book",why:"$4 is less than $5."},
 {q:"🛒 A toy costs $8. You have $5. How much more do you need?",o:["$3","$13","$5"],a:"$3",why:"$8 − $5 = $3."},
 {q:"🛒 Which is the smartest way to shop?",o:["Make a list and check prices","Buy the first thing you see","Spend all your money"],a:"Make a list and check prices",why:"Planning saves money."},
 {q:"🛒 One pen costs $2. How much do 4 pens cost?",o:["$8","$6","$2"],a:"$8",why:"2 × 4 = 8."},
 {q:"🔺 How many sides do two triangles have altogether?",o:["6","3","5"],a:"6",why:"3 + 3 = 6."},
 {q:"🔺 How many corners do a square and a triangle have altogether?",o:["7","8","6"],a:"7",why:"4 + 3 = 7."},
 {q:"🔺 Which shape could you NOT stack easily in a tall tower?",o:["Spheres","Cubes","Rectangular boxes"],a:"Spheres",why:"Spheres roll off each other."},
 {q:"🧮 Which is the best estimate for 98 + 3?",o:["About 100","About 50","About 1,000"],a:"About 100",why:"98 is about 100, and 3 is small."},
 {q:"🧮 A class has 24 children in rows of 6. How many rows?",o:["4","6","18"],a:"4",why:"24 ÷ 6 = 4."},
 {q:"🧮 What number is 10 more than 47?",o:["57","48","147"],a:"57",why:"47 + 10 = 57."},
 {q:"🧮 What is the next even number after 18?",o:["20","19","22"],a:"20",why:"Even numbers go up by 2: 18, 20, 22…"}
];
const maths=()=>{const t=R(["hours","days","coins","quarters","shapes","tens"]);let q,ans,why;
  if(t==="hours"){const a=rint(1,4);ans=a*60;q=`How many minutes are in ${a} hours?`;why=`${a} × 60 = ${ans} minutes.`}
  else if(t==="days"){const w=rint(2,5);ans=w*7;q=`How many days are in ${w} weeks?`;why=`${w} × 7 = ${ans} days.`}
  else if(t==="coins"){const k=rint(2,9);ans=k*10;q=`You have ${k} coins of 10¢. How many cents is that?`;why=`${k} × 10 = ${ans}¢.`}
  else if(t==="quarters"){const k=rint(1,4);ans=k*25;q=`You have ${k} coin${k>1?"s":""} of 25¢. How many cents is that?`;why=`${k} × 25 = ${ans}¢.`}
  else if(t==="shapes"){const tr=rint(1,5),sq=rint(1,5);ans=tr*3+sq*4;q=`How many sides do ${tr} triangle${tr>1?"s":""} and ${sq} square${sq>1?"s":""} have altogether?`;why=`${tr} × 3 + ${sq} × 4 = ${tr*3} + ${sq*4} = ${ans}.`}
  else{const a=rint(11,89);ans=a+10;q=`What is 10 more than ${a}?`;why=`${a} + 10 = ${ans}.`}
  const wr=uniq([ans+1,ans-1,ans+10,ans-10,ans+5].filter(x=>x>=0&&x!==ans));
  return mcQ("🔢 "+q,String(ans),SAMPLE(wr,2).map(String),why,"Is it more, less, groups of, or sharing?")};
const GRP={"flat shapes":["triangle","square","circle","hexagon","rectangle"],"3D shapes":["cube","sphere","cylinder","cone","pyramid"],"units of time":["second","minute","hour","day","week"],"kinds of money":["dollar","rupee","euro","yen","peso"],"days of the week":["Monday","Tuesday","Friday","Sunday"],"months":["January","April","July","October"],"maths signs":["+","−","×","="]};
const odd=()=>{const ks=Object.keys(GRP);const k=R(ks),k2=R(ks.filter(x=>x!==k));const three=SAMPLE(GRP[k],3),o=R(GRP[k2].filter(x=>!GRP[k].includes(x)));
  return mcQ(`🤔 Which one does NOT belong?`,o,three,`${three.join(", ")} are all ${k}. <b>${o}</b> is not.`,"Find what three of them have in common.")};
const ANA=[["Triangle is to 3 as square is to ___.","4",["3","6"]],["Hexagon is to 6 as octagon is to ___.","8",["5","10"]],["Minute is to hour as day is to ___.","week",["second","noon"]],["Clock is to time as ruler is to ___.","length",["money","weather"]],["Circle is to sphere as square is to ___.","cube",["cone","cylinder"]],["Canada is to dollar as India is to ___.","rupee",["yen","euro"]],["Add is to plus as subtract is to ___.","minus",["equals","times"]],["Double is to two times as half is to ___.","one of two equal parts",["four times","ten"]],["Morning is to breakfast as evening is to ___.","dinner",["lunch","sunrise"]],["Cent is to dollar as minute is to ___.","hour",["second","coin"]],["Buy is to sell as spend is to ___.","save",["shop","pay"]],["Early is to late as first is to ___.","last",["second","before"]],["January is to February as Monday is to ___.","Tuesday",["Sunday","March"]],["Sand is to hourglass as shadow is to ___.","sundial",["calendar","coin"]],["Bee is to hexagon as bridge is to ___.","triangle",["circle","sphere"]],["Ball is to sphere as can is to ___.","cylinder",["cube","pyramid"]],["Who is to a person as where is to ___.","a place",["a time","a reason"]],["When is to a time as why is to ___.","a reason",["a place","a number"]],["He is to has as they is to ___.","have",["has","having"]],["Lots is to many as not many is to ___.","few",["some","more"]]];
const analogy=()=>{const x=R(ANA);return mcQ("🔗 "+x[0],x[1],x[2],`${x[0].replace("___","<b>"+x[1]+"</b>")} Think about how the first two words are linked.`,"How are the first two words linked? Use the same link.")};

/* ================= LEARN NOTES ================= */
const L={
 detail:"Read the short text carefully. The answer is <b>in the text</b>.",
 main:"The <b>main idea</b> is what the whole text is mostly about. It fits <b>all</b> the sentences.",
 factop:"A <b>fact</b> can be checked (with a clock, a book or maths). An <b>opinion</b> is a feeling: <i>Maths is the most fun subject.</i>",
 order:"Times, days, months and stories all have an <b>order</b>. What comes first, next and last?",
 cause:"The <b>cause</b> is <b>why</b>. The <b>effect</b> is <b>what happened</b>. Look for <b>because</b> and <b>so</b>.",
 compare:"<b>Same:</b> look for <b>both</b>, <b>also</b>. <b>Different:</b> look for <b>but</b>.",
 wp:"<b>Read the problem twice.</b> Find the numbers and the <b>key words</b>:<br>➕ altogether, in all, total · ➖ left, difference, how many more · ✖️ each, rows of, groups of · ➗ share equally, equal groups.",
 vocab:"Read the word, say it aloud, and think of a sentence that uses it.",
 clock:"The <b>short hand</b> shows the <b>hour</b>. The <b>long hand</b> shows the <b>minutes</b>.<br>Long hand on <b>12</b> → o'clock · on <b>3</b> → quarter past · on <b>6</b> → half past · on <b>9</b> → quarter to.",
 clock5:"Each number on the clock = <b>5 minutes</b>. Count by fives from the 12 to the long hand: 5, 10, 15, 20… Then write <b>hour : minutes</b>, like <b>4:25</b>.",
 elapsed:"To find how long, <b>count on</b> from the start time. To find the end time, <b>add</b> the hours first, then the minutes. 60 minutes = 1 hour.",
 cal:"<b>Days:</b> Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday.<br><b>Months:</b> January … December. \"Thirty days hath September, April, June, and November…\"",
 tf:"60 seconds = 1 minute · 60 minutes = 1 hour · 24 hours = 1 day · 7 days = 1 week · 12 months = 1 year · 100 years = 1 century.",
 shape:"<b>Triangle</b> 3 sides · <b>Square</b> 4 equal sides · <b>Rectangle</b> 4 sides (2 long, 2 short) · <b>Pentagon</b> 5 · <b>Hexagon</b> 6 · <b>Octagon</b> 8 · <b>Circle</b> 0.<br>3D: <b>cube</b> (dice), <b>sphere</b> (ball), <b>cylinder</b> (can), <b>cone</b>, <b>pyramid</b>.",
 money:"100¢ = $1. Count coins starting with the <b>biggest</b>. <b>Change</b> = what you pay − the price. A <b>budget</b> is a plan for your money.",
 mw:"Maths words: <b>sum/total</b> (add), <b>difference</b> (subtract), <b>double</b> (×2), <b>half</b> (÷2), <b>equal</b> (the same), <b>estimate</b> (careful guess).",
 pattern:"Find the rule. Does each number go up, go down or double? For shapes, find the part that <b>repeats</b>.",
 syn:"<b>Synonyms</b> mean almost the same: total = sum, cost = price.",
 opp:"<b>Opposites</b>: add ↔ subtract, early ↔ late, spend ↔ save.",
 comp:"<b>Compound words</b>: after + noon = afternoon, hour + glass = hourglass.",
 has:"Use <b>has</b> with <b>he, she, it</b> and one person or thing: <i>Sam <b>has</b> a coin. A triangle <b>has</b> three sides.</i><br>Use <b>have</b> with <b>I, you, we, they</b> and more than one: <i>I <b>have</b> a watch. Squares <b>have</b> four sides.</i>",
 doHave:"In questions: <b>Does</b> he/she/it <b>have</b>…? · <b>Do</b> I/you/we/they <b>have</b>…? (After does, it is always <b>have</b>, never has.)",
 smf:"<b>many</b> = a lot (things you can count): <i>many stars</i>.<br><b>few</b> = not many: <i>very few people, only a few leaves</i>.<br><b>some</b> = an amount, often of things you can't count one by one: <i>some water, some bread, some money</i>.",
 qw:"<b>Who</b> → a person · <b>What</b> → a thing · <b>Where</b> → a place · <b>When</b> → a time · <b>Why</b> → a reason (because…) · <b>How</b> → the way · <b>How many</b> → a number · <b>How much</b> → an amount or price · <b>Which</b> → a choice · <b>Whose</b> → who owns it.",
 qmark:"A <b>question</b> asks something. It starts with a capital letter and ends with a <b>question mark ?</b><br>Many questions start with a question word, or with <b>Is, Are, Can, Do, Does</b>.",
 fix:"Check: <b>1.</b> capital letter at the start, <b>2.</b> capitals for names, places, days, months and I, <b>3.</b> a full stop at the end.",
 orderW:"Find the word with the capital letter: it goes first. Then think: <b>who? does what?</b>",
 write:"Plan in your head first. Then write: capital letter, complete idea, end mark.",
 spell:"Use <b>Look → Say → Cover → Write → Check</b>.",
 nums:"Number words: <b>-teen</b> numbers (thirteen…nineteen) and <b>-ty</b> numbers (twenty, thirty…). Watch out: <b>forty</b> has no u!",
 qws:"Most question words start with <b>wh</b>: who, what, where, when, why, which, whose. <b>How</b> starts with h.",
 choose:"Say the word slowly and picture it. Watch for silent letters: <b>h</b>our, ha<b>l</b>f.",
 think:"Read carefully, picture the problem and check your answer. Some riddles are tricky!",
 maths:"Is it more (add), less (take away), groups of (multiply) or sharing (divide)?",
 odd:"Three belong to the same group. Find the one that does <b>not</b> belong.",
 ana:"Find how the first two words are linked. Use the <b>same link</b> for the next pair.",
 review:"These questions come from earlier units, so you keep everything you learned fresh."
};
const RV=id=>UNITS.find(x=>x.id===id).review;
u.review=MIX(hasHave,doesHave,smfQ,qwQ,qFix,clockQ,clock5,coinsQ,changeQ,shapeName,whichOp,solveWP,F.vocab(u.words));

/* ================= THE SKILL LIST ================= */
u.cats=[
 {n:"Reading",e:"📖",items:[
  {id:"r_t1",t:"Problem-solving story: The Lemonade Stand",act:"story",si:0},
  {id:"r_t2",t:"Story: Arjun and Grandpa's Clock",act:"story",si:1},
  {id:"r_t3",t:"Fact text: Shapes All Around Us",act:"story",si:2},
  {id:"r_t4",t:"Fact text: The Story of Money",act:"story",si:3},
  {id:"r_t5",t:"Fable: Later-Later Lula",act:"story",si:4},
  {id:"r_t6",t:"Real-world reading: A market price board and a school timetable",act:"story",si:5},
  {id:"r_p1",t:"Traditional rhyme: Thirty Days Hath September",act:"poem",pi:0},
  {id:"r_p2",t:"Poem: Shapes on My Street",act:"poem",pi:1},
  {id:"r_wp",t:"Read and solve word problems",learn:L.wp,gen:solveWP},
  {id:"r_detail",t:"Read and find the details",learn:L.detail,gen:detail},
  {id:"r_main",t:"Find the main idea",learn:L.main,gen:mainIdea},
  {id:"r_factop",t:"Fact or opinion?",learn:L.factop,gen:factOp},
  {id:"r_order",t:"Order and sequence",learn:L.order,gen:order},
  {id:"r_cause",t:"Cause and effect",learn:L.cause,gen:cause},
  {id:"r_compare",t:"Compare and contrast",learn:L.compare,gen:compare}]},
 {n:"Vocabulary",e:"🔤",items:[
  {id:"v_s1",t:"Time words",learn:L.vocab,gen:F.vocab(set(0))},
  {id:"v_s2",t:"Shape words",learn:L.vocab,gen:F.vocab(set(1))},
  {id:"v_s3",t:"Money words",learn:L.vocab,gen:F.vocab(set(2))},
  {id:"v_s4",t:"Maths words",learn:L.vocab,gen:F.vocab(set(3))},
  {id:"v_fill",t:"Use the right word in a sentence",learn:L.vocab,gen:F.fill(u.words)},
  {id:"v_op",t:"Maths key words: add, subtract, multiply or divide?",learn:L.wp,gen:whichOp},
  {id:"v_mw",t:"Maths word meanings (sum, difference, double, half)",learn:L.mw,gen:F.bank(MW)},
  {id:"v_syn",t:"Synonyms",learn:L.syn,gen:F.pairs(SYN,"synonym")},
  {id:"v_opp",t:"Opposites",learn:L.opp,gen:F.pairs(OPP,"opposite")},
  {id:"v_comp",t:"Compound words",learn:L.comp,gen:MIX(F.compoundJoin(COMP),F.compoundPick(COMP))}]},
 {n:"Grammar",e:"🧩",items:[
  {id:"g_has",t:"Has or have?",learn:L.has,gen:MIX(hasHave,hasFix)},
  {id:"g_dohave",t:"Do or does … have? (questions)",learn:L.doHave,gen:doesHave},
  {id:"g_smf",t:"Some, many or few?",learn:L.smf,gen:smfQ},
  {id:"g_qw",t:"Choose the question word",learn:L.qw,gen:qwQ},
  {id:"g_qmatch",t:"Match the question to the answer",learn:L.qw,gen:qMatch},
  {id:"g_qmark",t:"Question marks: is it a question?",learn:L.qmark,gen:MIX(isQ,G.endMark(TELL,ASK,EXCL))},
  {id:"g_qfix",t:"Fix the question (capital letter and ?)",learn:L.qmark,gen:qFix},
  {id:"g_turnq",t:"Turn a sentence into a question",learn:L.qmark,gen:turnQ},
  {id:"g_fix",t:"Fix the sentence (capitals and full stops)",learn:L.fix,gen:fix},
  {id:"g_order",t:"Put the words in order",learn:L.orderW,gen:G.order(SENT.filter(x=>(x.match(/\b[A-Z]/g)||[]).length===1))},
  {id:"g_write",t:"Write your own sentences",learn:L.write,gen:F.write(WP)},
  {id:"g_mixed",t:"Mixed grammar review",learn:"Use all the has/have, some/many/few and question rules from this unit.",gen:MIX(hasHave,hasFix,doesHave,smfQ,qwQ,isQ,qFix,turnQ)}]},
 {n:"Time, shapes and money",e:"⏰",items:[
  {id:"m_clock",t:"Tell the time: o'clock, half past, quarter past, quarter to",learn:L.clock,gen:MIX(clockQ,wordsToNum)},
  {id:"m_clock5",t:"Tell the time to 5 minutes",learn:L.clock5,gen:MIX(clock5,clockType)},
  {id:"m_elapsed",t:"How long? Start and end times",learn:L.elapsed,gen:elapsed},
  {id:"m_cal",t:"Days, months and the calendar",learn:L.cal,gen:calQ},
  {id:"m_tf",t:"Time facts",learn:L.tf,gen:F.bank(TF)},
  {id:"m_shape",t:"Name the shape",learn:L.shape,gen:MIX(shapeName,shapeObj)},
  {id:"m_sides",t:"Count sides and corners",learn:L.shape,gen:shapeCount},
  {id:"m_sh",t:"Flat and 3D shapes",learn:L.shape,gen:F.bank(SH)},
  {id:"m_coins",t:"Count the coins",learn:L.money,gen:coinsQ},
  {id:"m_change",t:"Shopping: totals, budgets and change",learn:L.money,gen:MIX(changeQ,shopQ)},
  {id:"m_mb",t:"Money around the world",learn:L.money,gen:F.bank(MB)}]},
 {n:"Spelling",e:"🎧",items:[
  {id:"s_maths",t:"Time, shape and money words: listen and write",learn:L.spell,gen:F.listen(SP)},
  {id:"s_nums",t:"Number words: listen and write",learn:L.nums,gen:F.listen(NUMS)},
  {id:"s_qw",t:"Question words: listen and write",learn:L.qws,gen:F.listen(QWS)},
  {id:"s_choose",t:"Choose the correct spelling",learn:L.choose,gen:F.chooseSpelling(CHOOSE)},
  {id:"s_missing",t:"Missing letters",learn:L.spell,gen:F.missing(SP.concat(NUMS))}]},
 {n:"Thinking",e:"🧠",items:[
  {id:"t_puz",t:"Puzzles and riddles",learn:L.think,gen:F.bank(PUZ)},
  {id:"t_pat",t:"Number and shape patterns",learn:L.pattern,gen:patternQ},
  {id:"t_maths",t:"Quick maths stories",learn:L.maths,gen:maths},
  {id:"t_odd",t:"Odd one out",learn:L.odd,gen:odd},
  {id:"t_ana",t:"Word links (analogies)",learn:L.ana,gen:analogy}]},
 {n:"Review earlier units",e:"🔁",items:[
  {id:"rv_u1",t:"Review: Unit 1 (sentences, question words, nouns)",learn:L.review,gen:RV("me")},
  {id:"rv_u2",t:"Review: Unit 2 (plurals, past tense, animals)",learn:L.review,gen:RV("animals")},
  {id:"rv_u3",t:"Review: Unit 3 (present tense, plants, magic e)",learn:L.review,gen:RV("plants")},
  {id:"rv_u4",t:"Review: Unit 4 (adjectives, comparing, homophones)",learn:L.review,gen:RV("weather")},
  {id:"rv_u5",t:"Review: Unit 5 (future tense, a/an/the, space)",learn:L.review,gen:RV("space")},
  {id:"rv_u6",t:"Review: Unit 6 (prepositions, pronouns, un-/re-)",learn:L.review,gen:RV("ocean")}]},
 {n:"Explore and write",e:"✏️",items:[
  {id:"x_facts",t:"Did you know? Amazing facts about time, shapes and money",act:"facts"},
  {id:"x_w1",t:"Writing step 1: A shopping list with prices",act:"write",wi:0},
  {id:"x_w2",t:"Writing step 2: Write your own word problem",act:"write",wi:1},
  {id:"x_w3",t:"Writing step 3: My day, hour by hour",act:"write",wi:2}]}
];
})();
