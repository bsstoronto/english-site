/* ===================== GRADE 1 · UNIT 1 · ALL ABOUT ME ===================== */
(function(){
const {f,t,p}=G4;
const u={grade:1,id:"g1_me",num:1,emoji:"🧒🏽👋🏠",title:"All About Me",short:"letter sounds, capital I and names, full stops",badge:"🌟 Super Me Star",
stories:[
/* 1 STORY: PROBLEM AND HAPPY ENDING */
{title:"Where Is Ted?",e:"🧸",kind:"Story",pages:[
 {pic:"🧒🏽🧸",text:"My name is Ravi. I live in Toronto. I have a teddy. His name is Ted. Ted is soft and brown. I like Ted a lot. I hug Ted every night.",
  qs:[f("What is the boy's name?","Ravi",["Ted","Sam"],"My name is Ravi."),
      f("What is Ted?","A teddy 🧸",["A dog 🐶","A ball ⚽"],"I have a teddy. His name is Ted.")]},
 {pic:"😟🛏️",text:"It is bedtime. I look for Ted. Ted is not on my bed. Ted is not on the sofa. Where is Ted? I am sad. I want my Ted!",
  qs:[f("How does Ravi feel?","Sad 😢",["Happy 😀","Silly 🤪"],"I am sad."),
      p("Who do you think will help Ravi?","His family",["A big lion","Nobody at all"],"Families help each other.")]},
 {pic:"👧🏽🔦",text:"My sister Asha comes in. \"I can help you,\" she says. We look under the bed. We look by the door. Then Asha sees a brown ear. It is in the toy box!",
  qs:[f("Who helps Ravi?","His sister Asha",["His dad","His teacher"],"My sister Asha comes in. \"I can help you,\" she says."),
      t("Whose brown ear does Asha see?","Ted's ear",["A dog's ear","Mom's ear"],"Ted is soft and brown, so the brown ear is Ted's!")]},
 {pic:"🤗🧸",text:"It is Ted! I am so happy. I give Asha a big hug. \"Thank you!\" I say. Then I hug Ted too. Now I can go to sleep.",
  qs:[f("Where was Ted?","In the toy box",["On the sofa","In the bath"],"It is in the toy box!"),
      t("How does Ravi feel at the end?","Happy 😀",["Sad 😢","Angry 😠"],"I am so happy.")]}
],turn:{q:"Write about a toy you like. Use the word I.",model:"I like my red ball. I play with it every day."}},
/* 2 NON-FICTION */
{title:"My Amazing Body",e:"🧍",kind:"Non-fiction",pages:[
 {pic:"👀👂👃",text:"Your body has many parts. You see with your eyes. You hear with your ears. You smell with your nose. You taste with your tongue.",
  qs:[f("What do you see with?","Your eyes 👀",["Your ears 👂","Your nose 👃"],"You see with your eyes."),
      f("What do you smell with?","Your nose 👃",["Your feet 🦶","Your hair"],"You smell with your nose.")]},
 {pic:"✋🦶",text:"You have two hands. Hands can clap, hold and wave. You have two feet. Feet can walk, run and jump. Your legs help you stand up tall.",
  qs:[f("What can hands do?","Clap and wave 👏",["Smell and hear","See the sky"],"Hands can clap, hold and wave."),
      t("Which body part helps you kick a ball?","Your foot 🦶",["Your ear 👂","Your nose 👃"],"Feet can walk, run and jump, and they can kick too!")]},
 {pic:"🦷🪥",text:"You have teeth in your mouth. Teeth help you bite and chew your food. Brush your teeth two times a day. Then they stay clean and strong.",
  qs:[f("What do teeth help you do?","Bite and chew",["Hear and see","Run and hop"],"Teeth help you bite and chew your food."),
      f("How many times a day should you brush?","Two times",["Ten times","No times"],"Brush your teeth two times a day.")]},
 {pic:"💧😴",text:"Your body needs good care. Eat good food. Drink water. Play and move every day. Sleep well at night. Then your body can grow big and strong!",
  qs:[t("What helps your body grow strong?","Food, play and sleep",["Only candy","No sleep"],"Eat good food, play, move and sleep well."),
      p("What will happen if you do not sleep?","You will feel tired 😴",["You will fly","You will grow wings"],"Your body needs sleep to rest.")]}
],turn:{q:"Write one thing your body can do. Start with I can.",model:"I can run fast with my legs."}},
/* 3 PATTERN TEXT */
{title:"I Can! Can You?",e:"🙌",kind:"Pattern book",pages:[
 {pic:"👏🙂",text:"Look at me! I can clap. Clap, clap, clap! Can you clap? Yes, I can! I can wave. Wave, wave, wave! Can you wave? Yes, I can!",
  qs:[f("What does the child do first?","Clap 👏",["Jump","Sing"],"I can clap. Clap, clap, clap!"),
      t("Which word do you see again and again?","can",["dog","red"],"I can… Can you…? Yes, I can!")]},
 {pic:"🐰🌀",text:"Look at me! I can hop. Hop, hop, hop! Can you hop? Yes, I can! I can spin. Spin, spin, spin! Can you spin? Yes, I can!",
  qs:[f("What does the child do after hop?","Spin 🌀",["Clap","Sleep"],"I can hop… I can spin."),
      p("What do you think the next page will say?","I can… one more thing",["Goodbye, Ted","The cat is wet"],"The book keeps saying I can.")]},
 {pic:"🎤💃",text:"I can sing. La, la, la! I can dance. Tap, tap, tap! I can do so much. What can you do? Come on, show me! We can do it together!",
  qs:[f("What sound does the child sing?","La, la, la",["Moo, moo","Tap, tap"],"I can sing. La, la, la!"),
      t("What does the child want you to do?","Show what you can do",["Go to sleep","Be very sad"],"What can you do? Show me!")]}
],turn:{q:"What can you do? Write a sentence with I can.",model:"I can hop on one foot."}},
/* 4 HOW-TO */
{title:"How to Wash Your Hands",e:"🧼",kind:"How-to text",pages:[
 {pic:"🦠✋",text:"Germs are very, very small. You can not see them. Some germs can make you sick. Washing your hands gets germs off. Here is how to do it.",
  qs:[f("Can you see germs?","No, they are too small",["Yes, they are big","Yes, they are red"],"You can not see them."),
      t("Why do we wash our hands?","To get germs off",["To make them dirty","To paint them"],"Washing your hands gets germs off.")]},
 {pic:"🚰🧼",text:"First, wet your hands with water. Next, put on soap. Then rub your hands together. Rub the front and the back. Rub between your fingers too.",
  qs:[f("What do you do first?","Wet your hands 💧",["Dry your hands","Eat lunch"],"First, wet your hands with water."),
      f("What comes after the water?","Soap 🧼",["A towel","A snack"],"Next, put on soap.")]},
 {pic:"⏱️🧻",text:"Keep on rubbing. Count to 20 slowly as you rub. Then rinse off all the soap with water. Last, dry your hands with a clean towel.",
  qs:[f("What do you count to?","20",["2","100"],"Count to 20 slowly as you rub."),
      f("What do you do last?","Dry your hands",["Put on soap","Wet your hands"],"Last, dry your hands with a clean towel.")]},
 {pic:"🍎✨",text:"When should you wash? Wash before you eat. Wash after you use the toilet. Wash after you play outside. Clean hands help you stay well!",
  qs:[t("When is a good time to wash your hands?","Before you eat 🍎",["Only on Sunday","Never"],"Wash before you eat."),
      p("Mia just played in the sand. What should she do next?","Wash her hands",["Eat a snack first","Go to bed"],"Wash after you play outside.")]}
],turn:{q:"Write one step for washing your hands. Use First, Next or Last.",model:"First, I wet my hands with water."}},
/* 5 CHILDREN AROUND THE WORLD */
{title:"Hello, World!",e:"🌍",kind:"Around the world",pages:[
 {pic:"🇨🇦👋",text:"Children all around the world say hello. Lena lives in Montreal, in Canada. She speaks French. She says, \"Bonjour!\" Bonjour means hello in French. Let us meet more children!",
  qs:[f("Where does Lena live?","Montreal, Canada",["Tokyo, Japan","Lima, Peru"],"Lena lives in Montreal, in Canada."),
      f("What does Bonjour mean?","Hello",["Goodbye","Thank you"],"Bonjour means hello in French.")]},
 {pic:"🇯🇵🇲🇽",text:"Yuki lives in Japan. She says, \"Konnichiwa!\" She bows to say hello. Diego lives in Mexico. He speaks Spanish. He says, \"¡Hola!\" He waves and smiles.",
  qs:[f("How does Yuki say hello?","Konnichiwa",["Hola","Jambo"],"She says, \"Konnichiwa!\""),
      f("Where does Diego live?","Mexico",["Japan","Kenya"],"Diego lives in Mexico.")]},
 {pic:"🇮🇳🇰🇪",text:"Arjun lives in India. He says, \"Namaste!\" He puts his hands together. Amani lives in Kenya. She speaks Swahili. She says, \"Jambo!\" Then she waves to her friends.",
  qs:[f("What does Arjun do with his hands?","Puts them together 🙏",["Claps them","Hides them"],"He puts his hands together."),
      t("Which word means hello in Swahili?","Jambo",["Namaste","Bonjour"],"Amani speaks Swahili. She says, \"Jambo!\"")]},
 {pic:"🌍😊",text:"There are many ways to say hello. Some people wave. Some people bow. Some people shake hands. A big smile says hello all over the world!",
  qs:[t("What says hello all over the world?","A smile 😊",["A frown 😠","A shout 📢"],"A big smile says hello all over the world!"),
      p("A new girl comes to your class. What could you do?","Smile and say hello",["Run away","Look away"],"A smile says hello in every place.")]}
],turn:{q:"How do you say hello? Write a sentence.",model:"I say hello and wave my hand."}},
/* 6 REAL-WORLD TEXT */
{title:"Real-world reading: A picture schedule, a name tag and a birthday chart",e:"📅",kind:"Real-world text",pages:[
 {pic:"⏰📅",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🌞 MAYA'S DAY</b><table class=\"realtbl\"><tr><th>Time</th><th>What I do</th></tr><tr><td>7:00</td><td>⏰ Wake up</td></tr><tr><td>7:15</td><td>🪥 Brush my teeth</td></tr><tr><td>7:30</td><td>🥣 Eat breakfast</td></tr><tr><td>8:15</td><td>🎒 Go to school</td></tr><tr><td>3:30</td><td>⚽ Play</td></tr><tr><td>6:00</td><td>🍝 Eat dinner</td></tr><tr><td>7:30</td><td>🛁 Take a bath</td></tr><tr><td>8:00</td><td>🛏️ Go to bed</td></tr></table></div>",
  qs:[f("What does Maya do at 7:15?","Brush her teeth 🪥",["Eat dinner 🍝","Go to bed 🛏️"],"7:15 · 🪥 Brush my teeth"),
      f("When does Maya go to bed?","8:00",["7:00","3:30"],"8:00 · 🛏️ Go to bed"),
      t("What does Maya do right after school?","Play ⚽",["Wake up ⏰","Eat breakfast 🥣"],"After school, at 3:30, she plays.")]},
 {pic:"🏷️👦🏾",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>👋 HELLO! My name is</b><br><span style=\"font-size:30px;font-weight:700\">Omar</span><br>🎂 I am 6.<br>🏠 I live in Calgary.<br>❤️ I like: 🚂 trains and 🎨 painting.<br>💪 I can: 🏊 swim.<br>👨‍👩‍👧 I live with my mom, my dad and my sister.</div>",
  qs:[f("What is the name on the tag?","Omar",["Maya","Lena"],"HELLO! My name is Omar."),
      f("How old is Omar?","6",["8","10"],"🎂 I am 6."),
      p("Omar likes painting. What might he make at school?","A painting 🎨",["A cake 🎂","A car 🚗"],"❤️ I like: painting.")]},
 {pic:"🎂🎈",text:"<div class=\"realdoc\" style=\"text-align:left\"><b>🎈 OUR BIRTHDAYS 🎈</b><table class=\"realtbl\"><tr><th>Month</th><th>Name</th></tr><tr><td>January</td><td>❄️ Omar</td></tr><tr><td>March</td><td>🌷 Maya</td></tr><tr><td>July</td><td>☀️ Lena</td></tr><tr><td>October</td><td>🍂 Ravi</td></tr></table>🎂 Find your month. Write your name there.<br><i>We sing and eat cake on our birthdays!</i></div>",
  qs:[f("When is Maya's birthday?","March",["July","October"],"March · 🌷 Maya"),
      f("Whose birthday is in July?","Lena",["Omar","Ravi"],"July · ☀️ Lena")]}
],turn:{q:"Make your own name tag. Write your name and your age in two sentences.",model:"My name is Zoe. I am seven years old."}}
],
poems:[
 {title:"Jack and Jill (a traditional nursery rhyme, more than 200 years old)",
  lines:["Jack and Jill went up the hill","To fetch a pail of water;","Jack fell down and broke his crown,","And Jill came tumbling after."],
  qs:[f("Where did Jack and Jill go?","Up the hill ⛰️",["To the sea 🌊","To school 🏫"],"\"Jack and Jill went up the hill\""),
      f("What did they go to get?","A pail of water 🪣",["A big cake","A red ball"],"\"To fetch a pail of water\""),
      t("In this rhyme, Jack's crown is the top of his…","Head",["Foot","Hand"],"Long ago, people called the top of the head the crown."),
      f("Which word rhymes with hill?","Jill",["Jack","water"],"Hill and Jill end with the same sound: -ill.")]},
 {title:"Just Me",
  lines:["Two eyes to see the big blue sky,","Two hands to wave and say goodbye,","Two feet to run and hop and play,","One mouth to sing and laugh all day.","From head to toe, as you can see,","I am happy being me!"],
  qs:[f("What do the two hands do?","Wave goodbye 👋",["Smell a rose","Hop and play"],"\"Two hands to wave and say goodbye\""),
      t("How does the child in the poem feel?","Happy 😀",["Sad 😢","Scared 😨"],"\"I am happy being me!\""),
      f("Which word rhymes with play?","day",["sky","see"],"Play and day end with the same sound: -ay.")]}
],
words:[
 {w:"hand",e:"✋",m:"the part at the end of your arm",ex:"I wave my hand.",fill:"I hold a cup in my ___."},
 {w:"foot",e:"🦶",m:"the part at the end of your leg",ex:"I hop on one foot.",fill:"I put a sock on my ___."},
 {w:"nose",e:"👃",m:"the part of your face you smell with",ex:"My nose can smell the cake.",fill:"I smell a flower with my ___."},
 {w:"ear",e:"👂",m:"the part of your head you hear with",ex:"I hear music with my ear.",fill:"Grandma tells a secret in my ___."},
 {w:"eye",e:"👁️",m:"the part of your face you see with",ex:"I shut one eye.",fill:"I wink one ___ at you."},
 {w:"mouth",e:"👄",m:"the part of your face you eat and talk with",ex:"I open my mouth wide.",fill:"I put food in my ___."},
 {w:"hair",e:"💇",m:"the soft strands that grow on your head",ex:"My hair is long and black.",fill:"I brush my ___ in the morning."},
 {w:"arm",e:"💪",m:"the long body part between shoulder and hand",ex:"I lift my arm up high.",fill:"Your elbow is in the middle of your ___."},
 {w:"leg",e:"🦵",m:"the long body part you walk with",ex:"I kick with my leg.",fill:"Your knee is in the middle of your ___."},
 {w:"tooth",e:"🦷",m:"a small, hard, white thing in your mouth",ex:"My tooth is loose.",fill:"I lost a baby ___ today!"},
 {w:"mom",e:"👩",m:"your mother",ex:"My mom reads to me.",fill:"My ___ and dad love me.",alt:["mum","mommy","mummy"]},
 {w:"dad",e:"👨",m:"your father",ex:"My dad makes pancakes.",fill:"My mom and ___ love me.",alt:["daddy"]},
 {w:"sister",e:"👧",m:"a girl who has the same parents as you",ex:"My sister is two years old.",fill:"My ___ is a girl, and she is four."},
 {w:"brother",e:"👦",m:"a boy who has the same parents as you",ex:"My brother likes to play.",fill:"My big ___ is a boy, and he is nine."},
 {w:"grandma",e:"👵",m:"the mother of your mom or dad",ex:"My grandma sings to me.",fill:"My mom's mother is my ___.",alt:["grandmother","granny"]},
 {w:"grandpa",e:"👴",m:"the father of your mom or dad",ex:"My grandpa tells funny stories.",fill:"My dad's father is my ___.",alt:["grandfather"]},
 {w:"hug",e:"🤗",m:"to hold someone close in your arms",ex:"I hug my dad.",fill:"I give my mom a big ___."},
 {w:"kiss",e:"😘",m:"to touch someone with your lips to show love",ex:"Mom gives me a kiss at night.",fill:"Grandma gives me a ___ on my cheek."},
 {w:"smile",e:"😊",m:"a happy look when your mouth turns up",ex:"My baby brother has a big smile.",fill:"When I am happy, I ___."},
 {w:"name",e:"📛",m:"the word people call you",ex:"My name is Mia.",fill:"Hello! My ___ is Leo."},
 {w:"house",e:"🏠",m:"a building where a family lives",ex:"My house is blue.",fill:"We live in a big ___."},
 {w:"bed",e:"🛏️",m:"the soft thing you sleep on at night",ex:"I sleep in my bed.",fill:"At night, I go to ___."},
 {w:"door",e:"🚪",m:"you open it to go into a room",ex:"Please shut the door.",fill:"Knock on the ___ before you go in."},
 {w:"window",e:"🪟",m:"glass in a wall that you look through",ex:"I look out the window.",fill:"I see the rain through the ___."},
 {w:"sofa",e:"🛋️",m:"a long, soft seat for two or more people",ex:"We sit on the sofa.",fill:"Dad naps on the ___."},
 {w:"bath",e:"🛁",m:"a tub of water you wash your body in",ex:"I take a bath at night.",fill:"I wash with soap in the ___."},
 {w:"shower",e:"🚿",m:"water that sprays down on you to wash",ex:"Dad takes a shower in the morning.",fill:"I stand under the ___ to wash my hair."},
 {w:"key",e:"🔑",m:"a small metal thing that opens a lock",ex:"Mom has a key for our house.",fill:"We lock the door with a ___."},
 {w:"mirror",e:"🪞",m:"glass where you can see yourself",ex:"I smile in the mirror.",fill:"I look in the ___ to see my face."},
 {w:"broom",e:"🧹",m:"a brush on a long stick for sweeping",ex:"I sweep with a broom.",fill:"Grandpa sweeps the floor with a ___."},
 {w:"ball",e:"⚽",m:"a round toy you kick or throw",ex:"I kick the ball.",fill:"Throw the ___ to me!"},
 {w:"drum",e:"🥁",m:"you hit it to make a loud beat",ex:"I bang on my drum.",fill:"Boom, boom! I play the ___."},
 {w:"teddy",e:"🧸",m:"a soft toy bear",ex:"I hug my teddy.",fill:"My soft ___ sleeps in my bed.",alt:["teddy bear"]},
 {w:"doll",e:"🪆",m:"a toy that looks like a small person",ex:"My doll has a red dress.",fill:"My ___ has a little hat and shoes."},
 {w:"puzzle",e:"🧩",m:"a game where you fit pieces together",ex:"I can do a puzzle.",fill:"I put the last piece in my ___."},
 {w:"sing",e:"🎤",m:"to make music with your voice",ex:"I sing a song.",fill:"Birds ___ in the morning."},
 {w:"dance",e:"💃",m:"to move your body to music",ex:"We dance at the party.",fill:"When music plays, I like to ___."},
 {w:"run",e:"🏃",m:"to move very fast on your feet",ex:"I run in the park.",fill:"I can ___ fast to catch the bus."},
 {w:"paint",e:"🎨",m:"to make a picture with a brush and colours",ex:"I paint a sun.",fill:"I use a brush to ___ a picture."},
 {w:"swim",e:"🏊",m:"to move in water with your arms and legs",ex:"I swim in the pool.",fill:"Ducks ___ in the pond."}
],
spelling:[],
facts:[
 {e:"👃",c:"You smell with your nose.",t:true,x:"True! Your nose smells flowers, food and more."},
 {e:"👂",c:"You see with your ears.",t:false,x:"Not true! You see with your eyes. You hear with your ears."},
 {e:"🦷",c:"Children lose their baby teeth, and new teeth grow in.",t:true,x:"True! Most children start losing baby teeth at about age 6."},
 {e:"🖐️",c:"No two people have the same fingerprints.",t:true,x:"True! Your fingerprints are only yours, even if you are a twin."},
 {e:"❤️",c:"Your heart is in your foot.",t:false,x:"Not true! Your heart is in your chest. It pumps blood all day and night."},
 {e:"😴",c:"Sleep helps your body grow and rest.",t:true,x:"True! Children need lots of sleep every night."},
 {e:"👅",c:"Your tongue helps you taste food.",t:true,x:"True! Your tongue can taste sweet, salty and sour."},
 {e:"🌍",c:"Everyone in the world speaks the same language.",t:false,x:"Not true! People speak thousands of languages."},
 {e:"🇫🇷",c:"Bonjour means hello in French.",t:true,x:"True! Many people in Canada speak French."},
 {e:"🙇",c:"In Japan, many people bow to say hello.",t:true,x:"True! A bow is a polite hello in Japan."},
 {e:"💇",c:"Your hair stops growing after you cut it.",t:false,x:"Not true! Your hair keeps growing. That is why you need haircuts."},
 {e:"🦴",c:"Babies have no bones.",t:false,x:"Not true! Babies have bones, and the bones grow as the baby grows."}
],
writing:[
 {e:"📛",t:"My name",level:"Step 1 · 2 sentences",
  prompt:"Write 2 sentences. Tell your name. Tell one thing about your hair, eyes or smile. Start each sentence with a capital letter and end with a full stop.",
  minS:2,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["\\.\\s*$","I ended with a full stop"],["\\b[Nn]ame\\b","I wrote my name"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["My name is ","I have ","My hair is ","My smile is "],
  model:"My name is Leo. I have short brown hair."},
 {e:"👨‍👩‍👧",t:"My family",level:"Step 2 · 3 sentences",
  prompt:"Write 3 sentences about your family. Who lives with you? What do you do together? Use I as a capital letter.",
  minS:3,minWords:1,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["\\.\\s*$","I ended with a full stop"],["\\b([Mm]om|[Mm]um|[Dd]ad|[Ss]ister|[Bb]rother|[Gg]randma|[Gg]randpa|[Ff]amily|[Aa]unt|[Uu]ncle|[Bb]aby)\\b","I named someone in my family"],["\\bI\\b","I used the word I"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["I live with ","My family likes to ","I love my ","We "],
  model:"I live with my mom and my brother. We play ball in the park. I give my mom a big hug every night."},
 {e:"🌟",t:"All about me",level:"Step 3 · All about me",
  prompt:"Write 3 sentences all about you. Start one with <b>I am</b>, one with <b>I like</b> and one with <b>I can</b>. Remember: a capital letter at the start and a full stop at the end.",
  minS:3,minWords:1,
  rx:[["\\bI am\\b","I wrote an I am sentence"],["\\bI like\\b","I wrote an I like sentence"],["\\bI can\\b","I wrote an I can sentence"],["^\\s*[A-Z]","I started with a capital letter"],["\\.\\s*$","I ended with a full stop"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["I am ","I like ","I can "],
  model:"I am six years old. I like my teddy and my drum. I can swim in the pool."}
]};
UNITS.push(u);

/* ================= PHONICS: BEGINNING LETTER SOUNDS A–Z ================= */
/* [word, emoji, clear picture on its own? 1/0] */
const LS={
 a:[["apple","🍎",1],["ant","🐜",1],["alligator","🐊",0]],
 b:[["bear","🐻",1],["bus","🚌",1],["banana","🍌",1],["bee","🐝",1]],
 c:[["cat","🐱",1],["car","🚗",1],["cake","🎂",0],["cow","🐄",1]],
 d:[["dog","🐶",0],["duck","🦆",1],["drum","🥁",1],["door","🚪",1]],
 e:[["egg","🥚",1],["elephant","🐘",1],["envelope","✉️",0]],
 f:[["fish","🐟",1],["fox","🦊",1],["frog","🐸",1],["foot","🦶",1]],
 g:[["goat","🐐",1],["grapes","🍇",1],["guitar","🎸",1],["gift","🎁",0]],
 h:[["hat","🎩",1],["horse","🐴",0],["house","🏠",1],["heart","❤️",0]],
 i:[["iguana","🦎",0],["insect","🐞",0],["inch","📏",0]],
 j:[["juice","🧃",1],["jeans","👖",0],["jet","✈️",0]],
 k:[["kite","🪁",1],["key","🔑",1],["kangaroo","🦘",1],["koala","🐨",1]],
 l:[["lion","🦁",1],["leaf","🍃",1],["lemon","🍋",1],["lollipop","🍭",0]],
 m:[["moon","🌙",1],["mouse","🐭",1],["milk","🥛",1],["monkey","🐒",1]],
 n:[["nest","🪺",0],["nose","👃",1],["nine","9️⃣",1],["net","🥅",0]],
 o:[["octopus","🐙",1],["otter","🦦",1],["olive","🫒",1],["ox","🐂",0]],
 p:[["pig","🐷",1],["pizza","🍕",1],["panda","🐼",1],["pear","🍐",1]],
 q:[["queen","👸",0],["question mark","❓",1]],
 r:[["rainbow","🌈",1],["ring","💍",1],["robot","🤖",1],["rabbit","🐰",0]],
 s:[["sun","☀️",1],["sock","🧦",1],["snake","🐍",1],["star","⭐",1]],
 t:[["tiger","🐯",1],["tree","🌳",1],["turtle","🐢",1],["tent","⛺",1]],
 u:[["umbrella","☂️",1],["up","⬆️",0]],
 v:[["violin","🎻",1],["volcano","🌋",0],["vest","🦺",1],["van","🚐",0]],
 w:[["watch","⌚",0],["worm","🪱",1],["web","🕸️",1],["wolf","🐺",0]],
 x:[["x-ray","🩻",1]],
 y:[["yo-yo","🪀",1],["yawn","🥱",1],["yarn","🧶",0]],
 z:[["zebra","🦓",1],["zero","0️⃣",1]]
};
const SOUNDL=Object.keys(LS).filter(l=>l!=="x");  // x rarely starts a word with its own sound
const grp=l=>"ckq".includes(l)?"k":l;              // c, k and q can share the /k/ sound
const otherL=(l,n)=>SAMPLE(SOUNDL.filter(x=>grp(x)!==grp(l)),n);
const pw=x=>`${x[1]} ${x[0]}`;
const BIG=s=>`<span style="font-size:40px;line-height:1.3">${s}</span>`;
const phStart=()=>{const l=R(SOUNDL),x=R(LS[l]);const wr=otherL(l,2).map(o=>pw(R(LS[o])));
  return mcQ(`🔤 Which picture starts with the sound <b style="font-size:26px">/${l}/</b>?`,pw(x),wr,`${x[1]} <b>${x[0]}</b> starts with <b>${l}</b>: /${l}/.`,"Say each word slowly. Listen to the very first sound.",{say:`Which picture starts with the sound of the letter ${l}?`})};
const phFirst=()=>{const l=R(SOUNDL),x=R(LS[l]);
  if(Math.random()<.5)return mcQ(`🔤 Say the word: ${BIG(x[1])} <b>${x[0]}</b><br>What sound does it start with?`,`/${l}/`,otherL(l,2).map(o=>`/${o}/`),`<b>${x[0]}</b> starts with /${l}/, the letter <b>${l}</b>.`,"Say the word slowly. What is the first sound you hear?",{say:`${x[0]}. What sound does ${x[0]} start with?`});
  return {type:"type",q:`🔤 Say the word: ${BIG(x[1])} <b>${x[0]}</b><br>Type the first letter.`,a:[l],why:`<b>${x[0]}</b> starts with the letter <b>${l}</b>.`,hint:"Say the word slowly. Type the letter for the first sound.",say:x[0]}};
const phMatch=()=>{const l=R(Object.keys(LS));const clear=LS[l].filter(x=>x[2]);
  if(clear.length&&Math.random()<.5){const x=R(clear);const wr=SAMPLE(Object.keys(LS).filter(o=>grp(o)!==grp(l)&&o!=="x"&&LS[o].some(y=>y[2])),2).map(o=>R(LS[o].filter(y=>y[2]))[1]);
    return mcQ(`🔗 Match the letter to a picture.<br>${BIG(l.toUpperCase()+" "+l)}<br>Which picture goes with this letter?`,x[1],wr,`${x[1]} <b>${x[0]}</b> starts with <b>${l}</b>.`,"Name each picture. Which one starts with this letter?",{say:`Which picture goes with the letter ${l}?`})}
  const x=R(LS[l]);const shown="_"+x[0].slice(1);
  if(Math.random()<.5)return mcQ(`🔗 Which letter goes on the line?<br>${BIG(x[1])}<br><b style="font-size:26px;letter-spacing:3px">${shown}</b>`,l,otherL(l,2),`${x[1]} <b>${x[0]}</b> starts with <b>${l}</b>.`,"Look at the picture and say its name.",{say:x[0]});
  return {type:"type",q:`🔗 Type the missing first letter:<br>${BIG(x[1])}<br><b style="font-size:26px;letter-spacing:3px">${shown}</b>`,a:[l],why:`${x[1]} <b>${x[0]}</b> starts with <b>${l}</b>.`,hint:"Say the picture's name. What sound comes first?",say:x[0]}};
/* uppercase and lowercase */
const LOWC={a:"eod",b:"dph",c:"eos",d:"bqp",e:"aoc",f:"tlk",g:"qjy",h:"nbk",i:"ljt",j:"igy",k:"hxf",l:"itj",m:"nwu",n:"mhu",o:"ace",p:"qbd",q:"pgd",r:"nhf",s:"zcx",t:"fli",u:"nvw",v:"uwy",w:"mvu",x:"kzy",y:"vgj",z:"sxn"};
const UPC={A:"HVR",B:"DPR",C:"GOQ",D:"BOP",E:"FBL",F:"EPT",G:"COQ",H:"NKA",I:"LTJ",J:"ILU",K:"XHR",L:"ITJ",M:"NWH",N:"MHZ",O:"QCD",P:"RBF",Q:"OGC",R:"PBK",S:"ZCG",T:"ILF",U:"VOJ",V:"WUY",W:"MVN",X:"KYZ",Y:"VXT",Z:"NSX"};
const SHAPE="abdefghijmnqrty"; // the big and small letters look different
const phCase=()=>{const l=R(Object.keys(LOWC)),L=l.toUpperCase(),k=Math.floor(Math.random()*4);
  if(k===0)return mcQ(`🔠 Find the small (lowercase) letter that goes with ${BIG(L)}`,l,SAMPLE(LOWC[l].split(""),2),`<b>${L}</b> and <b>${l}</b> are partners: ${L} ${l}.`,"Big letter, small letter: they make the same sound.");
  if(k===1)return mcQ(`🔠 Find the big (uppercase) letter that goes with ${BIG(l)}`,L,SAMPLE(UPC[L].split(""),2),`<b>${l}</b> and <b>${L}</b> are partners: ${L} ${l}.`,"Big letter, small letter: they make the same sound.");
  if(k===2)return mcQ(`🔠 Which pair is a big letter and its small letter?`,`${L} ${l}`,SAMPLE(LOWC[l].split(""),2).map(z=>`${L} ${z}`),`<b>${L} ${l}</b> go together.`,"Look at the small letter. Is it the partner of the big letter?");
  const m=R(SHAPE.split(""));const up=Math.random()<.5;const c=up?m.toUpperCase():m;
  return mcQ(`🔠 Is this a big (uppercase) letter or a small (lowercase) letter?<br>${BIG(c)}`,up?"uppercase (big)":"lowercase (small)",[up?"lowercase (small)":"uppercase (big)"],`<b>${c}</b> is ${up?"the uppercase (big)":"the lowercase (small)"} letter. Its partner is <b>${up?m:m.toUpperCase()}</b>.`,"Big letters are used at the start of a sentence and for names.")};
/* listen and write 3-letter words */
const CVC=G4.sp([["cat","My cat naps on the sofa.","c-a-t: three sounds, three letters."],["dog","The dog wags its tail.","d-o-g"],["sun","The sun is hot today.","s-u-n"],["hat","Dad has a blue hat.","h-a-t"],["pig","The pig is pink.","p-i-g"],["bus","I ride the bus to school.","b-u-s"],["red","My ball is red.","r-e-d"],["ten","I have ten toes.","t-e-n"],["six","I am six years old.","s-i-x"],["cup","Mom fills my cup with milk.","c-u-p"],["map","We look at the map.","m-a-p"],["box","The toys are in a box.","b-o-x"],["leg","I hurt my leg.","l-e-g"],["lip","I bit my lip.","l-i-p"],["hen","The hen sits on her eggs.","h-e-n"],["jam","I like jam on my toast.","j-a-m"],["mop","Dad cleans the floor with a mop.","m-o-p"],["rug","The baby sits on the rug.","r-u-g"],["fan","The fan keeps us cool.","f-a-n"],["wig","The clown has a green wig.","w-i-g"],["net","I catch a bug in my net.","n-e-t"],["mud","My boots are full of mud.","m-u-d"],["hug","I give Grandma a hug.","h-u-g"],["bag","I put my book in my bag.","b-a-g"],["top","We climb to the top of the hill.","t-o-p"]]);

/* ================= SIGHT WORDS ================= */
const SWL=["I","a","the","is","my","me","am","see","like","can"];
const SWS=["I can see my dog.","My mom is kind.","I like the sun.","I am six.","The cat can hop.","I see a big bus.","My dad likes me.","I am in the bath.","Can you see me?","I like my teddy.","The ball is red.","My sister can swim.","I see the moon.","Grandma hugs me.","I am happy.","A dog is in the house.","I can sing a song.","My nose is small.","I like to paint.","The door is open.","Mom can see me.","I am a big sister.","My hair is long.","I see a red kite."];
const swFind=()=>{const s=R(SWS);const toks=uniq(s.replace(/[.!?]/g,"").split(" ").map(w=>w==="I"?w:w.toLowerCase()));const targets=toks.filter(w=>SWL.includes(w));const w=R(targets);
  return mcQ(`🔍 Find the word <b style="font-size:24px">${w}</b> in this sentence:<br><b style="font-size:22px">${s}</b>`,w,SAMPLE(toks.filter(x=>x!==w),2),`<b>${w}</b> is a sight word. Read it fast: <b>${w}</b>!`,"Look at each word. Find the one that looks the same.",{say:s})};
const SWF=[["I ___ six years old.","am",["is","the"]],["My dog ___ big.","is",["am","me"]],["I ___ see the moon.","can",["the","my"]],["Look at ___!","me",["I","the"]],["I ___ the sun.","see",["is","me"]],["I ___ my teddy.","like",["is","a"]],["This is ___ house.","my",["I","am"]],["I see ___ cat.","a",["am","is"]],["___ am happy.","I",["My","The"]],["Mom gives ___ a hug.","me",["I","am"]],["___ sun is hot.","The",["I","Am"]],["The cat ___ on the bed.","is",["am","me"]],["I ___ hop on one foot.","can",["is","the"]],["Can you ___ the bird?","see",["am","is"]],["I ___ to swim.","like",["is","me"]],["I have ___ red ball.","a",["am","I"]],["___ name is Omar.","My",["I","Am"]],["I ___ seven.","am",["is","can"]],["It ___ my bed.","is",["am","me"]],["Please help ___.","me",["I","my"]],["I can ___ you!","see",["am","is"]],["Where is ___ dog?","my",["am","I"]],["I ___ a girl.","am",["is","can"]],["Grandpa ___ sing.","can",["am","is"]],["I see ___ moon.","the",["am","I"]]];
const swFill=()=>{const x=R(SWF);return mcQ(`✏️ Which word fills the gap?<br><b style="font-size:22px">${x[0]}</b>`,x[1],x[2],`<b>${x[0].replace("___",x[1])}</b>`,"Read the sentence with each word. Which one sounds right?",{say:x[0]})};
const swListen=()=>{const w=R(SWL);return mcQ(`🎧 Listen. Which word do you hear?`,w,SAMPLE(SWL.filter(x=>x.toLowerCase()!==w.toLowerCase()),2),`You heard <b>${w}</b>.`,"Tap 🔊 Listen again, then look at each word.",{say:w,autoSay:true})};
const swQ=G4.MIX(swFind,swFill,swListen);

/* ================= GRAMMAR: CAPITAL I, CAPITAL NAMES, FULL STOP ================= */
const CAPI=["I like my dog.","Mom and I sing.","I can hop.","I am six.","Dad and I run.","I see the sun.","I have two hands.","I love my grandma.","My sister and I read.","Today I can swim.","I brush my teeth.","I am happy.","I like to paint.","I hug my brother.","Grandpa and I walk.","I am seven.","At night I read a book.","I wash my hands.","I play with my ball.","Now I can dance.","Mom and I bake a cake.","I see my house.","After school I play.","I can kick a ball."];
const lowI=s=>s.replace(/\bI\b/g,"i");
const capIQ=()=>{const s=R(CAPI);
  if(Math.random()<.5){const bad=lowI(s);const bad2=/^I\b/.test(s)?s.replace(/\.$/,""):bad.charAt(0).toLowerCase()+bad.slice(1);
    return mcQ(`🅸 Which sentence is correct?`,s,[bad,bad2],`<b>${s}</b> The word <b>I</b> is always a capital letter.`,"Find the word I in each sentence. Is it big?",{say:s})}
  const b=lowI(s);const ws=b.replace(/\.$/,"").split(" ");const others=uniq(ws.filter((w,i)=>i>0&&w!=="i"&&/^[a-z]/.test(w)));
  return mcQ(`🅸 Fix the capital I. Which word should be a capital letter?<br><b style="font-size:22px">${b}</b>`,"i",SAMPLE(others,2),`<b>${s}</b> The word <b>I</b> is always a capital letter.`,"When you write about yourself, the word I is always big.",{say:s})};
const NAMES=[["My friend Sam is six.","Sam"],["I play with Aiko.","Aiko"],["This is my dog Max.","Max"],["We go to see Ravi.","Ravi"],["My sister Mia can swim.","Mia"],["Here comes Omar.","Omar"],["I like to read with Lena.","Lena"],["Dad hugs baby Noah.","Noah"],["The cat is called Tom.","Tom"],["We sing with Diego.","Diego"],["Grandma made a cake for Priya.","Priya"],["My brother Kofi can run fast.","Kofi"],["I wave to Yuki.","Yuki"],["The big dog is Rex.","Rex"],["My friend Amani is kind.","Amani"],["Today we have a party for Zoe.","Zoe"],["I sit next to Hana.","Hana"],["The baby is called Ben.","Ben"],["We play ball with Leo.","Leo"],["My best friend is Malik.","Malik"],["Mom calls Fatima for lunch.","Fatima"],["I give a hug to Chen.","Chen"],["My puppy Bella likes to run.","Bella"],["The new girl is Nia.","Nia"]];
const lowN=(s,n)=>s.replace(new RegExp("\\b"+n+"\\b"),n.toLowerCase());
const nameQ=()=>{const x=R(NAMES),s=x[0],n=x[1],k=Math.random();
  if(k<.5){const b=lowN(s,n);const others=uniq(b.replace(/\.$/,"").split(" ").filter((w,i)=>i>0&&w!==n.toLowerCase()&&/^[a-z]/.test(w)));
    return mcQ(`📛 Which name needs a capital letter?<br><b style="font-size:22px">${b}</b>`,n.toLowerCase(),SAMPLE(others,2),`<b>${s}</b> <b>${n}</b> is a name, so it starts with a capital letter.`,"Find the word that is a name of a person or a pet.",{say:s})}
  const ws=s.replace(/\.$/,"").split(" ");const idx=ws.map((w,i)=>i).filter(i=>i>0&&/^[a-z]/.test(ws[i]));const j=R(idx);const odd=ws.map((w,i)=>i===j?cap(w):w).join(" ")+".";
  return mcQ(`📛 Which sentence is written correctly?`,s,[lowN(s,n),odd],`<b>${s}</b> Names start with a capital letter. Other words in the middle do not.`,"Look for the name. Does it have a capital? Do other words have capitals they don't need?",{say:s})};
const STOP=["I like my house.","The sun is up.","My dog can run.","Mom has a red hat.","We eat lunch.","The baby is asleep.","I see a bird.","Dad reads a book.","My cat is black.","We go to the park.","The ball is big.","I can count to ten.","My sister likes to paint.","The door is open.","I brush my hair.","We play a game.","The bath is warm.","I have a new puzzle.","My brother can sing.","It is time for bed.","The fish can swim.","I hug my teddy.","We wave hello.","Grandpa has a drum."];
const stopQ=()=>{const s=R(STOP);const k=Math.random();
  if(k<.6){const has=Math.random()<.5;const shown=has?s:s.replace(/\.$/,"");
    return mcQ(`⏺️ Does this sentence end with a full stop?<br><b style="font-size:24px">${shown}</b>`,has?"Yes ✅":"No ❌",[has?"No ❌":"Yes ✅"],has?`Yes! <b>${s}</b> has a full stop (.) at the end.`:`No. It needs a full stop at the end: <b>${s}</b>`,"Look at the very end of the sentence. Is there a little dot?",{say:s})}
  const o=SAMPLE(STOP.filter(x=>x!==s),2).map(x=>x.replace(/\.$/,""));
  return mcQ(`⏺️ Which sentence ends with a full stop?`,s,o,`<b>${s}</b> A telling sentence ends with a full stop (.).`,"Look for the little dot at the end.",{say:s})};
/* choose the correct sentence: capital at the start, capital I and names, full stop */
const RIGHT=CAPI.concat(NAMES.map(x=>x[0]));
const rightQ=()=>{const s=R(RIGHT);const n=(NAMES.find(x=>x[0]===s)||[])[1];const errs=[s.charAt(0).toLowerCase()+s.slice(1),s.replace(/\.$/,"")];
  if(n)errs.push(lowN(s,n));if(/ I\b/.test(s))errs.push(s.replace(/ I\b/g," i"));
  return mcQ(`✅ Choose the correct sentence.`,s,SAMPLE(uniq(errs).filter(x=>x!==s),2),`<b>${s}</b> It has a capital letter at the start, capitals for I and names, and a full stop at the end.`,"Check three things: the first letter, I and names, and the dot at the end.",{say:s})};

/* ================= READING: READ AND MATCH THE PICTURE ================= */
const PICS=[["I can clap my hands.","👏",["🦶","👃"]],["I smell with my nose.","👃",["👂","🦵"]],["I hear a bell.","🔔",["🎈","🧦"]],["I kick the ball.","⚽",["🎂","🛏️"]],["I brush my teeth.","🪥",["🧹","🎨"]],["I sleep in my bed.","🛏️",["🚿","🚗"]],["I take a shower.","🚿",["🛋️","⚽"]],["I hug my teddy.","🧸",["🐟","🍕"]],["I play the drum.","🥁",["🎻","🔑"]],["I sweep with a broom.","🧹",["🪥","🔑"]],["I look in the mirror.","🪞",["🚪","🥁"]],["I open the lock with a key.","🔑",["🧦","🍎"]],["I paint a picture.","🎨",["🥁","🛁"]],["I swim in the pool.","🏊",["🚲","🛏️"]],["I sing a song.","🎤",["🧹","🦷"]],["I dance to the music.","💃",["😴","🛁"]],["My tooth is loose.","🦷",["👂","🦶"]],["Grandma has white hair.","👵",["👶","👦"]],["My baby sister is asleep.","😴",["🏃","💃"]],["I wave hello.","👋",["🦶","🛏️"]],["I wash in the bath.","🛁",["🚗","⚽"]],["I put on my sock.","🧦",["🎩","🧤"]],["I wear a top hat.","🎩",["🧦","👟"]],["I do a puzzle.","🧩",["🎤","🍌"]],["I eat an apple.","🍎",["🥁","🔑"]],["I sit on the sofa.","🛋️",["🚿","🪁"]],["I run in the park.","🏃",["🛌","🛁"]],["I fly my kite.","🪁",["🛋️","🦷"]],["I read a book.","📖",["🥁","🧹"]]];
const picQ=()=>{const x=R(PICS);return mcQ(`📖 Read the sentence. Which picture matches?<br><b style="font-size:24px">${x[0]}</b>`,x[1],x[2],`<b>${x[0]}</b> ${x[1]}`,"Read each word. Then look for the picture that shows it.",{say:x[0]})};

/* ================= THINKING: ME AND MY WORLD ================= */
const ME=[
 {q:"👃 Which body part do you use to smell?",o:["👃 nose","👂 ear","🦶 foot"],a:"👃 nose",why:"You smell with your nose."},
 {q:"🐦 You hear a bird sing. Which body part helps you?",o:["👂 ear","👃 nose","✋ hand"],a:"👂 ear",why:"You hear with your ears."},
 {q:"🍬 You ate a sweet treat. What should you do later?",o:["Brush my teeth","Eat more sweets","Hide my teeth"],a:"Brush my teeth",why:"Brushing keeps your teeth clean and strong."},
 {q:"😢 Your friend falls down. What can you do?",o:["Help and be kind","Laugh at them","Walk away"],a:"Help and be kind",why:"Kind friends help each other."},
 {q:"❄️ It is cold and snowy. What should you wear?",o:["A warm coat 🧥","Swim shorts 🩳","No shoes"],a:"A warm coat 🧥",why:"A warm coat keeps your body warm."},
 {q:"🧼 Your hands are dirty. You want a snack. What do you do first?",o:["Wash my hands","Eat the snack","Wipe them on my shirt"],a:"Wash my hands",why:"Wash before you eat to get germs off."},
 {q:"👋 A new boy says, \"¡Hola!\" What does he mean?",o:["Hello","Goodbye","Thank you"],a:"Hello",why:"Hola means hello in Spanish."},
 {q:"🎂 It is Mia's birthday. What can you say?",o:["Happy birthday!","Good night!","Go away!"],a:"Happy birthday!",why:"We say happy birthday to make a friend feel special."},
 {q:"🥱 You feel very sleepy. What does your body need?",o:["Sleep","A drum","More games"],a:"Sleep",why:"Sleep helps your body rest and grow."},
 {q:"🧸 Your little brother wants your toy. What is a kind thing to do?",o:["Take turns","Hide the toy","Shout at him"],a:"Take turns",why:"Taking turns is fair and kind."},
 {q:"🔥 The stove is hot. What should you do?",o:["Not touch it","Touch it fast","Put my hand on it"],a:"Not touch it",why:"Hot things can burn you. Stay safe!"},
 {q:"🚸 You want to cross the street. Who should be with you?",o:["A grown-up","My teddy","Nobody"],a:"A grown-up",why:"Always cross the street with a grown-up."},
 {q:"📛 A new girl comes to your class. What can you ask her?",o:["What is your name?","Why are you here?","Can you go away?"],a:"What is your name?",why:"Asking a name is a friendly way to say hello."},
 {q:"📖 Which body part do you use to read a book?",o:["👀 eyes","👃 nose","👂 ears"],a:"👀 eyes",why:"You read with your eyes."},
 {q:"🐰 You want to hop like a bunny. What do you use?",o:["🦶 feet","👂 ears","👄 mouth"],a:"🦶 feet",why:"You hop on your feet."},
 {q:"🍎 Which snack helps your body grow strong?",o:["An apple 🍎","Only candy 🍬","Only soda 🥤"],a:"An apple 🍎",why:"Fruit is good food for your body."},
 {q:"🙏 Arjun puts his hands together and says, \"Namaste.\" What is he doing?",o:["Saying hello","Eating lunch","Going to sleep"],a:"Saying hello",why:"Namaste is a way to greet people in India."},
 {q:"🌍 What is the same for children all over the world?",o:["They all have feelings","They all speak French","They all live in Japan"],a:"They all have feelings",why:"Children everywhere feel happy, sad and more."},
 {q:"🤧 You need to sneeze. What should you do?",o:["Sneeze into my elbow","Sneeze on a friend","Sneeze on the food"],a:"Sneeze into my elbow",why:"Sneezing into your elbow keeps germs away from others."},
 {q:"🛏️ Which room do you usually sleep in?",o:["The bedroom","The bathroom","The kitchen"],a:"The bedroom",why:"Most people sleep in a bedroom."},
 {q:"🧮 You have 2 feet. Each foot has 5 toes. How many toes in all?",o:["10","5","7"],a:"10",why:"5 + 5 = 10 toes."},
 {q:"🧮 Mia has 3 balls. Her dad gives her 1 more. How many balls now?",o:["4","2","3"],a:"4",why:"3 + 1 = 4."},
 {q:"🧮 There are 5 people in my family. 2 go to the shop. How many stay home?",o:["3","7","5"],a:"3",why:"5 − 2 = 3."},
 {q:"🧮 Ravi is 6. His sister is 2 years older. How old is she?",o:["8","4","6"],a:"8",why:"6 + 2 = 8."}
];

/* ================= BANKS FOR STANDARD SKILLS ================= */
const B={
 SP:G4.sp([["hand","I wave my hand.","h-a-n-d: four sounds."],["foot","I hop on one foot.","oo in the middle."],["nose","I smell with my nose.","The e at the end is silent."],["mouth","I open my mouth.","ou says ow, then th."],["hair","My hair is curly.","ai-r says air."],["tooth","My tooth is loose.","oo in the middle, th at the end."],["sister","My sister is four.","sis-ter: two parts."],["brother","My brother is tall.","bro-ther: th in the middle."],["grandma","My grandma sings.","grand + ma."],["grandpa","My grandpa reads to me.","grand + pa."],["smile","I smile at you.","The e at the end is silent."],["house","My house is blue.","ou says ow. Silent e at the end."],["door","Shut the door, please.","oo here says or."],["window","I look out the window.","win-dow: two parts."],["sofa","We sit on the sofa.","so-fa: two parts."],["bath","I take a bath.","b-a-th: th at the end."],["mirror","I look in the mirror.","mir-ror: two r's in the middle."],["ball","I kick the ball.","Two l's at the end."],["puzzle","I like my puzzle.","Two z's in the middle."],["teddy","I hug my teddy.","Two d's, then y."]]),
 CHOOSE:null,
 DETAIL:[
  ["My Name","My name is Kenji. I am six. I live in Vancouver with my mom and dad.",[["What is the boy's name?","Kenji",["Ravi","Omar"]],["How old is Kenji?","Six",["Two","Ten"]],["Who does Kenji live with?","His mom and dad",["His teacher","His dog only"]]]],
  ["Grandma's Visit","Grandma comes on Sunday. She brings a red kite. We fly it in the park.",[["When does Grandma come?","Sunday",["Monday","Friday"]],["What does Grandma bring?","A red kite",["A blue ball","A cake"]],["Where do they fly the kite?","In the park",["In the bath","At school"]]]],
  ["My Teeth","I have a loose tooth. It is at the front. I wiggle it with my tongue.",[["What kind of tooth is it?","A loose tooth",["A gold tooth","A big tooth"]],["Where is the tooth?","At the front",["At the back","On my nose"]],["What does the child wiggle it with?","The tongue",["A spoon","A finger"]]]],
  ["Bath Time","At night, I take a bath. I play with a toy duck. Then Dad dries my hair.",[["When does the child take a bath?","At night",["At lunch","In the morning"]],["What toy is in the bath?","A toy duck",["A toy car","A doll"]],["Who dries the child's hair?","Dad",["Mom","Grandpa"]]]],
  ["Hello from Brazil","Lucas lives in Brazil. He speaks Portuguese. He says \"Olá\" to say hello.",[["Where does Lucas live?","Brazil",["Japan","Canada"]],["What language does Lucas speak?","Portuguese",["French","Swahili"]],["How does Lucas say hello?","Olá",["Jambo","Namaste"]]]],
  ["My Room","My room has a bed and a lamp. My teddy sits on the bed. I like my room.",[["What is in the room?","A bed and a lamp",["A car and a bus","A sofa and a tree"]],["Where does the teddy sit?","On the bed",["On the lamp","On the floor"]],["How does the child feel about the room?","They like it",["They are scared","They do not care"]]]],
  ["Playing Music","Mia has a drum. Her brother has a guitar. They play a song for Mom.",[["What does Mia have?","A drum",["A guitar","A violin"]],["Who has a guitar?","Mia's brother",["Mom","Mia"]],["Who do they play for?","Mom",["Grandpa","The teacher"]]]],
  ["Lost Shoe","Sam can not find his shoe. He looks under the sofa. The shoe is there!",[["What is lost?","Sam's shoe",["Sam's hat","Sam's dog"]],["Where does Sam look?","Under the sofa",["In the bath","On the roof"]],["Is the shoe under the sofa?","Yes, it is there",["No, it is lost","No, it is at school"]]]],
  ["Hello from China","Mei lives in China. She says \"Nǐ hǎo\" to say hello. She likes to paint.",[["Where does Mei live?","China",["Mexico","Kenya"]],["How does Mei say hello?","Nǐ hǎo",["Hola","Bonjour"]],["What does Mei like to do?","Paint",["Swim","Sing"]]]],
  ["Snow Day","It is a snow day in Winnipeg. Noah puts on his hat and boots. He makes a snowman.",[["What kind of day is it?","A snow day",["A hot day","A rainy day"]],["What does Noah put on?","His hat and boots",["His swimsuit","His sandals"]],["What does Noah make?","A snowman",["A cake","A sandcastle"]]]],
  ["My Pet","I have a cat. Her name is Luna. She sleeps on my bed.",[["What pet does the child have?","A cat",["A dog","A fish"]],["What is the cat's name?","Luna",["Max","Rex"]],["Where does Luna sleep?","On the bed",["In the bath","On the door"]]]],
  ["Dance Class","Amara goes to dance class. She dances with her friend Zoe. They spin and clap.",[["Where does Amara go?","Dance class",["Swim class","The shop"]],["Who dances with Amara?","Zoe",["Omar","Grandma"]],["What do they do?","Spin and clap",["Sleep and eat","Read and write"]]]]
 ],
 MAIN:[
  ["I have two eyes. I have one nose. I have one mouth.","Parts of my face",["My nose","My house"]],
  ["My mom reads to me. My dad sings to me. My sister plays with me.","My family does things with me",["My dad sings","My pet cat"]],
  ["My house has a red door. It has big windows. It has a blue roof.","What my house looks like",["A red door","A trip to the park"]],
  ["I like to sing. I like to dance. I like to paint.","Things I like to do",["I like to sing","My big bed"]],
  ["Yuki says Konnichiwa. Diego says Hola. Lena says Bonjour.","Ways to say hello",["Diego says Hola","How to wash hands"]],
  ["Wet your hands. Rub on soap. Rinse and dry.","How to wash your hands",["Dry your hands","How to bake a cake"]],
  ["I can hop. I can skip. I can jump.","Things I can do with my body",["I can skip","Things in my bag"]],
  ["Grandma has grey hair. She wears glasses. She has a big smile.","What Grandma looks like",["Grandma's glasses","My new shoes"]],
  ["Eat good food. Drink water. Sleep at night.","How to keep my body healthy",["Drink water","How to fly a kite"]],
  ["My teddy is soft. My teddy is brown. I hug my teddy.","My teddy",["My soft bed","My brown dog"]],
  ["I see with my eyes. I hear with my ears. I smell with my nose.","How my body helps me know things",["I hear with my ears","My favourite food"]],
  ["We have a big sofa. We have a small table. We have a soft rug.","Things in our living room",["A soft rug","Things at the beach"]],
  ["Omar is six. Omar lives in Calgary. Omar likes trains.","All about Omar",["Omar likes trains","All about Lena"]],
  ["I wake up. I eat breakfast. I go to school.","My morning",["I eat breakfast","My bedtime"]],
  ["My baby brother can smile. He can clap. He can wave bye-bye.","What my baby brother can do",["He can clap","What my cat eats"]],
  ["I brush my teeth. I take a bath. I go to bed.","My bedtime",["I take a bath","My lunch"]],
  ["Ravi lost his teddy. Asha helped him look. They found it in the toy box.","Ravi finds his lost teddy",["The toy box","Ravi goes to school"]],
  ["Some people bow. Some people wave. Some people shake hands.","Ways people say hello",["Some people bow","Ways to swim"]],
  ["I have a drum. I have a ball. I have a puzzle.","My toys",["My drum","My family"]],
  ["Mom hugs me. Dad kisses me. Grandpa holds my hand.","My family shows me love",["Dad kisses me","My new house"]],
  ["My hands can clap. My feet can run. My mouth can sing.","Things my body can do",["My feet can run","Things in the sky"]],
  ["Lena has red hair. Amani has black hair. Omar has brown hair.","Children have different hair",["Lena has red hair","Children have pets"]],
  ["I can tie my shoes. I can zip my coat. I can put on my hat.","I can get dressed by myself",["I can zip my coat","I can bake bread"]],
  ["Maya wakes up at 7. She goes to school at 8. She goes to bed at 8 at night.","Maya's day",["Maya's bed","Maya's dog"]]
 ],
 FACTS:["People have two eyes.","You hear with your ears.","Ravi lives in Toronto.","Fish can swim.","Snow is cold.","The sun is in the sky.","A week has seven days.","Hola means hello in Spanish.","Teeth help you chew food.","Japan is a country.","Babies grow into children.","You smell with your nose.","A cat has four legs.","Dogs can bark.","Ice is frozen water.","Your heart is in your chest.","Montreal is in Canada.","A bed is for sleeping.","Soap helps wash off germs.","Birds have feathers.","Grandma is your mom's or dad's mother.","Kenya is in Africa.","People need water to live.","A key can open a lock.","Most people have ten toes."],
 OPIN:["Dogs are the best pets.","Pink is the prettiest colour.","Baths are more fun than showers.","Drums are too loud.","Puzzles are boring.","Pizza is the best food.","Summer is better than winter.","My teddy is the cutest toy.","Singing is more fun than dancing.","Long hair looks nicer than short hair.","Big houses are better than small houses.","Cats are funnier than dogs.","Painting is the best thing to do.","Rainy days are sad.","Bedtime is too early.","Green is a nicer colour than blue.","Swimming is the most fun sport.","Little sisters are the best.","Apples taste better than bananas.","Sofas are comfier than beds.","Morning is the best time of day.","Snow is more fun than sand.","Grandma's cake is the yummiest.","Red kites are the nicest kites.","Saturday is the best day."],
 SEQ:[["Wake up","Get dressed","Eat breakfast","Go to school"],["Wet your hands","Put on soap","Rub and count to 20","Dry your hands"],["Put toothpaste on the brush","Brush your teeth","Spit","Rinse your mouth"],["Fill the bath","Get in the bath","Wash with soap","Dry off with a towel"],["Put on pyjamas","Brush your teeth","Read a story","Go to sleep"],["Ravi loses Ted","Ravi feels sad","Asha helps him look","They find Ted"],["Get the paper","Paint a picture","Let it dry","Give it to Grandma"],["Baby","Child","Teenager","Grown-up"],["Put on socks","Put on shoes","Tie the laces","Go outside"],["Open the box","Take out the pieces","Fit the pieces together","See the whole puzzle picture"],["Knock on the door","Grandpa opens it","Say hello","Give Grandpa a hug"],["Sing the first line","Sing the middle","Sing the last line","Take a bow"]],
 CE:[["Ravi lost his teddy, so he was sad.","Ravi lost his teddy","he was sad"],["Asha found Ted, so Ravi was happy.","Asha found Ted","Ravi was happy"],["It was cold, so I put on my hat.","it was cold","I put on my hat"],["I ate lots of sweets, so I brushed my teeth.","I ate lots of sweets","I brushed my teeth"],["The ice cream fell, so Sam cried.","the ice cream fell","Sam cried"],["My hands were dirty, so I washed them.","my hands were dirty","I washed them"],["I was sleepy, so I went to bed.","I was sleepy","I went to bed"],["It was Mia's birthday, so we sang a song.","it was Mia's birthday","we sang a song"],["The music played, so we danced.","the music played","we danced"],["I fell in the mud, so I took a bath.","I fell in the mud","I took a bath"],["My tooth fell out, so I smiled a big gap smile.","my tooth fell out","I smiled a big gap smile"],["The door was locked, so Mom used her key.","the door was locked","Mom used her key"],["It began to rain, so we ran inside.","it began to rain","we ran inside"],["I was hungry, so I ate an apple.","I was hungry","I ate an apple"],["My brother was sad, so I gave him a hug.","my brother was sad","I gave him a hug"],["The floor was dusty, so Grandpa got the broom.","the floor was dusty","Grandpa got the broom"],["I practised every day, so I can swim now.","I practised every day","I can swim now"],["The sun was hot, so we sat in the shade.","the sun was hot","we sat in the shade"],["The puzzle had a lost piece, so we looked under the sofa.","the puzzle had a lost piece","we looked under the sofa"],["A new girl came to class, so we said hello.","a new girl came to class","we said hello"]],
 CMP:[
  ["Mia has a dog. Sam has a dog too. Mia's dog is big. Sam's dog is small.","Both have a dog","Mia's dog is big, Sam's is small",["Both have a cat","Both dogs are small"]],
  ["Yuki and Diego both say hello. Yuki bows. Diego waves.","Both say hello","Yuki bows, but Diego waves",["Both say goodbye","Yuki waves"]],
  ["A bath and a shower both use water. You sit in a bath. You stand in a shower.","Both use water","You sit in a bath, but stand in a shower",["Both use sand","You sit in a shower"]],
  ["My eyes and my ears both help me. Eyes help me see. Ears help me hear.","Both help me","Eyes see, but ears hear",["Both help me smell","Ears help me see"]],
  ["Grandma and Grandpa both love me. Grandma sings to me. Grandpa reads to me.","Both love me","Grandma sings, but Grandpa reads",["Both are babies","Grandpa sings"]],
  ["A teddy and a doll are both toys. A teddy is a bear. A doll looks like a person.","Both are toys","A teddy is a bear, a doll is like a person",["Both are bears","Both are food"]],
  ["Hands and feet are both body parts. Hands can clap. Feet can kick.","Both are body parts","Hands clap, but feet kick",["Both are toys","Feet can clap"]],
  ["Lena and Omar are both six. Lena lives in Montreal. Omar lives in Calgary.","Both are six","Lena lives in Montreal, Omar in Calgary",["Both are ten","Both live in Calgary"]],
  ["A drum and a guitar both make music. You hit a drum. You strum a guitar.","Both make music","You hit a drum, but strum a guitar",["Both are food","You hit a guitar"]],
  ["My sister and my brother both like to swim. My sister likes to paint. My brother likes to run.","Both like to swim","She likes to paint, he likes to run",["Both like to sleep","Both hate water"]],
  ["A sofa and a bed are both soft. You sit on a sofa. You sleep in a bed.","Both are soft","You sit on a sofa, but sleep in a bed",["Both are hard","You sleep on a door"]],
  ["Summer and winter are both seasons. Summer is hot. Winter is cold.","Both are seasons","Summer is hot, but winter is cold",["Both are cold","Both are food"]]
 ],
 GRP:{"body parts":["hand","nose","ear","knee","elbow"],"people in a family":["mom","dad","sister","brother","grandma"],"toys":["ball","doll","teddy","puzzle","yo-yo"],"things in a home":["bed","sofa","door","window","lamp"],"colours":["red","blue","green","yellow","pink"],"ways to say hello":["bonjour","hola","namaste","jambo","konnichiwa"],"numbers":["one","two","three","four","five"]},
 ANA:[["Hand is to glove as foot is to ___.","sock",["hat","ring"]],["Eye is to see as ear is to ___.","hear",["smell","run"]],["Mom is to dad as sister is to ___.","brother",["grandma","baby"]],["Grandma is to grandpa as girl is to ___.","boy",["mom","doll"]],["Cat is to kitten as dog is to ___.","puppy",["calf","chick"]],["Nose is to smell as tongue is to ___.","taste",["see","hear"]],["Bed is to sleep as chair is to ___.","sit",["swim","fly"]],["Bird is to fly as fish is to ___.","swim",["walk","bark"]],["Hot is to cold as up is to ___.","down",["top","high"]],["Hat is to head as shoe is to ___.","foot",["hand","nose"]],["Day is to sun as night is to ___.","moon",["cake","bus"]],["Book is to read as song is to ___.","sing",["eat","sleep"]],["Toothbrush is to teeth as comb is to ___.","hair",["feet","ears"]],["Cup is to drink as spoon is to ___.","eat",["sleep","hop"]],["Crayon is to draw as broom is to ___.","sweep",["sing","read"]],["Morning is to breakfast as night is to ___.","dinner",["lunch","school"]],["Snow is to cold as sun is to ___.","hot",["wet","icy"]],["Baby is to small as grown-up is to ___.","big",["tiny","new"]],["Kitchen is to cook as bedroom is to ___.","sleep",["swim","bake"]],["Ear is to earring as finger is to ___.","ring",["sock","hat"]]],
 SENT:["I play with Sam.","Mia and I sing.","My name is Omar.","I see Lena.","Ravi has a teddy.","Yuki lives in Japan.","Diego can swim.","I like Grandma Rosa.","Asha and I read.","My dog is Max.","I hug Kofi.","Zoe has a red hat.","Leo and I run.","I live in Toronto.","Hana can paint.","Amani lives in Kenya.","I wave to Ben.","My cat is Luna.","Noah and I dance.","Priya can hop."],
 ORDER:["I like my dog.","My cat is black.","The sun is hot.","I can hop.","Mom hugs me.","I see a bird.","My hair is long.","We play ball.","Dad can sing.","I wash my hands.","The baby is sleeping.","I have two eyes.","Grandma bakes a cake.","My nose can smell.","I brush my teeth.","The ball is red.","We sit on the sofa.","My brother can swim.","I open the door.","Grandpa reads to me."],
 WP:[
  {q:"Write a sentence about you. Use the word <b>I</b>.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\bI\\b","Uses the word I"]],model:"I am six years old."},
  {q:"Write a sentence that tells your name.",checks:[CHK.cap,CHK.end,CHK.w3,["\\b[Nn]ame\\b","Uses the word name"]],model:"My name is Ana."},
  {q:"Write a sentence about your pet or a pet you would like.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I would like a little dog."},
  {q:"Write a sentence about someone in your family.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Mm]om|[Mm]um|[Dd]ad|[Ss]ister|[Bb]rother|[Gg]randma|[Gg]randpa|[Aa]unt|[Uu]ncle|[Bb]aby|[Cc]ousin)\\b","Names a family member"]],model:"My grandma makes yummy soup."},
  {q:"Write a sentence that starts with <b>I like</b>.",checks:[["^\\s*I like\\b","Starts with I like"],CHK.end,CHK.w3],model:"I like to paint pictures."},
  {q:"Write a sentence that starts with <b>I can</b>.",checks:[["^\\s*I can\\b","Starts with I can"],CHK.end,CHK.w3],model:"I can swim in the pool."},
  {q:"Write a sentence that starts with <b>I am</b>.",checks:[["^\\s*I am\\b","Starts with I am"],CHK.end,CHK.w3],model:"I am a good friend."},
  {q:"Write a sentence about your friend. Use your friend's name with a capital letter.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.name],model:"My friend Lucas is funny."},
  {q:"Write a sentence about one part of your body.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Hh]ands?|[Ff]oot|[Ff]eet|[Nn]ose|[Ee]ars?|[Ee]yes?|[Mm]outh|[Hh]air|[Aa]rms?|[Ll]egs?|[Tt]ooth|[Tt]eeth|[Tt]oes?|[Ff]ingers?|[Hh]ead)\\b","Names a body part"]],model:"My hair is black and curly."},
  {q:"Write a sentence about your home.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Hh]ome|[Hh]ouse|[Aa]partment|[Rr]oom|[Bb]ed|[Dd]oor|[Ww]indow|[Ss]ofa|[Kk]itchen)\\b","Tells about your home"]],model:"My house has a green door."},
  {q:"Write a sentence about your favourite toy.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"My favourite toy is my teddy."},
  {q:"Write a sentence about what you do at bedtime.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I read a book in bed."},
  {q:"Write a sentence that uses <b>Mom and I</b> or <b>Dad and I</b>.",checks:[CHK.cap,CHK.end,["\\b(Mom|Mum|Dad) and I\\b","Uses Mom and I or Dad and I"]],model:"Mom and I walk to the park."},
  {q:"Write a sentence about how you say hello.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b([Hh]ello|[Hh]i|[Ww]ave|[Bb]onjour|[Hh]ola|[Ss]mile)\\b","Tells how you say hello"]],model:"I wave and say hello."},
  {q:"Write a sentence about something you see out your window.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b(see|sees|saw)\\b","Uses see"]],model:"I see a big tree."},
  {q:"Write a sentence about what you like to eat.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I like to eat rice and beans."},
  {q:"Write a sentence about a game you play.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I play tag with my brother."},
  {q:"Write a sentence that tells how old you are.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I,["\\b(old|age|\\d+|five|six|seven|eight)\\b","Tells your age"]],model:"I am seven years old."},
  {q:"Write a sentence about a person who helps you. Use their name.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.name],model:"My aunt Rosa helps me read."},
  {q:"Write a sentence about how you feel today.",checks:[CHK.cap,CHK.end,CHK.w3,CHK.I],model:"I feel happy today."}
 ],
 SYN:[["big","large"],["small","little"],["happy","glad"],["sad","unhappy"],["fast","quick"],["mom","mother"],["dad","father"],["shout","yell"],["begin","start"],["close","shut"],["talk","speak"],["tired","sleepy"],["gift","present"],["rock","stone"],["kid","child"],["sick","ill"],["nice","kind"],["road","street"],["sofa","couch"],["angry","mad"]],
 OPP:[["up","down"],["hot","cold"],["day","night"],["happy","sad"],["in","out"],["on","off"],["fast","slow"],["wet","dry"],["tall","short"],["old","new"],["full","empty"],["top","bottom"],["push","pull"],["big","small"],["hard","soft"],["loud","quiet"],["clean","dirty"],["stop","go"],["boy","girl"],["laugh","cry"]],
 COMP:[["sun","flower"],["rain","bow"],["pan","cake"],["tooth","brush"],["hair","cut"],["snow","man"],["bath","tub"],["lady","bug"],["butter","fly"],["fire","place"],["star","fish"],["door","bell"],["eye","brow"],["hand","bag"],["grand","ma"],["play","ground"],["birth","day"],["home","work"],["sand","box"],["jelly","fish"]]
};
B.CHOOSE=G4.ch([["hand","hnad","handd"],["foot","fute","fooot"],["nose","noze","nosse"],["mouth","mowth","mouf"],["hair","hiar","haer"],["tooth","tooht","tueth"],["sister","sistor","sistr"],["brother","bruther","brothr"],["grandma","gramdma","grandmah"],["grandpa","granpah","grandpaa"],["smile","smiel","smyle"],["house","howse","hous"],["door","doar","dorr"],["window","windo","windoe"],["sofa","sofah","soffa"],["bath","bathh","barth"],["mirror","miror","mirrer"],["ball","baul","balll"],["puzzle","puzle","puzzel"],["teddy","tedy","teddey"]],B.SP);

const L={
 start:"Every letter makes a sound. Say a word slowly and listen to the <b>first</b> sound. <i>🐻 bear starts with /b/.</i>",
 first:"Say the word slowly. The first sound tells you the first letter. <i>🐟 fish → /f/ → f</i>",
 match:"Look at the picture and say its name. Which letter makes its first sound? <i>🌙 moon → M m</i>",
 kase:"Each letter has a big (uppercase) and a small (lowercase) shape. <i>B b, G g, R r</i> They make the same sound.",
 cvc:"Say the word slowly, one sound at a time. Write a letter for each sound. <i>c-a-t → cat</i>",
 sight:"Sight words are words we see a lot. Learn to read them fast! <i>I, a, the, is, my, me, am, see, like, can</i>",
 capI:"When you write about yourself, <b>I</b> is always a capital letter. <i>Mom and <b>I</b> sing.</i>",
 name:"Names of people and pets start with a capital letter. <i>My friend <b>S</b>am is six.</i>",
 stop:"A telling sentence ends with a full stop (.). <i>I like my house<b>.</b></i>",
 right:"Check three things: a capital letter at the start, capitals for I and names, and a full stop at the end. <i><b>I</b> play with <b>S</b>am<b>.</b></i>",
 pic:"Read each word in the sentence. Then find the picture that shows it. <i>I kick the ball. → ⚽</i>",
 me:"Think about your body, your family and how to be safe and kind. Choose the best answer."};
u.review=G4.MIX(capIQ,nameQ,stopQ,rightQ,phStart,phFirst,phCase,swQ,F.vocab(u.words));
u.cats=G4.std(u,{sets:["My body","My family","My home","Things I like to do"],B,
 reading:[{id:"r_pic",t:"Read the sentence and match the picture",learn:L.pic,gen:picQ}],
 vocab:[{id:"v_sight",t:"Sight words: I, a, the, is, my, me, am, see, like, can",learn:L.sight,gen:swQ}],
 grammar:[{id:"g_capI",t:"Fix the capital I",learn:L.capI,gen:capIQ},{id:"g_name",t:"Which name needs a capital?",learn:L.name,gen:nameQ},{id:"g_stop",t:"Does it end with a full stop?",learn:L.stop,gen:stopQ},{id:"g_right",t:"Choose the correct sentence",learn:L.right,gen:rightQ},{id:"g_mixed",t:"Mixed review: letters, sight words and sentences",learn:"Use everything you learned in this unit.",gen:u.review}],
 spelling:[{id:"s_start",t:"Which picture starts with this sound?",learn:L.start,gen:phStart},{id:"s_first",t:"What sound does this word start with?",learn:L.first,gen:phFirst},{id:"s_match",t:"Match the letter to a picture",learn:L.match,gen:phMatch},{id:"s_case",t:"Uppercase and lowercase letters",learn:L.kase,gen:phCase},{id:"s_cvc",t:"Listen and write 3-letter words",learn:L.cvc,gen:F.listen(CVC)}],
 thinking:[{id:"t_me",t:"Me and my world: think and choose",learn:L.me,gen:F.bank(ME)}]});
})();
