/* ===================== GRADE 3 · UNIT 3 · HOW PLANTS GROW (original content) ===================== */
(function(){
const f=(q,a,o,why)=>({lv:"find",q,o:[a].concat(o),a:[a],why});
const t=(q,a,o,why)=>({lv:"think",q,o:[a].concat(o),a:[a],why});
UNITS.push({
id:"plants", num:3, emoji:"🌱🌻🍎", title:"How Plants Grow", badge:"🌻 Green Thumb",

stories:[
/* ---------- 1. STORY ---------- */
{title:"Mia's Bean Plant", e:"🌱", kind:"Story", pages:[
 {pic:"🏫🫘", text:"On Monday, Mr. Lee gave every child in Grade 3 a dry bean seed and a paper cup. \"Your job is to grow a bean plant,\" he said. \"Each day, write down what you observe in your plant diary.\" Mia looked at her tiny seed. It was hard, smooth and brown. \"How can a whole plant come out of this?\" she wondered.",
  qs:[f("What did Mr. Lee give each child?","A bean seed and a paper cup",["A flower and a pot","A book and a pencil"],"He gave every child a dry bean seed and a paper cup."),
      t("What does \"observe\" mean here?","Look carefully and notice",["Throw away","Eat quickly"],"Scientists observe: they look carefully and write down what they notice.")]},
 {pic:"🪴💧", text:"At home, Mia filled her cup with soil. She pushed the seed into the soil with her finger, about as deep as her first knuckle. Then she sprinkled water on top until the soil was damp, but not soaking wet. She put the cup on the kitchen windowsill, where the sun shone in every morning.",
  qs:[f("How deep did Mia plant the seed?","About as deep as her first knuckle",["On top of the soil","At the bottom of a deep hole"],"She pushed it in about as deep as her first knuckle."),
      t("Why did Mia put the cup on the windowsill?","So the plant would get sunlight",["So the cat could not reach it","Because it looked pretty"],"The sun shone in every morning. Plants need sunlight to grow.")]},
 {pic:"😟🪴", text:"For five days, nothing happened. Mia checked her cup every morning. \"Maybe my seed is broken,\" she said sadly. Grandmother smiled. \"Seeds are busy underground, where you cannot see. Be patient.\" On the eighth day, Mia shouted, \"It's growing!\" A tiny green shoot was pushing up through the soil.",
  qs:[f("On which day did Mia see the shoot?","The eighth day",["The first day","The fifth day"],"On the eighth day, Mia shouted, \"It's growing!\""),
      t("What did Grandmother mean by \"Seeds are busy underground\"?","The seed was growing roots even though Mia could not see it",["Insects were eating it","The seed was sleeping forever"],"Roots grow first, under the soil, before the shoot comes up.")]},
 {pic:"🌱☀️", text:"The seedling grew quickly. Two round leaves opened at the top, then more leaves appeared. One day, Mia noticed something strange. Her plant was leaning towards the window! She turned the cup around. Two days later, the plant had bent back towards the window again. \"It's following the light!\" Mia laughed.",
  qs:[f("Which way was the plant leaning?","Towards the window",["Towards the door","Towards the floor"],"Her plant was leaning towards the window."),
      t("Why did the plant bend towards the window?","Plants grow towards light",["The wind blew it","It was too heavy"],"Mia discovered that plants grow towards the light they need.")]},
 {pic:"🌸🐝", text:"After four weeks, Mia's plant was taller than her ruler. She tied it gently to a stick so it would not fall over. Then small white flowers opened along the stem. Mia moved the cup outside onto the balcony, and a bee came buzzing from flower to flower. Soon the flowers dried up, and little green pods began to grow in their place.",
  qs:[f("What grew in the place of the flowers?","Little green pods",["Red apples","More leaves"],"Little green pods began to grow in their place."),
      t("Why did Mia tie the plant to a stick?","To hold it up so it would not fall over",["To measure it","To stop the bee"],"The tall stem needed support.")]},
 {pic:"🫘📒", text:"Mia opened one of the pods. Inside were five new bean seeds, just like the one she had planted! She wrote in her diary: \"One seed made a plant, and the plant made many seeds. It is a circle that never ends.\" The next spring, Mia planted her new seeds in Grandmother's garden.",
  qs:[f("How many seeds were inside the pod?","Five",["One","Twenty"],"Inside were five new bean seeds."),
      t("Why did Mia say \"It is a circle that never ends\"?","The plant made new seeds that can grow into new plants",["The pod was round","Her diary had a circle on it"],"Seed → plant → flowers → new seeds → new plants. This is a life cycle.")]}
], turn:{q:"Have you ever grown a plant or helped in a garden? If not, what would you like to grow? Write two sentences.",model:"I would like to grow tomatoes on my balcony. I would water them every evening."}},

/* ---------- 2. STORY ---------- */
{title:"The Seed That Travelled", e:"🌬️", kind:"Story", pages:[
 {pic:"🌼🌬️", text:"I am a dandelion seed. I was born in a fluffy white ball at the top of a tall stem, with hundreds of brothers and sisters. Each of us has a tiny parachute made of soft white hairs. One morning, a girl picked our stem, made a wish and blew. Whoosh! Away we flew!",
  qs:[f("What does each dandelion seed have?","A tiny parachute of soft white hairs",["Wings like a bird","Sharp hooks"],"Each seed has a tiny parachute made of soft white hairs."),
      t("Who is telling this story?","The dandelion seed",["The girl","A bird"],"The story says \"I am a dandelion seed.\" The seed is telling it.")]},
 {pic:"☁️🌳", text:"The wind carried me high over the houses. I floated past a tall oak tree, where a squirrel was burying acorns. \"Why are you hiding those?\" I called. \"To eat in winter,\" said the squirrel. \"But I always forget a few, and they grow into new oak trees!\"",
  qs:[f("What was the squirrel doing?","Burying acorns",["Eating flowers","Building a nest"],"A squirrel was burying acorns."),
      t("How does the squirrel help oak trees?","It forgets some acorns, which grow into new trees",["It waters the trees","It cuts the branches"],"The forgotten acorns grow into new oak trees. Animals help spread seeds.")]},
 {pic:"🐕🌰", text:"Next, I drifted down near a field. A dog ran past with something stuck to its fur. \"What are those?\" I asked. \"Burrs,\" said a burr seed, holding on tightly with its tiny hooks. \"We catch a ride on animals. When the dog scratches, we fall off far away and grow there.\"",
  qs:[f("How does the burr seed hold on to the dog?","With tiny hooks",["With glue","With a parachute"],"It holds on tightly with its tiny hooks."),
      t("What do the dandelion, the acorn and the burr have in common?","They all travel to new places to grow",["They are all fruits we eat","They all grow underwater"],"Each seed has a different way to travel away from its parent plant.")]},
 {pic:"🍒🐦", text:"A robin landed on a branch and ate a bright red berry. \"Birds help seeds travel too,\" she sang. \"I eat the berry, fly away, and drop the seeds far from here.\" Then the wind blew harder, and I was carried over a river. A coconut bobbed below me. \"I can float across the sea to a new island!\" it called.",
  qs:[f("How does the coconut travel?","It floats on water",["A bird carries it","It rolls down hills"],"\"I can float across the sea to a new island!\""),
      t("Why is it good for seeds to travel far from the parent plant?","They get their own space, light and water",["They get lonely","Parent plants are scary"],"If all the seeds landed under the parent plant, they would have to share sunlight, water and space.")]},
 {pic:"🌧️🟫", text:"At last, the wind grew calm, and I landed softly in a crack of dark, damp soil beside a path. Rain fell, and I soaked it up. I felt my coat split open. A tiny root wiggled down into the soil, and a little green shoot reached up towards the sun.",
  qs:[f("Where did the seed land?","In a crack of soil beside a path",["In the river","On the robin's back"],"It landed in a crack of dark, damp soil beside a path."),
      f("What grew first from the seed?","A tiny root",["A yellow flower","A fluffy ball"],"A tiny root wiggled down first, then a shoot reached up.")]},
 {pic:"🌼☀️", text:"Now I am a bright yellow dandelion, smiling at everyone who walks by. Soon my flower will turn into a fluffy white ball, full of seeds with tiny parachutes. And one day, a child will pick me, make a wish and blow. Whoosh! A new journey will begin.",
  qs:[t("What will happen to the dandelion next?","Its flower will become a fluffy ball of new seeds",["It will turn into a tree","It will fly away as a flower"],"The life cycle starts again: flower → seeds → new plants."),
      t("What is this story mostly about?","How seeds travel and grow",["How to make a wish","How dogs play"],"The story shows many ways seeds travel: wind, animals, birds and water.")]}
], turn:{q:"Choose one way that seeds travel (wind, animals, birds or water). Explain it in two sentences.",model:"Some seeds travel on the wind. A dandelion seed has a tiny parachute that helps it float far away."}},

/* ---------- 3. FACT TEXT ---------- */
{title:"The Parts of a Plant", e:"🌿", kind:"Fact text", pages:[
 {pic:"🌳🌻🌵", text:"Plants come in many shapes and sizes, from tiny moss to giant trees. But most plants have the same main parts: <b>roots</b>, a <b>stem</b>, <b>leaves</b> and <b>flowers</b>. Each part has its own job, and all the parts work together to keep the plant alive.",
  qs:[f("What are the four main parts of most plants?","Roots, stem, leaves and flowers",["Eyes, ears, nose and mouth","Bark, sand, rocks and water"],"Roots, a stem, leaves and flowers."),
      t("Why must all the parts work together?","Each part does a different job the plant needs",["They are all the same","Plants have only one part"],"Each part has its own job, and together they keep the plant alive.")]},
 {pic:"🥕🟫", text:"The <b>roots</b> grow under the ground. They hold the plant firmly in the soil so the wind cannot blow it away. Roots also <b>absorb</b> (soak up) water and nutrients from the soil. Some plants, like carrots and radishes, store food in their big roots.",
  qs:[f("What do roots absorb from the soil?","Water and nutrients",["Sunlight","Air and rain"],"Roots absorb water and nutrients from the soil."),
      f("Which vegetable is a root?","A carrot",["A lettuce","An apple"],"Carrots and radishes store food in their big roots.")]},
 {pic:"🌱⬆️", text:"The <b>stem</b> holds the plant up towards the light. It works like a straw. Tiny tubes inside the stem carry water from the roots up to the leaves and flowers. A tree trunk is a very big, hard stem covered in bark.",
  qs:[f("How is a stem like a straw?","Tubes inside carry water up the plant",["It is made of plastic","You can drink from it"],"Tiny tubes inside the stem carry water from the roots to the leaves."),
      f("What is a tree trunk?","A very big, hard stem",["A root","A leaf"],"A tree trunk is a very big, hard stem covered in bark.")]},
 {pic:"🍃☀️", text:"The <b>leaves</b> make food for the plant. They use sunlight, water and air to make sugar, which gives the plant energy. This is called <b>photosynthesis</b>. While they make food, leaves give out <b>oxygen</b>, the gas that people and animals need to breathe.",
  qs:[f("What three things do leaves use to make food?","Sunlight, water and air",["Soil, rocks and sand","Milk, bread and honey"],"Leaves use sunlight, water and air to make sugar."),
      t("Why are plants important for people and animals?","They give out the oxygen we breathe",["They are good for climbing","They make the weather hot"],"Leaves give out oxygen, the gas people and animals need to breathe.")]},
 {pic:"🌸🐝", text:"The <b>flowers</b> make seeds. Many flowers have bright petals and a sweet smell to attract bees, butterflies and birds. These animals drink sweet nectar and carry a yellow dust called <b>pollen</b> from flower to flower. This is called <b>pollination</b>. After a flower is pollinated, it can make seeds.",
  qs:[f("What is the yellow dust in flowers called?","Pollen",["Nectar","Soil"],"A yellow dust called pollen."),
      t("Why do many flowers have bright petals and a sweet smell?","To attract bees, butterflies and birds",["To scare animals away","To keep warm"],"Bright colours and smells attract the animals that carry pollen.")]},
 {pic:"🍎🌰", text:"Many plants grow a <b>fruit</b> around their seeds to protect them. Apples, oranges, tomatoes and peppers are all fruits with seeds inside. When animals eat the fruit, they help spread the seeds. Next time you eat an apple, count its seeds. Each one could grow into a new apple tree!",
  qs:[f("What does a fruit do for the seeds?","It protects them",["It eats them","It hides them underground"],"Many plants grow a fruit around their seeds to protect them."),
      t("A tomato has seeds inside. What does this tell us?","A tomato is a fruit",["A tomato is a root","A tomato is a leaf"],"In science, a fruit is the part of the plant that holds the seeds. So tomatoes are fruits!")]}
], turn:{q:"Which part of a plant do you think is the most important? Write two sentences explaining why.",model:"I think the roots are the most important. Without roots, the plant could not get water."}},

/* ---------- 4. FACT TEXT ---------- */
{title:"The Life Cycle of a Plant", e:"🔄", kind:"Fact text", pages:[
 {pic:"🔄🌱", text:"All living things go through a <b>life cycle</b>. A life cycle is the set of stages a living thing goes through as it grows, makes new living things, and dies. For a flowering plant, the life cycle has five main stages: seed, sprout, young plant, adult plant with flowers, and new seeds.",
  qs:[f("What is a life cycle?","The stages a living thing goes through as it grows and makes new life",["A kind of bicycle","A plant's favourite season"],"A life cycle is the set of stages a living thing goes through."),
      f("How many main stages does this text name?","Five",["Two","Ten"],"Seed, sprout, young plant, adult plant with flowers, and new seeds: five.")]},
 {pic:"🫘💧", text:"<b>Stage 1: Seed.</b> A seed has a baby plant and a store of food inside, all wrapped in a hard coat. A seed can wait for a long time, even years, until it finds the right conditions. Most seeds need water, air and warmth to start growing.",
  qs:[f("What is inside a seed?","A baby plant and a store of food",["Water and sand","Nothing at all"],"A seed has a baby plant and a store of food inside."),
      f("What do most seeds need to start growing?","Water, air and warmth",["Snow and ice","Darkness and salt"],"Most seeds need water, air and warmth.")]},
 {pic:"🌱🟫", text:"<b>Stage 2: Sprout.</b> When a seed soaks up water, its coat splits open. This is called <b>germination</b>. First, a root grows down into the soil. Then a shoot grows up towards the light. The baby plant uses the food stored in the seed until its first leaves open.",
  qs:[f("What grows first when a seed germinates?","A root",["A flower","A fruit"],"First, a root grows down into the soil."),
      t("Why does the baby plant need the food stored in the seed?","It has no leaves yet to make its own food",["It does not like soil","It is too cold"],"Leaves make food. Until the first leaves open, the seed's food store feeds the plant.")]},
 {pic:"🪴🌿", text:"<b>Stage 3: Young plant.</b> The young plant, called a <b>seedling</b>, grows more leaves and longer roots. Now it can make its own food from sunlight. Seedlings are delicate. They need the right amount of water, light and space to grow strong.",
  qs:[f("What is a young plant called?","A seedling",["A pod","A pollen"],"The young plant is called a seedling."),
      f("What does \"delicate\" mean in this text?","Easily hurt or damaged",["Very heavy","Very old"],"Seedlings are delicate: they can be hurt easily.")]},
 {pic:"🌻🐝", text:"<b>Stage 4: Adult plant.</b> The plant grows tall and strong, and it makes flowers. Insects and birds visit the flowers and carry pollen between them. Once a flower is pollinated, its petals fall off and the seeds begin to grow, often inside a fruit.",
  qs:[f("What happens after a flower is pollinated?","The petals fall off and seeds begin to grow",["The plant shrinks","The roots fly away"],"Once a flower is pollinated, its petals fall off and the seeds begin to grow."),
      t("Which stage comes just before seeds are made?","Pollination of the flower",["Germination","The seed coat splitting"],"Flowers must be pollinated before they can make seeds.")]},
 {pic:"🍂🔄", text:"<b>Stage 5: New seeds.</b> The new seeds are carried away by wind, water or animals. Some plants, like sunflowers, live for just one year. Others, like oak trees, can live for hundreds of years and make millions of seeds. When a new seed lands in a good place, the life cycle begins again.",
  qs:[f("Which plant can live for hundreds of years?","An oak tree",["A sunflower","A bean"],"Oak trees can live for hundreds of years."),
      t("Why is it called a CYCLE?","It goes round and round and begins again",["It has wheels","It only happens once"],"A cycle repeats: seed → plant → flower → seed → plant…")]}
], turn:{q:"Draw the life cycle in words. Write the stages of a plant's life cycle in order, using arrows (→) or the words first, next, then and finally.",model:"First there is a seed. Next it sprouts. Then it grows into a seedling. Finally it becomes an adult plant with flowers and new seeds."}},

/* ---------- 5. FABLE ---------- */
{title:"Bella Bunny and the Carrot Seeds (a fable)", e:"🐰", kind:"Fable", pages:[
 {pic:"🐰🐢", text:"In spring, Bella Bunny and Old Tortoise each planted a row of carrot seeds. \"I can't wait to eat my carrots!\" said Bella, bouncing up and down. Old Tortoise slowly patted the soil and watered his row. \"Good things take time,\" he said.",
  qs:[f("What did Bella and Tortoise plant?","Carrot seeds",["Apple trees","Sunflowers"],"They each planted a row of carrot seeds."),
      t("How was Bella different from Tortoise?","Bella was impatient and Tortoise was calm",["Bella was slow and Tortoise was fast","They were exactly the same"],"Bella bounced and could not wait. Tortoise said, \"Good things take time.\"")]},
 {pic:"🐰🕳️", text:"The next morning, Bella dug up one of her seeds. \"Nothing yet!\" she sighed, and pushed it back into the soil. The next day, she dug it up again. And the next day, and the next. Every day, she pulled up her seeds to see if they were growing.",
  qs:[f("What did Bella do every day?","She dug up her seeds to check them",["She watered her seeds","She sang to her seeds"],"Every day, she pulled up her seeds to see if they were growing."),
      t("Is digging up seeds every day a good idea?","No, it hurts the tiny roots",["Yes, it helps them grow faster"],"Digging up the seeds breaks the tiny roots before they can grow.")]},
 {pic:"🐢🌱", text:"Meanwhile, Old Tortoise gave his row a drink of water each evening and pulled out the weeds. Then he left his seeds alone. After two weeks, feathery green leaves popped up all along his row. Bella's row was still bare, brown soil.",
  qs:[f("What did Tortoise do for his seeds?","Watered them and pulled out weeds",["Dug them up","Moved them every day"],"He gave his row water each evening and pulled out the weeds."),
      f("What did Bella's row look like after two weeks?","Bare, brown soil",["Full of carrots","Covered in flowers"],"Bella's row was still bare, brown soil.")]},
 {pic:"😢🥕", text:"\"It isn't fair!\" cried Bella. \"My seeds must be broken.\" Old Tortoise shook his head gently. \"Your seeds were not broken, little one. Each time you dug them up, you broke their tiny roots. A seed needs time and peace to grow.\" Bella's ears drooped. \"May I try again?\" she asked.",
  qs:[f("Why did Bella's seeds not grow?","She broke their roots by digging them up",["The seeds were broken","There was no sun"],"\"Each time you dug them up, you broke their tiny roots.\""),
      t("How did Bella feel when she understood?","Sorry, but ready to try again",["Angry at Tortoise","Happy about her bare row"],"Her ears drooped, but she asked to try again.")]},
 {pic:"🥕🐰🐢", text:"So Bella planted new seeds. This time, she watered them, pulled the weeds and waited, even when it was very hard. By the end of summer, she pulled up a fat orange carrot. It was the sweetest carrot she had ever tasted. <b>Lesson: Good things take time. Be patient.</b>",
  qs:[t("What is the lesson of this fable?","Good things take time, so be patient",["Always dig up your seeds","Tortoises are better than bunnies"],"Bella learned that some things cannot be rushed."),
      t("Why did the carrot taste so sweet to Bella?","She had worked hard and waited for it",["It had sugar on it","Tortoise gave it to her"],"Things we work and wait for often feel extra special.")]}
], turn:{q:"Write about something you had to be patient for. How did you feel when it finally happened?",model:"I had to wait a whole year for my birthday party. When it finally came, I felt so happy and excited."}},

/* ---------- 6. REAL-WORLD TEXT ---------- */
{title:"Real-world reading: A seed packet and a growth chart", e:"📦", kind:"Real-world text", pages:[
 {pic:"🌻📦", text:"Read the back of this seed packet.<div class=\"realdoc\" style=\"text-align:left\"><b>🌻 GIANT SUNFLOWER SEEDS</b><br>☀️ <b>Sunlight:</b> Full sun (6 or more hours a day)<br>📏 <b>Plant:</b> 2 cm deep, 30 cm apart<br>💧 <b>Water:</b> Keep soil damp until sprouts appear<br>🌱 <b>Sprouts in:</b> 7 to 10 days<br>🌼 <b>Flowers in:</b> about 80 days<br>📐 <b>Height:</b> up to 3 metres!<br><br>⚠️ Plant after the last frost, when the soil is warm.</div>",
  qs:[f("How deep should you plant the seeds?","2 cm deep",["30 cm deep","3 metres deep"],"Plant: 2 cm deep, 30 cm apart."),
      f("How many hours of sun do sunflowers need each day?","6 or more",["1 or 2","None"],"Full sun: 6 or more hours a day."),
      f("How long until the seeds sprout?","7 to 10 days",["80 days","One year"],"Sprouts in: 7 to 10 days."),
      t("Why should seeds be planted 30 cm apart?","So each plant has enough space, water and light",["So they look tidy","To make them grow shorter"],"Plants planted too close together must share water, light and space."),
      t("What does \"after the last frost\" mean?","When the cold, icy nights of winter are over",["In the middle of winter","On a rainy day"],"Frost is ice that forms on cold nights. Young plants can be killed by frost.")]},
 {pic:"📏📈", text:"Mia measured her bean plant and wrote the results in this chart.<table class=\"realtbl\"><tr><th>Day</th><th>Height of plant</th><th>What Mia noticed</th></tr><tr><td>Day 3</td><td>0 cm</td><td>Nothing yet</td></tr><tr><td>Day 8</td><td>1 cm</td><td>A tiny shoot!</td></tr><tr><td>Day 12</td><td>5 cm</td><td>Two round leaves</td></tr><tr><td>Day 16</td><td>11 cm</td><td>Leaning to the window</td></tr><tr><td>Day 24</td><td>22 cm</td><td>First flowers</td></tr></table>",
  qs:[f("How tall was the plant on Day 12?","5 cm",["1 cm","11 cm"],"Day 12: 5 cm."),
      f("On which day did Mia see the first flowers?","Day 24",["Day 8","Day 16"],"Day 24: First flowers."),
      t("How much did the plant grow between Day 12 and Day 16?","6 cm",["11 cm","4 cm"],"11 cm − 5 cm = 6 cm."),
      t("Why does Mia write the date AND the height?","So she can see how the plant changes over time",["Because Mr. Lee likes numbers","To fill the page"],"Scientists record results over time so they can see patterns.")]}
], turn:{q:"Write two instructions for looking after a plant. Start each one with an action word, like Water, Put or Check.",model:"Water the plant when the soil feels dry. Put it near a sunny window."}}
],

poems:[
 {title:"Little Seed",
  lines:["Little seed, so small and round,","Sleeping softly underground.","Rain comes down to give a drink,","Sun comes out to help you think.","Push your root and stretch up high,","Reach your green arms to the sky!","Soon you'll bloom, so bright and new,","And make more little seeds like you."],
  qs:[f("Which word rhymes with 'round'?","underground",["seed","small"],"Round and underground end with the same sound: -ound."),
      t("In the poem, what are the seed's \"green arms\"?","Its leaves and stems",["Real arms","Its roots"],"The poet imagines the plant's leaves and stems as arms reaching up. This is called personification."),
      f("What will the seed make at the end?","More little seeds",["A cake","A nest"],"\"And make more little seeds like you.\"")]},
 {title:"The Tree in Four Seasons",
  lines:["In spring, my tree wears blossoms white,","In summer, leaves of green so bright.","In autumn, red and gold come down,","They float and twirl onto the ground.","In winter, branches bare and grey","Wait for the sun to come and play.","Then spring returns, and look! Hooray!","The blossoms bloom again today."],
  qs:[f("What colour are the leaves in summer?","Green",["Red and gold","White"],"\"In summer, leaves of green so bright.\""),
      f("What happens to the tree in winter?","Its branches are bare",["It has white blossoms","It has red leaves"],"\"In winter, branches bare and grey.\""),
      t("Why does the poem end with spring again?","The seasons go round in a cycle",["The poet forgot winter","Trees only grow in spring"],"Spring, summer, autumn, winter… and then spring again. Like a life cycle, seasons repeat.")]}
],

words:[
 {w:"seed",e:"🫘",m:"the small part of a plant that can grow into a new plant",ex:"Mia planted a bean seed in a cup.",fill:"A tiny ___ can grow into a giant tree."},
 {w:"roots",e:"🥕",m:"the parts of a plant that grow under the ground and take in water",ex:"The roots hold the plant in the soil.",fill:"The tree's ___ grow deep under the ground."},
 {w:"stem",e:"🌱",m:"the main part of a plant that holds up the leaves and flowers",ex:"Water travels up the stem.",fill:"The flower sits at the top of a long, green ___."},
 {w:"leaf",e:"🍃",m:"a flat, green part of a plant that makes food from sunlight",ex:"A leaf fell from the tree.",fill:"A green ___ uses sunlight to make food."},
 {w:"petal",e:"🌸",m:"one of the coloured parts of a flower",ex:"The rose has soft red petals.",fill:"The daisy has a white ___ all around its middle."},
 {w:"bud",e:"🌷",m:"a small, closed flower or leaf that has not opened yet",ex:"A tiny bud opened into a flower.",fill:"The rose ___ will open into a flower soon."},
 {w:"fruit",e:"🍎",m:"the part of a plant that holds and protects its seeds",ex:"An apple is a fruit with seeds inside.",fill:"An orange is a ___ with seeds inside."},
 {w:"branch",e:"🌳",m:"a part of a tree that grows out from the trunk",ex:"The robin sat on a branch.",fill:"The bird built a nest on a high ___ of the tree."},
 {w:"bark",e:"🪵",m:"the rough, hard outside layer of a tree",ex:"The bark of the old oak tree is rough.",fill:"The tree trunk is covered in rough brown ___."},
 {w:"seedling",e:"🪴",m:"a very young plant that has just grown from a seed",ex:"The seedling has two small leaves.",fill:"The little ___ grew two tiny leaves."},

 {w:"soil",e:"🟫",m:"the top layer of earth where plants grow",ex:"Mia filled her cup with soil.",fill:"Plant the seed in dark, damp ___."},
 {w:"sunlight",e:"☀️",m:"the light that comes from the sun",ex:"Plants need sunlight to make food.",fill:"Put the plant by the window so it gets ___."},
 {w:"nutrients",e:"🧪",m:"things in soil and food that help living things grow",ex:"Roots take nutrients from the soil.",fill:"Good soil is full of ___ that help plants grow."},
 {w:"sprout",e:"🌱",m:"to begin to grow and push out of the soil",ex:"The beans began to sprout after a week.",fill:"The seeds will ___ in about ten days."},
 {w:"germinate",e:"🫘",m:"(of a seed) to start growing",ex:"Seeds need water to germinate.",fill:"A seed needs water and warmth to ___."},
 {w:"harvest",e:"🧺",m:"to pick and gather crops when they are ready",ex:"Farmers harvest the wheat in autumn.",fill:"In autumn, the farmers ___ the apples."},
 {w:"compost",e:"♻️",m:"old plants and food scraps that rot and become rich soil",ex:"We put banana peels in the compost.",fill:"Grandmother puts old leaves and fruit peels in the ___ bin."},
 {w:"gardener",e:"🧑‍🌾",m:"a person who looks after a garden",ex:"The gardener planted roses.",fill:"The ___ waters the flowers every morning."},
 {w:"greenhouse",e:"🏡",m:"a glass building that keeps plants warm",ex:"Tomatoes grow in the warm greenhouse.",fill:"In winter, the plants stay warm in the glass ___."},
 {w:"wilt",e:"🥀",m:"(of a plant) to droop and become weak, often from too little water",ex:"Plants wilt if you forget to water them.",fill:"If you forget to water the flowers, they will ___."},

 {w:"pollen",e:"🌼",m:"yellow dust made by flowers that helps them make seeds",ex:"The bee's legs were covered in pollen.",fill:"Bees carry yellow ___ from flower to flower."},
 {w:"pollinate",e:"🐝",m:"to carry pollen from one flower to another so seeds can grow",ex:"Bees pollinate the apple flowers.",fill:"Bees and butterflies help ___ flowers."},
 {w:"nectar",e:"🍯",m:"a sweet juice inside flowers",ex:"Butterflies drink nectar from flowers.",fill:"The hummingbird drinks sweet ___ from the flower."},
 {w:"absorb",e:"🧽",m:"to soak up",ex:"Roots absorb water from the soil.",fill:"A sponge can ___ a lot of water."},
 {w:"oxygen",e:"🫁",m:"a gas in the air that people and animals need to breathe",ex:"Leaves give out oxygen.",fill:"Trees give out ___, the gas we breathe."},
 {w:"energy",e:"⚡",m:"the power that living things need to move and grow",ex:"Food gives us energy.",fill:"Breakfast gives you ___ for the morning."},
 {w:"scatter",e:"🌬️",m:"to spread things in many different directions",ex:"The wind scatters dandelion seeds.",fill:"The wind will ___ the seeds across the field."},
 {w:"crop",e:"🌾",m:"a plant that farmers grow for food",ex:"Rice is an important crop in India.",fill:"Wheat is a ___ that farmers grow to make flour."},
 {w:"cycle",e:"🔄",m:"a set of events that happen again and again in the same order",ex:"Seed, plant, flower and seed again is a life cycle.",fill:"Spring, summer, autumn and winter are a ___ that repeats."},
 {w:"mature",e:"🌳",m:"fully grown",ex:"A mature oak tree is very tall.",fill:"It takes many years for a tree to become ___."},

 {w:"delicate",e:"🦋",m:"easily broken or hurt; needs gentle care",ex:"The seedling's leaves are delicate.",fill:"Be careful with the ___ flower petals."},
 {w:"sturdy",e:"🪨",m:"strong and not easily broken",ex:"The old oak has a sturdy trunk.",fill:"The ___ table did not wobble at all."},
 {w:"fragrant",e:"🌹",m:"having a sweet, pleasant smell",ex:"The roses are very fragrant.",fill:"The ___ flowers smell lovely."},
 {w:"ripe",e:"🍌",m:"(of fruit) ready to eat",ex:"The yellow banana is ripe.",fill:"The red strawberries are ___ and ready to pick."},
 {w:"lush",e:"🌿",m:"full of thick, healthy green plants",ex:"The rainforest is lush and green.",fill:"After the rain, the garden was green and ___."},
 {w:"sprinkle",e:"💦",m:"to drop small amounts of something, like water",ex:"Sprinkle water gently on the seeds.",fill:"___ a little water on the soil."},
 {w:"measure",e:"📏",m:"to find out the size or amount of something",ex:"Mia used a ruler to measure her plant.",fill:"Use a ruler to ___ how tall the plant is."},
 {w:"observe",e:"🔍",m:"to watch carefully and notice things",ex:"Scientists observe plants as they grow.",fill:"Every day, ___ your plant and write what you see."},
 {w:"patient",e:"⏳",m:"able to wait calmly without getting upset",ex:"Grandmother told Mia to be patient.",fill:"Seeds take time to grow, so be ___."},
 {w:"gradually",e:"🐢",m:"slowly, a little at a time",ex:"The plant grew gradually.",fill:"The sky ___ got darker as the sun went down."}
],

spelling:[
 {w:"plant",s:"Mia has a bean plant."},
 {w:"seed",s:"She planted a seed in the soil.",tip:"Double e: s-ee-d."},
 {w:"root",s:"The root grows down.",tip:"Double o: r-oo-t."},
 {w:"leaf",s:"A leaf fell from the tree.",tip:"'ea' says its name: l-ea-f."},
 {w:"flower",s:"The flower is yellow.",tip:"'ow' as in cow: fl-ow-er."},
 {w:"grow",s:"Plants grow towards the light.",tip:"'ow' as in snow: gr-ow."},
 {w:"water",s:"Plants need water."},
 {w:"soil",s:"Push the seed into the soil.",tip:"'oi' as in coin: s-oi-l."},
 {w:"green",s:"The leaves are green."},
 {w:"garden",s:"Grandmother has a garden."},
 {w:"tree",s:"The tree is very tall."},
 {w:"sunlight",s:"Plants need sunlight.",tip:"sun + light. The 'gh' is silent."},
 {w:"fruit",s:"An apple is a fruit.",tip:"'ui' sounds like 'oo': fr-ui-t."},
 {w:"bloom",s:"The roses bloom in summer."},
 {w:"stem",s:"Water goes up the stem."}
],

facts:[
 {e:"🎋",c:"Some kinds of bamboo can grow almost one metre in a single day.",t:true,x:"True! Some bamboo plants are among the fastest-growing plants on Earth."},
 {e:"🌻",c:"Young sunflowers turn their heads to follow the sun across the sky.",t:true,x:"True! Young sunflowers face east in the morning and turn west during the day."},
 {e:"🪤",c:"Some plants catch and eat insects.",t:true,x:"True! The Venus flytrap snaps its leaves shut when an insect lands inside."},
 {e:"🍅",c:"A tomato is a vegetable, not a fruit.",t:false,x:"Not true! In science, a tomato is a fruit, because it holds the plant's seeds."},
 {e:"🍓",c:"Strawberries have their seeds on the outside.",t:true,x:"True! A strawberry has about 200 tiny seeds on its skin."},
 {e:"🌲",c:"The tallest trees in the world are taller than a 30-storey building.",t:true,x:"True! Coast redwood trees in California can grow more than 110 metres tall."},
 {e:"🟫",c:"All plants need soil to grow.",t:false,x:"Not true! Some plants grow in water, and air plants grow on trees with no soil at all."},
 {e:"🍌",c:"Bananas grow on trees.",t:false,x:"Not true! A banana plant looks like a tree, but it has no wood. It is actually a giant herb."},
 {e:"🌴",c:"A seed about 2,000 years old was once planted, and it grew!",t:true,x:"True! Scientists grew a date palm from a very old seed found in Israel."},
 {e:"🥕",c:"All carrots are orange.",t:false,x:"Not true! Carrots can also be purple, yellow, red or white."},
 {e:"🥜",c:"Peanuts grow under the ground.",t:true,x:"True! After the flower is pollinated, the peanut pods grow down into the soil."},
 {e:"🌵",c:"A cactus's spines are a special kind of leaf.",t:true,x:"True! The thin spines lose less water than flat leaves, and they protect the cactus from animals."}
],

writing:[
 {e:"🌷",t:"Describe a plant using your senses",level:"Step 1 · Sentences",
  prompt:"Choose a plant, flower, fruit or tree you know well. Write at least 4 sentences describing it. What does it look like? How does it feel? Does it have a smell or a taste? Use at least 2 describing words from the word bank.",
  minS:4,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],["^(?![\\s\\S]*\\bi\\b)","I wrote I as a capital letter"]],
  starters:["My plant is a ","It looks ","Its leaves feel ","It smells ","I like it because "],
  model:"My favourite plant is the jasmine bush in our garden. It has small white flowers with soft, delicate petals. The flowers are very fragrant, especially in the evening. Its leaves are dark green and smooth. I like it because it reminds me of my grandmother."},
 {e:"📋",t:"How to plant a seed (instructions)",level:"Step 2 · Instructions",
  prompt:"Write instructions that teach someone how to plant a seed and look after it. Write at least 5 steps. Start each step with a time word (First, Next, Then, After that, Finally) and an action word (Fill, Push, Water, Put, Wait…).",
  minS:5,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop"],
      ["\\bFirst\\b","I used First"],["\\bFinally\\b","I used Finally"],
      ["\\b([Ff]ill|[Pp]ush|[Pp]ut|[Ww]ater|[Pp]lant|[Pp]lace|[Cc]over|[Ww]ait|[Cc]heck|[Ss]prinkle|[Dd]ig|[Mm]easure|[Cc]hoose|[Gg]et|[Kk]eep|[Pp]our|[Oo]bserve)\\b","I used action words (fill, push, water…)"]],
  starters:["You will need: ","First, ","Next, ","Then, ","After that, ","Finally, "],
  model:"You will need a cup, some soil, a bean seed and water.\nFirst, fill the cup with soil.\nNext, push the seed into the soil, about 2 cm deep.\nThen, sprinkle water on the soil until it is damp.\nAfter that, put the cup on a sunny windowsill.\nFinally, observe your seed every day and be patient!"},
 {e:"✨",t:"The magic seed (story)",level:"Step 3 · Story",
  prompt:"Imagine you find a magic seed. You plant it, and something amazing grows! Write a story of at least 7 sentences. What did you find? What happened when you planted it? What grew? How did the story end? Write in the past tense and use time words.",
  minS:7,minWords:2,
  rx:[["^\\s*[A-Z]","I started with a capital letter"],["[.!?]\\s*$","I ended with a full stop (or ? or !)"],
      ["\\b(First|Then|Next|After that|Finally|Later|One day|The next morning|Soon)\\b","I used a time word (One day, Then, Finally…)"],
      ["(\\b(\\w+ed|found|grew|saw|went|said|was|were|had|made|took|ran|came|thought|knew|began|became|gave|flew|told|felt)\\b[\\s\\S]*){3}","I used at least 3 past-tense verbs"]],
  starters:["One day, I found a ","I planted it ","The next morning, ","I could not believe ","Then ","Finally, "],
  model:"One day, I found a shiny blue seed under my bed. I planted it in a pot and watered it before school. The next morning, a giant stem had grown right through my bedroom ceiling! I climbed up the stem, higher and higher. At the top, I found a garden in the clouds with fruit that tasted like ice cream. I picked some ripe fruit for my family. Finally, I climbed down, and we shared a delicious cloud-fruit breakfast together."}
]
});
})();
