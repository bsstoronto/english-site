import os
head=open('src/shell_head.html').read(); tail=open('src/shell_tail.html').read()
def build(out,grade,parts,coming=''):
    js="const GRADE=%d;\n"%grade+"\n".join(open('src/'+p).read() for p in parts if os.path.exists('src/'+p))
    if coming: js=js.replace('const COMING=[];','const COMING=[];\n'+coming,1)
    open(out,'w').write(head+"<script>\n"+js+"\n</script>"+tail)
    print(out,len(head+js+tail))
g3=['lib.js','u1.js','u1texts.js','u1skills.js']+[f for n in range(2,13) for f in ('u%d.js'%n,'u%dskills.js'%n)]+['app.js']
build('index.html',3,g3)
g4=['lib.js','g4lib.js']+['g4u%d.js'%n for n in range(1,13)]+['app.js']
build('grade4.html',4,g4)
g5=['lib.js','g4lib.js']+['g5u%d.js'%n for n in range(1,13)]+['app.js']
build('grade5.html',5,g5)
g6=['lib.js','g4lib.js']+['g6u%d.js'%n for n in range(1,13)]+['app.js']
C6='COMING.push(["🧠💭","Mysteries of the Mind"],["🚀🌊","Exploring Space and the Deep"],["📚🦊","Folktales, Fables and World Literature"],["🤖🔮","Technology and the Future"],["🌐⚖️","Global Citizenship and Justice"],["🐝🌳","Ecosystems Under Pressure"],["🦸📖","Heroes, Villains and Graphic Novels"],["🍜🌍","Food, Culture and Health"],["🎤🗣️","Speeches, Debate and Performance"]);'
build('grade6.html',6,g6)
g7=['lib.js','g4lib.js']+['g7u%d.js'%n for n in range(1,13)]+['app.js']
build('grade7.html',7,g7)
g8=['lib.js','g4lib.js']+['g8u%d.js'%n for n in range(1,13)]+['app.js']
C8='COMING.push(["💹🛒","Economics and Everyday Life"],["🌌🔭","Space Science and Big Questions"],["🌱💪","Resilience and Mental Wellbeing"],["📣✊","Voices of Change: Speeches and Poetry"]);'
build('grade8.html',8,g8)
g1=['lib.js','g4lib.js']+['g1u%d.js'%n for n in range(1,13)]+['app.js']
C1='COMING.push(["🌦️🍂","Weather and Seasons"],["🌱🐞","Plants and Bugs"],["👩‍🚒👨‍⚕️","People Who Help Us"],["🚌🚲","On the Move"],["🐠🐙","Under the Sea"],["😊🤝","Feelings and Friends"],["🌙⭐","Day and Night Sky"],["🏰🐺","Fairy Tales and Fables"]);'
build('grade1.html',1,g1,C1)
g2=['lib.js','g4lib.js']+['g2u%d.js'%n for n in range(1,13)]+['app.js']
C2='COMING.push(["⛅🌡️","Weather Watchers"],["🕰️📜","Long Ago and Today"],["🌱🌻","Plants Grow"],["👷‍♀️🧑‍🍳","Jobs in My Town"],["🍎🏃","Healthy Me"],["🌍📚","Stories from Around the World"],["🛝⚙️","Moving Things"],["🎉🪔","Celebrations"]);'
build('grade2.html',2,g2,C2)
g9=['lib.js','g4lib.js']+['g9u%d.js'%n for n in range(1,13)]+['app.js']
C9='COMING.push(["✍️🎨","Short Fiction: Craft and Voice"],["📜🎼","Poetry: Form and Meaning"],["📱📰","Media in the Digital Age"],["💼🔮","Work and the Future of Jobs"],["🎭⚔️","Tragedy and Choice"],["🚀🤖","Science Fiction and the Future"],["🔍📚","Research and Ethics"],["🗣️📝","Voices: The Personal Essay"]);'
build('grade9.html',9,g9)
g10=['lib.js','g4lib.js']+['g10u%d.js'%n for n in range(1,13)]+['app.js']
C10='COMING.push(["🃏😏","Satire and Humour"],["🌳⚖️","Environmental Justice"],["🎙️🌍","Voices of the 21st Century"]);'
build('grade10.html',10,g10,C10)
